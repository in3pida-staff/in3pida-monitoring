<?php
defined('ABSPATH') || exit;

class IF2_Lang {

    private static ?string $lang = null;

    public static function lang(): string {
        if (self::$lang === null) {
            self::$lang = get_option('if2_lang', 'it');
        }
        return self::$lang;
    }

    public static function reset(): void {
        self::$lang = null;
    }

    public static function t(string $key): string {
        $l = self::lang();
        $strings = self::strings();
        return $strings[$l][$key] ?? $strings['it'][$key] ?? $key;
    }

    public static function ago(int $ts): string {
        $diff = time() - $ts;
        $days = (int) round($diff / 86400);
        $mins = (int) round($diff / 60);
        $hrs  = (int) round($diff / 3600);
        if ($diff < 60)      return self::t('just_now');
        if ($diff < 3600)    return $mins . self::t($mins === 1 ? 'minute_ago' : 'minutes_ago');
        if ($diff < 7200)    return self::t('one_hour_ago');
        if ($diff < 86400)   return $hrs . self::t('hours_ago');
        if ($diff < 172800)  return self::t('one_day_ago');
        if ($diff < 604800)  return $days . self::t('days_ago');
        return date_i18n('d/m/Y', $ts);
    }

    private static function strings(): array {
        return [
            'it' => [
                // Menu
                'menu_main'             => 'in3pidaForm Dashboard',
                'menu_forms'            => 'Form',
                'menu_submissions'      => 'Risposte',
                'menu_stats'            => 'Statistiche',
                'menu_builder'          => 'Builder',
                'menu_settings'         => 'Impostazioni generali',
                'menu_crm'              => 'Integrazioni CRM',
                // Topbar
                'export_all'            => 'Esporta tutto',
                // Forms page
                'forms_title'           => 'Form',
                'search_placeholder'    => 'Cerca',
                'new_form_btn'          => '+ NUOVO MODULO',
                'col_id'                => 'ID',
                'col_name'              => 'NOME',
                'col_created_at'        => 'CREAZIONE',
                'col_last_modified'     => 'MODIFICA',
                'no_forms'              => 'Nessun modulo trovato',
                'stats_module_title'    => 'Statistiche modulo',
                'disable_stats'         => 'Disabilita statistiche',
                'reset_stats'           => '↑ AZZERA DATI STATISTICHE',
                'all_forms'             => 'Tutti i moduli',
                'custom_range'          => 'PERSONALIZZATO',
                'from_date'             => 'Da',
                'to_date'               => 'A',
                'apply_range'           => 'Applica',
                'stat_views'            => 'visualizzazioni',
                'stat_responses'        => 'risposte',
                'stat_conversion'       => 'conversione',
                'stat_charges'          => 'addebiti',
                'modal_title'           => 'Nuovo modulo',
                'modal_empty'           => 'VUOTO',
                'modal_template'        => 'TEMPLATE',
                'modal_duplicate'       => 'DUPLICA',
                'modal_import'          => 'IMPORTA',
                'modal_name_ph'         => 'Nome modulo',
                'modal_create'          => 'CREA MODULO',
                // Submissions page
                'submissions_title'     => 'Risposte',
                'bulk_delete'           => 'ELIMINA SELEZIONATI',
                'export_btn'            => '↑ ESPORTA',
                'all_forms_filter'      => 'Tutti i form',
                'col_created'           => 'CREATO',
                'no_submissions'        => 'Nessuna risposta trovata',
                'view_submission'       => 'Visualizza risposta',
                'hide_empty_fields'     => 'NASCONDI CAMPI VUOTI',
                'show_empty_fields'     => 'MOSTRA CAMPI VUOTI',
                'edit_submission'       => 'MODIFICA RISPOSTA',
                'print_btn'             => 'STAMPA',
                'empty_value'           => '(vuoto)',
                'source_label'          => 'Provenienza',
                'ip_label'              => 'IP',
                'sub_count_s'           => 'risposta',
                'sub_count_p'           => 'risposte',
                // Stats page
                'stats_title'           => 'Statistiche',
                'load_stats_btn'        => '↑ OTTIENI STATISTICHE',
                'select_form_label'     => 'Seleziona modulo',
                'all_forms_stats'       => 'Tutti i moduli',
                'period_label'          => 'Periodo',
                'period_all'            => 'Tutto',
                'period_week'           => 'Ultima settimana',
                'period_month'          => 'Ultimo mese',
                'period_year'           => 'Ultimo anno',
                'max_results_label'     => 'Max risposte',
                'no_stats'              => 'Nessuna statistica disponibile',
                'learn_more'            => 'scopri di più',
                // Settings page
                'tagline'               => 'Plugin form avanzato per hotel — powered by in3pida',
                'settings_saved'        => 'Impostazioni salvate.',
                'section_lang'          => '🌐 LINGUA',
                'lang_label'            => 'Lingua interfaccia',
                'lang_option_it'        => 'Italiano',
                'lang_option_en'        => 'English',
                'lang_desc'             => 'Lingua delle voci di questo plugin (non influenza il resto di WordPress).',
                'section_supabase'      => '☁ DATABASE SUPABASE',
                'supabase_url_label'    => 'URL Progetto Supabase',
                'supabase_key_label'    => 'API Key Supabase',
                'test_connection'       => '▶ Testa Connessione',
                'section_hotel'         => '🏨 IDENTIFICAZIONE HOTEL',
                'hotel_id_label'        => 'ID Hotel',
                'hotel_id_desc'         => 'Identificatore univoco della struttura (es. hotel-riviera-riccione). — Hotel singolo: impostalo qui, viene applicato a tutti i form. — Multi-hotel: lascia vuoto e imposta l\'Hotel ID direttamente nelle impostazioni di ogni singolo form (tab IN3PIDA nel builder).',
                'section_channels'      => '🔗 CANALI PERSONALIZZATI',
                'channels_label'        => 'Canali aggiuntivi',
                'channels_desc'         => 'Uno per riga. Si aggiungono alle opzioni Canale di default (Sito, Meta, Google Ads, Newsletter, Altro).',
                'section_antispam'      => '🛡 ANTI-SPAM',
                'antispam_ip_label'     => 'Limite invii per IP',
                'antispam_active'       => 'Attivo',
                'antispam_inactive'     => 'Disattivo',
                'antispam_max_label'    => 'Massimo invii per ora',
                'antispam_ip_desc'      => "Blocca lo stesso IP dopo N invii nell'arco di un'ora.",
                'honeypot_label'        => 'Campo Honeypot',
                'honeypot_desc'         => 'Aggiunge un campo invisibile. I bot lo compilano automaticamente e vengono scartati.',
                'section_queue'         => '📋 SUBMISSIONS IN CODA (FALLBACK)',
                'queue_status'          => 'Stato',
                'queue_count'           => 'Conteggio',
                'queue_action'          => 'Azione',
                'queue_pending'         => 'In attesa di retry',
                'queue_failed'          => 'Falliti definitivamente (5+ retry)',
                'queue_retry'           => 'Riprova ora',
                'queue_manual'          => 'Richiede intervento manuale',
                'save_settings'         => '💾 Salva Impostazioni',
                // Relative dates
                'just_now'              => 'alcuni secondi fa',
                'minute_ago'            => ' minuto fa',
                'minutes_ago'           => ' minuti fa',
                'one_hour_ago'          => "un'ora fa",
                'hours_ago'             => ' ore fa',
                'one_day_ago'           => 'un giorno fa',
                'days_ago'              => ' giorni fa',
                // Supabase descriptions
                'supabase_url_desc'     => 'URL del tuo progetto Supabase (es: <code>https://abcdefgh.supabase.co</code>)',
                'supabase_key_desc'     => 'Usa la chiave <code>anon</code> con RLS abilitata su Supabase (consigliata). La chiave viene cifrata nel database.',
                // Builder topbar
                'builder_back'          => '← BACHECA',
                'builder_settings'      => '⚙ IMPOSTAZIONI',
                'builder_styling'       => '≡ STILE',
                'builder_addons'        => '⊕ ADDON',
                'builder_logic'         => '⚡ LOGICA',
                'builder_save'          => '✓ SALVA',
                'builder_preview'       => '▶ ANTEPRIMA',
                'builder_help'          => 'ⓘ AIUTO',
                // Builder panel titles
                'panel_settings'        => 'Impostazioni',
                'panel_styling'         => 'Stile',
                'panel_addons'          => 'Addon',
                'panel_logic'           => 'Logica',
                'panel_help'            => 'Aiuto',
                // Builder ADD FIELD panel
                'builder_add_field'     => 'AGGIUNGI ∧',
                'builder_more_fields'   => '‹ ALTRI CAMPI',
                'builder_survey'        => '‹ SONDAGGIO',
                // Builder settings tabs
                'builder_tab_general'   => 'GENERALE',
                'builder_tab_email'     => 'EMAIL',
                'builder_tab_embed'     => 'INCORPORA',
                'builder_tab_custom'    => 'TESTI',
                'builder_tab_advanced'  => 'AVANZATE',
                'builder_tab_in3pida'   => 'IN3PIDA',
                // Builder webhook
                'builder_webhook_label' => 'Invia dati a URL personalizzato',
                // JS strings
                'js_testing'            => 'Test in corso…',
                'js_insert_url_key'     => 'Inserisci URL e API Key.',
                'js_connection_ok'      => '✓ Connessione OK',
                'js_connection_error'   => '✗ Errore ',
                'js_connection_failed'  => '✗ Connessione fallita',
            ],
            'en' => [
                // Menu
                'menu_main'             => 'in3pidaForm Dashboard',
                'menu_forms'            => 'Forms',
                'menu_submissions'      => 'Submissions',
                'menu_stats'            => 'Statistics',
                'menu_builder'          => 'Builder',
                'menu_settings'         => 'in3pida Settings',
                'menu_crm'              => 'CRM Integrations',
                // Topbar
                'export_all'            => 'Export All Data',
                // Forms page
                'forms_title'           => 'Forms',
                'search_placeholder'    => 'Search',
                'new_form_btn'          => '+ NEW FORM',
                'col_id'                => 'ID',
                'col_name'              => 'NAME',
                'col_created_at'        => 'CREATED',
                'col_last_modified'     => 'MODIFIED',
                'no_forms'              => 'No forms found',
                'stats_module_title'    => 'Form Statistics',
                'disable_stats'         => 'Disable statistics',
                'reset_stats'           => '↑ RESET STATISTICS',
                'all_forms'             => 'All forms',
                'custom_range'          => 'CUSTOM',
                'from_date'             => 'From',
                'to_date'               => 'To',
                'apply_range'           => 'Apply',
                'stat_views'            => 'views',
                'stat_responses'        => 'responses',
                'stat_conversion'       => 'conversion',
                'stat_charges'          => 'charges',
                'modal_title'           => 'New form',
                'modal_empty'           => 'BLANK',
                'modal_template'        => 'TEMPLATE',
                'modal_duplicate'       => 'DUPLICATE',
                'modal_import'          => 'IMPORT',
                'modal_name_ph'         => 'Form name',
                'modal_create'          => 'CREATE FORM',
                // Submissions page
                'submissions_title'     => 'Submissions',
                'bulk_delete'           => 'DELETE SELECTED',
                'export_btn'            => '↑ EXPORT',
                'all_forms_filter'      => 'All forms',
                'col_created'           => 'CREATED',
                'no_submissions'        => 'No submissions found',
                'view_submission'       => 'View submission',
                'hide_empty_fields'     => 'HIDE EMPTY FIELDS',
                'show_empty_fields'     => 'SHOW EMPTY FIELDS',
                'edit_submission'       => 'EDIT SUBMISSION',
                'print_btn'             => 'PRINT',
                'empty_value'           => '(empty)',
                'source_label'          => 'Source',
                'ip_label'              => 'IP',
                'sub_count_s'           => 'submission',
                'sub_count_p'           => 'submissions',
                // Stats page
                'stats_title'           => 'Statistics',
                'load_stats_btn'        => '↑ GET STATISTICS',
                'select_form_label'     => 'Select form',
                'all_forms_stats'       => 'All forms',
                'period_label'          => 'Period',
                'period_all'            => 'All time',
                'period_week'           => 'Last week',
                'period_month'          => 'Last month',
                'period_year'           => 'Last year',
                'max_results_label'     => 'Max results',
                'no_stats'              => 'No statistics available',
                'learn_more'            => 'learn more',
                // Settings page
                'tagline'               => 'Advanced form plugin for hotels — powered by in3pida',
                'settings_saved'        => 'Settings saved.',
                'section_lang'          => '🌐 LANGUAGE',
                'lang_label'            => 'Interface language',
                'lang_option_it'        => 'Italian',
                'lang_option_en'        => 'English',
                'lang_desc'             => "Language for this plugin's labels (does not affect the rest of WordPress).",
                'section_supabase'      => '☁ SUPABASE DATABASE',
                'supabase_url_label'    => 'Supabase Project URL',
                'supabase_key_label'    => 'Supabase API Key',
                'test_connection'       => '▶ Test Connection',
                'section_hotel'         => '🏨 HOTEL IDENTIFICATION',
                'hotel_id_label'        => 'Hotel ID',
                'hotel_id_desc'         => 'Unique identifier for the property (e.g. hotel-riviera-riccione). — Single hotel: set it here, applied to all forms. — Multi-hotel: leave empty and set Hotel ID directly in each form\'s settings (IN3PIDA tab in the builder).',
                'section_channels'      => '🔗 CUSTOM CHANNELS',
                'channels_label'        => 'Additional channels',
                'channels_desc'         => 'One per line. Added to default channel options (Website, Meta, Google Ads, Newsletter, Other).',
                'section_antispam'      => '🛡 ANTI-SPAM',
                'antispam_ip_label'     => 'Submission limit per IP',
                'antispam_active'       => 'Active',
                'antispam_inactive'     => 'Inactive',
                'antispam_max_label'    => 'Maximum submissions per hour',
                'antispam_ip_desc'      => 'Blocks the same IP after N submissions within one hour.',
                'honeypot_label'        => 'Honeypot Field',
                'honeypot_desc'         => 'Adds an invisible field. Bots fill it automatically and are discarded.',
                'section_queue'         => '📋 QUEUED SUBMISSIONS (FALLBACK)',
                'queue_status'          => 'Status',
                'queue_count'           => 'Count',
                'queue_action'          => 'Action',
                'queue_pending'         => 'Waiting for retry',
                'queue_failed'          => 'Permanently failed (5+ retries)',
                'queue_retry'           => 'Retry now',
                'queue_manual'          => 'Requires manual intervention',
                'save_settings'         => '💾 Save Settings',
                // Relative dates
                'just_now'              => 'a few seconds ago',
                'minute_ago'            => ' minute ago',
                'minutes_ago'           => ' minutes ago',
                'one_hour_ago'          => 'an hour ago',
                'hours_ago'             => ' hours ago',
                'one_day_ago'           => 'a day ago',
                'days_ago'              => ' days ago',
                // Supabase descriptions
                'supabase_url_desc'     => 'Your Supabase project URL (e.g. <code>https://abcdefgh.supabase.co</code>)',
                'supabase_key_desc'     => 'Use the <code>anon</code> key with RLS enabled on Supabase (recommended). The key is encrypted in the database.',
                // Builder topbar
                'builder_back'          => '← DASHBOARD',
                'builder_settings'      => '⚙ SETTINGS',
                'builder_styling'       => '≡ STYLING',
                'builder_addons'        => '⊕ ADDONS',
                'builder_logic'         => '⚡ LOGIC',
                'builder_save'          => '✓ SAVE',
                'builder_preview'       => '▶ PREVIEW',
                'builder_help'          => 'ⓘ HELP',
                // Builder panel titles
                'panel_settings'        => 'Settings',
                'panel_styling'         => 'Styling',
                'panel_addons'          => 'Addons',
                'panel_logic'           => 'Logic',
                'panel_help'            => 'Help',
                // Builder ADD FIELD panel
                'builder_add_field'     => 'ADD FIELD ∧',
                'builder_more_fields'   => '‹ MORE FIELDS',
                'builder_survey'        => '‹ SURVEY',
                // Builder settings tabs
                'builder_tab_general'   => 'GENERAL',
                'builder_tab_email'     => 'EMAIL',
                'builder_tab_embed'     => 'EMBED',
                'builder_tab_custom'    => 'CUSTOM TEXT',
                'builder_tab_advanced'  => 'ADVANCED',
                'builder_tab_in3pida'   => 'IN3PIDA',
                // Builder webhook
                'builder_webhook_label' => 'Send data to custom URL',
                // JS strings
                'js_testing'            => 'Testing…',
                'js_insert_url_key'     => 'Please enter URL and API Key.',
                'js_connection_ok'      => '✓ Connection OK',
                'js_connection_error'   => '✗ Error ',
                'js_connection_failed'  => '✗ Connection failed',
            ],
        ];
    }
}
