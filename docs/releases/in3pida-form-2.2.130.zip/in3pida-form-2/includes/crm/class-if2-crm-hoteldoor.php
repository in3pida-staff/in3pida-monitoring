<?php
defined('ABSPATH') || exit;

class IF2_CRM_HotelDoor {

    const ENDPOINT = 'https://hub.hoteldoor.it/api/v1/request/add';

    public static function send(array $creds, array $fields, array $meta): array {
        $token    = trim($creds['token'] ?? '');
        $hotel_id = (int)($creds['hotel_id'] ?? 0);

        if (!$token || !$hotel_id) {
            return ['status' => 'error', 'code' => 0, 'message' => 'token o hotel_id mancanti'];
        }

        // Date DD/MM/YYYY → YYYY-MM-DD
        $checkin  = self::convert_date($fields['checkin']  ?? '');
        $checkout = self::convert_date($fields['checkout'] ?? '');

        // Nome → first + last
        $full  = trim($fields['fullname'] ?? '');
        $space = strpos($full, ' ');
        $first = $space !== false ? substr($full, 0, $space) : '';
        $last  = $space !== false ? substr($full, $space + 1) : $full;

        // Bambini
        $children = [];
        foreach (['child_age_1', 'child_age_2', 'child_age_3', 'child_age_4'] as $slot) {
            $age = $fields[$slot] ?? '';
            if ($age === '' || $age === null) continue;
            $children[] = $age === '-1' ? 0 : (int)$age;
        }

        $newsletter = filter_var($fields['newsletter'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $lang       = substr(get_locale(), 0, 2);

        // Referer con UTM dal canale
        $channel = $meta['channel'] ?? '';
        $referer  = $meta['source_url'] ?? get_site_url();
        [$src, $medium] = self::channel_utm($channel);
        if ($src) {
            $sep      = strpos($referer, '?') !== false ? '&' : '?';
            $referer .= $sep . http_build_query([
                'utm_source'   => $src,
                'utm_medium'   => $medium,
                'utm_campaign' => $channel,
            ]);
        }

        $occupancy = ['AdultsCount' => max(1, (int)($fields['adults'] ?? 1))];
        if (!empty($children)) {
            $occupancy['ChildrenAgeArray'] = $children;
        }

        $payload = [
            'StayRequest' => [
                'Key'              => null,
                'ReceivedDateTime' => current_time('Y-m-d\TH:i:s'), // ora locale del sito (Italia), non UTC
                'CheckIn'          => $checkin,
                'CheckOut'         => $checkout,
                'HotelsId'         => [$hotel_id],
                'GuestNotes'       => $fields['notes'] ?? '',
                'RequestReferer'   => $referer,
                'RoomsDetails'     => [[
                    'BoardBasis' => $fields['treatment'] ?? '',
                    'Occupancy'  => $occupancy,
                ]],
            ],
            'Contact' => [
                'Key'                    => null,
                'Email'                  => $fields['email'] ?? '',
                'Language'               => $lang,
                'FirstName'              => $first,
                'LastName'               => $last,
                'MobilePhone'            => $fields['phone'] ?? '',
                'NewsletterSubscription' => $newsletter,
            ],
        ];

        $resp = wp_remote_post(self::ENDPOINT, [
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $token,
            ],
            'body'    => wp_json_encode($payload),
            'timeout' => 8,
            'blocking'=> true,
        ]);

        if (is_wp_error($resp)) {
            return ['status' => 'error', 'code' => 0, 'message' => $resp->get_error_message()];
        }

        $code = wp_remote_retrieve_response_code($resp);
        $ok   = $code >= 200 && $code < 300;
        return [
            'status'  => $ok ? 'ok' : 'error',
            'code'    => $code,
            'message' => $ok ? '' : substr(wp_remote_retrieve_body($resp), 0, 200),
        ];
    }

    private static function convert_date(string $date): string {
        if (preg_match('/^(\d{2})\/(\d{2})\/(\d{4})$/', $date, $m)) {
            return $m[3] . '-' . $m[2] . '-' . $m[1];
        }
        return $date; // già ISO o vuoto
    }

    private static function channel_utm(string $ch): array {
        $map = [
            'fb'         => ['facebook',          'social'],
            'Meta'       => ['facebook',          'social'],
            'ads'        => ['google-adwords',    'ppc'],
            'Google Ads' => ['google-adwords',    'ppc'],
            'nl'         => ['newsletter',         'email'],
            'Newsletter' => ['newsletter',         'email'],
            'rmk'        => ['google-remarketing', 'ppc'],
            'web'        => ['Sito',               'organic'],
            'Sito'       => ['Sito',               'organic'],
            'landing'    => ['landing',            'landing'],
        ];
        return $map[$ch] ?? [$ch ?: '', 'referral'];
    }
}
