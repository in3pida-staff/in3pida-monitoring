/* in3pida Form 2 – Admin JS */
jQuery(function ($) {
    'use strict';

    var ajaxurl = IF2Admin.ajaxurl;
    var nonce   = IF2Admin.nonce;
    var statsChart = null;
    var currentRange  = '1m';
    var currentFormId = 0;

    // -------------------------------------------------------------------------
    // Crea nuovo form — MODAL
    // -------------------------------------------------------------------------
    var $modal     = $('#if2-modal-new-form');
    var $nameInput = $('#if2-modal-form-name');

    // Apre modal
    $('#if2-btn-new-form').on('click', function () {
        $nameInput.val('');
        $modal.addClass('open');
        setTimeout(function () { $nameInput.focus(); }, 100);
    });

    // Chiude modal
    $('#if2-modal-close, #if2-modal-new-form').on('click', function (e) {
        if (e.target === this) $modal.removeClass('open');
    });
    $(document).on('keydown', function (e) {
        if (e.key === 'Escape') $modal.removeClass('open');
    });

    // Selezione tipo (VUOTO/TEMPLATE/DUPLICA/IMPORTA)
    $(document).on('click', '.if2-modal-option', function () {
        $('.if2-modal-option').removeClass('active');
        $(this).addClass('active');
        var type = $(this).data('type');
        $('#if2-import-area').toggle(type === 'importa');
        $('#if2-dup-area').toggle(type === 'duplica');
        if (type === 'importa') {
            $nameInput.attr('placeholder', 'Nome modulo (opzionale, usa quello del file)');
        } else if (type === 'duplica') {
            $nameInput.attr('placeholder', 'Nome della copia (opzionale)');
        } else {
            $nameInput.attr('placeholder', $nameInput.data('orig-ph') || 'Nome modulo');
        }
    });

    // Crea form
    $('#if2-modal-create').on('click', function () {
        var activeType = $('.if2-modal-option.active').data('type') || 'vuoto';

        if (activeType === 'importa') {
            var jsonStr = $.trim($('#if2-import-json').val());
            if (!jsonStr) { $('#if2-import-json').focus(); return; }
            var parsed;
            try { parsed = JSON.parse(jsonStr); } catch(ex) { alert('JSON non valido. Verifica il file esportato.'); return; }

            var importName = $.trim($nameInput.val()) || parsed.name || 'Form importato';
            var $btn = $(this).prop('disabled', true).text('Importazione…');

            $.post(ajaxurl, { action: 'if2_new_form', nonce: nonce, name: importName }, function (res) {
                if (!res.success) { $btn.prop('disabled', false).text('CREA MODULO'); alert('Errore durante la creazione.'); return; }
                var newId = res.data.id;
                $.post(ajaxurl, {
                    action: 'if2_save_form', nonce: nonce, form_id: newId,
                    fields: JSON.stringify(parsed.fields || []),
                    config: JSON.stringify(parsed.config || {})
                }, function (res2) {
                    $btn.prop('disabled', false).text('CREA MODULO');
                    $modal.removeClass('open');
                    window.location.href = ajaxurl.replace('admin-ajax.php', 'admin.php') + '?page=if2-builder&form_id=' + newId;
                });
            });
            return;
        }

        if (activeType === 'duplica') {
            var srcId = $('#if2-dup-form').val();
            if (!srcId) { $('#if2-dup-form').focus(); return; }
            var dupName = $.trim($nameInput.val());
            var $dbtn = $(this).prop('disabled', true).text('Duplicazione…');
            $.post(ajaxurl, { action: 'if2_get_form', nonce: nonce, form_id: srcId }, function (res) {
                if (!res.success) { $dbtn.prop('disabled', false).text('CREA MODULO'); alert('Errore nel leggere il form da duplicare.'); return; }
                var src = res.data;
                var newName = dupName || ('Copia di ' + (src.name || 'Form'));
                $.post(ajaxurl, { action: 'if2_new_form', nonce: nonce, name: newName }, function (r2) {
                    if (!r2.success) { $dbtn.prop('disabled', false).text('CREA MODULO'); alert('Errore durante la creazione.'); return; }
                    var newId = r2.data.id;
                    $.post(ajaxurl, {
                        action: 'if2_save_form', nonce: nonce, form_id: newId,
                        fields: JSON.stringify(src.fields || []),
                        config: JSON.stringify(src.config || {})
                    }, function () {
                        $dbtn.prop('disabled', false).text('CREA MODULO');
                        $modal.removeClass('open');
                        window.location.href = ajaxurl.replace('admin-ajax.php', 'admin.php') + '?page=if2-builder&form_id=' + newId;
                    });
                });
            });
            return;
        }

        var name = $.trim($nameInput.val());
        if (!name) { $nameInput.focus(); return; }
        var $btn = $(this).prop('disabled', true).text('Creazione…');

        $.post(ajaxurl, { action: 'if2_new_form', nonce: nonce, name: name }, function (res) {
            $btn.prop('disabled', false).text('CREA MODULO');
            if (res.success) {
                $modal.removeClass('open');
                window.location.href = ajaxurl.replace('admin-ajax.php', 'admin.php') +
                    '?page=if2-builder&form_id=' + res.data.id;
            } else {
                alert('Errore durante la creazione del form.');
            }
        });
    });

    // Invio con Enter nell'input nome
    $nameInput.on('keydown', function (e) {
        if (e.key === 'Enter') $('#if2-modal-create').trigger('click');
    });

    // Lettura file JSON dal PC
    $(document).on('change', '#if2-import-file', function () {
        var file = this.files && this.files[0];
        if (!file) return;
        $('#if2-import-filename').text(file.name);
        var reader = new FileReader();
        reader.onload = function (e) {
            var content = e.target.result;
            $('#if2-import-json').val(content);
            try {
                var parsed = JSON.parse(content);
                if (parsed.plugin === 'FormCraft') {
                    $('#if2-import-json').val('');
                    $('#if2-import-filename').text('');
                    alert('File FormCraft rilevato.\n\nPer importarlo:\n1. Crea un form vuoto\n2. Aprilo nel Builder\n3. Vai nel pannello Impostazioni → clicca "Import (.json / FormCraft .txt)"\n4. Seleziona il file .txt da lì');
                    return;
                }
                if (parsed.name && !$.trim($nameInput.val())) {
                    $nameInput.val(parsed.name);
                }
            } catch (ex) {}
        };
        reader.readAsText(file);
    });

    // Click sull'intera riga (non su checkbox o delete)
    $(document).on('click', '.if2-form-row', function (e) {
        if ($(e.target).closest('.if2-btn-delete-form').length) return;
        if ($(e.target).closest('.if2-sub-del').length) return;
        if ($(e.target).is('input[type="checkbox"]') || $(e.target).closest('input[type="checkbox"]').length) return;
        var url   = $(this).data('builder-url');
        var subId = $(this).data('sub-id');
        var $panel = $('.if2-panel-stats');

        // RISPOSTE: carica il dettaglio via AJAX e sostituisci solo il pannello destro.
        // Niente ricarica pagina → niente flash e niente salto di posizione (e più veloce).
        if (subId && url && $panel.length) {
            var $row = $(this);
            $('.if2-form-row').removeClass('if2-sub-active');
            $row.addClass('if2-sub-active');
            $panel.css('opacity', '0.45');
            $.get(url)
                .done(function (html) {
                    var np = null;
                    try { np = new DOMParser().parseFromString(html, 'text/html').querySelector('.if2-panel-stats'); } catch (err) {}
                    if (np) {
                        $panel.html(np.innerHTML).css('opacity', '1');
                        emptyHidden = true; applyEmptyState(); // dettaglio aperto via AJAX: ripristina default = campi vuoti nascosti
                        try { history.pushState(null, '', url); } catch (err) {}
                    } else {
                        window.location.href = url; // fallback
                    }
                })
                .fail(function () { window.location.href = url; });
            return;
        }

        // FORM: vai al builder come prima (ricarica necessaria)
        if (url) window.location.href = url;
    });

    // Checkbox singola → aggiorna bottone bulk
    $(document).on('change', '.if2-sub-check', function (e) {
        e.stopPropagation();
        updateBulkDelete();
    });

    // Check-all
    $(document).on('change', '#if2-check-all', function (e) {
        e.stopPropagation();
        var checked = $(this).is(':checked');
        $('.if2-sub-check').prop('checked', checked);
        updateBulkDelete();
    });

    function updateBulkDelete() {
        var count = $('.if2-sub-check:checked').length;
        var $btn  = $('#if2-bulk-delete');
        if (count > 0) {
            var label = (IF2Admin.strings && IF2Admin.strings.bulk_delete) ? IF2Admin.strings.bulk_delete : 'ELIMINA SELEZIONATI';
            $btn.text(label + ' (' + count + ')').css('display', 'inline-flex');
        } else {
            $btn.css('display', 'none');
        }
    }

    // Elimina selezionati
    $(document).on('click', '#if2-bulk-delete', function () {
        var $checked = $('.if2-sub-check:checked');
        var ids = $checked.closest('tr').map(function () { return $(this).data('sub-id'); }).get();
        if (!ids.length) return;
        if (!confirm('Eliminare ' + ids.length + ' risposta/e? Operazione irreversibile.')) return;

        var done = 0;
        ids.forEach(function (id) {
            $.post(ajaxurl, { action: 'if2_delete_submission', nonce: nonce, submission_id: id }, function (res) {
                if (res.success) {
                    $('tr[data-sub-id="' + id + '"]').fadeOut(200, function () { $(this).remove(); });
                }
                done++;
                if (done === ids.length) updateBulkDelete();
            });
        });
    });

    // Elimina la singola richiesta dalla "x" a destra della riga (senza aprire il dettaglio).
    // Usa il modale custom #if2-modal-delete-sub (NON il confirm del browser).
    var if2DelSubId = null, if2DelSub$Row = null;

    $(document).on('click', '.if2-sub-del', function (e) {
        e.preventDefault();
        e.stopPropagation();
        if2DelSubId  = $(this).data('id');
        if2DelSub$Row = $(this).closest('tr');
        if (!if2DelSubId) return;
        $('#if2-modal-delete-sub').addClass('open'); // .open = display:flex → box centrato
    });

    $(document).on('click', '#if2-delete-sub-close, #if2-delete-sub-cancel', function () {
        $('#if2-modal-delete-sub').removeClass('open');
    });

    $(document).on('click', '#if2-delete-sub-confirm', function () {
        var id = if2DelSubId, $row = if2DelSub$Row;
        $('#if2-modal-delete-sub').removeClass('open');
        if (!id) return;
        $.post(ajaxurl, { action: 'if2_delete_submission', nonce: nonce, submission_id: id }, function (res) {
            if (res && res.success) {
                $row.fadeOut(200, function () { $(this).remove(); updateBulkDelete(); });
            }
        });
    });

    // -------------------------------------------------------------------------
    // Elimina form
    // -------------------------------------------------------------------------
    var if2DeleteFormId = null;

    $(document).on('click', '.if2-btn-delete-form', function () {
        if2DeleteFormId = $(this).data('id');
        $('#if2-modal-delete-form').fadeIn(150);
    });

    $(document).on('click', '#if2-delete-modal-close, #if2-delete-form-cancel', function () {
        $('#if2-modal-delete-form').fadeOut(150);
        if2DeleteFormId = null;
    });

    $(document).on('click', '#if2-delete-form-confirm', function () {
        var id = if2DeleteFormId;
        if (!id) return;
        $('#if2-modal-delete-form').fadeOut(150);
        if2DeleteFormId = null;
        $.post(ajaxurl, { action: 'if2_delete_form', nonce: nonce, form_id: id }, function (res) {
            if (res.success) {
                $('tr[data-form-id="' + id + '"]').fadeOut(300, function () { $(this).remove(); });
            } else {
                alert('Errore eliminazione.');
            }
        });
    });

    // -------------------------------------------------------------------------
    // Ricerca form
    // -------------------------------------------------------------------------
    $('#if2-search-forms').on('input', function () {
        var q = $(this).val().toLowerCase();
        $('#if2-forms-table tbody tr').each(function () {
            var name = $(this).find('td:nth-child(2)').text().toLowerCase();
            $(this).toggle(!q || name.indexOf(q) !== -1);
        });
    });

    // (delete submission gestito in fondo al file)

    // -------------------------------------------------------------------------
    // STATISTICHE — caricamento
    // -------------------------------------------------------------------------
    function loadStats(dateFrom, dateTo) {
        var postData = {
            action:  'if2_get_stats',
            nonce:   nonce,
            range:   currentRange,
            form_id: currentFormId,
        };
        if (dateFrom && dateTo) {
            postData.date_from = dateFrom;
            postData.date_to   = dateTo;
        }
        $.post(ajaxurl, postData, function (res) {
            if (!res.success) return;
            var d = res.data;

            $('#stat-views').text(d.views);
            $('#stat-responses').text(d.responses);
            $('#stat-conversion').text(d.conversion + '%');

            renderChart(d.chart);
            equalizeFormPanels();
        });
    }

    function renderChart(chart) {
        var ctx = document.getElementById('if2-stats-chart');
        if (!ctx) return;

        if (statsChart) {
            statsChart.destroy();
            statsChart = null;
        }

        statsChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: chart.labels,
                datasets: [
                    {
                        label: 'Visualizzazioni',
                        data:  chart.views,
                        borderColor:     '#d82d6b',
                        backgroundColor: 'rgba(216,45,107,0.08)',
                        borderWidth: 1,
                        pointRadius: 0,
                        pointHoverRadius: 3,
                        fill: false,
                        tension: 0.3,
                    },
                    {
                        label: 'Risposte',
                        data:  chart.responses || [],
                        borderColor:     '#009bb9',
                        backgroundColor: 'rgba(0,155,185,0.08)',
                        borderWidth: 1,
                        pointRadius: 0,
                        pointHoverRadius: 3,
                        fill: false,
                        tension: 0.3,
                    },
                ],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: { boxWidth: 28, font: { size: 11 }, color: '#888', padding: 16 },
                    },
                },
                scales: {
                    x: { grid: { color: '#f2f2f2' }, ticks: { font: { size: 11 }, color: '#aaa' } },
                    y: { grid: { color: '#f2f2f2' }, ticks: { font: { size: 11 }, color: '#aaa', precision: 0 } },
                },
            },
        });
    }

    // Filtri range
    $(document).on('click', '.if2-filter-btn', function () {
        var range = $(this).data('range');
        $('.if2-filter-btn').removeClass('active');
        $(this).addClass('active');

        if (range === 'custom') {
            var $cr = $('#if2-custom-range');
            if ($cr.is(':visible')) { $cr.hide(); } else { $cr.css('display', 'flex'); }
            return;
        }

        $('#if2-custom-range').hide();
        currentRange = range;
        loadStats();
    });

    // Applica range personalizzato
    $(document).on('click', '#if2-apply-custom-range', function () {
        var from = $('#if2-date-from').val();
        var to   = $('#if2-date-to').val();
        if (!from || !to) { alert('Seleziona entrambe le date.'); return; }
        currentRange = 'custom';
        loadStats(from, to);
    });

    // Impedisce di selezionare una data fine precedente alla data inizio
    $(document).on('change', '#if2-date-from', function () {
        var from = $(this).val();
        var $to  = $('#if2-date-to');
        $to.attr('min', from);
        if ($to.val() && $to.val() < from) $to.val(from);
    });

    // Filtro per form
    $(document).on('change', '#if2-stats-form-filter', function () {
        currentFormId = parseInt($(this).val(), 10) || 0;
        loadStats();
    });

    // ─── REPORT RICHIESTE PER FORM (tab Risposte, bottone toggle, chiuso di default) ───
    var reportRange  = '1m';
    var reportLoaded = false;
    function if2EscHtml(s) { return $('<div>').text(s == null ? '' : s).html(); }

    function loadReport(from, to) {
        var $tb = $('#if2-report-tbody');
        if (!$tb.length) return;
        var post = { action: 'if2_forms_report', nonce: nonce, range: reportRange, _: Date.now() };
        if (from && to) { post.date_from = from; post.date_to = to; }
        $tb.html('<tr class="if2-empty-row"><td colspan="7">Caricamento…</td></tr>');
        $.post(ajaxurl, post, function (res) {
            if (!res || !res.success) { $tb.html('<tr class="if2-empty-row"><td colspan="7">Errore nel caricamento.</td></tr>'); return; }
            var d    = res.data || {};
            var rows = d.rows || [];
            $('#if2-report-range').text(d.period_label ? '(' + d.period_label + ')' : '');
            // somma richieste per canale (riquadro a destra del filtro)
            var $chBox = $('#if2-report-channels');
            if ($chBox.length) {
                var chans = d.channels || [];
                $chBox.html(chans.map(function (c) {
                    return '<span><strong>' + if2EscHtml(c.label) + '</strong> ' + (parseInt(c.count, 10) || 0) + '</span>';
                }).join('<span style="display:inline-block;width:1px;height:15px;background:#d8d8de"></span>'));
                $chBox.css('display', chans.length ? 'flex' : 'none');
            }
            if (!rows.length) { $tb.html('<tr class="if2-empty-row"><td colspan="7">Nessuna richiesta nel periodo.</td></tr>'); return; }
            var html = '';
            rows.forEach(function (r) {
                html += '<tr>'
                      + '<td><span class="if2-form-name-link">' + if2EscHtml(r.name) + '</span></td>'
                      + '<td class="if2-report-c">' + (parseInt(r.count, 10) || 0) + '</td>'
                      + '<td class="if2-report-c">' + if2EscHtml(r.pct_total) + '</td>'
                      + '<td class="if2-form-date">' + if2EscHtml(r.created) + '</td>'
                      + '<td class="if2-form-date">' + if2EscHtml(r.last) + '</td>'
                      + '<td>' + if2EscHtml(r.top_period) + '</td>'
                      + '<td class="if2-form-date">' + if2EscHtml(r.db) + ' · ' + if2EscHtml(r.crm) + ' · ' + if2EscHtml(r.am) + '</td>'
                      + '</tr>';
            });
            $tb.html(html);
        });
    }

    // bottone toggle: apre/chiude la tabella; carica al primo "Mostra".
    // Lo stato è ricordato in localStorage: aprendo il dettaglio di una risposta la pagina si ricarica,
    // ma il report deve restare aperto se l'avevi aperto.
    function if2SetReport(open) {
        var $p = $('#if2-report-panel');
        if (!$p.length) return;
        if (open) {
            $p.removeClass('if2-hidden');
            $('#if2-report-toggle').text('Nascondi report richieste per form');
            if (!reportLoaded) { reportLoaded = true; loadReport(); }
        } else {
            $p.addClass('if2-hidden');
            $('#if2-report-toggle').text('Mostra report richieste per form');
        }
        try { localStorage.setItem('if2_report_open', open ? '1' : '0'); } catch (e) {}
    }
    $(document).on('click', '#if2-report-toggle', function () {
        if2SetReport($('#if2-report-panel').hasClass('if2-hidden'));
    });
    // ripristina lo stato dopo un reload (es. apertura dettaglio risposta)
    try { if (localStorage.getItem('if2_report_open') === '1') if2SetReport(true); } catch (e) {}

    // tendina periodo (come la pagina Statistiche)
    $(document).on('change', '#if2-report-period', function () {
        var range = $(this).val();
        if (range === 'custom') {
            reportRange = 'custom';
            $('#if2-report-custom').css('display', 'flex');
            return;
        }
        $('#if2-report-custom').hide();
        reportRange = range;
        loadReport();
    });

    $(document).on('click', '#if2-report-apply', function () {
        var from = $('#if2-report-from').val();
        var to   = $('#if2-report-to').val();
        if (!from || !to) { alert('Seleziona entrambe le date.'); return; }
        reportRange = 'custom';
        loadReport(from, to);
    });

    $(document).on('change', '#if2-report-from', function () {
        var from = $(this).val();
        var $to  = $('#if2-report-to');
        $to.attr('min', from);
        if ($to.val() && $to.val() < from) $to.val(from);
    });

    // Reset statistiche
    $('#if2-reset-stats').on('click', function () {
        if (!confirm('Azzerare tutte le statistiche? Operazione irreversibile.')) return;
        var $btn = $(this).prop('disabled', true);

        $.post(ajaxurl, { action: 'if2_reset_stats', nonce: nonce }, function (res) {
            $btn.prop('disabled', false);
            if (res.success) {
                loadStats();
            }
        });
    });

    // Disabilita statistiche (solo UI)
    $('#if2-disable-stats').on('change', function () {
        var disabled = $(this).is(':checked');
        $('.if2-chart-wrap, .if2-stats-cards').toggleClass('if2-stats-hidden', disabled);
    });

    // -------------------------------------------------------------------------
    // Export CSV (topbar globale + pulsante form specifico)
    // -------------------------------------------------------------------------
    function downloadCSV(formId, filename) {
        $.post(ajaxurl, { action: 'if2_export_data', nonce: nonce, form_id: formId || 0 }, function (res) {
            if (!res.success) { alert('Errore export.'); return; }
            var blob = new Blob([res.data.csv], { type: 'text/csv;charset=utf-8;' });
            var url  = URL.createObjectURL(blob);
            var a    = document.createElement('a');
            a.href     = url;
            a.download = filename || 'if2-submissions.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        });
    }

    $('#if2-export-all').on('click', function (e) {
        e.preventDefault();
        downloadCSV(0, 'if2-all-submissions.csv');
    });

    $(document).on('click', '#if2-export-form', function (e) {
        e.preventDefault();
        var fid = $(this).data('form-id');
        downloadCSV(fid, 'if2-form-' + fid + '-submissions.csv');
    });

    // -------------------------------------------------------------------------
    // Statistiche pagina dedicata — periodo custom + analisi hotel
    // -------------------------------------------------------------------------

    // Mostra/nascondi riga date custom
    $(document).on('change', '#if2-stats-period-select', function () {
        $('#if2-stats-custom-row').toggle($(this).val() === 'custom');
    });

    // Popola dropdown Config Hotel quando si cambia form
    $(document).on('change', '#if2-stats-form-filter', function () {
        var fid = parseInt($(this).val(), 10) || 0;
        var $selects = $('#if2-checkin-field, #if2-checkout-field, #if2-target-field');
        if (!fid) { $selects.html('<option value="">— Auto —</option>'); return; }
        $.post(ajaxurl, { action: 'if2_get_form', nonce: nonce, form_id: fid }, function (res) {
            if (!res.success || !res.data || !res.data.fields) return;
            var skip = ['submit', 'heading', 'html', 'page_break'];
            var opts = '<option value="">— Auto —</option>';
            res.data.fields.forEach(function (f) {
                if (skip.indexOf(f.type || '') !== -1) return;
                opts += '<option value="' + f.id + '">' + (f.label || f.id) + ' (' + (f.type || '') + ')</option>';
            });
            $selects.html(opts);
        });
    });

    // Chart instances hotel
    var _hotelCharts = {};
    function destroyHotelCharts() {
        Object.keys(_hotelCharts).forEach(function (k) {
            if (_hotelCharts[k]) { _hotelCharts[k].destroy(); _hotelCharts[k] = null; }
        });
    }

    var PINK_PALETTE = ['#BD1350','#D82D6B','#E04A82','#EA729A','#F299B5','#F6BECD','#F9D5E0','#FCEAF0'];

    function hBar(id, labels, data, label, color) {
        var ctx = document.getElementById(id); if (!ctx) return;
        if (_hotelCharts[id]) { _hotelCharts[id].destroy(); }
        _hotelCharts[id] = new Chart(ctx, {
            type: 'bar',
            data: { labels: labels, datasets: [{ label: label || '', data: data, backgroundColor: color || '#D82D6B', borderRadius: 4, borderSkipped: false }] },
            options: { responsive: true, maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    x: { grid: { display: false }, ticks: { font: { size: 10 }, color: '#888', maxRotation: 40 } },
                    y: { beginAtZero: true, grid: { color: '#f5f5f5' }, ticks: { precision: 0, font: { size: 11 }, color: '#aaa' } }
                }
            }
        });
    }

    // Barre con la % mostrata sopra ogni colonna + nel tooltip. Colore unico per tutte le barre.
    function hBarPct(id, labels, data, color) {
        var ctx = document.getElementById(id); if (!ctx) return;
        if (_hotelCharts[id]) { _hotelCharts[id].destroy(); }
        var total = data.reduce(function(a, b){ return a + (b || 0); }, 0);
        _hotelCharts[id] = new Chart(ctx, {
            type: 'bar',
            data: { labels: labels, datasets: [{ data: data, backgroundColor: color || '#D82D6B', borderRadius: 4, borderSkipped: false }] },
            options: { responsive: true, maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: { callbacks: { label: function(c){ var p = total > 0 ? Math.round(c.parsed.y / total * 100) : 0; return c.parsed.y + ' (' + p + '%)'; } } }
                },
                scales: {
                    x: { grid: { display: false }, ticks: { font: { size: 10 }, color: '#888', maxRotation: 40 } },
                    y: { beginAtZero: true, grid: { color: '#f5f5f5' }, ticks: { precision: 0, font: { size: 11 }, color: '#aaa' } }
                }
            }
        });
    }

    function hDonut(id, labels, data, colors, totalOverride) {
        var ctx = document.getElementById(id); if (!ctx) return;
        if (_hotelCharts[id]) { _hotelCharts[id].destroy(); }
        var clrs = (colors || PINK_PALETTE).slice(0, data.length);
        var dataSum = data.reduce(function(a, b) { return a + b; }, 0);
        var total   = totalOverride || dataSum;

        // ── Layout UNIFORME per tutte le torte: ciambella quadrata fissa a sinistra +
        //    legenda HTML a larghezza fissa a destra, sempre nella stessa posizione e dimensione.
        //    (la legenda nativa di Chart.js cambiava larghezza in base alle etichette, spostando la ciambella). ──
        var cv  = ctx.parentNode;
        var box;
        if (cv && cv.className === 'if2-donut-canvas') {
            box = cv.parentNode;                       // ri-render: struttura già pronta
        } else {
            box = cv;                                  // primo render: costruisco la struttura
            box.style.height = '240px';
            box.style.display = 'flex';
            box.style.alignItems = 'center';
            box.style.justifyContent = 'center';
            box.style.gap = '24px';
            box.style.flexWrap = 'wrap';
            cv = document.createElement('div');
            cv.className = 'if2-donut-canvas';
            cv.style.cssText = 'flex:0 0 200px;width:200px;height:200px;position:relative';
            box.insertBefore(cv, ctx);
            cv.appendChild(ctx);
        }
        var lg = box.querySelector('.if2-donut-legend');
        if (!lg) {
            lg = document.createElement('div');
            lg.className = 'if2-donut-legend';
            lg.style.cssText = 'flex:0 0 210px;width:210px;display:flex;flex-direction:column;gap:9px;font-size:11px;color:#555;line-height:1.25';
            box.appendChild(lg);
        }
        lg.innerHTML = labels.map(function(l, i) {
            var pct = total > 0 ? Math.round(data[i] / total * 100) : 0;
            return '<div class="if2-legend-item" data-idx="' + i + '" title="Clicca per escludere/includere" style="display:flex;align-items:center;gap:8px;cursor:pointer;user-select:none">' +
                   '<span style="flex:0 0 12px;width:12px;height:12px;border-radius:3px;background:' + clrs[i] + '"></span>' +
                   '<span>' + geoEsc(l) + ' ' + pct + '%</span></div>';
        }).join('');

        _hotelCharts[id] = new Chart(ctx, {
            type: 'doughnut',
            data: { labels: labels.map(function(l, i) { var pct = total > 0 ? Math.round(data[i] / total * 100) : 0; return l + ' ' + pct + '%'; }),
                    datasets: [{ data: data, backgroundColor: clrs, borderWidth: 2, borderColor: '#fff', hoverOffset: 6 }] },
            options: { responsive: true, maintainAspectRatio: false, cutout: '52%',
                plugins: {
                    legend: { display: false },
                    tooltip: { callbacks: { label: function(c) { return ' ' + c.parsed + ' (' + (total > 0 ? Math.round(c.parsed / total * 100) : 0) + '%)'; } } }
                }
            }
        });

        // Click su una voce della legenda → esclude/include la fetta e ricalcola il grafico (come la legenda nativa).
        lg.onclick = function(e) {
            var item = e.target.closest ? e.target.closest('.if2-legend-item') : null;
            if (!item) return;
            var idx = parseInt(item.getAttribute('data-idx'), 10);
            var ch = _hotelCharts[id]; if (!ch || isNaN(idx)) return;
            ch.toggleDataVisibility(idx);
            ch.update();
            item.style.opacity = ch.getDataVisibility(idx) ? '1' : '0.35';
            item.style.textDecoration = ch.getDataVisibility(idx) ? 'none' : 'line-through';
        };
    }

    // ─── PROVENIENZA (geolocalizzazione) ─────────────────────────────────────
    function geoEsc(s){ return (s==null?'':String(s)).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
    var _regAlias = {
        'piemonte':'Piemonte','piedmont':'Piemonte',
        'valledaosta':"Valle d'Aosta/Vallée d'Aoste",'valledaostavalleedaoste':"Valle d'Aosta/Vallée d'Aoste",'aostavalley':"Valle d'Aosta/Vallée d'Aoste",'valleedaoste':"Valle d'Aosta/Vallée d'Aoste",
        'lombardia':'Lombardia','lombardy':'Lombardia',
        'trentinoaltoadige':'Trentino-Alto Adige/Südtirol','trentinoaltoadigesudtirol':'Trentino-Alto Adige/Südtirol','trentinosouthtyrol':'Trentino-Alto Adige/Südtirol','trentino':'Trentino-Alto Adige/Südtirol','sudtirol':'Trentino-Alto Adige/Südtirol',
        'veneto':'Veneto','friuliveneziagiulia':'Friuli-Venezia Giulia','liguria':'Liguria','emiliaromagna':'Emilia-Romagna',
        'toscana':'Toscana','tuscany':'Toscana','umbria':'Umbria','marche':'Marche','marches':'Marche',
        'lazio':'Lazio','latium':'Lazio','abruzzo':'Abruzzo','abruzzi':'Abruzzo','molise':'Molise','campania':'Campania',
        'puglia':'Puglia','apulia':'Puglia','basilicata':'Basilicata','calabria':'Calabria',
        'sicilia':'Sicilia','sicily':'Sicilia','sardegna':'Sardegna','sardinia':'Sardegna'
    };
    function geoNorm(s){ return (s||'').toString().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^a-z]/g,''); }
    function geoCanonRegion(name){ return _regAlias[geoNorm(name)] || null; }
    function geoColor(cnt, maxC){
        if (!cnt || maxC<=0) return 'rgba(255,255,255,0.16)';
        var t=cnt/maxC, c1=[206,238,244], c2=[0,123,145];
        return 'rgb('+Math.round(c1[0]+(c2[0]-c1[0])*t)+','+Math.round(c1[1]+(c2[1]-c1[1])*t)+','+Math.round(c1[2]+(c2[2]-c1[2])*t)+')';
    }
    function topoDecoder(tp){
        var sc=tp.transform.scale, tr=tp.transform.translate;
        var arcs=tp.arcs.map(function(arc){ var x=0,y=0; return arc.map(function(d){ x+=d[0]; y+=d[1]; return [x*sc[0]+tr[0], y*sc[1]+tr[1]]; }); });
        function ac(i){ return i>=0 ? arcs[i] : arcs[~i].slice().reverse(); }
        function ring(r){ var c=[]; r.forEach(function(i,idx){ var a=ac(i); c=c.concat(idx===0?a:a.slice(1)); }); return c; }
        return {
            path: function(geom, proj){
                var polys=geom.type==='MultiPolygon'?geom.arcs:[geom.arcs], d='';
                polys.forEach(function(rings){ rings.forEach(function(rg){ var co=ring(rg); for(var i=0;i<co.length;i++){ var p=proj(co[i][0],co[i][1]); var jump=i>0&&Math.abs(co[i][0]-co[i-1][0])>180; d+=((i===0||jump)?'M':'L')+p[0]+' '+p[1]; } d+='Z'; }); });
                return d;
            },
            bbox: function(geom){
                var polys=geom.type==='MultiPolygon'?geom.arcs:[geom.arcs], x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;
                polys.forEach(function(rings){ rings.forEach(function(rg){ ring(rg).forEach(function(c){ if(c[0]<x0)x0=c[0]; if(c[0]>x1)x1=c[0]; if(c[1]<y0)y0=c[1]; if(c[1]>y1)y1=c[1]; }); }); });
                return [x0,y0,x1,y1];
            }
        };
    }
    // Inquadrature disponibili: [lonMin, latMin, lonMax, latMax]
    var GEO_VIEWS = {
        italia:  [6.0, 35.2, 19.0, 47.6],
        europa:  [-12, 33, 43, 62],
        mondo:   [-180, -80, 180, 80],
        asia:    [38, 4, 150, 56],
        america: [-160, -30, -15, 48]
    };
    // Traduzione nomi nazioni EN→IT (i dati restano in EN per combaciare con la mappa mondiale)
    var GEO_COUNTRY_IT = {
        'Italy':'Italia','Netherlands':'Paesi Bassi','Germany':'Germania','France':'Francia','Spain':'Spagna',
        'Switzerland':'Svizzera','Austria':'Austria','Belgium':'Belgio','United Kingdom':'Regno Unito','Ireland':'Irlanda',
        'United States':'Stati Uniti','United States of America':'Stati Uniti','Portugal':'Portogallo','Poland':'Polonia',
        'Czechia':'Repubblica Ceca','Czech Republic':'Repubblica Ceca','Slovakia':'Slovacchia','Slovenia':'Slovenia',
        'Croatia':'Croazia','Hungary':'Ungheria','Romania':'Romania','Greece':'Grecia','Sweden':'Svezia','Norway':'Norvegia',
        'Denmark':'Danimarca','Finland':'Finlandia','Russia':'Russia','Ukraine':'Ucraina','Turkey':'Turchia','Türkiye':'Turchia',
        'Luxembourg':'Lussemburgo','Malta':'Malta','Iceland':'Islanda','Serbia':'Serbia','Bulgaria':'Bulgaria',
        'Canada':'Canada','Brazil':'Brasile','Argentina':'Argentina','Mexico':'Messico','Australia':'Australia',
        'China':'Cina','Japan':'Giappone','India':'India','Israel':'Israele','Egypt':'Egitto','Morocco':'Marocco',
        'Tunisia':'Tunisia','Albania':'Albania','Estonia':'Estonia','Latvia':'Lettonia','Lithuania':'Lituania',
        'Monaco':'Monaco','San Marino':'San Marino','Cyprus':'Cipro','Bosnia and Herz.':'Bosnia-Erzegovina','North Macedonia':'Macedonia del Nord',
        'The Netherlands':'Paesi Bassi','Holland':'Paesi Bassi','United Arab Emirates':'Emirati Arabi Uniti','South Africa':'Sudafrica','New Zealand':'Nuova Zelanda'
    };
    function geoCountryIT(n){
        if (GEO_COUNTRY_IT[n]) return GEO_COUNTRY_IT[n];
        var s=(n||'').replace(/^The\s+/i,'');           // "The Netherlands" → "Netherlands"
        return GEO_COUNTRY_IT[s] || n;
    }
    // Traduzione nomi città EN→IT (ipapi le restituisce spesso in inglese: Rome, Milan…)
    var GEO_CITY_IT = {
        'Rome':'Roma','Milan':'Milano','Florence':'Firenze','Naples':'Napoli','Turin':'Torino',
        'Venice':'Venezia','Genoa':'Genova','Padua':'Padova','Mantua':'Mantova','Syracuse':'Siracusa',
        'Leghorn':'Livorno','Munich':'Monaco di Baviera','Cologne':'Colonia','Vienna':'Vienna','Geneva':'Ginevra','Zurich':'Zurigo'
    };
    function geoCityIT(n){ return GEO_CITY_IT[n] || n; }

    var _geoView = 'italia';
    var _geoData = { countByReg:{}, maxCReg:0, countries:{}, maxCCountry:0, total:0 };
    function renderGeoMap(){
        var itTopo=window.IF2_IT_TOPO, wTopo=window.IF2_WORLD_TOPO, mapEl=document.getElementById('if2-geo-map'), emptyEl=document.getElementById('if2-geo-map-empty');
        if (!mapEl || !itTopo) return;
        var countByReg=_geoData.countByReg, maxCReg=_geoData.maxCReg, countries=_geoData.countries||{}, maxCCountry=_geoData.maxCCountry||0, total=_geoData.total||0;
        if (emptyEl) emptyEl.style.display = (maxCReg>0 || maxCCountry>0) ? 'none' : '';

        // Box largo: adatto i bounds all'aspect del viewBox così la mappa RIEMPIE il box.
        var W=900, H=440, pad=6;
        var v=GEO_VIEWS[_geoView]||GEO_VIEWS.italia;
        var cx=(v[0]+v[2])/2, cy=(v[1]+v[3])/2, hw=(v[2]-v[0])/2, hh=(v[3]-v[1])/2;
        var k=Math.cos(cy*Math.PI/180);
        var targetA=(W-2*pad)/(H-2*pad), curA=(hw*2*k)/(hh*2);
        if (curA < targetA) { hw = (targetA*(hh*2)/k)/2; } else { hh = ((hw*2*k)/targetA)/2; }
        var vb=[cx-hw, cy-hh, cx+hw, cy+hh];
        var gw=(vb[2]-vb[0])*k, gh=(vb[3]-vb[1]), s=Math.min((W-2*pad)/gw,(H-2*pad)/gh), ox=(W-gw*s)/2, oy=(H-gh*s)/2;
        function proj(lon,lat){ return [Math.round((ox+(lon-vb[0])*k*s)*10)/10, Math.round((oy+(vb[3]-lat)*s)*10)/10]; }
        function overlaps(bb){ return !(bb[2]<vb[0] || bb[0]>vb[2] || bb[3]<vb[1] || bb[1]>vb[3]); }
        function pct(c){ return total>0?Math.round(c/total*100):0; }
        var out='';
        // Nazioni estere: riempite per conteggio (Italia esclusa, la fanno le regioni)
        if (wTopo && wTopo.objects && wTopo.objects.countries){
            var wd=topoDecoder(wTopo);
            wTopo.objects.countries.geometries.forEach(function(geom){
                var nm=geom.properties?geom.properties.name:'';
                if (nm==='Italy') return;
                if (!overlaps(wd.bbox(geom))) return;
                var d=wd.path(geom, proj); if(!d) return;
                var cnt=countries[nm]||0;
                if (cnt>0) out += '<path class="if2-geo-area" data-n="'+geoEsc(geoCountryIT(nm))+'" data-c="'+cnt+'" data-p="'+pct(cnt)+'" d="'+d+'" fill="'+geoColor(cnt,maxCCountry)+'" stroke="#fff" stroke-width="0.5"/>';
                else     out += '<path d="'+d+'" fill="rgba(255,255,255,0.10)" stroke="rgba(255,255,255,0.45)" stroke-width="0.5"/>';
            });
        }
        // Regioni d'Italia (riempite per conteggio) sopra ai contorni
        var idc=topoDecoder(itTopo);
        itTopo.objects.regions.geometries.forEach(function(geom){
            var name=geom.properties.reg_name, cnt=countByReg[name]||0;
            out += '<path class="if2-geo-area" data-n="'+geoEsc(name)+'" data-c="'+cnt+'" data-p="'+pct(cnt)+'" d="'+idc.path(geom, proj)+'" fill="'+geoColor(cnt,maxCReg)+'" stroke="#fff" stroke-width="0.6"/>';
        });
        mapEl.innerHTML='<svg viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="xMidYMid meet" style="width:100%;height:auto;display:block">'+out+'</svg>'
            + '<div id="if2-geo-tip" style="position:absolute;display:none;pointer-events:none;background:rgba(24,24,52,.92);color:#fff;font-size:12px;line-height:1.35;padding:7px 10px;border-radius:6px;white-space:nowrap;z-index:5;box-shadow:0 2px 8px rgba(0,0,0,.25)"></div>';
    }
    // Pulsanti inquadratura
    $(document).on('click', '.if2-geo-view-btn', function(){
        $('.if2-geo-view-btn').removeClass('is-active');
        $(this).addClass('is-active');
        _geoView = $(this).attr('data-view');
        renderGeoMap();
    });
    // Tooltip su hover regione/nazione (#5)
    $(document).on('mousemove', '#if2-geo-map .if2-geo-area', function(ev){
        var tip=document.getElementById('if2-geo-tip'), map=document.getElementById('if2-geo-map');
        if(!tip||!map) return;
        tip.innerHTML='<strong>'+this.getAttribute('data-n')+'</strong><br>'+this.getAttribute('data-c')+' richieste · '+this.getAttribute('data-p')+'%';
        tip.style.display='block';
        var r=map.getBoundingClientRect(), x=ev.clientX-r.left, y=ev.clientY-r.top, tw=tip.offsetWidth;
        tip.style.left=Math.max(4, Math.min(x+14, r.width-tw-6))+'px';
        tip.style.top=Math.max(4, y-12)+'px';
    });
    $(document).on('mouseleave', '#if2-geo-map', function(){ var t=document.getElementById('if2-geo-tip'); if(t) t.style.display='none'; });
    function renderGeoRegions(regions){
        var countByReg={};
        Object.keys(regions||{}).forEach(function(name){ var c=geoCanonRegion(name); if(c) countByReg[c]=(countByReg[c]||0)+(regions[name]||0); });
        var entries=Object.keys(countByReg).map(function(r){return {r:r,c:countByReg[r]};}).filter(function(e){return e.c>0;}).sort(function(a,b){return b.c-a.c;});
        var maxC=entries.length?entries[0].c:0, rtot=_geoData.total||0;
        if (entries.length){
            $('#if2-geo-top-region').text(entries[0].r);
            $('#if2-geo-top-region-pct').text(entries[0].c+' richieste'+(rtot>0?' · '+Math.round(entries[0].c/rtot*100)+'%':''));
        } else { $('#if2-geo-top-region').text('—'); $('#if2-geo-top-region-pct').text(''); }
        // Torta distribuzione regioni (sopra l'istogramma)
        var topR=entries.slice(0,8);
        hDonut('if2-geo-regions-pie', topR.map(function(e){return e.r;}), topR.map(function(e){return e.c;}), PINK_PALETTE);
        // Stesso identico istogramma degli altri due (hBar, stesso rosa)
        hBar('if2-geo-regions-chart', entries.map(function(e){return e.r;}), entries.map(function(e){return e.c;}), 'Richieste', '#D82D6B');
        _geoData.countByReg=countByReg; _geoData.maxCReg=maxC;
        renderGeoMap();
    }
    function loadGeoStats(formId, flt){
        flt = flt || {};
        $.post(ajaxurl, { action:'if2_get_geo_stats', nonce:nonce, form_id: formId||0, period: flt.period||'all', channel: flt.channel||'', lang: flt.lang||'', date_from: flt.date_from||'', date_to: flt.date_to||'' }, function(res){
            if (!res || !res.success || !res.data || !res.data.configured){ $('#if2-section-geo').hide(); return; }
            var g=res.data, total=g.total||0;
            $('#if2-section-geo').show();
            $('.if2-geo-extra').show();
            // Provenienza × valore: soggiorno medio e ospiti medi per regione
            var rv = g.regions_value || [];
            var rvHtml = rv.map(function(r){
                return '<tr>'
                     + '<td>' + geoEsc(geoCanonRegion(r.name) || r.name) + '</td>'
                     + '<td style="text-align:center">' + (parseInt(r.count,10)||0) + '</td>'
                     + '<td style="text-align:center">' + (r.avg_stay != null ? r.avg_stay + ' notti' : '—') + '</td>'
                     + '<td style="text-align:center">' + (r.avg_pax  != null ? r.avg_pax : '—') + '</td>'
                     + '</tr>';
            }).join('');
            $('#if2-geo-value-tbody').html(rvHtml || '<tr><td colspan="4" style="text-align:center;color:#aaa;padding:20px">Nessun dato</td></tr>');
            $('#if2-section-geo-value').toggle(rv.length > 0);
            var cpct  = total>0 && g.top_country_count ? Math.round(g.top_country_count/total*100) : 0;
            var cipct = total>0 && g.top_city_count    ? Math.round(g.top_city_count/total*100)    : 0;
            $('#if2-geo-top-country').text(g.top_country ? geoCountryIT(g.top_country) : '—');
            $('#if2-geo-top-country-sub').text(g.top_country_count ? (g.top_country_count+' richieste · '+cpct+'%') : '');
            $('#if2-geo-top-city').text(g.top_city?geoCityIT(g.top_city):'—');
            $('#if2-geo-top-city-sub').text(g.top_city_count ? (g.top_city_count+' richieste · '+cipct+'%') : '');
            // Box principali delle sezioni torta (nazione/città)
            $('#if2-geo-top-country-2').text(g.top_country ? geoCountryIT(g.top_country) : '—');
            $('#if2-geo-top-country-2-pct').text(g.top_country_count ? (g.top_country_count+' richieste · '+cpct+'%') : '');
            $('#if2-geo-top-city-2').text(g.top_city?geoCityIT(g.top_city):'—');
            $('#if2-geo-top-city-2-pct').text(g.top_city_count ? (g.top_city_count+' richieste · '+cipct+'%') : '');
            var countries=g.countries||[];
            hDonut('if2-geo-countries-pie', countries.map(function(c){return geoCountryIT(c.name);}), countries.map(function(c){return c.count;}), PINK_PALETTE);
            hBar('if2-geo-countries-chart', countries.map(function(c){return geoCountryIT(c.name);}), countries.map(function(c){return c.count;}), 'Richieste', '#D82D6B');
            var cities=g.cities||[];
            hDonut('if2-geo-cities-pie', cities.map(function(c){return geoCityIT(c.name);}), cities.map(function(c){return c.count;}), PINK_PALETTE);
            hBar('if2-geo-cities-chart', cities.map(function(c){return geoCityIT(c.name);}), cities.map(function(c){return c.count;}), 'Richieste', '#E04A82');
            // Dati per la mappa: nazioni estere (#4) + totale per le percentuali
            _geoData.countries = g.countries_all || {};
            var maxCC=0; Object.keys(_geoData.countries).forEach(function(n){ if(n!=='Italy' && _geoData.countries[n]>maxCC) maxCC=_geoData.countries[n]; });
            _geoData.maxCCountry = maxCC; _geoData.total = total;
            renderGeoRegions(g.regions||{});
            loadGeoPeriods(formId, flt);   // tabella richieste per mese (regioni/città/nazioni)
            // Backfill incrementale: se restano IP da geolocalizzare, ricarico tra poco per completarli.
            if (g.pending && g.pending > 0) {
                $('#if2-geo-total').html('· geolocalizzo… '+g.pending+' rimaste');
                clearTimeout(window._if2GeoTimer);
                window._if2GeoTimer = setTimeout(function(){ loadGeoStats(formId, flt); }, 1500);
            } else if (total) {
                var dd = g.debug || {}, tot = dd.rows || total, extra = '';
                if (tot > total) {
                    var parts = [];
                    if (dd.no_ip)  parts.push(dd.no_ip + ' senza IP');
                    if (dd.failed) parts.push(dd.failed + ' non risolti');
                    if (g.pending) parts.push(g.pending + ' in corso');
                    extra = ' su ' + tot + (parts.length ? (' · ' + parts.join(' · ')) : '');
                }
                $('#if2-geo-total').text('· ' + total + ' geolocalizzate' + extra);
            } else {
                var d = g.debug || {};
                var diag = 'richieste ' + (d.rows || 0)
                         + ' · con IP ' + (g.with_ip || 0)
                         + ' · risolti ' + (d.resolved || 0)
                         + ' · falliti ' + (d.failed || 0);
                $('#if2-geo-total').html('0 <span style="font-size:11px;color:#c0392b;font-weight:400">[' + diag + ']</span>');
            }
        });
    }

    // ─── Tabella incrocio: richieste per mese (12) × regione/città/nazione ───
    var GEO_MONTHS = ['Gen','Feb','Mar','Apr','Mag','Giu','Lug','Ago','Set','Ott','Nov','Dic'];
    function geoHeat(v, max){
        if (!v || max<=0) return 'transparent';
        var t=v/max, c1=[251,228,238], c2=[216,45,107];
        return 'rgb('+Math.round(c1[0]+(c2[0]-c1[0])*t)+','+Math.round(c1[1]+(c2[1]-c1[1])*t)+','+Math.round(c1[2]+(c2[2]-c1[2])*t)+')';
    }
    function geoTransform(name, kind){
        if (kind==='nazioni') return geoCountryIT(name);
        if (kind==='città')   return geoCityIT(name);
        if (kind==='regioni')  return geoCanonRegion(name) || name;
        return name;
    }
    function renderGeoTable(elId, rows, kind){
        var el=document.getElementById(elId); if(!el) return;
        if(!rows || !rows.length){ el.innerHTML='<div style="color:#aaa;font-size:12px;padding:8px 0">Nessun dato.</div>'; return; }
        var max=0; rows.forEach(function(r){ (r.months||[]).forEach(function(m){ var v=(m&&m.c)||0; if(v>max)max=v; }); });
        var head='<th style="text-align:left;position:sticky;left:0;background:#fff;padding:5px 8px;color:#999">'+(kind==='regioni'?'Regione':kind==='città'?'Città':'Nazione')+'</th>';
        GEO_MONTHS.forEach(function(m){ head+='<th style="padding:5px 6px;font-weight:600;color:#999;text-align:center">'+m+'</th>'; });
        head+='<th style="padding:5px 8px;color:#181834;text-align:center">Tot</th><th style="padding:5px 8px;color:#999;text-align:left">Sett. top</th>';
        var body='';
        rows.forEach(function(r){
            body+='<tr style="border-top:1px solid #f3f3f3"><td style="text-align:left;font-weight:600;color:#181834;position:sticky;left:0;background:#fff;white-space:nowrap;padding:5px 8px">'+geoEsc(geoTransform(r.name, kind))+'</td>';
            (r.months||[]).forEach(function(m){
                var v=(m&&m.c)||0, bg=geoHeat(v,max), light=(max>0?v/max:0)<0.55;
                body+='<td style="text-align:center;padding:4px 5px"><span style="display:inline-block;min-width:24px;border-radius:4px;background:'+bg+';color:'+(v>0?(light?'#181834':'#fff'):'#ccc')+';font-size:11px;padding:2px 4px">'+(v||'·')+'</span></td>';
            });
            body+='<td style="text-align:center;font-weight:700;color:#d82d6b;padding:5px 8px">'+(r.total||0)+'</td>';
            body+='<td style="text-align:left;color:#555;white-space:nowrap;padding:5px 8px">'+(r.top_week?(geoEsc(r.top_week)+' <span style="color:#aaa">('+r.top_week_count+')</span>'):'—')+'</td></tr>';
        });
        el.innerHTML='<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:11px"><thead><tr style="border-bottom:1px solid #eee">'+head+'</tr></thead><tbody>'+body+'</tbody></table></div>';
    }
    // Config dei 3 dataset (regione / città / nazione): stesso comportamento (tendina + serie + box + confronto)
    var GEO_KINDS = {
        region:  { sel:'if2-geo-region-select',  canvas:'if2-geo-region-series',  top:'if2-geo-reg-top',     topPct:'if2-geo-reg-top-pct',     tot:'if2-geo-reg-total',     pct:'if2-geo-reg-pct',     wk:'if2-geo-reg-week',     wks:'if2-geo-reg-week-sub',     italianOnly:true, tf:function(n){return geoCanonRegion(n)||n;} },
        city:    { sel:'if2-geo-city-select',    canvas:'if2-geo-city-series',    top:'if2-geo-city-top',    topPct:'if2-geo-city-top-pct',    tot:'if2-geo-city-total',    pct:'if2-geo-city-pct',    wk:'if2-geo-city-week',    wks:'if2-geo-city-week-sub',    tf:function(n){return geoCityIT(n);} },
        country: { sel:'if2-geo-country-select', canvas:'if2-geo-country-series', top:'if2-geo-country-top', topPct:'if2-geo-country-top-pct', tot:'if2-geo-country-total', pct:'if2-geo-country-pct', wk:'if2-geo-country-week', wks:'if2-geo-country-week-sub', tf:function(n){return geoCountryIT(n);} }
    };
    var _geoData2  = { region:[], city:[], country:[] };   // periodo principale
    var _geoData2c = { region:[], city:[], country:[] };   // periodo di confronto
    var _geoAll = null, _geoAllC = null;                   // aggregato "Tutti"

    function loadGeoPeriods(formId, flt){
        flt = flt || {};
        _geoData2c = { region:[], city:[], country:[] }; _geoAllC = null;   // reset confronto
        $.post(ajaxurl, { action:'if2_get_geo_periods', nonce:nonce, form_id: formId||0, period: flt.period||'all', channel: flt.channel||'', lang: flt.lang||'', date_from: flt.date_from||'', date_to: flt.date_to||'' }, function(res){
            var d = (res && res.success && res.data) ? res.data : {};
            _geoData2 = { region: d.regions||[], city: d.cities||[], country: d.countries||[] };
            _geoAll = d.all || null;
            Object.keys(GEO_KINDS).forEach(function(k){ populateGeoSelect(k); renderGeoSeries(k); });
            if (flt.compare) loadGeoPeriodsCompare(formId, flt.compare, flt.channel);
        });
    }
    function loadGeoPeriodsCompare(formId, cDates, channel){
        if (!cDates) { _geoData2c={region:[],city:[],country:[]}; _geoAllC=null; Object.keys(GEO_KINDS).forEach(renderGeoSeries); return; }
        $.post(ajaxurl, { action:'if2_get_geo_periods', nonce:nonce, form_id: formId||0, period:'custom', channel: channel||'', date_from: cDates.from, date_to: cDates.to }, function(res){
            var d = (res && res.success && res.data) ? res.data : {};
            _geoData2c = { region: d.regions||[], city: d.cities||[], country: d.countries||[] };
            _geoAllC = d.all || null;
            Object.keys(GEO_KINDS).forEach(renderGeoSeries);
        });
    }
    // Tendina: "— Tutti —" + le voci (regioni: solo italiane)
    function populateGeoSelect(kind){
        var cfg=GEO_KINDS[kind], sel=document.getElementById(cfg.sel); if(!sel) return;
        var rows=_geoData2[kind]||[];
        if (cfg.italianOnly) rows = rows.filter(function(r){ return geoCanonRegion(r.name); });
        var prev=sel.value, allTot = _geoAll ? _geoAll.total : 0;
        var opts = '<option value="__all__">— Tutti — ('+allTot+')</option>'
                 + rows.map(function(r){ return '<option value="'+geoEsc(r.name)+'">'+geoEsc(cfg.tf(r.name))+' ('+r.total+')</option>'; }).join('');
        sel.innerHTML = opts;
        if (prev && (prev==='__all__' || rows.some(function(r){return r.name===prev;}))) sel.value=prev;
    }
    // Serie temporale Gen→Dic + box laterali + linea di confronto ciano
    function renderGeoSeries(kind){
        var cfg=GEO_KINDS[kind], sel=document.getElementById(cfg.sel), ctx=document.getElementById(cfg.canvas);
        if(!sel||!ctx) return;
        var val=sel.value, r=null, rc=null;
        if (val==='__all__' || val===''){ r=_geoAll; rc=_geoAllC; }
        else {
            (_geoData2[kind]||[]).forEach(function(x){ if(x.name===val) r=x; });
            (_geoData2c[kind]||[]).forEach(function(x){ if(x.name===val) rc=x; });
        }
        var grand = _geoAll ? _geoAll.total : 0;
        // Box "principale": entità con più richieste (leader), indipendente dalla selezione
        var rowsK = _geoData2[kind]||[];
        if (cfg.italianOnly) rowsK = rowsK.filter(function(x){ return geoCanonRegion(x.name); });
        var leader = rowsK[0] || null;
        if (leader){ $('#'+cfg.top).text(cfg.tf(leader.name)); $('#'+cfg.topPct).text(leader.total+' richieste · '+(grand>0?Math.round(leader.total/grand*100):0)+'%'); }
        else { $('#'+cfg.top).text('—'); $('#'+cfg.topPct).text(''); }
        if (r){
            var pct = grand>0 ? Math.round(r.total/grand*100) : 0;
            $('#'+cfg.tot).text(r.total+' richieste');
            $('#'+cfg.pct).text(pct+'% sul totale');
            $('#'+cfg.wk).text(r.top_week || '—');
            $('#'+cfg.wks).text(r.top_week ? (r.top_week_count+' richieste') : '');
        } else {
            $('#'+cfg.tot).text('—'); $('#'+cfg.pct).text(''); $('#'+cfg.wk).text('—'); $('#'+cfg.wks).text('');
        }
        if(_hotelCharts[cfg.canvas]){ _hotelCharts[cfg.canvas].destroy(); _hotelCharts[cfg.canvas]=null; }
        if(!r) return;
        var months=r.months||[];
        var datasets=[{ label:'Richieste', data:months.map(function(m){return m.c;}), borderColor:'#d82d6b', backgroundColor:'rgba(216,45,107,0.12)', fill:true, tension:0.35, pointRadius:4, pointHoverRadius:6, pointBackgroundColor:'#d82d6b', borderWidth:2 }];
        if (rc){
            datasets.push({ label:'Confronto', data:(rc.months||[]).map(function(m){return m.c;}), borderColor:'#009bb9', backgroundColor:'rgba(0,155,185,0.10)', fill:true, tension:0.35, pointRadius:3, pointHoverRadius:5, pointBackgroundColor:'#009bb9', borderWidth:2, borderDash:[5,4] });
        }
        _hotelCharts[cfg.canvas]=new Chart(ctx,{
            type:'line',
            data:{ labels:GEO_MONTHS, datasets:datasets },
            options:{ responsive:true, maintainAspectRatio:false,
                plugins:{ legend:{display: rc?true:false, position:'top', labels:{boxWidth:12,font:{size:11},color:'#555'}}, tooltip:{ callbacks:{
                    title:function(items){ return items.length?GEO_MONTHS[items[0].dataIndex]:''; },
                    label:function(c){ var src=(c.datasetIndex===0?months:(rc?rc.months:[])); var m=src[c.dataIndex]||{}; var pre=(c.datasetIndex===0?'':'Confronto — '); var out=[pre+(m.c||0)+' richieste', (m.p||0)+'% del totale']; if(m.tw) out.push('Settimana top: '+m.tw+' ('+m.twc+')'); return out; }
                }}},
                scales:{ x:{grid:{display:false},ticks:{font:{size:11},color:'#888'}}, y:{beginAtZero:true,grid:{color:'#f5f5f5'},ticks:{precision:0,font:{size:11},color:'#aaa'}} }
            }
        });
    }
    $(document).on('change','#if2-geo-region-select',  function(){ renderGeoSeries('region'); });
    $(document).on('change','#if2-geo-city-select',    function(){ renderGeoSeries('city'); });
    $(document).on('change','#if2-geo-country-select', function(){ renderGeoSeries('country'); });

    function renderHotelStats(d) {
        destroyHotelCharts();
        $('#if2-hotel-stats').show();
        $('#if2-section-summary').show();
        $('#if2-total-requests').text(d.total || 0);

        // Soggiorno
        if (d.soggiorno) {
            var s = d.soggiorno;
            $('#if2-section-soggiorno').show();
            $('#if2-avg-stay').text(s.media_giorni + ' giorni');
            $('#if2-stay-count').text('su ' + s.count + ' soggiorni calcolati');
            $('#if2-top-bucket').text(s.top_bucket);
            $('#if2-top-bucket-pct').text(s.top_bucket_pct + ' delle richieste');
            hDonut('if2-chart-stay-pie', s.pie.labels, s.pie.data, PINK_PALETTE);
        } else {
            $('#if2-section-soggiorno').hide();
        }

        // Target
        if (d.target) {
            var tg = d.target;
            $('#if2-section-target').show();
            $('#if2-top-target').text(tg.top);
            $('#if2-top-target-pct').text(tg.top_pct + ' delle richieste');
            $('#if2-top-target-2').text(tg.top);
            $('#if2-top-target-pct-2').text(tg.top_pct + ' delle richieste');
            hDonut('if2-chart-target-pie', tg.pie.labels, tg.pie.data, PINK_PALETTE);
        } else {
            $('#if2-section-target').hide();
            $('#if2-top-target').text('—'); $('#if2-top-target-pct').text('');
        }

        // Periodo — sempre visibile
        var p = d.periodo || { labels: [], data: [], top_month: null, top_week: null, stacked: [], months_pie: { labels: [], data: [] }, weeks_pie: { labels: [], data: [] } };
        $('#if2-section-periodo, #if2-section-periodo-weeks').show();
        $('#if2-top-month').text(p.top_month || '—');
        $('#if2-top-month-pct').text(p.top_month_pct ? p.top_month_pct + ' delle richieste' : '');
        if (p.top_week) {
            $('#if2-top-week').text(p.top_week.label);
            $('#if2-top-week-pct').text(p.top_week.pct + ' delle richieste');
        } else {
            $('#if2-top-week').text('—'); $('#if2-top-week-pct').text('');
        }
        // Months donut
        hDonut('if2-chart-periodo-months', p.months_pie.labels, p.months_pie.data, PINK_PALETTE);
        var mPairs = p.months_pie.labels.map(function(l, i) { return { l: l, d: p.months_pie.data[i] }; });
        mPairs.sort(function(a, b) { return b.d - a.d; });
        hBar('if2-chart-months-bar',
            mPairs.map(function(m) { return m.l; }),
            mPairs.map(function(m) { return m.d; }),
            'Richieste', '#BD1350');
        // Weeks donut
        hDonut('if2-chart-periodo-weeks', p.weeks_pie.labels, p.weeks_pie.data, PINK_PALETTE);
        var wL = p.weeks_pie.labels.slice(0, 5);
        var wD = p.weeks_pie.data.slice(0, 5);
        hBar('if2-chart-weeks-bar', wL, wD, 'Richieste', '#D82D6B');

        // Giorno d'arrivo preferito
        if (d.arrival_day) {
            var ad = d.arrival_day;
            $('#if2-section-arrival-day').show();
            $('#if2-arr-top').text(ad.top);
            $('#if2-arr-top-pct').text(ad.top_pct + ' degli arrivi');
            $('#if2-arr-split').text('Weekend ' + ad.weekend_pct + ' · Infrasett. ' + ad.midweek_pct);
            hBarPct('if2-chart-arrival-day', ad.labels, ad.data, '#D82D6B');
        } else {
            $('#if2-section-arrival-day').hide();
        }

        // Giorno/ora di punta degli invii
        if (d.submit_time) {
            var st = d.submit_time;
            $('#if2-section-submit-time').show();
            $('#if2-subt-top-day').text(st.top_day);
            $('#if2-subt-top-hour').text(st.top_hour);
            hBarPct('if2-chart-submit-day', st.day_labels, st.day_data, '#D82D6B');
            hBarPct('if2-chart-submit-hour', st.hour_labels, st.hour_data, '#D82D6B');
        } else {
            $('#if2-section-submit-time').hide();
        }

        // Booking window
        if (d.booking_window) {
            var bw = d.booking_window;
            $('#if2-bw-summary-box').show();
            $('#if2-top-bw-avg').text(bw.media_giorni + ' gg');
            $('#if2-section-booking-window').show();
            $('#if2-bw-avg').text(bw.media_giorni + ' giorni');
            $('#if2-bw-count').text('su ' + bw.count + ' richieste');
            $('#if2-bw-top').text(bw.top_bucket);
            $('#if2-bw-top-pct').text(bw.top_pct + ' delle richieste');
            hDonut('if2-chart-bw-pie', bw.pie.labels, bw.pie.data, PINK_PALETTE);
        } else {
            $('#if2-bw-summary-box').hide();
            $('#if2-section-booking-window').hide();
        }

        // Canali
        if (d.canali) {
            var cn = d.canali;
            $('#if2-section-canali').show();
            $('#if2-top-canale').text(cn.top);
            $('#if2-top-canale-pct').text(cn.top_pct + ' delle richieste');
            if (cn.tracked !== undefined && d.total && cn.tracked < d.total) {
                $('#if2-canali-tracked').text(cn.tracked + ' su ' + d.total + ' con canale tracciato').show();
            } else {
                $('#if2-canali-tracked').hide();
            }
            hDonut('if2-chart-canali-pie', cn.pie.labels, cn.pie.data, PINK_PALETTE, d.total);
        } else {
            $('#if2-section-canali').hide();
        }

        // Distribuzione trattamento (solo se il form ha il campo trattamento)
        if (d.treatment) {
            var tr = d.treatment;
            $('#if2-section-treatment').show();
            $('#if2-trt-top').text(tr.top);
            $('#if2-trt-top-pct').text(tr.top_pct + ' delle richieste');
            hDonut('if2-chart-treatment-pie', tr.pie.labels, tr.pie.data, PINK_PALETTE);
        } else {
            $('#if2-section-treatment').hide();
        }

        if2NavApply(if2CurrentView); // ri-applica la sezione selezionata nel menu dopo il render
    }

    // ─── SECONDO MENU: navigazione sezioni statistiche ─────────────────────────
    var IF2_NAV_VIEWS = {
        all:           null,
        filtri:        ['#if2-section-summary'],
        riepilogo:     ['#if2-section-summary'],
        soggiorno:     ['#if2-row-soggiorno'],
        mesi:          ['#if2-section-periodo'],
        settimane:     ['#if2-section-periodo-weeks'],
        arrivo:        ['#if2-section-arrival-day', '#if2-section-submit-time'],
        booking:       ['#if2-row-booking'],
        trattamento:   ['#if2-section-treatment'],
        provenienza:   ['#if2-section-geo', '#if2-section-geo-value'],
        nazione:       ['#if2-section-nazioni'],
        regione:       ['#if2-section-regioni'],
        citta:         ['#if2-section-citta'],
        distribuzione: ['#if2-section-distribuzione'],
        analisiform:   ['#if2-stats-content']
    };
    var IF2_NAV_ALL = '#if2-section-summary,#if2-row-soggiorno,#if2-section-periodo,#if2-section-periodo-weeks,#if2-section-arrival-day,#if2-section-submit-time,#if2-row-booking,#if2-section-treatment,#if2-section-geo,#if2-section-geo-value,#if2-section-nazioni,#if2-section-regioni,#if2-section-citta,#if2-section-distribuzione,#if2-stats-content';
    var if2CurrentView = 'all';
    function if2NavApply(view) {
        if (!$('#if2-stats-nav-select').length) return;
        var sel = IF2_NAV_VIEWS[view];
        if (!sel) { $(IF2_NAV_ALL).removeClass('if2-nav-off'); return; } // "Vedi tutti"
        $(IF2_NAV_ALL).addClass('if2-nav-off');
        $(sel.join(',')).removeClass('if2-nav-off');
    }
    $(document).on('change', '#if2-stats-nav-select', function () {
        if2CurrentView = $(this).val();
        if2NavApply(if2CurrentView);
        if (if2CurrentView === 'filtri') window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    // -------------------------------------------------------------------------
    // Statistiche — pulsante CARICA (pagina stats dedicata — per-campo + hotel)
    // -------------------------------------------------------------------------
    // Helper: compute comparison date range
    function getCompareDates(period, compareWith, dateFrom, dateTo) {
        var now = new Date();
        var msDay = 86400000;
        var mainFrom, mainTo, dur;
        if (period === '1s')  { mainTo = now; mainFrom = new Date(+now - 7 * msDay); }
        else if (period === '2s')  { mainTo = now; mainFrom = new Date(+now - 14 * msDay); }
        else if (period === '1m')  { mainTo = now; mainFrom = new Date(+now - 30 * msDay); }
        else if (period === '3m')  { mainTo = now; mainFrom = new Date(+now - 90 * msDay); }
        else if (period === '6m')  { mainTo = now; mainFrom = new Date(+now - 180 * msDay); }
        else if (period === '1a')  { mainTo = now; mainFrom = new Date(+now - 365 * msDay); }
        else if (period === 'custom' && dateFrom && dateTo) { mainFrom = new Date(dateFrom); mainTo = new Date(dateTo); }
        else return null;
        dur = +mainTo - +mainFrom;
        if (compareWith === 'prev') {
            return { from: fmtDate(new Date(+mainFrom - dur)), to: fmtDate(new Date(+mainTo - dur)) };
        } else if (compareWith === 'year') {
            var f2 = new Date(mainFrom); f2.setFullYear(f2.getFullYear() - 1);
            var t2 = new Date(mainTo);   t2.setFullYear(t2.getFullYear() - 1);
            return { from: fmtDate(f2), to: fmtDate(t2) };
        }
        return null;
    }
    function fmtDate(d) {
        return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    }

    // Data-to non può essere prima di data-from
    $(document).on('change', '#if2-stats-date-from', function () {
        var val = $(this).val();
        var $to = $('#if2-stats-date-to');
        $to.attr('min', val || '');
        if (val && $to.val() && $to.val() < val) $to.val(val);
    });

    $(document).on('click', '#if2-load-stats-btn', function () {
        currentFormId = parseInt($('#if2-stats-form-filter').val(), 10) || 0;
        var periodSel = $('#if2-stats-period-select');
        if (periodSel.length) currentRange = periodSel.val() || 'all';
        var dateFrom    = $('#if2-stats-date-from').val() || '';
        var dateTo      = $('#if2-stats-date-to').val()   || '';
        var compareMode = $('#if2-compare-mode').val()    || '';

        // form_id=0 significa "tutti i form" — consentito

        var channelFilter = $('#if2-stats-channel-filter').val() || '';
        var langFilter    = $('#if2-stats-lang-filter').val() || '';
        var $btn = $(this).prop('disabled', true).text('Caricamento…');
        $('#if2-stats-empty').hide();
        $('#if2-stats-content').empty().show();
        $('#if2-hotel-stats').hide();
        $('#if2-compare-badge').text('').removeClass('if2-analytics-box-delta if2-delta-up if2-delta-down');

        // Chiamata per-campo
        var postData = {
            action:  'if2_get_field_stats',
            nonce:   nonce,
            form_id: currentFormId,
            period:  currentRange,
            channel: channelFilter,
            lang:    langFilter,
        };
        if (currentRange === 'custom') { postData.date_from = dateFrom; postData.date_to = dateTo; }

        $.post(ajaxurl, postData, function (res) {
            $btn.prop('disabled', false).text('CARICA');
            if (!res.success || !res.data.fields || !res.data.fields.length) {
                $('#if2-stats-content').hide();
                if (!$('#if2-hotel-stats').is(':visible')) $('#if2-stats-empty').show();
            } else {
                renderFieldStats(res.data.fields, currentFormId === 0);
            }
        });

        // Chiamata analisi hotel — sempre eseguita
        var hp = { action: 'if2_get_hotel_stats', nonce: nonce, form_id: currentFormId,
                   period: currentRange, channel: channelFilter, lang: langFilter,
                   checkin_field:  $('#if2-checkin-field').val()  || '',
                   checkout_field: $('#if2-checkout-field').val() || '',
                   target_field:   $('#if2-target-field').val()   || '' };
        if (currentRange === 'custom') { hp.date_from = dateFrom; hp.date_to = dateTo; }
        $.post(ajaxurl, hp, function (res) {
            if (res.success && res.data) {
                renderHotelStats(res.data);
                loadGeoStats(currentFormId, { period: currentRange, channel: channelFilter, lang: langFilter, date_from: dateFrom, date_to: dateTo, compare: (compareMode ? getCompareDates(currentRange, compareMode, dateFrom, dateTo) : null) });
                $('#if2-stats-empty').hide();

                // Compare
                if (compareMode) {
                    var cDates = getCompareDates(currentRange, compareMode, dateFrom, dateTo);
                    if (cDates) {
                        var hpC = { action: 'if2_get_hotel_stats', nonce: nonce, form_id: currentFormId,
                                    period: 'custom', checkin_field: '', checkout_field: '',
                                    target_field: '', date_from: cDates.from, date_to: cDates.to };
                        $.post(ajaxurl, hpC, function (resC) {
                            if (resC.success && resC.data) {
                                var currTotal = res.data.total || 0;
                                var prevTotal = resC.data.total || 0;
                                var lbl = compareMode === 'year' ? 'anno prec.' : 'periodo prec.';
                                if (prevTotal > 0) {
                                    var diff  = Math.round((currTotal - prevTotal) / prevTotal * 100);
                                    var cls   = diff >= 0 ? 'if2-delta-up' : 'if2-delta-down';
                                    var arrow = diff >= 0 ? '▲' : '▼';
                                    var color = diff >= 0 ? '#27ae60' : '#e74c3c';
                                    var html  = prevTotal + ' (' + lbl + ')' +
                                                '<br><span style="color:' + color + ';font-weight:700">' +
                                                arrow + ' ' + Math.abs(diff) + '%</span>';
                                    $('#if2-compare-badge')
                                        .html(html)
                                        .addClass('if2-analytics-box-delta ' + cls);
                                } else {
                                    $('#if2-compare-badge')
                                        .text('0 (' + lbl + ')')
                                        .addClass('if2-analytics-box-delta');
                                }
                            }
                        });
                    } else {
                        $('#if2-compare-badge').text('Seleziona un periodo specifico per confrontare').css('color', '#aaa');
                    }
                }
            }
        });
    });

    function escHtml(str) {
        return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    function renderFieldStats(fields, allForms) {
        var $container = $('#if2-stats-content').empty();
        if (!fields || !fields.length) { return; }
        $container.append('<div style="font-size:10px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:.07em;padding:6px 0 12px">ANALISI FORM</div>');
        fields.forEach(function (field) {
            var cid  = 'if2-fchart-' + field.id;
            var html = '<div class="if2-field-chart-card">' +
                '<div class="if2-field-chart-header">' +
                '<span class="if2-field-chart-title">' + escHtml(field.label) + '</span>' +
                '<span class="if2-field-chart-count">Risposte analizzate: ' + field.total + '</span>' +
                '</div>' +
                '<div class="if2-field-chart-body"><canvas id="' + cid + '"></canvas></div>' +
                '</div>';
            $container.append(html);

            var ctx = document.getElementById(cid);
            if (!ctx) return;
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: field.labels,
                    datasets: [{
                        label: 'Count',
                        data:  field.data,
                        backgroundColor: 'rgba(216,45,107,0.75)',
                        borderColor:     '#d82d6b',
                        borderWidth: 1,
                        borderRadius: 2,
                    }],
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: { callbacks: { label: function (c) { return ' ' + c.parsed.y; } } }
                    },
                    scales: {
                        x: { grid: { display: false }, ticks: { font: { size: 11 }, color: '#aaa', maxRotation: 45 } },
                        y: { beginAtZero: true, grid: { color: '#f5f5f5' }, ticks: { font: { size: 11 }, color: '#aaa', precision: 0 } },
                    },
                },
            });
        });
    }

    // -------------------------------------------------------------------------
    // Test connessione Supabase (pagina settings)
    // -------------------------------------------------------------------------
    $(document).on('click', '#if2-test-supabase', function () {
        var url = $('input[name="supabase_url"]').val().trim();
        var key = $('input[name="supabase_anon_key"]').val().trim();
        var s    = IF2Admin.strings || {};
        var $res = $('#if2-supabase-test-result').text(s.testing || 'Test in corso…').css('color', '#888');

        if (!url || !key) {
            $res.text(s.insert_url_key || 'Inserisci URL e API Key.').css('color', '#e53e3e');
            return;
        }

        fetch(url + '/rest/v1/form_submissions?limit=1', {
            method:  'GET',
            headers: { 'apikey': key, 'Authorization': 'Bearer ' + key, 'Accept': 'application/json' },
        })
        .then(function (r) {
            // 200 (service_role), 401/403 con anon+RLS = chiave valida ma SELECT non permessa (ok)
            if (r.ok || r.status === 401 || r.status === 403) {
                $res.text(s.connection_ok || '✓ Connessione OK').css('color', '#38a169');
            } else {
                $res.text((s.connection_error || '✗ Errore ') + r.status).css('color', '#e53e3e');
            }
        })
        .catch(function () {
            $res.text(s.connection_failed || '✗ Connessione fallita').css('color', '#e53e3e');
        });
    });

    // -------------------------------------------------------------------------
    // Test connessione Amelia / SMSHosting (pagina settings)
    // -------------------------------------------------------------------------
    $(document).on('click', '#if2-test-amelia', function () {
        var key    = $('#if2_amelia_key').val().trim();
        var secret = $('#if2_amelia_secret').val().trim();
        var apiurl = $('#if2_amelia_apiurl').val().trim() || 'https://api.smsgatewayapi.com/v1';
        var $res   = $('#if2-amelia-test-result').text('Test in corso…').css('color', '#888');

        if (!key || !secret) {
            $res.text('Inserisci Auth Key e Auth Secret.').css('color', '#e53e3e');
            return;
        }

        $.post(ajaxurl, {
            action: 'if2_test_amelia',
            nonce:  nonce,
            key:    key,
            secret: secret,
            apiurl: apiurl,
        }, function (res) {
            if (res.success) {
                $res.text(res.data.message || '✓ Connessione OK').css('color', '#38a169');
            } else {
                $res.text(res.data.message || '✗ Connessione fallita').css('color', '#e53e3e');
            }
        }).fail(function () {
            $res.text('✗ Errore di rete').css('color', '#e53e3e');
        });
    });

    // Test aggiungi contatto Amelia
    $(document).on('click', '#if2-test-amelia-contact', function () {
        var key    = $('#if2_amelia_key').val().trim();
        var secret = $('#if2_amelia_secret').val().trim();
        var apiurl = $('#if2_amelia_apiurl').val().trim() || 'https://api.smshosting.it/rest/api';
        var listid = $('#if2_amelia_listid').val().trim();
        var phone  = $('#if2-amelia-test-phone').val().trim();
        var $res   = $('#if2-amelia-contact-result').text('Test in corso…').css('color', '#888');

        $.post(ajaxurl, { action: 'if2_test_amelia_contact', nonce: nonce, key: key, secret: secret, apiurl: apiurl, listid: listid, phone: phone }, function (res) {
            if (res.success) {
                $res.text(res.data.message || '✓ OK').css('color', '#38a169');
            } else {
                $res.text(res.data.message || '✗ Errore').css('color', '#e53e3e');
            }
        }).fail(function () {
            $res.text('✗ Errore di rete').css('color', '#e53e3e');
        });
    });

    // -------------------------------------------------------------------------
    // Amelia — liste multi-paese (pagina Impostazioni)
    // -------------------------------------------------------------------------
    var IF2_AMELIA_COUNTRIES = [
        { value: 'IT',    label: 'IT — Italia (.it)' },
        { value: 'DE',    label: 'DE — Germania (.de, .at, .ch)' },
        { value: 'FR',    label: 'FR — Francia (.fr)' },
        { value: 'EN',    label: 'EN — UK / Internazionale (.uk, .co.uk, .com, .ie)' },
        { value: 'CZ',    label: 'CZ — Repubblica Ceca (.cz)' },
        { value: 'PL',    label: 'PL — Polonia (.pl)' },
        { value: 'RO',    label: 'RO — Romania (.ro)' },
        { value: 'CA',    label: 'CA — Canada (.ca)' },
        { value: 'ES',    label: 'ES — Spagna (.es)' },
        { value: 'ALTRO', label: 'ALTRO — Altri' },
    ];

    function buildAmeliaCountrySelect(selectedVal) {
        var html = '<select name="if2_amelia_list_country[]" style="padding:4px 6px;border:1px solid #ccc;border-radius:3px;font-size:13px">';
        IF2_AMELIA_COUNTRIES.forEach(function (c) {
            html += '<option value="' + c.value + '"' + (c.value === selectedVal ? ' selected' : '') + '>' + c.label + '</option>';
        });
        html += '</select>';
        return html;
    }

    function buildAmeliaListRow(listid, country) {
        return '<tr>' +
            '<td style="padding:4px 0"><input type="text" name="if2_amelia_list_id[]" value="' + (listid || '') + '" placeholder="es. 42" style="width:120px;padding:4px 6px;border:1px solid #ccc;border-radius:3px;font-size:13px"></td>' +
            '<td style="padding:4px 0 4px 10px">' + buildAmeliaCountrySelect(country || 'IT') + '</td>' +
            '<td style="padding:4px 0 4px 8px"><button type="button" class="if2-amelia-remove-list" style="background:none;border:none;color:#d82d6b;cursor:pointer;font-size:16px;padding:0 4px;line-height:1" title="Rimuovi">✕</button></td>' +
            '</tr>';
    }

    $(document).on('click', '#if2-amelia-add-list', function () {
        $('#if2-amelia-lists-tbody').append(buildAmeliaListRow('', 'IT'));
    });

    $(document).on('click', '.if2-amelia-remove-list', function () {
        $(this).closest('tr').remove();
    });

    // -------------------------------------------------------------------------
    // Toggle label dinamico anti-spam
    // -------------------------------------------------------------------------
    $(document).on('change', '.if2-toggle input[type="checkbox"]', function () {
        var label = $(this).closest('.if2-toggle').find('.if2-toggle-label');
        var s = IF2Admin.strings || {};
        label.text($(this).is(':checked') ? (s.active || 'Attivo') : (s.inactive || 'Disattivo'));
    });

    // -------------------------------------------------------------------------
    // Risposte — NASCONDI CAMPI VUOTI (default: nascosti)
    // -------------------------------------------------------------------------
    var emptyHidden = true;
    function applyEmptyState() {
        var s = IF2Admin.strings || {};
        $('.if2-sub-grid-field.if2-field-empty').toggleClass('if2-hidden', emptyHidden);
        $('#if2-toggle-empty').text(emptyHidden ? (s.show_empty_fields || 'MOSTRA CAMPI VUOTI') : (s.hide_empty_fields || 'NASCONDI CAMPI VUOTI'));
    }
    $(document).ready(function () { applyEmptyState(); });
    $(document).on('click', '#if2-toggle-empty', function () {
        emptyHidden = !emptyHidden;
        applyEmptyState();
    });

    // -------------------------------------------------------------------------
    // Risposte — STAMPA
    // -------------------------------------------------------------------------
    $(document).on('click', '#if2-print-sub', function () {
        window.print();
    });

    // -------------------------------------------------------------------------
    // Risposte — ricerca nella lista sinistra
    // -------------------------------------------------------------------------
    $(document).on('input', '#if2-search-submissions', function () {
        var q = $(this).val().toLowerCase();
        $('#if2-submissions-table tbody tr').each(function () {
            var text = $(this).text().toLowerCase();
            $(this).toggle(!q || text.indexOf(q) !== -1);
        });
    });

    // -------------------------------------------------------------------------
    // Submissions — ordina per data di creazione
    // -------------------------------------------------------------------------
    $(document).on('click', '#if2-sub-sort-created', function () {
        var $ico    = $('#if2-sub-sort-ico');
        var $tbody  = $('#if2-submissions-table tbody');
        var $rows   = $tbody.find('tr.if2-form-row');
        var curDir  = $(this).data('sort-dir') || 'desc';
        var asc     = (curDir === 'desc');
        $rows.sort(function (a, b) {
            var ta = parseInt($(a).data('ts'), 10) || 0;
            var tb = parseInt($(b).data('ts'), 10) || 0;
            return asc ? ta - tb : tb - ta;
        });
        $tbody.append($rows);
        $(this).data('sort-dir', asc ? 'asc' : 'desc');
        $ico.text(asc ? '↑' : '↓').css('color', '#d82d6b');
    });

    // -------------------------------------------------------------------------
    // Risposte — export CSV dal pannello sinistro
    // -------------------------------------------------------------------------
    $(document).on('click', '#if2-export-sub', function (e) {
        e.preventDefault();
        var fid = parseInt($(this).data('form-id'), 10) || 0;
        downloadCSV(fid, fid ? 'if2-form-' + fid + '-submissions.csv' : 'if2-all-submissions.csv');
    });

    // -------------------------------------------------------------------------
    // Risposte — elimina e torna alla lista
    // -------------------------------------------------------------------------
    $(document).on('click', '.if2-delete-submission', function () {
        var id = $(this).data('id');
        if (!confirm('Eliminare questa submission?')) return;
        var $row = $('#if2-submissions-table tr[data-sub-id="' + id + '"]');

        $.post(ajaxurl, { action: 'if2_delete_submission', nonce: nonce, submission_id: id }, function (res) {
            if (res.success) {
                if ($row.length) {
                    $row.fadeOut(300, function () { $(this).remove(); });
                } else {
                    // Siamo nel pannello destro — torna alla lista
                    var url = window.location.href.replace(/&sub_id=\d+/, '');
                    window.location.href = url;
                }
            } else {
                alert('Errore eliminazione submission.');
            }
        });
    });

    // -------------------------------------------------------------------------
    // Sorting colonne DATA CREAZIONE e ULTIMA MODIFICA nella tabella Form
    // -------------------------------------------------------------------------
    var $formsTable = $('#if2-forms-table');
    var originalRowOrder = null; // saved on first sort

    function saveOriginalOrder() {
        if (originalRowOrder !== null) return;
        originalRowOrder = $formsTable.find('tbody tr:not(.if2-empty-row)').toArray().map(function (r) { return r; });
    }

    function restoreOriginalOrder() {
        if (!originalRowOrder) return;
        var $tbody = $formsTable.find('tbody');
        $.each(originalRowOrder, function (i, row) { $tbody.append(row); });
    }

    function applySort(tdClass, icoId, activeCol) {
        saveOriginalOrder();
        var $tbody = $formsTable.find('tbody');
        var $rows  = $tbody.find('tr:not(.if2-empty-row)').toArray();

        // Reset both icons
        $('#if2-sort-ico').text('↕').css('color', '#bbb');
        $('#if2-sort-ico-created').text('↕').css('color', '#bbb');

        // If already sorted asc by this col → restore original
        if ($formsTable.data('sort-col') === activeCol) {
            $formsTable.removeData('sort-col');
            restoreOriginalOrder();
            return;
        }

        // Sort ascending (oldest → newest)
        $rows.sort(function (a, b) {
            var ta = parseInt($(a).find('td.' + tdClass).data('ts'), 10) || 0;
            var tb = parseInt($(b).find('td.' + tdClass).data('ts'), 10) || 0;
            return ta - tb;
        });
        $.each($rows, function (i, row) { $tbody.append(row); });
        $formsTable.data('sort-col', activeCol);
        $(icoId).text('↑').css('color', '#d82d6b');
    }

    $('#if2-sort-date').on('click', function () {
        applySort('if2-form-date', '#if2-sort-ico', 'date');
    });
    $('#if2-sort-created').on('click', function () {
        applySort('if2-form-created', '#if2-sort-ico-created', 'created');
    });

    // -------------------------------------------------------------------------
    // Equalizza altezza pannelli nella pagina Forms
    // -------------------------------------------------------------------------
    function equalizeFormPanels() {
        var $left  = $('.if2-panel-forms');
        var $right = $('.if2-panel-stats');
        if (!$left.length || !$right.length) return;
        $left[0].style.minHeight = '';
        var h = $right.outerHeight(true);
        if (h > $left.outerHeight(true)) $left[0].style.minHeight = h + 'px';
    }

    // -------------------------------------------------------------------------
    // Avvio
    // -------------------------------------------------------------------------
    // Equalizza pannelli nella pagina Risposte (server-rendered, no chart)
    if ($('.if2-panel-forms').length && $('.if2-panel-stats').length && !$('#if2-stats-chart').length) {
        equalizeFormPanels();
        setTimeout(equalizeFormPanels, 150);
        setTimeout(equalizeFormPanels, 500);
        $(window).on('load', equalizeFormPanels);
        if (window.ResizeObserver && $('.if2-panel-stats')[0]) {
            new ResizeObserver(equalizeFormPanels).observe($('.if2-panel-stats')[0]);
        }
    }

    // Carica stats solo nella dashboard Forms (non nella pagina Statistiche dedicata)
    if ($('#if2-stats-chart').length && !$('#if2-load-stats-btn').length) {
        loadStats();
        setTimeout(equalizeFormPanels, 200);
        setTimeout(equalizeFormPanels, 800);
        $(window).on('load', equalizeFormPanels);
        // Ogni volta che il pannello stats cambia altezza, ricalcola
        if (window.ResizeObserver && $('.if2-panel-stats')[0]) {
            new ResizeObserver(equalizeFormPanels).observe($('.if2-panel-stats')[0]);
        }
    }

});
