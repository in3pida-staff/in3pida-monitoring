<?php
defined('ABSPATH') || exit;

class IF2_Ajax {

    public static function init(): void {
        add_action('wp_ajax_if2_submit',           [self::class, 'submit']);
        add_action('wp_ajax_nopriv_if2_submit',    [self::class, 'submit']);
        add_action('wp_ajax_if2_run_integrations',        [self::class, 'run_integrations_request']);
        add_action('wp_ajax_nopriv_if2_run_integrations', [self::class, 'run_integrations_request']);
        add_action('wp_ajax_if2_get_form',         [self::class, 'get_form']);
        add_action('wp_ajax_if2_save_form',        [self::class, 'save_form']);
        add_action('wp_ajax_if2_new_form',         [self::class, 'new_form']);
        add_action('wp_ajax_if2_rename_form',      [self::class, 'rename_form']);
        add_action('wp_ajax_if2_delete_form',      [self::class, 'delete_form']);
        add_action('wp_ajax_if2_get_submissions',  [self::class, 'get_submissions']);
        add_action('wp_ajax_if2_delete_submission',[self::class, 'delete_submission']);
        add_action('wp_ajax_if2_upload_file',      [self::class, 'upload_file']);
        add_action('wp_ajax_if2_get_stats',        [self::class, 'get_stats']);
        add_action('wp_ajax_if2_forms_report',     [self::class, 'forms_report']);
        add_action('wp_ajax_if2_reset_stats',      [self::class, 'reset_stats']);
        add_action('wp_ajax_if2_export_data',      [self::class, 'export_data']);
        add_action('wp_ajax_if2_get_field_stats',    [self::class, 'get_field_stats']);
        add_action('wp_ajax_if2_send_test_email',    [self::class, 'send_test_email']);
        add_action('wp_ajax_if2_get_hotel_stats',    [self::class, 'get_hotel_stats']);
        add_action('wp_ajax_if2_get_geo_stats',      [self::class, 'get_geo_stats']);
        add_action('wp_ajax_if2_get_geo_periods',    [self::class, 'get_geo_periods']);
        add_action('wp_ajax_if2_test_amelia',         [self::class, 'test_amelia']);
        add_action('wp_ajax_if2_test_amelia_contact', [self::class, 'test_amelia_contact']);
        add_action('wp_ajax_if2_retry_supabase',      [self::class, 'retry_supabase']);
        add_action('wp_ajax_if2_retry_crm',           [self::class, 'retry_crm']);
        add_action('wp_ajax_if2_retry_amelia',        [self::class, 'retry_amelia']);
    }

    // -------------------------------------------------------------------------
    // Frontend: invio form
    // -------------------------------------------------------------------------

    public static function submit(): void {
        check_ajax_referer('if2_submit_' . (int) $_POST['if2_form_id'], 'if2_nonce');

        $form_id = (int) $_POST['if2_form_id'];
        $form    = IF2_Form::get($form_id);
        if (!$form) wp_send_json_error(['message' => 'Form non trovato.']);

        $config  = $form['config'];
        $fields  = $form['fields'];

        // Honeypot
        if (get_option('if2_honeypot_enabled', 1) && !empty($_POST['if2_hp_field'])) {
            wp_send_json_success(['message' => $config['success_message'] ?? 'Grazie!', 'redirect' => '', 'redirect_delay' => 0]);
            return;
        }

        // Rate limiting per IP
        if (get_option('if2_antispam_enabled', 1)) {
            $limit = max(1, (int) get_option('if2_antispam_limit', 5));
            $ip    = isset($_SERVER['HTTP_X_FORWARDED_FOR'])
                     ? sanitize_text_field(trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]))
                     : sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '');
            $tk    = 'if2_rate_' . md5($ip . '_' . $form_id);
            $count = (int) get_transient($tk);
            if ($count >= $limit) {
                wp_send_json_error(['message' => 'Troppi invii. Riprova più tardi.']);
            }
            set_transient($tk, $count + 1, HOUR_IN_SECONDS);
        }

        $data   = [];
        $errors = [];

        foreach ($fields as $field) {
            $ftype    = $field['type'] ?? 'text';
            $fid      = $field['id'];
            $required = !empty($field['required']);

            if (in_array($ftype, ['page_break', 'html', 'heading', 'submit'], true)) continue;

            if ($ftype === 'checkbox') {
                $val = array_map(fn($v) => sanitize_text_field(wp_unslash($v)), (array) ($_POST[$fid] ?? []));
            } elseif ($ftype === 'file') {
                if ($required && (!isset($_FILES[$fid]) || ($_FILES[$fid]['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK)) {
                    $errors[$fid] = sprintf('Il campo "%s" è obbligatorio.', $field['label'] ?? $fid);
                }
                continue;
            } elseif ($ftype === 'matrix') {
                $rows = $field['matrix_rows'] ?? [];
                $val  = [];
                foreach ($rows as $r_idx => $row_label) {
                    $row_key         = $fid . '_row_' . $r_idx;
                    $val[$row_label] = sanitize_text_field(wp_unslash($_POST[$row_key] ?? ''));
                }
            } else {
                $val = sanitize_text_field(wp_unslash($_POST[$fid] ?? ''));
            }

            if ($required && ($val === '' || $val === [])) {
                $errors[$fid] = sprintf('Il campo "%s" è obbligatorio.', $field['label'] ?? $fid);
            }

            if ($ftype === 'email' && $val !== '' && !is_email($val)) {
                $errors[$fid] = 'Inserisci un indirizzo email valido.';
            }

            $data[$fid] = $val;
        }

        // Validazione date (DEFAULT per TUTTI i form): la partenza non può essere prima dell'arrivo.
        $date_fields = array_values(array_filter($fields, fn($f) => in_array($f['type'] ?? '', ['date', 'datepicker'], true)));
        if (count($date_fields) >= 2) {
            $ci = null; $co = null;
            foreach ($date_fields as $df) {
                $lbl = remove_accents(strtolower((string) ($df['label'] ?? '')));
                if ($ci === null && (strpos($lbl, 'arriv') !== false || strpos($lbl, 'check-in') !== false || strpos($lbl, 'checkin') !== false)) { $ci = $df; continue; }
                if ($co === null && (strpos($lbl, 'partenz') !== false || strpos($lbl, 'check-out') !== false || strpos($lbl, 'checkout') !== false)) { $co = $df; }
            }
            if (!$ci || !$co) { $ci = $date_fields[0]; $co = $date_fields[1]; } // fallback: i primi due in ordine
            $tci = self::date_ts($data[$ci['id']] ?? '');
            $tco = self::date_ts($data[$co['id']] ?? '');
            if ($tci && $tco && $tco <= $tci) {
                $errors[$co['id']] = 'La data di partenza deve essere successiva all\'arrivo.';
            }
        }

        if (!empty($errors)) {
            wp_send_json_error(['errors' => $errors]);
        }

        // Gestione upload file (salvati prima della submission, collegati dopo)
        $uploaded_file_ids = [];
        foreach ($fields as $field) {
            if (($field['type'] ?? '') !== 'file') continue;
            $fid = $field['id'];
            if (!isset($_FILES[$fid]) || $_FILES[$fid]['error'] !== UPLOAD_ERR_OK) continue;
            $allowed_types = self::get_allowed_mime_types($field['accept'] ?? '');
            $file_info     = wp_check_filetype(basename($_FILES[$fid]['name']), $allowed_types);
            if (!$file_info['type']) continue;
            $max_mb = (int) ($field['max_size_mb'] ?? 5);
            if ($_FILES[$fid]['size'] > $max_mb * 1024 * 1024) continue;
            $upload    = wp_upload_dir();
            $dir       = trailingslashit($upload['basedir']) . 'if2-uploads/' . $form_id . '/';
            wp_mkdir_p($dir);
            $filename  = wp_unique_filename($dir, sanitize_file_name($_FILES[$fid]['name']));
            $file_path = $dir . $filename;
            if (!move_uploaded_file($_FILES[$fid]['tmp_name'], $file_path)) continue;
            $file_url  = trailingslashit($upload['baseurl']) . 'if2-uploads/' . $form_id . '/' . $filename;
            $wpdb->insert(IF2_DB::files_table(), [
                'form_id'   => $form_id,
                'field_id'  => $fid,
                'filename'  => $filename,
                'file_url'  => $file_url,
                'file_path' => $file_path,
                'mime_type' => $file_info['type'],
                'file_size' => (int) $_FILES[$fid]['size'],
            ]);
            $file_id = (int) $wpdb->insert_id;
            if ($file_id) {
                $uploaded_file_ids[] = $file_id;
                $data[$fid] = $file_url;
            }
        }

        // Meta
        $meta = [];
        if (!empty($_POST['_channel']))  $meta['channel']  = sanitize_text_field($_POST['_channel']);
        if (!empty($_POST['_hotel_id'])) $meta['hotel_id'] = sanitize_text_field($_POST['_hotel_id']);

        // IP salvato SEMPRE: serve alla provenienza (geolocalizzazione). È solo lato server, non mostrato all'utente.
        $ip = isset($_SERVER['HTTP_X_FORWARDED_FOR'])
              ? sanitize_text_field(trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]))
              : sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '');
        if ($ip !== '') $meta['ip'] = $ip;
        if (!empty($_POST['_source_url'])) {
            $meta['source_url'] = esc_url_raw($_POST['_source_url']);
        }

        // Esclusione statistiche: le richieste fatte dallo STAFF in3pida (email @in3pida.it) NON vanno MAI
        // contate in nessuna statistica/grafico (totali, hotel, campi, geo, dashboard monitoring). La richiesta
        // viene comunque salvata e inviata al CRM (i test devono funzionare): è solo invisibile alle statistiche.
        foreach ($fields as $f) {
            if (($f['type'] ?? '') !== 'email') continue;
            $ev = trim((string) ($data[$f['id']] ?? ''));
            if ($ev !== '' && preg_match('/@in3pida\.it$/i', $ev)) { $meta['staff'] = true; break; }
        }

        $submission_id = IF2_Submission::save($form_id, $data, $meta);

        // Se il salvataggio nel database FALLISCE (tabella corrotta/struttura sbagliata/colonna troppo piccola),
        // NON proseguiamo con le integrazioni — altrimenti l'invio gira a vuoto. Mostriamo l'errore REALE del DB,
        // così si capisce subito la causa invece di vedere uno spinner infinito.
        if (!$submission_id) {
            global $wpdb;
            $db_err = $wpdb->last_error ?: 'inserimento non riuscito (submission_id = 0)';
            error_log('[IF2] Salvataggio submission FALLITO su form ' . $form_id . ' — DB: ' . $db_err);
            wp_send_json_error(['message' => 'Errore database: ' . $db_err]);
        }

        if ($uploaded_file_ids && $submission_id) {
            $ids_in = implode(',', array_map('intval', $uploaded_file_ids));
            $wpdb->query($wpdb->prepare(
                "UPDATE " . IF2_DB::files_table() . " SET submission_id = %d WHERE id IN ({$ids_in})",
                $submission_id
            ));
        }

        do_action('if2_after_submit', $form_id, $data, $meta, $submission_id);

        // Redirect calcolato subito (serve nella risposta): logica condizionale (no HTTP) > thankyou > redirect_url
        $redirect = self::logic_redirect($config, $data);
        if ($redirect === '') {
            $redirect = !empty($config['thankyou_url'])  ? esc_url_raw($config['thankyou_url'])
                      : (!empty($config['redirect_url']) ? esc_url_raw($config['redirect_url']) : '');
        }
        // Invio integrazioni: SEMPRE IN BACKGROUND (loopback non bloccante) per TUTTI i siti, così
        // il submit risponde SEMPRE subito e non gira mai a vuoto, anche se un'integrazione (email/Supabase/
        // Amelia/webhook) è lenta o si pianta. NON dipende più dal feature flag (che su alcuni siti era
        // spento e rendeva l'invio bloccante e lentissimo). Solo se la submission non si salva → inline.
        if ($submission_id) {
            // TUTTE le integrazioni (webhook + CRM + email + Amelia + Supabase + logica) in BACKGROUND, via
            // loopback con timeout DURO di 1s: l'invio risponde SEMPRE entro ~1s e non può MAI girare a vuoto,
            // qualunque integrazione si impianti (anche un webhook "chiamata a sé stesso" che si blocca).
            $bg_token = wp_generate_password(20, false);
            set_transient('if2_bg_' . $submission_id, $bg_token, 5 * MINUTE_IN_SECONDS);
            self::fire_loopback($submission_id, $bg_token, 'all');
        }
        // (Se la submission non si salva, sopra abbiamo già risposto con l'errore DB e ci siamo fermati.)

        wp_send_json_success([
            'message'        => wp_kses_post($config['success_message'] ?? 'Grazie!'),
            'redirect'       => $redirect,
            'redirect_delay' => (int) ($config['redirect_delay'] ?? 0),
        ]);
    }

    /**
     * Spedisce una POST in FIRE-AND-FORGET con fsockopen e timeout DURO sulla connessione: scrive la
     * richiesta e chiude, NON aspetta la risposta. Non può MAI impiccare l'invio (niente spinner infinito),
     * e se il destinatario è raggiungibile la richiesta arriva comunque. Ritorna true se è partita.
     */
    private static function fire_post(string $url, array $body, float $timeout = 3.0): bool {
        $p = wp_parse_url($url);
        if (empty($p['host'])) return false;
        $ssl  = (($p['scheme'] ?? 'http') === 'https');
        $host = $p['host'];
        $port = (int) ($p['port'] ?? ($ssl ? 443 : 80));
        $path = ($p['path'] ?? '/') . (isset($p['query']) ? '?' . $p['query'] : '');
        $payload = http_build_query($body);
        $errno = 0; $errstr = '';
        $fp = @fsockopen(($ssl ? 'ssl://' : '') . $host, $port, $errno, $errstr, $timeout); // connessione: max $timeout
        if (!$fp) return false;
        $req  = "POST {$path} HTTP/1.1\r\n";
        $req .= "Host: {$host}\r\n";
        $req .= "Content-Type: application/x-www-form-urlencoded\r\n";
        $req .= "Content-Length: " . strlen($payload) . "\r\n";
        $req .= "Connection: Close\r\n\r\n";
        $req .= $payload;
        @stream_set_timeout($fp, (int) ceil($timeout));
        @fwrite($fp, $req);
        @fclose($fp); // non aspettiamo la risposta
        return true;
    }

    /** Loopback per le integrazioni lente (email/Supabase). Fire-and-forget, non impicca mai l'invio. */
    private static function fire_loopback(int $submission_id, string $token, string $mode = 'rest'): void {
        self::fire_post(admin_url('admin-ajax.php'), [
            'action'        => 'if2_run_integrations',
            'submission_id' => $submission_id,
            'token'         => $token,
            'mode'          => $mode,
        ], 1.0);
    }

    /** Handler della richiesta loopback in background: ricarica la submission ed esegue le integrazioni. */
    public static function run_integrations_request(): void {
        // PRIMA di tutto: non farti uccidere quando il chiamante (loopback non bloccante) si disconnette.
        @ignore_user_abort(true);
        @set_time_limit(120);

        $submission_id = (int) ($_REQUEST['submission_id'] ?? 0);
        $token         = isset($_REQUEST['token']) ? (string) $_REQUEST['token'] : '';
        if (!$submission_id || $token === '') { wp_die('', '', ['response' => 400]); }
        $expected = get_transient('if2_bg_' . $submission_id);
        if (!$expected || !hash_equals((string) $expected, $token)) { wp_die('', '', ['response' => 403]); }
        delete_transient('if2_bg_' . $submission_id);

        $sub = IF2_Submission::get_one($submission_id);
        if (!$sub) { wp_die(); }
        $form_id = (int) ($sub['form_id'] ?? 0);
        $data    = json_decode($sub['data'] ?? '[]', true) ?: [];
        $meta    = json_decode($sub['meta'] ?? '[]', true) ?: [];
        $form    = $form_id ? IF2_Form::get($form_id) : null;
        if (!$form) { wp_die(); }
        $config  = (array) ($form['config'] ?? []);
        $fields  = (array) ($form['fields'] ?? []);

        $mode = in_array(($_REQUEST['mode'] ?? ''), ['rest', 'crm', 'all'], true) ? (string) $_REQUEST['mode'] : 'rest';
        self::run_integrations($form, $data, $meta, $config, $submission_id, $form_id, $fields, $mode);
        wp_die();
    }

    /** Email + integrazioni (webhook/Amelia/Supabase/CRM/azioni logica) — eseguite in background dopo la risposta. */
    private static function run_integrations(array $form, array $data, array $meta, array $config, int $submission_id, int $form_id, array $fields, string $mode = 'all'): void {
        // Richiesta dello STAFF in3pida (email @in3pida.it, marcata in meta['staff']): le integrazioni
        // (webhook/CRM/Amelia/email) girano comunque, ma NON va conteggiata in nessuna statistica del
        // monitoring (mon_events/mon_integration_stats). Il flag copre tutto il flusso del loopback.
        IF2_Telemetry::$skip = !empty($meta['staff']);

        $do_crm  = ($mode === 'all' || $mode === 'crm');   // webhook + CRM nativi → SINCRONI (immediati, come il vecchio script)
        $do_rest = ($mode === 'all' || $mode === 'rest');  // email + Amelia + Supabase + azioni logica → in background

        // (L'email è spostata in fondo: è la più lenta e meno critica → prima webhook/CRM/dati.)

        // === INTEGRATION LOG ===
        $integration_log = [];

        // Webhook (es. vecchio script CRM tipo mrpreno-insert.php): gira IN BACKGROUND (fase 'rest'), NON
        // durante l'invio. Motivo: spesso punta a uno script sullo STESSO server (chiamata a sé stesso) che
        // su alcuni server si impianta → NON deve bloccare l'invio dell'utente. In background può essere
        // bloccante (consegna affidabile + pallino con esito vero). 5xx = entrato (come HotelDoor).
        if ($do_rest) {
            if (!empty($config['webhook_url'])) {
                $webhook_data = [];
                foreach ($form['fields'] as $wf) {
                    $fid = $wf['id'] ?? '';
                    if (!array_key_exists($fid, $data)) continue;
                    $key = !empty($wf['alt_label']) ? sanitize_text_field($wf['alt_label']) : $fid;
                    $val = $data[$fid];
                    $webhook_data[$key] = is_array($val) ? implode(', ', $val) : (string) $val;
                }
                $webhook_data['form_id']       = $form_id;
                $webhook_data['submission_id'] = $submission_id;
                $webhook_data['channel']       = $meta['channel']  ?? '';
                $webhook_data['hotel_id']      = $meta['hotel_id'] ?? '';

                $resp = wp_remote_post(esc_url_raw($config['webhook_url']), ['body' => $webhook_data, 'timeout' => 10, 'blocking' => true, 'sslverify' => false]);
                if (is_wp_error($resp)) {
                    $integration_log['webhook'] = ['status' => 'error', 'code' => 0, 'message' => $resp->get_error_message()];
                } else {
                    $code = (int) wp_remote_retrieve_response_code($resp);
                    $ok   = !($code >= 400 && $code < 500); // 5xx = entrato; errore reale solo 4xx
                    $integration_log['webhook'] = ['status' => $ok ? 'ok' : 'error', 'code' => $code, 'message' => $ok ? '' : substr(wp_remote_retrieve_body($resp), 0, 120)];
                }
                IF2_Telemetry::track_crm_result($integration_log['webhook']);
            } else {
                $integration_log['webhook'] = ['status' => 'disabled'];
            }
        }

        if ($do_crm): // Amelia + Supabase girano SINCRONI col CRM, così i pallini DB/AM si registrano subito
        // Amelia / SMSHosting
        $amelia_log = ['status' => 'disabled'];
        $amelia_key    = get_option('if2_amelia_key', '');
        $amelia_secret = get_option('if2_amelia_secret', '');
        $amelia_listid = get_option('if2_amelia_listid', '');        // fallback globale singolo
        $amelia_apiurl = rtrim(get_option('if2_amelia_apiurl', 'https://api.smshosting.it/rest/api'), '/');
        $amelia_lists  = json_decode(get_option('if2_amelia_lists', '[]'), true) ?: [];

        // TLD → codice paese
        $if2_tld_map = [
            'it' => 'IT', 'de' => 'DE', 'at' => 'DE', 'ch' => 'DE',
            'fr' => 'FR', 'uk' => 'EN', 'ie' => 'EN', 'com' => 'EN',
            'cz' => 'CZ', 'pl' => 'PL', 'ro' => 'RO', 'ca' => 'CA', 'es' => 'ES',
        ];

        // Risolve il List ID corretto per un'email:
        // 1) TLD dell'email → paese → lista corrispondente
        // 2) Lista di default del form
        // 3) Fallback: List ID globale singolo
        $if2_resolve_listid = function(string $email) use ($amelia_lists, $amelia_listid, $config, $if2_tld_map): string {
            if ($email && !empty($amelia_lists)) {
                $domain  = substr($email, strrpos($email, '@') + 1);
                $tld     = strtolower(substr($domain, strrpos($domain, '.') + 1));
                if (substr($domain, -6) === '.co.uk') $tld = 'uk';
                $country = $if2_tld_map[$tld] ?? null;
                if ($country) {
                    foreach ($amelia_lists as $list) {
                        if (($list['country'] ?? '') === $country && !empty($list['listid'])) {
                            return $list['listid'];
                        }
                    }
                }
            }
            $form_default = $config['amelia_default_list'] ?? '';
            if ($form_default) return $form_default;
            return $amelia_listid;
        };

        $if2_dbg = function(string $msg): void {
            error_log('[if2-amelia] ' . $msg);
        };

        $has_any_list = $amelia_listid || !empty($amelia_lists);
        $if2_dbg('[IF2 Amelia] --- AVVIO form_id=' . $form_id . ' credenziali=' . ($amelia_key && $amelia_secret && $has_any_list ? 'OK' : 'MANCANTI'));

        if ($amelia_key && $amelia_secret && $has_any_list) {
            $consent_field = null;
            $phone_field   = null;
            $email_field   = null;
            $name_field    = null;

            // Solo parole "marketing": la casella privacy/trattamento (obbligatoria) NON è un consenso marketing
            $consent_keywords = ['marketing','newsletter','sms','promo','promozion','offert','pubblicit'];
            $phone_keywords   = ['telefon','cellu','phone','mobile','cel','tel'];
            $name_keywords    = ['nome','cognome','name','surname','nominativo'];

            // Priorità assoluta: il campo con il flag esplicito "Amelia Consenso" è IL consenso.
            // Solo se nessun campo ha il flag si usa il fallback per parole chiave.
            foreach ($fields as $f) {
                if (!empty($f['amelia_consent'])) { $consent_field = $f; break; }
            }
            $has_consent_flag = $consent_field !== null;

            foreach ($fields as $f) {
                $flabel = mb_strtolower(($f['label'] ?? '') . ' ' . ($f['alt_label'] ?? ''));
                $ftype  = $f['type'] ?? '';

                if (!empty($f['amelia_phone'])   && $phone_field   === null) { $phone_field   = $f; }
                if (!empty($f['amelia_name'])    && $name_field    === null) { $name_field    = $f; }
                if ($ftype === 'email'            && $email_field   === null) { $email_field   = $f; }

                if ($name_field === null && in_array($ftype, ['text','textarea'], true)) {
                    foreach ($name_keywords as $kw) {
                        if (strpos($flabel, $kw) !== false) { $name_field = $f; break; }
                    }
                }
                // Fallback per parole chiave SOLO se nessun campo ha il flag "Amelia Consenso"
                if (!$has_consent_flag && $consent_field === null && $ftype === 'checkbox') {
                    $opts_text = mb_strtolower(implode(' ', array_column($f['options'] ?? [], 'label')));
                    $search    = $flabel . ' ' . $opts_text;
                    foreach ($consent_keywords as $kw) {
                        if (strpos($search, $kw) !== false) { $consent_field = $f; break; }
                    }
                }
                if ($phone_field === null && in_array($ftype, ['text','tel','phone','number'], true)) {
                    foreach ($phone_keywords as $kw) {
                        if (strpos($flabel, $kw) !== false) { $phone_field = $f; break; }
                    }
                }
            }

            $if2_dbg('[IF2 Amelia] consent_field=' . ($consent_field ? $consent_field['id'] . '(' . ($consent_field['label'] ?? '') . ')' : 'NON TROVATO')
                . ' phone_field=' . ($phone_field ? $phone_field['id'] . '(' . ($phone_field['label'] ?? '') . ')' : 'NON TROVATO')
                . ' email_field=' . ($email_field ? $email_field['id'] . '(' . ($email_field['label'] ?? '') . ')' : 'NON TROVATO'));

            if ($consent_field !== null) {
                $consent_raw  = $data[$consent_field['id']] ?? '';
                $consent_flat = is_array($consent_raw) ? implode('', $consent_raw) : (string) $consent_raw;
                $is_consented = $consent_flat !== '' && $consent_flat !== '0' && $consent_flat !== 'false';

                $if2_dbg('[IF2 Amelia] consent_raw=' . print_r($consent_raw, true) . ' is_consented=' . ($is_consented ? 'SI' : 'NO'));

                if (!$is_consented) {
                    $if2_dbg('[IF2 Amelia] Consenso non dato — contatto NON aggiunto.');
                    $amelia_log = ['status' => 'skipped', 'message' => 'consenso non dato'];
                } else {
                    // Legge telefono; se assente, fisso o non valido si userà un numero fake.
                    // L'unico vero blocco per Amelia è il consenso marketing (gestito sopra).
                    $fake_phone = false;
                    $phone_val  = '';
                    if ($phone_field !== null) {
                        $phone_val = trim(is_array($data[$phone_field['id']] ?? '') ? implode('', $data[$phone_field['id']]) : (string)($data[$phone_field['id']] ?? ''));
                        $phone_val = preg_replace('/[\s\-\.\(\)]+/', '', $phone_val);
                        if (str_starts_with($phone_val, '+'))   $phone_val = substr($phone_val, 1);
                        if (str_starts_with($phone_val, '00'))  $phone_val = substr($phone_val, 2);
                        $phone_val = preg_replace('/\D+/', '', $phone_val); // rimuove lettere e caratteri non numerici
                        if (str_starts_with($phone_val, '0')) $phone_val = ''; // fisso italiano → userà fake
                        if (str_starts_with($phone_val, '3') && strlen($phone_val) === 10) $phone_val = '39' . $phone_val;
                    }

                    $email_val       = $email_field ? trim(is_array($data[$email_field['id']] ?? '') ? implode('', $data[$email_field['id']]) : (string)($data[$email_field['id']] ?? '')) : '';
                    $resolved_listid = $if2_resolve_listid($email_val);

                    if (!$resolved_listid) {
                        $if2_dbg('[IF2 Amelia] Nessuna lista trovata per email=' . $email_val . ' — contatto NON aggiunto.');
                        $amelia_log = ['status' => 'skipped', 'message' => 'nessuna lista trovata'];
                    } else {
                        // Numero fisso/non normalizzabile → usa fake
                        if (!$phone_val) { $phone_val = '393471234567'; $fake_phone = true; }

                        // Corpo base — il msisdn viene aggiunto all'invio
                        $body = ['groupsId' => $resolved_listid];
                        if ($email_val) { $body['email'] = $email_val; }
                        if ($name_field) {
                            $name_raw = trim(is_array($data[$name_field['id']] ?? '') ? implode(' ', $data[$name_field['id']]) : (string)($data[$name_field['id']] ?? ''));
                            if ($name_raw !== '') {
                                $parts = explode(' ', $name_raw, 2);
                                $body['name']     = $parts[0];
                                if (!empty($parts[1])) $body['lastname'] = $parts[1];
                            }
                        }

                        $send_amelia = function ($msisdn) use ($amelia_apiurl, $amelia_key, $amelia_secret, $body) {
                            $b = $body; $b['msisdn'] = $msisdn;
                            $resp = wp_remote_post($amelia_apiurl . '/phonebook/contact', [
                                'headers'  => ['Authorization' => 'Basic ' . base64_encode($amelia_key . ':' . $amelia_secret)],
                                'body'     => $b,
                                'timeout'  => 8,
                                'blocking' => true,
                            ]);
                            return [
                                'wp_error' => is_wp_error($resp),
                                'code'     => is_wp_error($resp) ? 0 : wp_remote_retrieve_response_code($resp),
                                'body'     => is_wp_error($resp) ? $resp->get_error_message() : wp_remote_retrieve_body($resp),
                            ];
                        };

                        $if2_dbg('[IF2 Amelia] Invio contatto: msisdn=' . $phone_val . ' email=' . $email_val . ' listid=' . $resolved_listid . ' (tld routing)');
                        $r = $send_amelia($phone_val);

                        // Numero rifiutato come non valido (es. prefisso inesistente) → retry col fake
                        if (!$fake_phone && $r['code'] == 400 && strpos($r['body'], 'BAD_CONTACT_MSISDN') !== false) {
                            $if2_dbg('[IF2 Amelia] Numero non valido (' . $phone_val . ') — retry con fake.');
                            $phone_val  = '393471234567';
                            $fake_phone = true;
                            $r          = $send_amelia($phone_val);
                        }

                        $code      = $r['code'];
                        $body_resp = $r['body'];
                        $if2_dbg('[IF2 Amelia] Risposta API: HTTP ' . $code . ' — ' . $body_resp);
                        $amelia_already = strpos($body_resp, 'CONTACT_ALREADY_EXISTS') !== false
                            || strpos(strtolower($body_resp), 'already exist') !== false;
                        if ($r['wp_error'] || $code === 0 || $code >= 500) {
                            // Errore di rete o server — critico
                            $amelia_log = ['status' => 'error', 'code' => $code, 'message' => substr($body_resp, 0, 120)];
                        } elseif ($amelia_already || $code === 409) {
                            // Contatto duplicato — non critico
                            $amelia_log = ['status' => 'info', 'code' => $code, 'message' => 'già presente'];
                        } elseif ($code >= 400) {
                            // Errore API Amelia — critico, il contatto non è stato aggiunto
                            $amelia_log = ['status' => 'error', 'code' => $code, 'message' => substr($body_resp, 0, 120)];
                        } else {
                            $amelia_log = ['status' => 'ok', 'code' => $code, 'message' => 'aggiunto'];
                        }
                        if ($fake_phone && in_array($amelia_log['status'], ['ok', 'info'], true)) {
                            $amelia_log['fake_phone'] = true;
                        }
                    }
                }
            } else {
                $if2_dbg('[IF2 Amelia] Nessun campo consenso trovato — integrazione saltata.');
                $amelia_log = ['status' => 'skipped', 'message' => 'nessun campo consenso'];
            }
        }

        $integration_log['amelia'] = $amelia_log;
        if ($submission_id) IF2_Submission::update_meta_log($submission_id, $integration_log); // DIAGNOSTICO: dopo Amelia

        // Supabase — blocking, cattura risultato nel log
        IF2_Extensions::$last_supabase_result = null;
        do_action('if2_submit_extensions', $form, $data, $meta, $submission_id);
        $integration_log['supabase'] = IF2_Extensions::$last_supabase_result ?? ['status' => 'disabled'];
        if ($submission_id) IF2_Submission::update_meta_log($submission_id, $integration_log); // DIAGNOSTICO: dopo Supabase
        endif; // fine $do_crm (Amelia + Supabase, sincroni come il CRM)

        // CRM nativi (HotelDoor/MrPreno) — SINCRONI/blocking, come il vecchio script → entrano subito.
        if ($do_crm) {
            $crm_logs        = IF2_CRM::dispatch($form, $data, $meta, $submission_id);
            $integration_log = array_merge($integration_log, $crm_logs);
        }

        // Salva il log (merge: non sovrascrive le parti già salvate dall'altra fase).
        IF2_Submission::update_meta_log($submission_id, $integration_log);

        if ($do_rest) {
            // Email per ULTIMA: è la più lenta (SMTP) e meno critica. Se si impianta, webhook/CRM/dati sono già fatti.
            IF2_Submission::send_notification($form, $data, $submission_id, $meta);
            IF2_Submission::send_autoresponder($form, $data, $submission_id);
            do_action('if2_submission_done', $submission_id, $form_id, $integration_log);
            // Azioni logica che fanno chiamate (Invia email / Attiva integrazione).
            self::process_logic_actions($config, $data, $meta, $fields);
        }
    }

    /** Data (DD/MM/YYYY, YYYY-MM-DD, ecc.) → intero YYYYMMDD per confronto. 0 se vuota/non valida. */
    private static function date_ts(string $d): int {
        $d = trim($d);
        if ($d === '') return 0;
        if (preg_match('#^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$#', $d, $m)) {   // DD/MM/YYYY
            return (int) sprintf('%04d%02d%02d', (int) $m[3], (int) $m[2], (int) $m[1]);
        }
        if (preg_match('#^(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})$#', $d, $m)) {     // YYYY-MM-DD
            return (int) sprintf('%04d%02d%02d', (int) $m[1], (int) $m[2], (int) $m[3]);
        }
        $ts = strtotime($d);
        return $ts ? (int) gmdate('Ymd', $ts) : 0;
    }

    /** Redirect da azione logica "Reindirizza a" (solo valutazione condizioni, nessuna chiamata HTTP). '' se nessuna. */
    private static function logic_redirect(array $config, array $data): string {
        foreach (($config['logic_rules'] ?? []) as $rule) {
            if (!is_array($rule) || ($rule['action_type'] ?? '') !== 'redirect') continue;
            if (!self::logic_rule_met($rule, $data)) continue;
            $url = esc_url_raw((string) ($rule['action_url'] ?? ''));
            if ($url) return $url;
        }
        return '';
    }

    // -------------------------------------------------------------------------
    // Logica: valutazione condizioni + azioni server-side
    // -------------------------------------------------------------------------

    private static function logic_cond_met(array $cond, array $data): bool {
        $fid = (string) ($cond['field'] ?? '');
        $op  = (string) ($cond['op'] ?? 'equals');
        $exp = (string) ($cond['value'] ?? '');
        $act = $data[$fid] ?? '';
        if (is_array($act)) $act = implode(', ', $act);
        $act = (string) $act;
        switch ($op) {
            case 'equals':       return $act === $exp;
            case 'not_equals':   return $act !== $exp;
            case 'contains':     return $exp !== '' && stripos($act, $exp) !== false;
            case 'not_contains': return $exp === '' || stripos($act, $exp) === false;
            case 'is_empty':     return $act === '';
            case 'not_empty':    return $act !== '';
        }
        return false;
    }

    /** Tutte le condizioni della regola devono essere vere (AND). */
    private static function logic_rule_met(array $rule, array $data): bool {
        $conds = $rule['conditions'] ?? [];
        if (empty($conds) || !is_array($conds)) return false;
        foreach ($conds as $c) {
            if (!is_array($c) || !self::logic_cond_met($c, $data)) return false;
        }
        return true;
    }

    /**
     * Esegue le azioni logica server-side (Reindirizza / Invia email / Attiva integrazione).
     * Ogni azione è isolata: un errore non blocca mai l'invio del form.
     */
    private static function process_logic_actions(array $config, array $data, array $meta, array $fields): array {
        $out   = ['redirect' => ''];
        $rules = $config['logic_rules'] ?? [];
        if (!is_array($rules)) return $out;

        // Mappa id → label per email leggibili
        $labels = [];
        foreach ($fields as $f) {
            if (!empty($f['id'])) $labels[$f['id']] = $f['label'] ?? $f['id'];
        }

        foreach ($rules as $rule) {
            if (!is_array($rule)) continue;
            $type = $rule['action_type'] ?? '';
            if (!in_array($type, ['redirect', 'send_email', 'webhook'], true)) continue;
            if (!self::logic_rule_met($rule, $data)) continue;
            try {
                if ($type === 'redirect') {
                    $url = esc_url_raw((string) ($rule['action_url'] ?? ''));
                    if ($url) $out['redirect'] = $url;
                } elseif ($type === 'send_email') {
                    $to = sanitize_email((string) ($rule['action_email'] ?? ''));
                    if (is_email($to)) {
                        $body = '<p>Nuova richiesta dal form.</p><table cellpadding="6" style="border-collapse:collapse">';
                        foreach ($data as $k => $v) {
                            if (is_array($v)) $v = implode(', ', $v);
                            $lbl  = $labels[$k] ?? $k;
                            $body .= '<tr><td style="border:1px solid #eee"><strong>' . esc_html($lbl) . '</strong></td><td style="border:1px solid #eee">' . esc_html((string) $v) . '</td></tr>';
                        }
                        $body   .= '</table>';
                        $headers = ['Content-Type: text/html; charset=UTF-8'];
                        if (!empty($config['email_from_name']) && !empty($config['email_from'])) {
                            $headers[] = 'From: ' . sanitize_text_field($config['email_from_name']) . ' <' . sanitize_email($config['email_from']) . '>';
                        }
                        IF2_Submission::send_mail($config, $to, 'Nuova richiesta dal form', $body, $headers);
                    }
                } elseif ($type === 'webhook') {
                    $url = esc_url_raw((string) ($rule['action_url'] ?? ''));
                    if ($url) {
                        wp_remote_post($url, [
                            'timeout'  => 8,
                            'blocking' => false,
                            'headers'  => ['Content-Type' => 'application/json'],
                            'body'     => wp_json_encode(['data' => $data, 'meta' => $meta]),
                        ]);
                    }
                }
            } catch (\Throwable $e) { /* non bloccare mai l'invio */ }
        }
        return $out;
    }

    // -------------------------------------------------------------------------
    // Admin: gestione form
    // -------------------------------------------------------------------------

    public static function get_form(): void {
        self::check_admin_nonce();
        $id   = (int) $_POST['form_id'];
        $form = IF2_Form::get($id);
        $form ? wp_send_json_success($form) : wp_send_json_error(['message' => 'Form non trovato.']);
    }

    public static function save_form(): void {
        self::check_admin_nonce();
        $id     = (int) $_POST['form_id'];
        $fields = json_decode(stripslashes($_POST['fields'] ?? '[]'), true) ?: [];
        $config = json_decode(stripslashes($_POST['config'] ?? '{}'), true) ?: [];
        // Sincronizza il NOME REALE del form (quello del riepilogo) con "Nome form" (AVANZATE)
        $form_name = isset($config['form_name']) ? sanitize_text_field((string) $config['form_name']) : '';
        $config = self::sanitize_config($config);
        if ($form_name !== '') {
            IF2_Form::rename($id, $form_name);
        }
        IF2_Form::save($id, $fields, $config)
            ? wp_send_json_success()
            : wp_send_json_error(['message' => 'Salvataggio fallito.']);
    }

    public static function new_form(): void {
        self::check_admin_nonce();
        $name = sanitize_text_field($_POST['name'] ?? 'Nuovo form');
        $id   = IF2_Form::create($name);
        $id ? wp_send_json_success(['id' => $id]) : wp_send_json_error();
    }

    public static function rename_form(): void {
        self::check_admin_nonce();
        $id   = (int) $_POST['form_id'];
        $name = sanitize_text_field($_POST['name'] ?? '');
        IF2_Form::rename($id, $name) ? wp_send_json_success() : wp_send_json_error();
    }

    public static function delete_form(): void {
        self::check_admin_nonce();
        $id = (int) $_POST['form_id'];
        self::cleanup_form_files($id);
        IF2_Form::delete($id) ? wp_send_json_success() : wp_send_json_error();
    }

    public static function get_submissions(): void {
        self::check_admin_nonce();
        $form_id = (int) $_POST['form_id'];
        $page    = max(1, (int) ($_POST['page'] ?? 1));
        $limit   = 20;
        $offset  = ($page - 1) * $limit;
        $rows    = IF2_Submission::get_all($form_id, $limit, $offset);
        $total   = IF2_Submission::count($form_id);
        foreach ($rows as &$row) {
            $row['data'] = json_decode($row['data'], true) ?: [];
            $row['meta'] = json_decode($row['meta'], true) ?: [];
        }
        wp_send_json_success([
            'rows'  => $rows,
            'total' => $total,
            'pages' => (int) ceil($total / $limit),
        ]);
    }

    public static function delete_submission(): void {
        self::check_admin_nonce();
        $id = (int) $_POST['submission_id'];
        self::cleanup_submission_files($id);
        IF2_Submission::delete($id) ? wp_send_json_success() : wp_send_json_error();
    }

    // -------------------------------------------------------------------------
    // Statistiche
    // -------------------------------------------------------------------------

    /** Statistiche di provenienza: geolocalizza gli IP già salvati nelle richieste locali (cache per-IP, backfill incrementale). */
    /** Richieste dell'hotel per la provenienza: dal DB LOCALE (è già per-hotel; ha IP dei nuovi invii e
     *  la data di Arrivo). Completa l'IP mancante da Supabase per entry_id. Ritorna [['ip'=>, 'ts'=>], …]. */
    private static function geo_collect_requests(int $form_id, string $period = 'all', string $channel = '', string $from = '', string $to = ''): array {
        global $wpdb;
        $sb = IF2_DB::submissions_table();
        // Filtro: form + PERIODO (stessa logica di get_hotel_stats) — il canale lo filtro in PHP.
        $conds = [];
        if ($form_id) $conds[] = $wpdb->prepare('form_id = %d', $form_id);
        $days = ['1s'=>7, '2s'=>14, '1m'=>30, '3m'=>90, '6m'=>180, '1a'=>365];
        if (isset($days[$period])) {
            $conds[] = $wpdb->prepare('created_at >= %s', date('Y-m-d H:i:s', strtotime('-' . $days[$period] . ' days')));
        } elseif ($period === 'custom') {
            if ($from !== '') $conds[] = $wpdb->prepare('created_at >= %s', date('Y-m-d 00:00:00', strtotime($from)));
            if ($to   !== '') $conds[] = $wpdb->prepare('created_at <= %s', date('Y-m-d 23:59:59', strtotime($to)));
        }
        $where = $conds ? (' WHERE ' . implode(' AND ', $conds)) : '';
        $rows  = $wpdb->get_results("SELECT id, form_id, data, meta, created_at FROM {$sb}{$where} ORDER BY id DESC LIMIT 5000", ARRAY_A);
        if (!is_array($rows)) $rows = [];
        $rows  = self::drop_staff($rows); // escludi richieste staff in3pida dalle stat di provenienza

        $ci_cache = [];
        $out = [];
        foreach ($rows as $r) {
            $id   = (int) $r['id'];
            $meta = json_decode($r['meta'] ?? '', true);
            if ($channel !== '' && mb_strtolower((string) (is_array($meta) ? ($meta['channel'] ?? '') : '')) !== mb_strtolower($channel)) continue;
            $ip   = is_array($meta) ? trim((string) ($meta['ip'] ?? '')) : '';
            $data = json_decode($r['data'] ?? '', true) ?: [];
            $fid  = (int) $r['form_id'];
            if (!array_key_exists($fid, $ci_cache)) $ci_cache[$fid] = self::detect_checkin_field($fid);
            $cf   = $ci_cache[$fid];
            $ts   = ($cf !== '' && !empty($data[$cf])) ? self::parse_date((string) $data[$cf]) : 0;          // data di ARRIVO (soggiorno)
            $sub  = !empty($r['created_at']) ? (int) strtotime($r['created_at']) : 0;                          // data di INVIO della richiesta
            $out[$id] = ['ip' => $ip, 'ts' => $ts, 'sub_ts' => $sub];
        }

        // Completa l'IP mancante da Supabase, agganciando per entry_id (= id locale). Uso DUE scope per
        // catturare anche le righe vecchie: per hotel_id (stabile) E per dominio (righe con hotel_id vuoto).
        $sb_url = get_option('if2_supabase_url', '') ?: get_option('in3pida_supabase_url', '');
        $sb_key = if2_decrypt( get_option('if2_supabase_anon_key', '') ) ?: get_option('in3pida_supabase_key', '');
        if ($sb_url && $sb_key) {
            $hotel_id = (string) get_option('if2_hotel_id', '');
            $host     = preg_replace('/^www\./i', '', (string) (wp_parse_url(get_site_url(), PHP_URL_HOST) ?: ''));
            $scopes = [];
            if ($hotel_id !== '') $scopes[] = 'hotel_id=eq.' . rawurlencode($hotel_id);
            if ($host !== '')     $scopes[] = 'domain=ilike.*' . rawurlencode($host) . '*';
            $fill = function ($rows_sb) use (&$out) {
                foreach ($rows_sb as $row) {
                    $eid = (int) ($row['entry_id'] ?? 0);
                    $rip = trim((string) ($row['ip'] ?? ''));
                    if ($eid && $rip && isset($out[$eid]) && $out[$eid]['ip'] === '') $out[$eid]['ip'] = $rip;
                }
            };
            foreach ($scopes as $scope) {
                foreach (['compilazioni', 'form_submissions'] as $table) {
                    $q = trailingslashit($sb_url) . 'rest/v1/' . $table . '?select=entry_id,ip&limit=5000&' . $scope;
                    $resp = wp_remote_get($q, ['timeout' => 8, 'headers' => ['apikey' => $sb_key, 'Authorization' => 'Bearer ' . $sb_key]]);
                    if (!is_wp_error($resp) && wp_remote_retrieve_response_code($resp) === 200) {
                        $d = json_decode(wp_remote_retrieve_body($resp), true);
                        if (is_array($d)) { $fill($d); break; }   // questo scope ha risposto: passo allo scope successivo
                    }
                }
            }
        }
        return array_values($out);
    }

    /** Trova l'id del campo data di arrivo (check-in) di un form. */
    private static function detect_checkin_field(int $form_id): string {
        $form = IF2_Form::get($form_id);
        if (!$form || empty($form['fields'])) return '';
        $first_dp = '';
        foreach ($form['fields'] as $f) {
            $type = $f['type'] ?? '';
            if ($type !== 'datepicker' && $type !== 'date') continue;
            $fid = (string) ($f['id'] ?? '');
            if ($fid === '') continue;
            if ($first_dp === '') $first_dp = $fid;
            $lbl = strtolower(($f['alt_label'] ?? '') . ' ' . ($f['label'] ?? ''));
            if (strpos($lbl, 'arriv') !== false || strpos($lbl, 'check') !== false) return $fid;
        }
        return $first_dp;
    }

    public static function get_geo_stats(): void {
        self::check_admin_nonce();
        $form_id = (int) ($_POST['form_id'] ?? 0);
        $period  = sanitize_key($_POST['period'] ?? 'all');
        $channel = sanitize_text_field($_POST['channel'] ?? '');
        $gfrom   = sanitize_text_field($_POST['date_from'] ?? '');
        $gto     = sanitize_text_field($_POST['date_to'] ?? '');

        // Sorgente: DB LOCALE (per-hotel) + supplemento IP da Supabase. Filtrata per periodo/canale.
        $reqs = self::geo_collect_requests($form_id, $period, $channel, $gfrom, $gto);
        if (!$reqs) { wp_send_json_success(['configured' => false]); return; }
        $records = [];
        foreach ($reqs as $rq) $records[] = ['ip' => $rq['ip'], 'country' => '', 'city' => '', 'region' => ''];
        $dbg = ['src' => 'local', 'rows' => count($records)];

        // Cache persistente IP → geo (anche vuoto = "già tentato"); geolocalizzo pochi IP nuovi per
        // chiamata (con budget di tempo) per non andare in timeout. Il resto si completa ai reload.
        $cache = get_option('if2_geo_ip_cache', []);
        if (!is_array($cache)) $cache = [];
        $cap_new = 25; $new_done = 0; $cache_dirty = false; $t_start = microtime(true);

        $countries = []; $cities = []; $regions = []; $geo_total = 0; $pending = 0; $with_ip = 0; $failed = 0;
        foreach ($records as $rec) {
            $c = $rec['country']; $ci = $rec['city']; $re = $rec['region']; $ip = $rec['ip'];
            // Se la geo non è già nota, la ricavo dall'IP (cache + backfill incrementale).
            if ($c === '' && $ci === '' && $re === '') {
                if ($ip === '') continue;
                $with_ip++;
                $entry     = $cache[$ip] ?? null;
                $is_failed = is_array($entry) && isset($entry['_fail']);
                $need = ($entry === null) || ($is_failed && (time() - (int) $entry['_fail']) > 1800);
                if ($need) {
                    if ($new_done >= $cap_new || (microtime(true) - $t_start) > 12) { $pending++; continue; }
                    $g = IF2_Extensions::geolocate_ip($ip);
                    $new_done++; $cache_dirty = true;
                    $cache[$ip] = (!empty($g['country']) || !empty($g['city']) || !empty($g['region']))
                                  ? $g : ['_fail' => time()];
                    $entry = $cache[$ip];
                }
                if (!is_array($entry) || isset($entry['_fail'])) { if (is_array($entry) && isset($entry['_fail'])) $failed++; continue; }
                $c  = trim((string) ($entry['country'] ?? ''));
                $ci = trim((string) ($entry['city']    ?? ''));
                $re = trim((string) ($entry['region']  ?? ''));
            } else {
                $with_ip++;
            }
            if ($c === '' && $ci === '' && $re === '') continue;
            $geo_total++;
            if ($c  !== '') $countries[$c] = ($countries[$c] ?? 0) + 1;
            if ($ci !== '') $cities[$ci]   = ($cities[$ci]   ?? 0) + 1;
            if ($re !== '') $regions[$re]  = ($regions[$re]  ?? 0) + 1;
        }
        if ($cache_dirty) {
            if (count($cache) > 6000) $cache = array_slice($cache, -5000, null, true);
            update_option('if2_geo_ip_cache', $cache, false);
        }
        arsort($countries); arsort($cities); arsort($regions);

        $top_country = $countries ? array_key_first($countries) : '';
        $top_city    = $cities    ? array_key_first($cities)    : '';
        $top_cities  = [];
        foreach (array_slice($cities, 0, 5, true) as $name => $cnt) $top_cities[] = ['name' => $name, 'count' => $cnt];
        $top_countries = [];
        foreach (array_slice($countries, 0, 5, true) as $name => $cnt) $top_countries[] = ['name' => $name, 'count' => $cnt];

        wp_send_json_success([
            'configured'        => true,
            'total'             => $geo_total,
            'pending'           => $pending,
            'with_ip'           => $with_ip,
            'rows'              => count($records),
            'debug'             => array_merge($dbg, ['resolved' => $geo_total, 'failed' => $failed, 'no_ip' => count($records) - $with_ip]),
            'top_country'       => $top_country,
            'top_country_count' => $top_country ? $countries[$top_country] : 0,
            'top_city'          => $top_city,
            'top_city_count'    => $top_city ? $cities[$top_city] : 0,
            'countries'         => $top_countries,
            'countries_all'     => (object) $countries,   // tutte le nazioni col conteggio (per colorare la mappa)
            'cities'            => $top_cities,
            'regions'           => (object) $regions,
        ]);
    }

    /** Tabella incrocio provenienza × periodo: per regione/città/nazione, richieste per mese (12) + settimana più richiesta. */
    public static function get_geo_periods(): void {
        self::check_admin_nonce();
        $form_id = (int) ($_POST['form_id'] ?? 0);
        $period  = sanitize_key($_POST['period'] ?? 'all');
        $channel = sanitize_text_field($_POST['channel'] ?? '');
        $gfrom   = sanitize_text_field($_POST['date_from'] ?? '');
        $gto     = sanitize_text_field($_POST['date_to'] ?? '');

        // Stessa sorgente di get_geo_stats, filtrata per periodo/canale.
        $reqs = self::geo_collect_requests($form_id, $period, $channel, $gfrom, $gto);
        if (!$reqs) { wp_send_json_success(['configured' => false]); return; }

        $cache = get_option('if2_geo_ip_cache', []);
        if (!is_array($cache)) $cache = [];

        $month_short = [1=>'Gen',2=>'Feb',3=>'Mar',4=>'Apr',5=>'Mag',6=>'Giu',7=>'Lug',8=>'Ago',9=>'Set',10=>'Ott',11=>'Nov',12=>'Dic'];
        $dbg = ['fetched' => count($reqs), 'with_geo' => 0, 'with_date' => 0];

        $reg = []; $cit = []; $nat = []; $all = [];
        $bump = function (&$agg, $name, $mnum, $wlabel, $wkey) {
            if ($name === '') return;
            if (!isset($agg[$name])) {
                $agg[$name] = ['total' => 0, 'm' => []];
                for ($i = 1; $i <= 12; $i++) $agg[$name]['m'][$i] = ['count' => 0, 'weeks' => []];
            }
            $agg[$name]['total']++;
            $agg[$name]['m'][$mnum]['count']++;
            if ($wkey !== '') {
                if (!isset($agg[$name]['m'][$mnum]['weeks'][$wkey])) $agg[$name]['m'][$mnum]['weeks'][$wkey] = ['label' => $wlabel, 'count' => 0];
                $agg[$name]['m'][$mnum]['weeks'][$wkey]['count']++;
            }
        };

        foreach ($reqs as $rq) {
            $ip = $rq['ip']; $ts = (int) $rq['ts'];
            if ($ip === '' || !isset($cache[$ip]) || !is_array($cache[$ip]) || isset($cache[$ip]['_fail'])) continue;
            $dbg['with_geo']++;
            $geo = $cache[$ip];
            $region  = trim((string) ($geo['region']  ?? ''));
            $city    = trim((string) ($geo['city']    ?? ''));
            $country = trim((string) ($geo['country'] ?? ''));

            // MESE = mese in cui è ARRIVATA la richiesta (data di invio), non la data di soggiorno.
            $sub_ts = (int) ($rq['sub_ts'] ?? 0);
            if (!$sub_ts) continue;
            $dbg['with_date']++;
            $mnum = (int) date('n', $sub_ts);

            // Settimana TOP = settimana di SOGGIORNO più richiesta (dalla data di arrivo), se presente.
            $wkey = ''; $wlabel = '';
            if ($ts) {
                $dow = (int) date('N', $ts);
                $sat_ts = $ts + (($dow === 7) ? 6 : (6 - $dow)) * 86400;
                $nx_ts  = $sat_ts + 7 * 86400;
                $wkey   = date('Y-m-d', $sat_ts);
                $sm = (int) date('n', $sat_ts); $sd = (int) date('j', $sat_ts);
                $nm = (int) date('n', $nx_ts);  $nd = (int) date('j', $nx_ts);
                $wlabel = ($sm === $nm) ? $sd . '/' . $nd . ' ' . $month_short[$sm]
                                        : $sd . ' ' . $month_short[$sm] . '/' . $nd . ' ' . $month_short[$nm];
            }

            if ($region  !== '') $bump($reg, $region,  $mnum, $wlabel, $wkey);
            if ($city    !== '') $bump($cit, $city,    $mnum, $wlabel, $wkey);
            if ($country !== '') $bump($nat, $country, $mnum, $wlabel, $wkey);
            $bump($all, 'all', $mnum, $wlabel, $wkey);   // aggregato "Tutti" (una volta per richiesta)
        }

        $serialize = function ($agg, $limit) {
            uasort($agg, function ($a, $b) { return $b['total'] - $a['total']; });
            $out = [];
            foreach (array_slice($agg, 0, $limit, true) as $name => $d) {
                $months = []; $allw = [];
                for ($i = 1; $i <= 12; $i++) {
                    $mc = $d['m'][$i]['count'];
                    $mtw = ''; $mtc = 0;
                    foreach ($d['m'][$i]['weeks'] as $wk => $w) {
                        if ($w['count'] > $mtc) { $mtc = $w['count']; $mtw = $w['label']; }
                        if (!isset($allw[$wk])) $allw[$wk] = ['label' => $w['label'], 'count' => 0];
                        $allw[$wk]['count'] += $w['count'];
                    }
                    $months[] = ['c' => $mc, 'p' => ($d['total'] > 0 ? round($mc / $d['total'] * 100) : 0), 'tw' => $mtw, 'twc' => $mtc];
                }
                $otw = ''; $otc = 0;
                foreach ($allw as $w) { if ($w['count'] > $otc) { $otc = $w['count']; $otw = $w['label']; } }
                $out[] = ['name' => $name, 'total' => $d['total'], 'months' => $months, 'top_week' => $otw, 'top_week_count' => $otc];
            }
            return $out;
        };

        $all_s = $serialize($all, 1);
        wp_send_json_success([
            'configured' => true,
            'regions'    => $serialize($reg, 25),
            'cities'     => $serialize($cit, 25),
            'countries'  => $serialize($nat, 25),
            'all'        => $all_s ? $all_s[0] : null,   // aggregato "Tutti"
            'debug'      => $dbg,
        ]);
    }

    /** Rimuove dai risultati le richieste dello STAFF in3pida (meta['staff']=true): escluse da TUTTE le statistiche. */
    private static function drop_staff(array $rows): array {
        return array_values(array_filter($rows, function ($r) {
            $m = json_decode($r['meta'] ?? '{}', true);
            return empty($m['staff']);
        }));
    }

    public static function get_stats(): void {
        self::check_admin_nonce();
        global $wpdb;

        $form_id = (int) ($_POST['form_id'] ?? 0);
        $range   = sanitize_key($_POST['range'] ?? '1m');

        if ($range === 'custom') {
            $from_raw = sanitize_text_field($_POST['date_from'] ?? '');
            $to_raw   = sanitize_text_field($_POST['date_to']   ?? '');
            $since    = $from_raw ? date('Y-m-d 00:00:00', strtotime($from_raw)) : date('Y-m-d H:i:s', strtotime('-30 days'));
            $until    = $to_raw   ? date('Y-m-d 23:59:59', strtotime($to_raw))   : date('Y-m-d 23:59:59');
            $days     = max(1, (int) round((strtotime($until) - strtotime($since)) / 86400) + 1);
        } else {
            $days  = match($range) { '1s' => 7, '1a' => 365, default => 30 };
            $since = date('Y-m-d H:i:s', strtotime("-{$days} days"));
            $until = date('Y-m-d 23:59:59');
        }

        $st = IF2_DB::stats_table();
        $sb = IF2_DB::submissions_table();
        $fc = $form_id ? $wpdb->prepare(" AND form_id = %d", $form_id) : '';
        $fs = $form_id ? $wpdb->prepare(" AND form_id = %d", $form_id) : '';

        $views     = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$st} WHERE event='view' AND created_at>=%s AND created_at<=%s" . $fc, $since, $until));
        $responses = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$sb} WHERE created_at>=%s AND created_at<=%s" . $fs, $since, $until) . IF2_DB::exclude_staff_sql());
        $conversion = $views > 0 ? round(($responses / $views) * 100, 1) : 0;

        $view_data = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(created_at) as day, COUNT(*) as cnt FROM {$st} WHERE event='view' AND created_at>=%s AND created_at<=%s" . $fc . " GROUP BY DATE(created_at) ORDER BY day ASC", $since, $until
        ), ARRAY_A);

        $resp_data = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE(created_at) as day, COUNT(*) as cnt FROM {$sb} WHERE created_at>=%s AND created_at<=%s" . $fs, $since, $until
        ) . IF2_DB::exclude_staff_sql() . " GROUP BY DATE(created_at) ORDER BY day ASC", ARRAY_A);

        // Genera TUTTI i giorni del range con valore 0 di default
        $all_days = [];
        $start_ts = strtotime(substr($since, 0, 10));
        $end_ts   = strtotime(substr($until, 0, 10));
        for ($ts = $start_ts; $ts <= $end_ts; $ts += 86400) {
            $all_days[ date('Y-m-d', $ts) ] = ['v' => 0, 'r' => 0];
        }
        foreach ($view_data as $r) { if (isset($all_days[$r['day']])) $all_days[$r['day']]['v'] = (int)$r['cnt']; }
        foreach ($resp_data as $r) { if (isset($all_days[$r['day']])) $all_days[$r['day']]['r'] = (int)$r['cnt']; }

        $labels = $views_arr = $resp_arr = [];
        foreach ($all_days as $day => $vals) {
            $labels[]    = date_i18n('j M', strtotime($day));
            $views_arr[] = $vals['v'];
            $resp_arr[]  = $vals['r'];
        }

        wp_send_json_success([
            'views'      => $views,
            'responses'  => $responses,
            'conversion' => $conversion,
            'chart'      => ['labels' => $labels, 'views' => $views_arr, 'responses' => $resp_arr],
        ]);
    }

    // -------------------------------------------------------------------------
    // Report richieste per form (tabella sotto la dashboard): per ogni form attivo →
    // n. richieste nel periodo, data creazione, ultima richiesta, periodo (settimana) più richiesto.
    // Filtro periodo come le statistiche + voce "report settimanale" (lun→dom della settimana PRECEDENTE).
    // -------------------------------------------------------------------------
    public static function forms_report(): void {
        self::check_admin_nonce();
        global $wpdb;

        $range = sanitize_key($_POST['range'] ?? '1m');
        $now   = current_time('timestamp');
        $mesi  = [1=>'gennaio',2=>'febbraio',3=>'marzo',4=>'aprile',5=>'maggio',6=>'giugno',7=>'luglio',8=>'agosto',9=>'settembre',10=>'ottobre',11=>'novembre',12=>'dicembre'];

        if ($range === 'report_week') {
            // Settimana FISSA precedente: da lunedì a domenica della settimana scorsa.
            // Es.: oggi 24/06 (mer) → 15/06 (lun) – 21/06 (dom).
            $this_monday = strtotime('monday this week', $now);
            $since = date('Y-m-d 00:00:00', $this_monday - 7 * 86400);
            $until = date('Y-m-d 23:59:59', $this_monday - 86400);
        } elseif ($range === 'custom') {
            $from_raw = sanitize_text_field($_POST['date_from'] ?? '');
            $to_raw   = sanitize_text_field($_POST['date_to']   ?? '');
            $since = $from_raw ? date('Y-m-d 00:00:00', strtotime($from_raw)) : date('Y-m-d H:i:s', strtotime('-30 days', $now));
            $until = $to_raw   ? date('Y-m-d 23:59:59', strtotime($to_raw))   : date('Y-m-d 23:59:59', $now);
        } elseif ($range === 'all') {
            $since = '1970-01-01 00:00:00';
            $until = date('Y-m-d 23:59:59', $now);
        } else {
            $days  = match ($range) { '1s' => 7, '2s' => 14, '3m' => 90, '6m' => 180, '1a' => 365, default => 30 };
            $since = date('Y-m-d H:i:s', strtotime("-{$days} days", $now));
            $until = date('Y-m-d 23:59:59', $now);
        }

        // Etichetta dell'intervallo (così si capisce sempre quale periodo si sta leggendo)
        if ($range === 'all') {
            $period_label = 'tutto il periodo';
        } else {
            $t1 = strtotime($since); $t2 = strtotime($until);
            $m1 = (int) date('n', $t1); $m2 = (int) date('n', $t2);
            $period_label = ($m1 === $m2)
                ? date('j', $t1) . '–' . date('j', $t2) . ' ' . ($mesi[$m2] ?? '')
                : date('j', $t1) . ' ' . ($mesi[$m1] ?? '') . ' – ' . date('j', $t2) . ' ' . ($mesi[$m2] ?? '');
        }

        $sb    = IF2_DB::submissions_table();
        $forms = IF2_Form::get_all(0, 0); // tutti i form attivi

        $out = [];
        foreach ($forms as $f) {
            $fid = (int) $f['id'];

            // Tutte le richieste del form nel periodo (staff in3pida esclusi) in UNA query.
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT data, meta FROM {$sb} WHERE form_id=%d AND created_at>=%s AND created_at<=%s", $fid, $since, $until
            ) . IF2_DB::exclude_staff_sql(), ARRAY_A);
            $rows  = self::drop_staff($rows ?: []);
            $count = count($rows);
            if ($count === 0) continue; // non mostrare i form senza richieste nel periodo selezionato

            // Ultima richiesta (la più recente in assoluto, staff esclusi) → tempo relativo
            $last = $wpdb->get_var($wpdb->prepare(
                "SELECT MAX(created_at) FROM {$sb} WHERE form_id=%d", $fid
            ) . IF2_DB::exclude_staff_sql());
            $last_rel = $last ? human_time_diff(strtotime($last), $now) . ' fa' : '—';

            // Periodo (settimana sab→sab dell'arrivo) più richiesto + % DB/CRM/Amelia
            $ci_field = self::detect_checkin_field($fid);
            $weeks = [];
            $db_n = $db_ok = $crm_n = $crm_ok = $am_n = $am_ok = 0;
            foreach ($rows as $r) {
                $m = json_decode($r['meta'] ?? '{}', true) ?: [];

                if ($ci_field !== '') {
                    $d = json_decode($r['data'] ?? '{}', true) ?: [];
                    if (!empty($d[$ci_field]) && ($ci = self::parse_date((string) $d[$ci_field]))) {
                        $dow  = (int) date('N', $ci);
                        $sat  = $ci + (($dow === 7) ? 6 : (6 - $dow)) * 86400;
                        $wkey = date('Y-m-d', $sat);
                        if (!isset($weeks[$wkey])) {
                            $sd = (int) date('j', $sat); $sm = (int) date('n', $sat);
                            $nd = (int) date('j', $sat + 7 * 86400); $nm = (int) date('n', $sat + 7 * 86400);
                            $weeks[$wkey] = ['label' => ($sm === $nm ? "$sd/$nd " . ($mesi[$sm] ?? '') : "$sd " . ($mesi[$sm] ?? '') . "/$nd " . ($mesi[$nm] ?? '')), 'count' => 0];
                        }
                        $weeks[$wkey]['count']++;
                    }
                }

                // DB = supabase, CRM = crm_*/webhook (5xx=ok), AM = amelia (log sotto meta['integration_log'])
                $ilog = $m['integration_log'] ?? [];
                $s = $ilog['supabase']['status'] ?? '';
                if ($s !== '' && $s !== 'disabled') { $db_n++; if ($s === 'ok' || $s === 'info') $db_ok++; }
                [$cs, $cact] = self::report_crm_status($ilog);
                if ($cact) { $crm_n++; if ($cs === 'ok' || $cs === 'info') $crm_ok++; }
                $a = $ilog['amelia']['status'] ?? '';
                if ($a !== '' && $a !== 'disabled') { $am_n++; if ($a === 'ok' || $a === 'info') $am_ok++; }
            }
            $top_period = '—';
            if ($weeks) { uasort($weeks, fn($a, $b) => $b['count'] - $a['count']); $top_period = reset($weeks)['label']; }

            $pct = fn(int $n, int $ok) => $n > 0 ? round($ok / $n * 100) . '%' : '—';

            $created_ts = strtotime($f['created_at'] ?? ($f['updated_at'] ?? ''));
            $out[] = [
                'name'       => $f['name'],
                'count'      => $count,
                'created'    => $created_ts ? date_i18n('d/m/Y', $created_ts) : '—',
                'last'       => $last_rel,
                'top_period' => $top_period,
                'db'         => $pct($db_n, $db_ok),
                'crm'        => $pct($crm_n, $crm_ok),
                'am'         => $pct($am_n, $am_ok),
            ];
        }

        // Ordina i form per numero di richieste (decrescente): prima chi ne ha di più.
        usort($out, fn($a, $b) => $b['count'] <=> $a['count']);

        wp_send_json_success(['rows' => $out, 'period_label' => $period_label]);
    }

    /** Stato CRM aggregato di una richiesta (per le % del report): [status, attivo?]. crm_* nativi o webhook (5xx = entrato). */
    private static function report_crm_status(array $m): array {
        $crm_keys = array_filter(array_keys($m), fn($k) => strpos($k, 'crm_') === 0);
        $active   = array_filter(array_intersect_key($m, array_flip($crm_keys)), fn($l) => (($l['status'] ?? 'disabled') !== 'disabled'));
        if (!empty($active)) {
            $st = IF2_CRM::aggregate($m)['status'] ?? 'disabled';
            return [$st, $st !== 'disabled'];
        }
        $w = $m['webhook'] ?? null;
        if (!$w || ($w['status'] ?? 'disabled') === 'disabled') return ['disabled', false];
        $st = $w['status'];
        if ($st === 'error' && (int) ($w['code'] ?? 0) >= 500) $st = 'ok';
        return [$st, true];
    }

    // -------------------------------------------------------------------------
    // Statistiche per-campo (distribuzione risposte — stile V1)
    // -------------------------------------------------------------------------
    public static function get_field_stats(): void {
        self::check_admin_nonce();
        global $wpdb;

        $form_id = (int) ($_POST['form_id'] ?? 0);
        $period  = sanitize_key($_POST['period'] ?? 'all');
        $max     = max(1, min(9999, (int) ($_POST['max'] ?? 9999)));
        $channel = sanitize_text_field($_POST['channel'] ?? '');

        $sb    = IF2_DB::submissions_table();
        $where = $form_id ? $wpdb->prepare('form_id = %d', $form_id) : '1=1';

        if ($period === '1s') {
            $where .= $wpdb->prepare(' AND created_at >= %s', date('Y-m-d H:i:s', strtotime('-7 days')));
        } elseif ($period === '2s') {
            $where .= $wpdb->prepare(' AND created_at >= %s', date('Y-m-d H:i:s', strtotime('-14 days')));
        } elseif ($period === '1m') {
            $where .= $wpdb->prepare(' AND created_at >= %s', date('Y-m-d H:i:s', strtotime('-30 days')));
        } elseif ($period === '3m') {
            $where .= $wpdb->prepare(' AND created_at >= %s', date('Y-m-d H:i:s', strtotime('-90 days')));
        } elseif ($period === '6m') {
            $where .= $wpdb->prepare(' AND created_at >= %s', date('Y-m-d H:i:s', strtotime('-180 days')));
        } elseif ($period === '1a') {
            $where .= $wpdb->prepare(' AND created_at >= %s', date('Y-m-d H:i:s', strtotime('-365 days')));
        } elseif ($period === 'custom') {
            $from_raw = sanitize_text_field($_POST['date_from'] ?? '');
            $to_raw   = sanitize_text_field($_POST['date_to']   ?? '');
            if ($from_raw) $where .= $wpdb->prepare(' AND created_at >= %s', date('Y-m-d 00:00:00', strtotime($from_raw)));
            if ($to_raw)   $where .= $wpdb->prepare(' AND created_at <= %s', date('Y-m-d 23:59:59', strtotime($to_raw)));
        }

        $rows = $wpdb->get_results(
            "SELECT data, meta, form_id FROM {$sb} WHERE {$where} ORDER BY created_at DESC LIMIT " . (int) $max,
            ARRAY_A
        );
        $rows = self::drop_staff($rows ?: []); // escludi richieste staff in3pida
        if ($channel !== '') {
            $rows = array_values(array_filter($rows, function($row) use ($channel) {
                $m = json_decode($row['meta'] ?? '{}', true) ?: [];
                return mb_strtolower($m['channel'] ?? '') === mb_strtolower($channel);
            }));
        }
        $total = count($rows);

        $allowed_analysis_types = ['select', 'radio', 'checkbox', 'date', 'datepicker', 'slider', 'thumb', 'star', 'matrix'];

        if ($form_id) {
            $form = IF2_Form::get($form_id);
            if (!$form) {
                wp_send_json_error(['msg' => 'Form non trovato.']);
                return;
            }
            $fields = array_values(array_filter(
                $form['fields'],
                fn($f) => in_array($f['type'] ?? '', $allowed_analysis_types, true)
            ));

            $result = [];
            foreach ($fields as $field) {
                $fid    = $field['id'];
                $label  = $field['label'] ?? $fid;
                $counts = [];
                foreach ($rows as $row) {
                    $data = json_decode($row['data'], true) ?: [];
                    $val  = $data[$fid] ?? '';
                    if (is_array($val)) $val = implode(', ', $val);
                    $val  = trim((string) $val);
                    if (strpos($val, '==') !== false) $val = substr($val, 0, strpos($val, '=='));
                    if ($val === '') $val = '(empty)';
                    $counts[$val] = ($counts[$val] ?? 0) + 1;
                }
                arsort($counts);
                $counts = array_slice($counts, 0, 20, true);
                $result[] = [
                    'id'     => $fid,
                    'label'  => $label,
                    'type'   => $field['type'] ?? 'text',
                    'total'  => $total,
                    'labels' => array_keys($counts),
                    'data'   => array_values($counts),
                ];
            }
        } else {
            // Tutti i form — aggrega le risposte raggruppando per label normalizzata
            $form_cache  = [];
            $field_stats = [];

            foreach ($rows as $row) {
                $fid_row = (int)($row['form_id'] ?? 0);
                if (!isset($form_cache[$fid_row])) {
                    $form_cache[$fid_row] = IF2_Form::get($fid_row);
                }
                $form_def = $form_cache[$fid_row];
                if (!$form_def) continue;

                $data = json_decode($row['data'], true) ?: [];

                foreach ($form_def['fields'] as $field) {
                    if (!in_array($field['type'] ?? '', $allowed_analysis_types, true)) continue;
                    $label = $field['label'] ?? $field['id'];
                    $norm  = mb_strtolower(trim($label));
                    if (!isset($field_stats[$norm])) {
                        $field_stats[$norm] = ['id' => $norm, 'label' => $label, 'type' => $field['type'] ?? 'text', 'count' => 0, 'counts' => []];
                    }
                    $val = $data[$field['id']] ?? '';
                    if (is_array($val)) $val = implode(', ', $val);
                    $val = trim((string)$val);
                    if ($val === '') $val = '(empty)';
                    $field_stats[$norm]['counts'][$val] = ($field_stats[$norm]['counts'][$val] ?? 0) + 1;
                    $field_stats[$norm]['count']++;
                }
            }

            $result = [];
            foreach ($field_stats as $stat) {
                arsort($stat['counts']);
                $stat['counts'] = array_slice($stat['counts'], 0, 20, true);
                $result[] = [
                    'id'     => $stat['id'],
                    'label'  => $stat['label'],
                    'type'   => $stat['type'],
                    'total'  => $stat['count'],
                    'labels' => array_keys($stat['counts']),
                    'data'   => array_values($stat['counts']),
                ];
            }
            usort($result, fn($a, $b) => $b['total'] - $a['total']);
        }

        wp_send_json_success(['fields' => $result, 'total' => $total]);
    }

    // -------------------------------------------------------------------------
    // Analisi Hotel: soggiorno, target, periodo
    // -------------------------------------------------------------------------
    public static function get_hotel_stats(): void {
        self::check_admin_nonce();
        global $wpdb;

        $form_id        = (int) ($_POST['form_id'] ?? 0);
        $period         = sanitize_key($_POST['period'] ?? 'all');
        $checkin_field  = sanitize_key($_POST['checkin_field']  ?? '');
        $checkout_field = sanitize_key($_POST['checkout_field'] ?? '');
        $target_field   = sanitize_key($_POST['target_field']   ?? '');
        $channel        = sanitize_text_field($_POST['channel'] ?? '');

        $sb    = IF2_DB::submissions_table();
        $where = $form_id ? $wpdb->prepare('form_id = %d', $form_id) : '1=1';

        if ($period === '1s') {
            $where .= $wpdb->prepare(' AND created_at >= %s', date('Y-m-d H:i:s', strtotime('-7 days')));
        } elseif ($period === '2s') {
            $where .= $wpdb->prepare(' AND created_at >= %s', date('Y-m-d H:i:s', strtotime('-14 days')));
        } elseif ($period === '1m') {
            $where .= $wpdb->prepare(' AND created_at >= %s', date('Y-m-d H:i:s', strtotime('-30 days')));
        } elseif ($period === '3m') {
            $where .= $wpdb->prepare(' AND created_at >= %s', date('Y-m-d H:i:s', strtotime('-90 days')));
        } elseif ($period === '6m') {
            $where .= $wpdb->prepare(' AND created_at >= %s', date('Y-m-d H:i:s', strtotime('-180 days')));
        } elseif ($period === '1a') {
            $where .= $wpdb->prepare(' AND created_at >= %s', date('Y-m-d H:i:s', strtotime('-365 days')));
        } elseif ($period === 'custom') {
            $fr = sanitize_text_field($_POST['date_from'] ?? '');
            $to = sanitize_text_field($_POST['date_to']   ?? '');
            if ($fr) $where .= $wpdb->prepare(' AND created_at >= %s', date('Y-m-d 00:00:00', strtotime($fr)));
            if ($to) $where .= $wpdb->prepare(' AND created_at <= %s', date('Y-m-d 23:59:59', strtotime($to)));
        }

        // Auto-detect checkin/checkout/target/adulti/bambini
        $adults_field   = '';
        $children_field = '';
        $form_def = $form_id ? IF2_Form::get($form_id) : null;
        if ($form_def) {
            $dp_fields = [];
            foreach ($form_def['fields'] as $f) {
                $ftype = $f['type'] ?? '';
                $flbl  = mb_strtolower($f['label'] ?? '');
                if (in_array($ftype, ['date', 'datepicker'], true)) {
                    $dp_fields[] = $f['id'];
                }
                if (!$target_field && in_array($ftype, ['select', 'radio'], true)) {
                    if (strpos($flbl, 'target') !== false || strpos($flbl, 'tipolog') !== false
                        || strpos($flbl, 'tipo ospite') !== false || strpos($flbl, 'cliente') !== false) {
                        $target_field = $f['id'];
                    }
                }
                if (!$adults_field && (strpos($flbl, 'adult') !== false)) {
                    $adults_field = $f['id'];
                }
                if (!$children_field && (strpos($flbl, 'bambin') !== false || strpos($flbl, 'child') !== false
                    || strpos($flbl, 'ragazz') !== false || strpos($flbl, 'infant') !== false)) {
                    $children_field = $f['id'];
                }
            }
            if (!$checkin_field  && isset($dp_fields[0])) $checkin_field  = $dp_fields[0];
            if (!$checkout_field && isset($dp_fields[1])) $checkout_field = $dp_fields[1];
        }

        $rows  = $wpdb->get_results("SELECT data, created_at, form_id, meta FROM {$sb} WHERE {$where}", ARRAY_A);
        $rows  = self::drop_staff($rows ?: []); // escludi richieste staff in3pida
        if ($channel !== '') {
            $rows = array_values(array_filter($rows, function($row) use ($channel) {
                $m = json_decode($row['meta'] ?? '{}', true) ?: [];
                return mb_strtolower($m['channel'] ?? '') === mb_strtolower($channel);
            }));
        }
        $total = count($rows);

        if ($total === 0) {
            wp_send_json_success(['total' => 0, 'soggiorno' => null, 'target' => null, 'periodo' => null, 'booking_window' => null, 'canali' => null]);
            return;
        }

        $lang = get_option('if2_lang', 'it');
        $month_names_en = [1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December'];
        $month_names_it = [1=>'Gennaio',2=>'Febbraio',3=>'Marzo',4=>'Aprile',5=>'Maggio',6=>'Giugno',7=>'Luglio',8=>'Agosto',9=>'Settembre',10=>'Ottobre',11=>'Novembre',12=>'Dicembre'];
        $month_names   = ($lang === 'it') ? $month_names_it : $month_names_en;
        $month_order   = array_flip(array_values($month_names));
        $month_short_it = [1=>'Gen',2=>'Feb',3=>'Mar',4=>'Apr',5=>'Mag',6=>'Giu',7=>'Lug',8=>'Ago',9=>'Set',10=>'Ott',11=>'Nov',12=>'Dic'];
        $month_short_en = [1=>'Jan',2=>'Feb',3=>'Mar',4=>'Apr',5=>'May',6=>'Jun',7=>'Jul',8=>'Aug',9=>'Sep',10=>'Oct',11=>'Nov',12=>'Dec'];
        $month_short    = ($lang === 'it') ? $month_short_it : $month_short_en;
        $bucket_keys   = ['we corto (1/2 gg)','we (3/4 gg)','we lungo (5/6 gg)','Settimana (7 gg)','Settimana lunga (8/10 gg)','Altri'];
        $stay_buckets  = array_fill_keys($bucket_keys, 0);
        $targets       = [];
        $checkin_months = [];
        $periodo_stacked = [];  // [bucket][month] = count
        $checkin_weeks  = [];
        $stay_days_total = 0;
        $stay_count      = 0;
        $bw_days_total   = 0;
        $bw_count        = 0;
        $bw_buckets      = ['Last minute (0-7 gg)' => 0, 'Breve (8-30 gg)' => 0, 'Medio (31-90 gg)' => 0, 'Lungo (+90 gg)' => 0];

        // Per-submission field detection cache (usato quando form_id=0)
        $_form_fields_cache = [];
        $_detect = function(int $fid) use (&$_form_fields_cache, $checkin_field, $checkout_field, $target_field): array {
            if (isset($_form_fields_cache[$fid])) return $_form_fields_cache[$fid];
            $f = IF2_Form::get($fid);
            if (!$f) return $_form_fields_cache[$fid] = ['', '', '', '', ''];
            $ci = $checkin_field; $co = $checkout_field; $tg = $target_field;
            $ad = ''; $ch = '';
            $dp = [];
            foreach ($f['fields'] as $ff) {
                $ftype = $ff['type'] ?? '';
                $flbl  = mb_strtolower($ff['label'] ?? '');
                if (in_array($ftype, ['date', 'datepicker'], true)) $dp[] = $ff['id'];
                if (!$tg && in_array($ftype, ['select', 'radio'], true)) {
                    if (strpos($flbl, 'target') !== false || strpos($flbl, 'tipolog') !== false
                        || strpos($flbl, 'tipo ospite') !== false || strpos($flbl, 'cliente') !== false)
                        $tg = $ff['id'];
                }
                if (!$ad && strpos($flbl, 'adult') !== false) $ad = $ff['id'];
                if (!$ch && (strpos($flbl, 'bambin') !== false || strpos($flbl, 'child') !== false
                    || strpos($flbl, 'ragazz') !== false || strpos($flbl, 'infant') !== false)) $ch = $ff['id'];
            }
            if (!$ci && isset($dp[0])) $ci = $dp[0];
            if (!$co && isset($dp[1])) $co = $dp[1];
            return $_form_fields_cache[$fid] = [$ci, $co, $ad, $ch, $tg];
        };

        // --- canali: conta per ogni submission il canale dal meta (solo submission con canale impostato) ---
        $canali_counts = [];
        foreach ($rows as $row) {
            $m  = json_decode($row['meta'] ?? '{}', true) ?: [];
            $ch = trim((string)($m['channel'] ?? ''));
            if ($ch === '') continue;
            $canali_counts[$ch] = ($canali_counts[$ch] ?? 0) + 1;
        }

        foreach ($rows as $row) {
            $data = json_decode($row['data'], true) ?: [];

            // Effective fields: per-row detection when form_id=0 (tutti i form)
            if ($form_id) {
                $eff_ci_f = $checkin_field; $eff_co_f = $checkout_field;
                $eff_ad_f = $adults_field;  $eff_ch_f = $children_field; $eff_tg_f = $target_field;
            } else {
                [$eff_ci_f, $eff_co_f, $eff_ad_f, $eff_ch_f, $eff_tg_f] = $_detect((int)($row['form_id'] ?? 0));
            }

            // --- soggiorno ---
            $bucket = null;
            if ($eff_ci_f && $eff_co_f && !empty($data[$eff_ci_f]) && !empty($data[$eff_co_f])) {
                $ci = self::parse_date((string)$data[$eff_ci_f]);
                $co = self::parse_date((string)$data[$eff_co_f]);
                if ($ci && $co && $co > $ci) {
                    $days = (int) round(($co - $ci) / 86400);
                    $stay_days_total += $days;
                    $stay_count++;
                    if      ($days <= 2)  $bucket = 'we corto (1/2 gg)';
                    elseif  ($days <= 4)  $bucket = 'we (3/4 gg)';
                    elseif  ($days <= 6)  $bucket = 'we lungo (5/6 gg)';
                    elseif  ($days === 7) $bucket = 'Settimana (7 gg)';
                    elseif  ($days <= 10) $bucket = 'Settimana lunga (8/10 gg)';
                    else                  $bucket = 'Altri';
                    $stay_buckets[$bucket]++;
                }
            }

            // --- mese/settimana: usa check-in se disponibile, altrimenti created_at ---
            $ci = 0;
            if ($eff_ci_f && !empty($data[$eff_ci_f])) {
                $ci = self::parse_date((string)$data[$eff_ci_f]);
            }
            if (!$ci && !empty($row['created_at'])) {
                $ci = (int) strtotime($row['created_at']);
            }
            if ($ci) {
                $mnum  = (int) date('n', $ci);
                $mname = $month_names[$mnum] ?? date('F', $ci);
                $checkin_months[$mname] = ($checkin_months[$mname] ?? 0) + 1;

                // stacked: by bucket
                $bk = $bucket ?? 'N/D';
                if (!isset($periodo_stacked[$bk])) $periodo_stacked[$bk] = [];
                $periodo_stacked[$bk][$mname] = ($periodo_stacked[$bk][$mname] ?? 0) + 1;

                // weeks — settimana sab→ven, mostrata come sab/sab successivo
                // Il booking va nella settimana del primo sabato del soggiorno:
                // se arrivi venerdì 29, il primo sabato del soggiorno è 30 → settimana 30/6
                $dow         = (int) date('N', $ci); // 1=Lun…6=Sab…7=Dom
                $days_to_sat = ($dow === 7) ? 6 : (6 - $dow); // 0 se già sabato
                $sat_ts      = $ci + $days_to_sat * 86400;
                $next_sat_ts = $sat_ts + 7 * 86400;
                $wkey        = date('Y-m-d', $sat_ts);
                if (!isset($checkin_weeks[$wkey])) {
                    $sat_d   = (int) date('j', $sat_ts);
                    $sat_m   = (int) date('n', $sat_ts);
                    $next_d  = (int) date('j', $next_sat_ts);
                    $next_m  = (int) date('n', $next_sat_ts);
                    $sat_mn  = $month_short[$sat_m]  ?? date('M', $sat_ts);
                    $next_mn = $month_short[$next_m] ?? date('M', $next_sat_ts);
                    $week_label = ($sat_m === $next_m)
                        ? $sat_d . '/' . $next_d . ' ' . $sat_mn
                        : $sat_d . ' ' . $sat_mn . '/' . $next_d . ' ' . $next_mn;
                    $checkin_weeks[$wkey] = ['label' => $week_label, 'count' => 0];
                }
                $checkin_weeks[$wkey]['count']++;
            }

            // --- booking window: giorni anticipo tra invio e check-in ---
            if ($eff_ci_f && !empty($data[$eff_ci_f])) {
                $ci_bw  = self::parse_date((string)$data[$eff_ci_f]);
                $sub_ts = (int) strtotime($row['created_at']);
                if ($ci_bw > $sub_ts && $sub_ts > 0) {
                    $bw_days = (int) round(($ci_bw - $sub_ts) / 86400);
                    $bw_days_total += $bw_days;
                    $bw_count++;
                    if      ($bw_days <= 7)  $bw_buckets['Last minute (0-7 gg)']++;
                    elseif  ($bw_days <= 30) $bw_buckets['Breve (8-30 gg)']++;
                    elseif  ($bw_days <= 90) $bw_buckets['Medio (31-90 gg)']++;
                    else                     $bw_buckets['Lungo (+90 gg)']++;
                }
            }

            // --- target: calcola da adulti+bambini oppure usa campo diretto ---
            if ($eff_ad_f && isset($data[$eff_ad_f])) {
                preg_match('/\d+/', (string)$data[$eff_ad_f], $ma);
                $n_adults = (int) ($ma[0] ?? 0);
                $n_children = 0;
                if ($eff_ch_f && isset($data[$eff_ch_f])) {
                    preg_match('/\d+/', (string)$data[$eff_ch_f], $mc);
                    $n_children = (int) ($mc[0] ?? 0);
                }
                if ($n_adults > 0) {
                    $cat = self::classify_hotel_target($n_adults, $n_children);
                    $targets[$cat] = ($targets[$cat] ?? 0) + 1;
                }
            } elseif ($eff_tg_f && !empty($data[$eff_tg_f])) {
                $val = is_array($data[$eff_tg_f]) ? implode(', ', $data[$eff_tg_f]) : trim((string)$data[$eff_tg_f]);
                if ($val !== '') $targets[$val] = ($targets[$val] ?? 0) + 1;
            }
        }

        // --- build soggiorno result ---
        $soggiorno = null;
        if ($stay_count > 0) {
            arsort($stay_buckets);
            reset($stay_buckets);
            $top_bk  = (string) array_key_first($stay_buckets);
            $top_cnt = $stay_buckets[$top_bk];
            $soggiorno = [
                'media_giorni'   => $stay_count > 0 ? round($stay_days_total / $stay_count, 1) : 0,
                'count'          => $stay_count,
                'top_bucket'     => $top_bk,
                'top_bucket_pct' => $stay_count > 0 ? round($top_cnt / $stay_count * 100) . '%' : '0%',
                'pie'            => ['labels' => array_keys($stay_buckets), 'data' => array_values($stay_buckets)],
            ];
        }

        // --- build target result ---
        $target_res = null;
        if (!empty($targets)) {
            arsort($targets);
            $top_t = (string) array_key_first($targets);
            $target_res = [
                'top'     => $top_t,
                'top_pct' => round($targets[$top_t] / $total * 100) . '%',
                'pie'     => ['labels' => array_keys($targets), 'data' => array_values($targets)],
            ];
        }

        // --- build periodo result ---
        $periodo_res = null;
        if (!empty($checkin_months)) {
            uksort($checkin_months, function($a, $b) use ($month_order) {
                return ($month_order[$a] ?? 99) <=> ($month_order[$b] ?? 99);
            });
            $months_sorted    = $checkin_months;
            arsort($months_sorted);
            $top_month        = (string) array_key_first($months_sorted);
            $top_month_count  = $months_sorted[$top_month] ?? 0;
            $top_month_pct    = $total > 0 ? round($top_month_count / $total * 100) . '%' : '0%';
            $top_week  = null;
            if (!empty($checkin_weeks)) {
                uasort($checkin_weeks, fn($a, $b) => $b['count'] - $a['count']);
                $fw = reset($checkin_weeks);
                $top_week = ['label' => $fw['label'], 'pct' => round($fw['count'] / $total * 100) . '%'];
            }
            // Build stacked datasets aligned to months order
            $month_labels = array_keys($checkin_months);
            $stacked_ds   = [];
            foreach ($periodo_stacked as $bk => $month_data) {
                $ds_data = [];
                foreach ($month_labels as $ml) {
                    $ds_data[] = $month_data[$ml] ?? 0;
                }
                $stacked_ds[] = ['label' => $bk, 'data' => $ds_data];
            }
            // Build weeks pie (top 8 weeks)
            $weeks_pie_labels = [];
            $weeks_pie_data   = [];
            foreach (array_slice($checkin_weeks, 0, 8, true) as $wdata) {
                $weeks_pie_labels[] = $wdata['label'];
                $weeks_pie_data[]   = $wdata['count'];
            }

            $periodo_res = [
                'labels'         => $month_labels,
                'data'           => array_values($checkin_months),
                'top_month'      => $top_month,
                'top_month_pct'  => $top_month_pct,
                'top_week'       => $top_week,
                'stacked'        => $stacked_ds,
                'months_pie'     => ['labels' => $month_labels, 'data' => array_values($checkin_months)],
                'weeks_pie'      => ['labels' => $weeks_pie_labels, 'data' => $weeks_pie_data],
            ];
        }

        // --- booking window result ---
        $booking_window = null;
        if ($bw_count > 0) {
            arsort($bw_buckets);
            $top_bw = (string) array_key_first($bw_buckets);
            $booking_window = [
                'media_giorni' => round($bw_days_total / $bw_count, 1),
                'count'        => $bw_count,
                'top_bucket'   => $top_bw,
                'top_pct'      => round($bw_buckets[$top_bw] / $bw_count * 100) . '%',
                'pie'          => ['labels' => array_keys($bw_buckets), 'data' => array_values($bw_buckets)],
            ];
        }

        // --- canali result ---
        $canali_res = null;
        if (!empty($canali_counts)) {
            arsort($canali_counts);
            $top_ch      = (string) array_key_first($canali_counts);
            $top_ch_cnt  = $canali_counts[$top_ch];
            $canali_tracked = array_sum($canali_counts);
            $canali_res = [
                'top'     => $top_ch,
                'top_pct' => $total > 0 ? round($top_ch_cnt / $total * 100) . '%' : '0%',
                'tracked' => $canali_tracked,
                'pie'     => ['labels' => array_keys($canali_counts), 'data' => array_values($canali_counts)],
            ];
        }

        wp_send_json_success([
            'total'          => $total,
            'soggiorno'      => $soggiorno,
            'target'         => $target_res,
            'periodo'        => $periodo_res,
            'booking_window' => $booking_window,
            'canali'         => $canali_res,
        ]);
    }

    public static function test_amelia_contact(): void {
        check_ajax_referer('if2_admin', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Permesso negato.']);

        $key    = sanitize_text_field($_POST['key']    ?? '');
        $secret = sanitize_text_field($_POST['secret'] ?? '');
        $apiurl = rtrim(sanitize_text_field($_POST['apiurl'] ?? 'https://api.smshosting.it/rest/api'), '/');
        $listid = sanitize_text_field($_POST['listid'] ?? '');
        $phone  = sanitize_text_field($_POST['phone']  ?? '');

        if (!$key || !$secret || !$listid || !$phone) {
            wp_send_json_error(['message' => 'Compila tutti i campi: Key, Secret, List ID e numero di telefono.']);
        }

        $body = ['msisdn' => $phone, 'groupsId' => $listid];
        $resp = wp_remote_post($apiurl . '/phonebook/contact', [
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode($key . ':' . $secret),
            ],
            'body'    => $body,
            'timeout' => 10,
        ]);

        $code    = is_wp_error($resp) ? 0 : wp_remote_retrieve_response_code($resp);
        $raw     = is_wp_error($resp) ? $resp->get_error_message() : wp_remote_retrieve_body($resp);
        $already = strpos($raw, 'CONTACT_ALREADY_EXISTS') !== false;
        $success = !is_wp_error($resp) && ($code >= 200 && $code < 300 || $already);
        $msg     = 'HTTP ' . $code . ' — ' . $raw;

        if ($success) {
            $label = $already ? '✓ Contatto già presente nella lista. ' : '✓ Contatto aggiunto! ';
            wp_send_json_success(['message' => $label . $msg]);
        } else {
            wp_send_json_error(['message' => '✗ ' . $msg]);
        }
    }

    private static function classify_hotel_target(int $adults, int $children): string {
        if ($adults === 1 && $children === 0) return 'Single';
        if ($adults === 1)                    return 'Genitore single';
        if ($children === 0)                  return ($adults === 2) ? 'Coppie' : 'Amici';
        if ($children === 1)                  return 'Famiglia con 1 bambino';
        if ($children === 2)                  return 'Famiglia con 2 bambini';
        return 'Famiglia numerosa';
    }

    private static function parse_date(string $val): int {
        $val = trim($val);
        if (!$val) return 0;
        if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})/', $val, $m))
            return (int) mktime(12, 0, 0, (int)$m[2], (int)$m[1], (int)$m[3]);
        if (preg_match('/^(\d{1,2})-(\d{1,2})-(\d{4})/', $val, $m))
            return (int) mktime(12, 0, 0, (int)$m[2], (int)$m[1], (int)$m[3]);
        $ts = strtotime($val);
        return $ts ? (int)$ts : 0;
    }

    public static function send_test_email(): void {
        self::check_admin_nonce();
        $to = sanitize_email($_POST['to'] ?? '');
        if (!is_email($to)) {
            wp_send_json_error(['message' => 'Indirizzo email non valido.']);
            return;
        }
        // Carica la config del form per usare mittente (Nome/Email mittente) e SMTP veri
        $form_id = (int) ($_POST['form_id'] ?? 0);
        $form    = $form_id ? IF2_Form::get($form_id) : null;
        $config  = ($form && !empty($form['config'])) ? (array) $form['config'] : [];

        // Mittente: Nome mittente / Email mittente del form (fallback all'utente SMTP)
        $from_name  = trim((string) ($config['email_from_name'] ?? ''));
        $from_email = sanitize_email((string) ($config['email_from'] ?? ''));
        if (!$from_email) $from_email = sanitize_email((string) ($config['smtp_user'] ?? ''));
        if (!$from_name)  $from_name  = $from_email;

        $subject = 'Email di prova';
        $body    = '<p>Questa è un\'email di prova.</p>'
                 . '<p>Se la ricevi, la configurazione email è corretta.</p>';
        $headers = ['Content-Type: text/html; charset=UTF-8'];
        if ($from_email) {
            $headers[] = 'From: ' . sanitize_text_field($from_name) . ' <' . $from_email . '>';
        }
        $result  = IF2_Submission::send_mail($config, $to, $subject, $body, $headers);
        if ($result) {
            wp_send_json_success(['message' => 'Email inviata a ' . $to]);
        } else {
            wp_send_json_error(['message' => 'Invio fallito. Controlla la configurazione email/SMTP.']);
        }
    }

    public static function reset_stats(): void {
        self::check_admin_nonce();
        global $wpdb;
        $wpdb->query("TRUNCATE TABLE " . IF2_DB::stats_table());
        wp_send_json_success();
    }

    public static function export_data(): void {
        self::check_admin_nonce();
        global $wpdb;
        $form_id = (int) ($_POST['form_id'] ?? 0);

        // Costruisce mappa field_id → label leggendo i form coinvolti
        $skip_types   = ['submit', 'page_break', 'html', 'heading'];
        $field_labels = [];

        if ($form_id > 0) {
            $form = IF2_Form::get($form_id);
            if ($form) {
                foreach ($form['fields'] as $f) {
                    if (!empty($f['id']) && !in_array($f['type'] ?? '', $skip_types, true)) {
                        $field_labels[$f['id']] = $f['label'] ?: $f['id'];
                    }
                }
            }
            $rows = $wpdb->get_results(
                $wpdb->prepare("SELECT * FROM " . IF2_DB::submissions_table() . " WHERE form_id = %d ORDER BY created_at DESC", $form_id),
                ARRAY_A
            );
        } else {
            // Tutti i form: carica le label di tutti
            foreach (IF2_Form::get_all() as $meta) {
                $f = IF2_Form::get((int) $meta['id']);
                if (!$f) continue;
                foreach ($f['fields'] as $field) {
                    if (!empty($field['id']) && !in_array($field['type'] ?? '', $skip_types, true) && !isset($field_labels[$field['id']])) {
                        $field_labels[$field['id']] = $field['label'] ?: $field['id'];
                    }
                }
            }
            $rows = $wpdb->get_results("SELECT * FROM " . IF2_DB::submissions_table() . " ORDER BY created_at DESC", ARRAY_A);
        }

        // Raccoglie tutte le chiavi presenti nelle risposte
        $all_keys = array_keys($field_labels);
        foreach ($rows as $row) {
            foreach (array_keys(json_decode($row['data'], true) ?: []) as $k) {
                if (!in_array($k, $all_keys, true)) $all_keys[] = $k;
            }
        }

        // Intestazione
        $header = ['ID', 'Form ID', 'Data'];
        foreach ($all_keys as $k) {
            $header[] = $field_labels[$k] ?? $k;
        }

        $csv = self::csv_encode_row($header);
        foreach ($rows as $row) {
            $data = json_decode($row['data'], true) ?: [];
            $line = [$row['id'], $row['form_id'], $row['created_at']];
            foreach ($all_keys as $k) {
                $val = $data[$k] ?? '';
                if (is_array($val)) $val = implode(', ', $val);
                $val = (string) $val;
                if (strpos($val, '==') !== false) $val = substr($val, 0, strpos($val, '=='));
                $line[] = $val;
            }
            $csv .= self::csv_encode_row($line);
        }

        wp_send_json_success(['csv' => $csv]);
    }

    private static function csv_encode_row(array $cols): string {
        $cells = array_map(function ($v) {
            return '"' . str_replace('"', '""', (string) $v) . '"';
        }, $cols);
        return implode(',', $cells) . "\n";
    }

    // -------------------------------------------------------------------------
    // Upload file
    // -------------------------------------------------------------------------

    public static function upload_file(): void {
        check_ajax_referer('if2_submit_' . (int) $_POST['if2_form_id'], 'if2_nonce');

        $form_id  = (int) $_POST['if2_form_id'];
        $field_id = sanitize_key($_POST['field_id'] ?? '');
        $form     = IF2_Form::get($form_id);
        if (!$form || !$field_id) wp_send_json_error(['message' => 'Parametri non validi.']);

        $field_def = null;
        foreach ($form['fields'] as $f) {
            if ($f['id'] === $field_id) { $field_def = $f; break; }
        }

        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            wp_send_json_error(['message' => 'Upload fallito.']);
        }

        $allowed_types = self::get_allowed_mime_types($field_def['accept'] ?? '');
        $file_info     = wp_check_filetype(basename($_FILES['file']['name']), $allowed_types);
        if (!$file_info['type']) {
            wp_send_json_error(['message' => 'Tipo file non consentito.']);
        }

        $max_mb   = (int) ($field_def['max_size_mb'] ?? 5);
        if ($_FILES['file']['size'] > $max_mb * 1024 * 1024) {
            wp_send_json_error(['message' => "File troppo grande (max {$max_mb}MB)."]);
        }

        $upload   = wp_upload_dir();
        $dir      = trailingslashit($upload['basedir']) . 'if2-uploads/' . $form_id . '/';
        wp_mkdir_p($dir);

        $filename  = wp_unique_filename($dir, sanitize_file_name($_FILES['file']['name']));
        $file_path = $dir . $filename;

        if (!move_uploaded_file($_FILES['file']['tmp_name'], $file_path)) {
            wp_send_json_error(['message' => 'Impossibile salvare il file.']);
        }

        $file_url = trailingslashit($upload['baseurl']) . 'if2-uploads/' . $form_id . '/' . $filename;

        global $wpdb;
        $wpdb->insert(IF2_DB::files_table(), [
            'form_id'   => $form_id,
            'field_id'  => $field_id,
            'filename'  => $filename,
            'file_url'  => $file_url,
            'file_path' => $file_path,
            'mime_type' => $file_info['type'],
            'file_size' => $_FILES['file']['size'],
        ]);

        wp_send_json_success(['file_id' => (int) $wpdb->insert_id, 'filename' => $filename, 'file_url' => $file_url]);
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private static function cleanup_submission_files(int $submission_id): void {
        global $wpdb;
        $ft    = IF2_DB::files_table();
        $files = $wpdb->get_results($wpdb->prepare("SELECT file_path FROM {$ft} WHERE submission_id = %d", $submission_id), ARRAY_A);
        foreach ($files as $file) {
            if (!empty($file['file_path']) && file_exists($file['file_path'])) {
                @unlink($file['file_path']);
            }
        }
        $wpdb->delete($ft, ['submission_id' => $submission_id]);
    }

    private static function cleanup_form_files(int $form_id): void {
        global $wpdb;
        $ft    = IF2_DB::files_table();
        $files = $wpdb->get_results($wpdb->prepare("SELECT file_path FROM {$ft} WHERE form_id = %d", $form_id), ARRAY_A);
        foreach ($files as $file) {
            if (!empty($file['file_path']) && file_exists($file['file_path'])) {
                @unlink($file['file_path']);
            }
        }
        $wpdb->delete($ft, ['form_id' => $form_id]);
    }

    private static function check_admin_nonce(): void {
        if (!check_ajax_referer('if2_admin', 'nonce', false) || !current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Non autorizzato.'], 403);
        }
    }

    private static function sanitize_config(array $config): array {
        $allowed_keys = array_keys(IF2_Form::default_config()); // amelia_default_list is plain text → handled by default sanitize_text_field
        $bool_keys    = ['send_email','supabase_enabled','disable_form','disable_form_page',
                         'disable_multiple','disable_autoscroll','enable_autosave','autoresponder','collect_ip',
                         'email_attach_files','email_multi_column','email_hide_empty',
                         'bg_transparent','hide_labels'];
        $url_keys     = ['redirect_url','webhook_url','thankyou_url','logo_url'];
        $int_keys     = ['max_submissions','redirect_delay'];
        $pass_keys    = ['smtp_pass'];
        $clean = [];
        foreach ($allowed_keys as $key) {
            if (!array_key_exists($key, $config)) continue;
            $val = $config[$key];
            if (in_array($key, $bool_keys, true)) {
                $clean[$key] = (bool) $val;
            } elseif (in_array($key, $url_keys, true)) {
                $clean[$key] = esc_url_raw((string) $val);
            } elseif (in_array($key, $int_keys, true)) {
                $clean[$key] = (int) $val;
            } elseif (in_array($key, $pass_keys, true)) {
                $clean[$key] = (string) $val; // password: no strip
            } elseif ($key === 'supabase_table') {
                $clean[$key] = sanitize_key($val);
            } elseif ($key === 'logic_rules') {
                $clean[$key] = is_array($val) ? $val : [];
            } elseif ($key === 'crm') {
                $clean[$key] = is_array($val) ? $val : [];
            } elseif ($key === 'blocked_dates') {
                $clean[$key] = array_map('sanitize_text_field', (array) $val);
            } elseif ($key === 'custom_css') {
                $clean[$key] = wp_strip_all_tags((string) $val);
            } elseif (in_array($key, ['autoresponder_body','email_body'], true)) {
                $clean[$key] = wp_kses_post((string) $val);
            } elseif (in_array($key, ['success_message','error_message'], true)) {
                $clean[$key] = sanitize_textarea_field((string) $val);
            } else {
                $clean[$key] = sanitize_text_field((string) $val);
            }
        }
        return array_merge(IF2_Form::default_config(), $clean);
    }

    private static function get_allowed_mime_types(string $accept): array {
        if (empty($accept)) return get_allowed_mime_types();
        $map = [
            'image/*' => ['jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp'],
            '.pdf'    => ['pdf' => 'application/pdf'],
            '.doc'    => ['doc' => 'application/msword'],
            '.docx'   => ['docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
        ];
        $result = [];
        foreach (array_map('trim', explode(',', $accept)) as $type) {
            if (isset($map[$type])) $result = array_merge($result, $map[$type]);
        }
        return $result ?: get_allowed_mime_types();
    }

    // -------------------------------------------------------------------------
    // Test connessione Amelia / SMSHosting
    // -------------------------------------------------------------------------

    public static function test_amelia(): void {
        check_ajax_referer('if2_admin', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Permesso negato.']);
        }

        $key    = sanitize_text_field($_POST['key']    ?? '');
        $secret = sanitize_text_field($_POST['secret'] ?? '');
        $apiurl = rtrim(sanitize_text_field($_POST['apiurl'] ?? 'https://api.smshosting.it/rest/api'), '/');

        if (!$key || !$secret) {
            wp_send_json_error(['message' => 'Inserisci Auth Key e Auth Secret.']);
        }

        $resp = wp_remote_get($apiurl . '/user', [
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode($key . ':' . $secret),
                'Content-Type'  => 'application/json',
            ],
            'timeout' => 10,
        ]);

        if (is_wp_error($resp)) {
            wp_send_json_error(['message' => $resp->get_error_message()]);
        }

        $code = wp_remote_retrieve_response_code($resp);
        if ($code === 200 || $code === 201) {
            wp_send_json_success(['message' => '✓ Connessione OK (HTTP ' . $code . ')']);
        } else {
            wp_send_json_error(['message' => '✗ Errore HTTP ' . $code . ': ' . substr(wp_remote_retrieve_body($resp), 0, 200)]);
        }
    }

    public static function retry_crm(): void {
        check_ajax_referer('if2_admin', 'nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Permesso negato');

        $submission_id = (int) ($_POST['submission_id'] ?? 0);
        if (!$submission_id) wp_send_json_error('ID mancante');

        $row = IF2_Submission::get_one($submission_id);
        if (!$row) wp_send_json_error('Submission non trovata');

        $form = IF2_Form::get((int) $row['form_id']);
        if (!$form) wp_send_json_error('Form non trovato');

        $data   = json_decode($row['data'], true) ?: [];
        $meta   = json_decode($row['meta'], true) ?: [];
        $config = $form['config'];
        $logs   = [];

        // Se la richiesta è dello staff in3pida, il retry non va conteggiato nel monitoring.
        IF2_Telemetry::$skip = !empty($meta['staff']);

        // Webhook
        if (!empty($config['webhook_url'])) {
            $webhook_data = [];
            foreach ($form['fields'] as $wf) {
                $fid = $wf['id'] ?? '';
                if (!array_key_exists($fid, $data)) continue;
                $key = !empty($wf['alt_label']) ? sanitize_text_field($wf['alt_label']) : $fid;
                $webhook_data[$key] = is_array($data[$fid]) ? implode(', ', $data[$fid]) : (string) $data[$fid];
            }
            $webhook_data['form_id']       = $form['id'];
            $webhook_data['submission_id'] = $submission_id;
            $webhook_data['channel']       = $meta['channel']  ?? '';
            $webhook_data['hotel_id']      = $meta['hotel_id'] ?? '';

            $resp = wp_remote_post(esc_url_raw($config['webhook_url']), ['body' => $webhook_data, 'timeout' => 8, 'blocking' => true]);
            $code = is_wp_error($resp) ? 0 : wp_remote_retrieve_response_code($resp);
            $ok   = !is_wp_error($resp) && $code >= 200 && $code < 300;
            $logs['webhook'] = [
                'status'  => $ok ? 'ok' : 'error',
                'code'    => $code,
                'message' => $ok ? '' : (is_wp_error($resp) ? $resp->get_error_message() : 'HTTP ' . $code),
            ];
        }

        // CRM nativi
        $crm_logs = IF2_CRM::dispatch($form, $data, $meta, $submission_id);
        $logs     = array_merge($logs, $crm_logs);

        IF2_Submission::update_meta_log($submission_id, $logs);
        if (!empty($logs['webhook'])) IF2_Telemetry::track_crm_result($logs['webhook']);

        $any_ok = false;
        foreach ($logs as $log) {
            if (in_array($log['status'] ?? '', ['ok', 'info'], true)) { $any_ok = true; break; }
        }
        if ($any_ok) {
            wp_send_json_success();
        } else {
            $msg = '';
            foreach ($logs as $log) {
                if (($log['status'] ?? '') === 'error') { $msg = $log['message'] ?? ''; break; }
            }
            wp_send_json_error($msg ?: 'Errore sconosciuto');
        }
    }

    public static function retry_amelia(): void {
        check_ajax_referer('if2_admin', 'nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Permesso negato');

        $submission_id = (int) ($_POST['submission_id'] ?? 0);
        if (!$submission_id) wp_send_json_error('ID mancante');

        $row = IF2_Submission::get_one($submission_id);
        if (!$row) wp_send_json_error('Submission non trovata');

        $form = IF2_Form::get((int) $row['form_id']);
        if (!$form) wp_send_json_error('Form non trovato');

        $data = json_decode($row['data'], true) ?: [];
        $meta = json_decode($row['meta'], true) ?: [];

        $amelia_key    = get_option('if2_amelia_key', '');
        $amelia_secret = get_option('if2_amelia_secret', '');
        $amelia_listid = get_option('if2_amelia_listid', '');
        $amelia_apiurl = rtrim(get_option('if2_amelia_apiurl', 'https://api.smshosting.it/rest/api'), '/');
        $amelia_lists  = json_decode(get_option('if2_amelia_lists', '[]'), true) ?: [];

        if (!$amelia_key || !$amelia_secret || (!$amelia_listid && empty($amelia_lists))) {
            wp_send_json_error('Amelia non configurata');
        }

        $resolve_listid = function(string $email) use ($amelia_listid, $amelia_lists): string {
            if (!empty($amelia_lists) && $email) {
                $tld = strtolower(substr(strrchr($email, '.'), 1) ?: '');
                foreach ($amelia_lists as $entry) {
                    if (strtolower($entry['country'] ?? '') === $tld) return $entry['listid'] ?? '';
                }
            }
            return $amelia_listid;
        };

        $phone_field = null; $email_field = null; $name_field = null;
        $phone_keywords = ['telefon','cellu','phone','mobile','cel','tel'];
        $name_keywords  = ['nome','cognome','name','surname','nominativo'];
        foreach ($form['fields'] as $f) {
            $ftype  = $f['type']  ?? '';
            $flabel = strtolower($f['label'] ?? '');
            if ($ftype === 'email' && $email_field === null) $email_field = $f;
            if (!empty($f['amelia_phone']) && $phone_field === null) $phone_field = $f;
            if (!empty($f['amelia_name'])  && $name_field  === null) $name_field  = $f;
            if ($name_field === null && in_array($ftype, ['text','textarea'], true)) {
                foreach ($name_keywords as $kw) {
                    if (strpos($flabel, $kw) !== false) { $name_field = $f; break; }
                }
            }
            if ($phone_field === null && in_array($ftype, ['text','tel','phone','number'], true)) {
                foreach ($phone_keywords as $kw) {
                    if (strpos($flabel, $kw) !== false) { $phone_field = $f; break; }
                }
            }
        }

        $fake_phone = false;
        $phone_val  = '';
        if ($phone_field !== null) {
            $phone_val = trim(is_array($data[$phone_field['id']] ?? '') ? implode('', $data[$phone_field['id']]) : (string)($data[$phone_field['id']] ?? ''));
            $phone_val = preg_replace('/[\s\-\.\(\)]+/', '', $phone_val);
            if (str_starts_with($phone_val, '+'))  $phone_val = substr($phone_val, 1);
            if (str_starts_with($phone_val, '00')) $phone_val = substr($phone_val, 2);
            $phone_val = preg_replace('/\D+/', '', $phone_val); // rimuove lettere e caratteri non numerici
            if (str_starts_with($phone_val, '0')) $phone_val = ''; // fisso italiano → userà fake
            if (str_starts_with($phone_val, '3') && strlen($phone_val) === 10) $phone_val = '39' . $phone_val;
        }
        if (!$phone_val) { $phone_val = '393471234567'; $fake_phone = true; }

        $email_val       = $email_field ? trim(is_array($data[$email_field['id']] ?? '') ? implode('', $data[$email_field['id']]) : (string)($data[$email_field['id']] ?? '')) : '';
        $resolved_listid = $resolve_listid($email_val);
        if (!$resolved_listid) wp_send_json_error('Nessuna lista trovata');

        $body = ['groupsId' => $resolved_listid];
        if ($email_val) $body['email'] = $email_val;
        if ($name_field) {
            $name_raw = trim(is_array($data[$name_field['id']] ?? '') ? implode(' ', $data[$name_field['id']]) : (string)($data[$name_field['id']] ?? ''));
            if ($name_raw !== '') {
                $parts = explode(' ', $name_raw, 2);
                $body['name'] = $parts[0];
                if (!empty($parts[1])) $body['lastname'] = $parts[1];
            }
        }

        $send_amelia = function ($msisdn) use ($amelia_apiurl, $amelia_key, $amelia_secret, $body) {
            $b = $body; $b['msisdn'] = $msisdn;
            $resp = wp_remote_post($amelia_apiurl . '/phonebook/contact', [
                'headers'  => ['Authorization' => 'Basic ' . base64_encode($amelia_key . ':' . $amelia_secret)],
                'body'     => $b, 'timeout' => 8, 'blocking' => true,
            ]);
            return [
                'wp_error' => is_wp_error($resp),
                'code'     => is_wp_error($resp) ? 0 : wp_remote_retrieve_response_code($resp),
                'body'     => is_wp_error($resp) ? $resp->get_error_message() : wp_remote_retrieve_body($resp),
            ];
        };

        $r = $send_amelia($phone_val);
        if (!$fake_phone && $r['code'] == 400 && strpos($r['body'], 'BAD_CONTACT_MSISDN') !== false) {
            $phone_val  = '393471234567';
            $fake_phone = true;
            $r          = $send_amelia($phone_val);
        }
        $code      = $r['code'];
        $body_resp = $r['body'];
        $already = strpos($body_resp, 'CONTACT_ALREADY_EXISTS') !== false
            || strpos(strtolower($body_resp), 'already exist') !== false;
        if ($r['wp_error'] || $code === 0 || $code >= 500) {
            $log = ['status' => 'error',   'code' => $code, 'message' => substr($body_resp, 0, 120)];
        } elseif ($already || $code === 409) {
            $log = ['status' => 'info',    'code' => $code, 'message' => 'già presente'];
        } elseif ($code >= 400) {
            $log = ['status' => 'error',   'code' => $code, 'message' => substr($body_resp, 0, 120)];
        } else {
            $log = ['status' => 'ok',      'code' => $code, 'message' => 'aggiunto'];
        }
        if ($fake_phone && in_array($log['status'], ['ok', 'info'], true)) {
            $log['fake_phone'] = true;
        }
        IF2_Submission::update_meta_log($submission_id, ['amelia' => $log]);
        IF2_Telemetry::track_amelia_result($log);
        if (in_array($log['status'] ?? '', ['ok', 'info'], true)) wp_send_json_success();
        else wp_send_json_error($log['message'] ?: 'Errore sconosciuto');
    }

    public static function retry_supabase(): void {
        check_ajax_referer('if2_admin', 'nonce');
        if (!current_user_can('edit_posts')) wp_send_json_error('Permesso negato');

        $submission_id = (int) ($_POST['submission_id'] ?? 0);
        if (!$submission_id) wp_send_json_error('ID mancante');

        $row = IF2_Submission::get_one($submission_id);
        if (!$row) wp_send_json_error('Submission non trovata');

        $form = IF2_Form::get((int) $row['form_id']);
        if (!$form) wp_send_json_error('Form non trovato');

        $data = json_decode($row['data'], true) ?: [];
        $meta = json_decode($row['meta'], true) ?: [];
        $meta['_row_created_at'] = $row['created_at'] ?? '';

        $result = IF2_Extensions::retry_supabase($form, $data, $meta, $submission_id);

        if ($result['status'] === 'ok') {
            IF2_Submission::update_meta_log($submission_id, ['supabase' => $result]);
            wp_send_json_success();
        } else {
            wp_send_json_error($result['message'] ?? 'Errore sconosciuto');
        }
    }
}
