/* in3pida Immagini - apre e chiude la guida. */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {

		var tasto = document.getElementById( 'in3img-apri-guida' );
		var guida = document.getElementById( 'in3img-guida' );

		if ( ! tasto || ! guida ) {
			return;
		}

		tasto.addEventListener( 'click', function () {

			var aperta = ! guida.hasAttribute( 'hidden' );

			if ( aperta ) {
				guida.setAttribute( 'hidden', '' );
				tasto.setAttribute( 'aria-expanded', 'false' );
				tasto.textContent = 'Guida';
				return;
			}

			guida.removeAttribute( 'hidden' );
			tasto.setAttribute( 'aria-expanded', 'true' );
			tasto.textContent = 'Chiudi la guida';
			guida.scrollIntoView( { behavior: 'smooth', block: 'start' } );
		} );
	} );
}() );
