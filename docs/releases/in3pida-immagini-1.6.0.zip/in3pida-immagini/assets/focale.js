/* in3pida Immagini - sposta a mano il punto del ritaglio. */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {

		var tela  = document.getElementById( 'in3img-tela' );
		var punto = document.getElementById( 'in3img-punto' );
		var campoX = document.getElementById( 'in3img-x' );
		var campoY = document.getElementById( 'in3img-y' );
		var campoM = document.getElementById( 'in3img-mano' );

		if ( ! tela || ! punto || ! campoX || ! campoY || ! campoM ) {
			return;
		}

		function sposta( evento ) {

			var area = tela.getBoundingClientRect();
			if ( ! area.width || ! area.height ) {
				return;
			}

			var x = ( evento.clientX - area.left ) / area.width;
			var y = ( evento.clientY - area.top ) / area.height;

			x = Math.max( 0, Math.min( 1, x ) );
			y = Math.max( 0, Math.min( 1, y ) );

			punto.style.left = ( x * 100 ).toFixed( 2 ) + '%';
			punto.style.top  = ( y * 100 ).toFixed( 2 ) + '%';

			campoX.value = x.toFixed( 4 );
			campoY.value = y.toFixed( 4 );
			campoM.value = '1';
		}

		tela.addEventListener( 'click', sposta );

		// Trascinamento, per chi preferisce.
		var premuto = false;
		tela.addEventListener( 'mousedown', function ( e ) { premuto = true; sposta( e ); e.preventDefault(); } );
		document.addEventListener( 'mousemove', function ( e ) { if ( premuto ) { sposta( e ); } } );
		document.addEventListener( 'mouseup', function () { premuto = false; } );
	} );
}() );
