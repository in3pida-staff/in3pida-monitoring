<?php
/**
 * Plugin Name: in3pida Immagini
 * Description: Alleggerisce le foto caricate, le rende disponibili in tre tagli e sceglie il punto giusto del ritaglio invece del centro fisso.
 * Version:     1.6.0
 * Author:      in3pida
 * License:     GPL-2.0-or-later
 * Requires at least: 5.6
 * Requires PHP: 7.4
 *
 * Tutto il lavoro pesante avviene una volta sola, al caricamento della foto.
 * In visita al sito questo plugin non fa assolutamente nulla.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'IN3IMG_VERSIONE', '1.6.0' );
define( 'IN3IMG_OPZIONE', 'in3img_misure' );
define( 'IN3IMG_OPZIONI', 'in3img_opzioni' );
define( 'IN3IMG_DIR', plugin_dir_path( __FILE__ ) );
define( 'IN3IMG_URL', plugin_dir_url( __FILE__ ) );

/**
 * Le due opzioni che non sono misure. Spente o accese, mai a meta'.
 */
function in3img_opzione( $chiave ) {

	static $o = null;
	if ( null === $o ) {
		$o = get_option( IN3IMG_OPZIONI );
		if ( ! is_array( $o ) ) {
			$o = array();
		}
	}

	$default = array(
		'nomi'          => 1, // pulisci i nomi dei file caricati
		'spegni_grandi'   => 0, // non generare le copie enormi di WordPress
		'butta_originale' => 0, // cancellare l'originale quando e' superfluo
	);

	if ( isset( $o[ $chiave ] ) ) {
		return (int) $o[ $chiave ];
	}

	return isset( $default[ $chiave ] ) ? $default[ $chiave ] : 0;
}

/* ------------------------------------------------------------------ *
 * Le tre misure
 * ------------------------------------------------------------------ */

function in3img_misure_default() {
	return array(
		array( 'slug' => 'in3-grande',  'nome' => 'Grande',  'w' => 1600, 'h' => 900 ),
		array( 'slug' => 'in3-media',   'nome' => 'Media',   'w' => 800,  'h' => 600 ),
		array( 'slug' => 'in3-piccola', 'nome' => 'Piccola', 'w' => 600,  'h' => 600 ),
	);
}

function in3img_misure() {

	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}

	$salvate = get_option( IN3IMG_OPZIONE );
	if ( ! is_array( $salvate ) || ! $salvate ) {
		$cache = in3img_misure_default();
		return $cache;
	}

	$pulite = array();
	foreach ( array_values( $salvate ) as $i => $v ) {
		$w = isset( $v['w'] ) ? absint( $v['w'] ) : 0;
		$h = isset( $v['h'] ) ? absint( $v['h'] ) : 0;
		if ( $w < 1 || $h < 1 ) {
			continue;
		}
		$pulite[] = array(
			'slug' => ! empty( $v['slug'] ) ? sanitize_key( $v['slug'] ) : 'in3-misura-' . ( $i + 1 ),
			'nome' => ! empty( $v['nome'] ) ? sanitize_text_field( $v['nome'] ) : 'Misura ' . ( $i + 1 ),
			'w'    => min( $w, 5000 ),
			'h'    => min( $h, 5000 ),
		);
	}

	$cache = $pulite ? $pulite : in3img_misure_default();
	return $cache;
}

add_action( 'after_setup_theme', 'in3img_registra_misure', 20 );
function in3img_registra_misure() {
	foreach ( in3img_misure() as $m ) {
		add_image_size( $m['slug'], $m['w'], $m['h'], true );
	}
}

/** Le nostre misure compaiono nel menu a tendina della libreria. */
add_filter( 'image_size_names_choose', 'in3img_nomi_leggibili' );
function in3img_nomi_leggibili( $nomi ) {
	foreach ( in3img_misure() as $m ) {
		$nomi[ $m['slug'] ] = $m['nome'] . ' (' . $m['w'] . '×' . $m['h'] . ')';
	}
	return $nomi;
}

/* ------------------------------------------------------------------ *
 * Peso
 * ------------------------------------------------------------------ */

/**
 * JPEG progressivo: stessa identica qualita', file piu' piccolo del 5-6%,
 * e la foto compare sfumata subito invece di scendere a fasce.
 * WordPress sa farlo ma lo tiene spento.
 *
 * Misurato su fotografie vere: 1115 KB -> 1053 KB.
 */
add_filter( 'image_save_progressive', 'in3img_progressivo', 10, 2 );
function in3img_progressivo( $progressivo, $mime = '' ) {
	if ( 'image/jpeg' === $mime ) {
		return true;
	}
	return $progressivo;
}

/**
 * Sulla qualita' non tocchiamo niente, ed e' una scelta.
 * WordPress comprime gia' a 82: scendere a 78 fa risparmiare solo il 5%
 * e comincia a sporcare i cieli e le pareti in tinta unita.
 *
 * Il peso vero non si toglie ricomprimendo, si toglie non servendo una foto
 * da 1600px dentro una scheda da 800: e' esattamente quello che fanno le tre
 * misure qui sotto. Misurato: -57% / -68% a foto.
 *
 * Se su un sito serve comunque comprimere di piu':
 *   add_filter( 'wp_editor_set_quality', function () { return 75; } );
 */

/* ------------------------------------------------------------------ *
 * Nome del file
 * ------------------------------------------------------------------ */

/**
 * "Città_di Napoli È BELLA (1).JPG" diventa "citta-di-napoli-e-bella-1.jpg".
 * Agisce solo sui file caricati, non su altri nomi gestiti da WordPress.
 */
add_filter( 'wp_handle_upload_prefilter', 'in3img_pulisci_nome', 20 );
add_filter( 'wp_handle_sideload_prefilter', 'in3img_pulisci_nome', 20 );
function in3img_pulisci_nome( $file ) {

	// Priorita' 20: se un altro plugin rinomina gia' i file, ha gia' deciso lui
	// e noi ci limitiamo a ripulire quello che ha scelto.
	if ( ! in3img_opzione( 'nomi' ) ) {
		return $file;
	}

	if ( empty( $file['name'] ) ) {
		return $file;
	}
	if ( empty( $file['type'] ) || 0 !== strpos( $file['type'], 'image/' ) ) {
		return $file;
	}

	$estensione = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
	$base       = pathinfo( $file['name'], PATHINFO_FILENAME );

	$base = remove_accents( $base );
	$base = strtolower( $base );
	$base = preg_replace( '/[^a-z0-9]+/', '-', $base );
	$base = trim( $base, '-' );

	if ( '' === $base ) {
		return $file; // meglio il nome originale che un nome vuoto
	}

	$file['name'] = $estensione ? $base . '.' . $estensione : $base;

	return $file;
}

/* ------------------------------------------------------------------ *
 * Il resto
 * ------------------------------------------------------------------ */

/**
 * Le copie enormi che WordPress genera da solo (1536 e 2048 px di lato) non
 * le usa quasi nessun tema, e sono i file piu' pesanti di tutta la libreria:
 * su una foto di prova pesavano 836 KB contro i 475 KB dei nostri tre tagli.
 *
 * Spento di default: e' una scelta che va fatta sapendo cosa usa il tema.
 */
add_filter( 'intermediate_image_sizes_advanced', 'in3img_spegni_grandi', 5 );
function in3img_spegni_grandi( $sizes ) {

	if ( ! in3img_opzione( 'spegni_grandi' ) ) {
		return $sizes;
	}

	unset( $sizes['1536x1536'], $sizes['2048x2048'] );

	return $sizes;
}

require_once IN3IMG_DIR . 'inc/analisi.php';
require_once IN3IMG_DIR . 'inc/monitoring.php';
require_once IN3IMG_DIR . 'inc/tagli.php';

if ( is_admin() ) {
	require_once IN3IMG_DIR . 'inc/admin.php';
}

/**
 * Appena attivato, il plugin si annuncia al cruscotto senza aspettare il giro
 * del giorno dopo: il primo battito parte un minuto dopo l'attivazione, non
 * subito, per non rallentare l'accensione.
 *
 * Un evento singolo qui non servirebbe: WordPress rifiuta di programmare due
 * volte lo stesso appuntamento a meno di dieci minuti di distanza. Si sposta
 * invece l'inizio di quello quotidiano.
 */
register_activation_hook( __FILE__, 'in3img_accendi' );
function in3img_accendi() {

	$gia = wp_next_scheduled( 'in3img_battito' );
	if ( $gia ) {
		wp_unschedule_event( $gia, 'in3img_battito' );
	}

	wp_schedule_event( time() + 60, 'daily', 'in3img_battito' );
}

/** Spegnendo il plugin si spegne anche il battito al cruscotto. */
register_deactivation_hook( __FILE__, 'in3img_spegni' );
function in3img_spegni() {
	$prossimo = wp_next_scheduled( 'in3img_battito' );
	if ( $prossimo ) {
		wp_unschedule_event( $prossimo, 'in3img_battito' );
	}
}

if ( ! function_exists( 'in3_immagine' ) ) {
	/**
	 * Comodo nel tema: echo in3_immagine( get_post_thumbnail_id(), 'in3-grande' );
	 */
	function in3_immagine( $attachment_id, $misura = 'in3-grande', $attr = array() ) {
		return wp_get_attachment_image( $attachment_id, $misura, false, $attr );
	}
}
