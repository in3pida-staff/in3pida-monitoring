<?php
/**
 * in3pida Immagini - pannelli di amministrazione.
 *
 * Grafica: stile in3pida, valori presi da in3pida form.
 * Tutto lo stile e' racchiuso in .in3img-wrap / .in3img-riquadro e non esce
 * da li': il resto del pannello di WordPress resta com'e'.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------------------ *
 * Fogli di stile
 * ------------------------------------------------------------------ */

add_action( 'admin_enqueue_scripts', 'in3img_assets' );
function in3img_assets( $hook ) {

	$nostra_pagina = ( 'settings_page_in3img' === $hook );
	$scheda_foto   = ( 'post.php' === $hook && in3img_e_immagine( get_post() ) );

	if ( ! $nostra_pagina && ! $scheda_foto ) {
		return;
	}

	wp_enqueue_style( 'in3img', IN3IMG_URL . 'assets/in3pida.css', array(), IN3IMG_VERSIONE );

	if ( $nostra_pagina ) {
		wp_enqueue_script( 'in3img-guida', IN3IMG_URL . 'assets/guida.js', array(), IN3IMG_VERSIONE, true );
	}

	if ( $scheda_foto ) {
		wp_enqueue_script( 'in3img', IN3IMG_URL . 'assets/focale.js', array(), IN3IMG_VERSIONE, true );
	}
}

/* ------------------------------------------------------------------ *
 * Impostazioni
 * ------------------------------------------------------------------ */

add_action( 'admin_menu', 'in3img_menu' );
function in3img_menu() {
	add_options_page( 'Immagini in3pida', 'Immagini in3pida', 'manage_options', 'in3img', 'in3img_pagina' );
}

add_action( 'admin_init', 'in3img_registra_opzione' );
function in3img_registra_opzione() {
	register_setting( 'in3img', IN3IMG_OPZIONE, array( 'sanitize_callback' => 'in3img_sanifica_misure' ) );
	register_setting( 'in3img', IN3IMG_OPZIONI, array( 'sanitize_callback' => 'in3img_sanifica_opzioni' ) );
}

function in3img_sanifica_opzioni( $valore ) {
	return array(
		'nomi'          => ! empty( $valore['nomi'] ) ? 1 : 0,
		'spegni_grandi'   => ! empty( $valore['spegni_grandi'] ) ? 1 : 0,
		'butta_originale' => ! empty( $valore['butta_originale'] ) ? 1 : 0,
	);
}

function in3img_sanifica_misure( $valore ) {

	if ( ! is_array( $valore ) ) {
		return in3img_misure_default();
	}

	$out   = array();
	$presi = array();

	foreach ( array_values( $valore ) as $i => $v ) {

		$w = isset( $v['w'] ) ? absint( $v['w'] ) : 0;
		$h = isset( $v['h'] ) ? absint( $v['h'] ) : 0;
		if ( $w < 1 || $h < 1 ) {
			continue;
		}

		$slug = ! empty( $v['slug'] ) ? sanitize_key( $v['slug'] ) : 'in3-misura-' . ( $i + 1 );
		if ( in_array( $slug, $presi, true ) ) {
			continue;
		}
		$presi[] = $slug;

		$out[] = array(
			'slug' => $slug,
			'nome' => ! empty( $v['nome'] ) ? sanitize_text_field( $v['nome'] ) : 'Misura ' . ( $i + 1 ),
			'w'    => min( $w, 5000 ),
			'h'    => min( $h, 5000 ),
		);
	}

	return $out ? $out : in3img_misure_default();
}

function in3img_pagina() {

	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$misure = in3img_misure();
	$campo  = IN3IMG_OPZIONE;
	$opz    = IN3IMG_OPZIONI;
	?>
	<div class="wrap in3img-wrap">

		<h1 class="wp-heading-inline">Immagini in3pida</h1>
		<button type="button" class="page-title-action in3img-bottone in3img-secondario"
			id="in3img-apri-guida" aria-expanded="false" aria-controls="in3img-guida">Guida</button>
		<hr class="wp-header-end">

		<form method="post" action="options.php">
			<?php settings_fields( 'in3img' ); ?>

			<div class="in3img-card">
				<h2>Le tre misure</h2>

				<table class="in3img-misure">
					<thead>
						<tr>
							<th>Nome</th>
							<th>Riferimento per il tema</th>
							<th>Larghezza</th>
							<th>Altezza</th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ( $misure as $i => $m ) : ?>
						<tr>
							<td>
								<input type="text" name="<?php echo esc_attr( $campo . '[' . $i . '][nome]' ); ?>"
									value="<?php echo esc_attr( $m['nome'] ); ?>">
							</td>
							<td>
								<code><?php echo esc_html( $m['slug'] ); ?></code>
								<input type="hidden" name="<?php echo esc_attr( $campo . '[' . $i . '][slug]' ); ?>"
									value="<?php echo esc_attr( $m['slug'] ); ?>">
							</td>
							<td>
								<input type="number" min="1" max="5000"
									name="<?php echo esc_attr( $campo . '[' . $i . '][w]' ); ?>"
									value="<?php echo (int) $m['w']; ?>"><span class="in3img-unita">px</span>
							</td>
							<td>
								<input type="number" min="1" max="5000"
									name="<?php echo esc_attr( $campo . '[' . $i . '][h]' ); ?>"
									value="<?php echo (int) $m['h']; ?>"><span class="in3img-unita">px</span>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<div class="in3img-card">
				<h2>Comportamento</h2>

				<label class="in3img-spunta">
					<input type="checkbox" name="<?php echo esc_attr( $opz ); ?>[nomi]" value="1"
						<?php checked( in3img_opzione( 'nomi' ), 1 ); ?>>
					<span>Pulisci il nome delle foto caricate</span>
				</label>

				<label class="in3img-spunta">
					<input type="checkbox" name="<?php echo esc_attr( $opz ); ?>[spegni_grandi]" value="1"
						<?php checked( in3img_opzione( 'spegni_grandi' ), 1 ); ?>>
					<span>Non generare le copie da 1536 e 2048 px di WordPress</span>
				</label>

				<label class="in3img-spunta">
					<input type="checkbox" name="<?php echo esc_attr( $opz ); ?>[butta_originale]" value="1"
						<?php checked( in3img_opzione( 'butta_originale' ), 1 ); ?>>
					<span>Cancella l'originale quando WordPress ne ha gi&agrave; fatto una copia a 2560 px
						<em class="in3img-allarme">non si torna indietro</em></span>
				</label>

				<?php submit_button( 'Salva' ); ?>
			</div>
		</form>

		<?php in3img_pannello_rigenera(); ?>
		<?php in3img_pannello_cruscotto(); ?>
		<?php in3img_guida(); ?>

	</div>
	<?php
}

/**
 * Tutte le spiegazioni stanno qui dentro, e solo qui.
 */
function in3img_guida() {

	$misure = in3img_misure();
	$primo  = $misure[0]['slug'];
	?>
	<div class="in3img-card in3img-guida" id="in3img-guida" hidden>
		<h2>Guida</h2>

		<h3>Che cosa fa</h3>
		<p>
			Quando qualcuno carica una foto, il plugin ne ricava subito tre copie gi&agrave; ritagliate
			nelle misure qui sopra. Chi carica non deve fare niente e non se ne accorge.
			L'originale non viene mai modificato.
		</p>

		<h3>Come si usano le tre misure</h3>
		<p>
			Non basta che esistano: le pagine devono chiederle, altrimenti WordPress continua a servire
			la foto intera e il sito resta pesante.
		</p>
		<p>
			Con Elementor: quando inserisci un'immagine, nel pannello a destra c'&egrave;
			<strong>Dimensione immagine</strong>, e l&igrave; dentro trovi le tre misure.
			Nel codice del tema:
		</p>
		<p>
			<code>the_post_thumbnail( '<?php echo esc_html( $primo ); ?>' );</code><br>
			<code>in3_immagine( $id, '<?php echo esc_html( $primo ); ?>' );</code>
		</p>
		<p>
			Se una misura non esiste perch&eacute; la foto era gi&agrave; piccola, WordPress ricade da solo
			sulla foto intera: non si rompe niente.
		</p>

		<h3>Dove finiscono i file</h3>
		<p>
			Nella stessa cartella dell'originale, dentro <code>wp-content/uploads</code>.
			Da <code>camera.jpg</code> nascono <code>camera-<?php echo esc_html( $primo ); ?>.jpg</code>
			e le altre due. Nella libreria non compaiono come foto separate: per WordPress sono
			la stessa foto in misure diverse.
		</p>

		<h3>Dove taglia</h3>
		<p>
			Il taglio parte dal centro e si sposta solo quando il soggetto &egrave; chiaramente da una parte,
			e comunque mai oltre il 15% della foto: su una camera d'albergo o un piatto ben fotografato
			il centro &egrave; gi&agrave; la scelta giusta, e spostarsi peggiorerebbe il taglio.
			Se nella foto c'&egrave; un orizzonte non lo taglia a met&agrave;: lo porta su un terzo.
		</p>
		<p>
			Quando sbaglia: Libreria media, si apre la foto, riquadro <strong>Punto del ritaglio</strong>,
			si clicca sul punto giusto e si salva. I tre tagli vengono rifatti subito.
		</p>
		<p>
			Il plugin <strong>non riconosce i volti</strong>. Per le foto di persone si usa il punto manuale.
		</p>

		<h3>Le tre spunte</h3>
		<p>
			<strong>Pulisci il nome delle foto caricate.</strong>
			&laquo;Foto Hotel Citt&agrave; Alta (1).JPG&raquo; diventa &laquo;foto-hotel-citta-alta-1.jpg&raquo;.
			Da togliere se un altro plugin si occupa gi&agrave; dei nomi dei file.
		</p>
		<p>
			<strong>Non generare le copie da 1536 e 2048 px.</strong>
			Sono i file pi&ugrave; pesanti della libreria e quasi nessun tema li usa: su una foto di prova
			pesavano 836 KB contro i 475 KB dei tre tagli. Da accendere solo dopo aver controllato
			che il tema non le richieda.
		</p>
		<p>
			<strong>Cancella l'originale.</strong>
			Riguarda solo le foto caricate sopra i 2560 px: di quelle WordPress si tiene gi&agrave;
			una copia su cui lavora, e l'originale resta sul server senza che nessuno lo usi.
			Su una foto da 4000&times;3000 sono 1,6 MB recuperati, e quella foto passa da 4,1 a 2,5 MB.
			Le foto pi&ugrave; piccole non vengono mai toccate, perch&eacute; l&igrave; l'originale &egrave;
			l'unico file che esiste. Se un taglio non riesce, non cancella niente.
			&Egrave; l'unica cosa che il plugin non pu&ograve; annullare: il file cancellato non torna.
		</p>

		<h3>Foto gi&agrave; in libreria</h3>
		<p>
			Le foto caricate prima del plugin non hanno i tre tagli. Il pulsante qui sopra ne rifà venti
			per volta, cos&igrave; una libreria grossa non manda in timeout il server.
			Si pu&ograve; cliccare quando si vuole, anche a distanza di giorni.
			Gli originali non vengono toccati.
		</p>

		<h3>Quanto costa</h3>
		<p>
			Al caricamento: circa mezzo secondo a foto. In visita al sito: zero, il plugin non gira
			davanti ai visitatori.
		</p>
	</div>
	<?php
}

/**
 * Le foto gia' in libreria: si rifanno a blocchi, cosi' anche una libreria
 * grossa non manda il server in timeout.
 */
function in3img_pannello_rigenera() {

	$fatte = 0;

	if ( isset( $_POST['in3img_rigenera'] ) && check_admin_referer( 'in3img_rigenera' ) && current_user_can( 'manage_options' ) ) {
		$blocco = in3img_da_fare( 20 );
		foreach ( $blocco['ids'] as $id ) {
			if ( in3img_rigenera( $id ) ) {
				$fatte++;
			} else {
				// Non e' un'immagine trattabile: la si segna comunque, altrimenti
				// resta in coda per sempre.
				update_post_meta( $id, '_in3img_fatto', 'saltata' );
			}
		}
	}

	$restano = in3img_da_fare();
	?>
	<div class="in3img-card">
		<h2>Foto gi&agrave; in libreria</h2>

		<?php if ( $fatte ) : ?>
			<p class="in3img-avviso">Rifatte <?php echo (int) $fatte; ?> foto.</p>
		<?php endif; ?>

		<?php if ( $restano['totale'] > 0 ) : ?>
			<p>Senza i tre tagli: <strong><?php echo (int) $restano['totale']; ?></strong> foto.</p>
			<form method="post">
				<?php wp_nonce_field( 'in3img_rigenera' ); ?>
				<p>
					<button type="submit" name="in3img_rigenera" value="1" class="in3img-bottone in3img-secondario">
						Rifai i tagli di 20 foto
					</button>
				</p>
			</form>
		<?php else : ?>
			<p>Tutte le foto della libreria hanno i tre tagli.</p>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Collegamento al cruscotto: si vede subito se il battito arriva o no,
 * e con che errore.
 */
function in3img_pannello_cruscotto() {

	if ( isset( $_POST['in3img_battito_ora'] ) && check_admin_referer( 'in3img_battito_ora' ) && current_user_can( 'manage_options' ) ) {
		delete_transient( 'in3img_saluto_in_corso' );
		in3img_manda_battito();
	}

	$u        = in3img_ultimo_battito();
	$prossimo = wp_next_scheduled( 'in3img_battito' );
	?>
	<div class="in3img-card">
		<h2>Cruscotto</h2>

		<?php if ( $u && ! empty( $u['ok'] ) ) : ?>
			<p class="in3img-avviso">Ultimo invio riuscito: <?php echo esc_html( wp_date( 'j F Y, H:i', (int) $u['quando'] ) ); ?></p>
		<?php elseif ( $u ) : ?>
			<p class="in3img-avviso in3img-guasto">
				Ultimo invio non riuscito<?php echo ! empty( $u['codice'] ) ? ' (codice ' . (int) $u['codice'] . ')' : ''; ?>:
				<?php echo esc_html( $u['messaggio'] ); ?>
			</p>
		<?php else : ?>
			<p>Non e' ancora stato mandato nessun segnale.</p>
		<?php endif; ?>

		<form method="post">
			<?php wp_nonce_field( 'in3img_battito_ora' ); ?>
			<p>
				<button type="submit" name="in3img_battito_ora" value="1" class="in3img-bottone in3img-secondario">
					Manda ora
				</button>
			</p>
		</form>

		<table class="in3img-misure">
			<tbody>
				<tr><td>Nome nel cruscotto</td><td><code><?php echo esc_html( IN3IMG_NOME_PLUGIN ); ?></code></td></tr>
				<tr><td>Identificativo del sito</td><td><code><?php echo esc_html( in3img_site_id() ); ?></code></td></tr>
				<tr><td>Prossimo invio automatico</td><td><?php echo $prossimo ? esc_html( wp_date( 'j F Y, H:i', $prossimo ) ) : 'non programmato'; ?></td></tr>
			</tbody>
		</table>
	</div>
	<?php
}

/* ------------------------------------------------------------------ *
 * Il punto del ritaglio, nella scheda della foto
 * ------------------------------------------------------------------ */

add_action( 'add_meta_boxes_attachment', 'in3img_aggiungi_riquadro' );
function in3img_aggiungi_riquadro( $post ) {

	if ( ! in3img_e_immagine( $post ) || ! current_user_can( 'edit_post', $post->ID ) ) {
		return;
	}

	add_meta_box( 'in3img_focale', 'Punto del ritaglio', 'in3img_riquadro', 'attachment', 'normal', 'high' );
}

function in3img_e_immagine( $post ) {
	return $post && 'attachment' === $post->post_type && 0 === strpos( (string) $post->post_mime_type, 'image/' );
}

function in3img_riquadro( $post ) {

	$url = wp_get_attachment_image_url( $post->ID, 'large' );
	if ( ! $url ) {
		echo '<p>Anteprima non disponibile.</p>';
		return;
	}

	$mano = get_post_meta( $post->ID, '_in3img_focale_mano', true );
	$auto = get_post_meta( $post->ID, '_in3img_focale', true );

	$a_mano = ( is_array( $mano ) && isset( $mano['x'], $mano['y'] ) );
	$punto  = $a_mano ? $mano : ( is_array( $auto ) ? $auto : array( 'x' => 0.5, 'y' => 0.5 ) );

	$tipo = isset( $auto['tipo'] ) ? $auto['tipo'] : 'centro';
	$come = array(
		'soggetto' => 'il soggetto sta da una parte, taglio spostato',
		'centro'   => 'foto equilibrata, taglio centrato',
	);
	$detto = isset( $come[ $tipo ] ) ? $come[ $tipo ] : $tipo;
	if ( isset( $auto['orizzonte'] ) && null !== $auto['orizzonte'] ) {
		$detto .= ', orizzonte tenuto su un terzo';
	}

	wp_nonce_field( 'in3img_focale_' . $post->ID, 'in3img_nonce' );
	?>
	<div class="in3img-riquadro">

		<p class="in3img-stato">
			<?php if ( $a_mano ) : ?>
				<strong>Punto impostato a mano.</strong>
			<?php else : ?>
				In automatico: <strong><?php echo esc_html( $detto ); ?></strong>.
			<?php endif; ?>
			Clicca sulla foto per spostare il punto.
		</p>

		<div class="in3img-tela" id="in3img-tela">
			<img src="<?php echo esc_url( $url ); ?>" alt="">
			<span class="in3img-punto" id="in3img-punto"
				style="left:<?php echo esc_attr( round( $punto['x'] * 100, 2 ) ); ?>%;top:<?php echo esc_attr( round( $punto['y'] * 100, 2 ) ); ?>%"></span>
		</div>

		<input type="hidden" name="in3img_x" id="in3img-x" value="<?php echo esc_attr( round( $punto['x'], 4 ) ); ?>">
		<input type="hidden" name="in3img_y" id="in3img-y" value="<?php echo esc_attr( round( $punto['y'], 4 ) ); ?>">
		<input type="hidden" name="in3img_mano" id="in3img-mano" value="<?php echo $a_mano ? '1' : '0'; ?>">

		<label class="in3img-spunta">
			<input type="checkbox" name="in3img_auto" value="1">
			<span>Torna al punto calcolato in automatico</span>
		</label>
	</div>
	<?php
}

add_action( 'edit_attachment', 'in3img_salva_focale' );
function in3img_salva_focale( $attachment_id ) {

	if ( ! isset( $_POST['in3img_nonce'] ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['in3img_nonce'] ) ), 'in3img_focale_' . $attachment_id ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $attachment_id ) ) {
		return;
	}

	if ( ! empty( $_POST['in3img_auto'] ) ) {

		delete_post_meta( $attachment_id, '_in3img_focale_mano' );
		delete_post_meta( $attachment_id, '_in3img_focale' ); // sara' ricalcolato

	} else {

		if ( ! isset( $_POST['in3img_mano'] ) || '1' !== $_POST['in3img_mano'] ) {
			return; // nessuno ha toccato il pallino: non si tocca niente
		}

		$x = isset( $_POST['in3img_x'] ) ? (float) $_POST['in3img_x'] : 0.5;
		$y = isset( $_POST['in3img_y'] ) ? (float) $_POST['in3img_y'] : 0.5;

		update_post_meta( $attachment_id, '_in3img_focale_mano', array(
			'x' => max( 0, min( 1, $x ) ),
			'y' => max( 0, min( 1, $y ) ),
		) );

		in3img_conta( 'punti_a_mano' );
	}

	in3img_rigenera( $attachment_id );
}
