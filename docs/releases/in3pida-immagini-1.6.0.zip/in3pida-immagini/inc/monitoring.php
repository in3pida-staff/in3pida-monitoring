<?php
/**
 * in3pida Immagini - collegamento al cruscotto Monitoring.
 *
 * Fa due cose:
 *   1. manda un battito giornaliero, cosi' il plugin compare nel cruscotto
 *      accanto a in3pida Form con la sua versione e i suoi numeri;
 *   2. espone due indirizzi che il cruscotto puo' chiamare, per leggere lo
 *      stato e per far installare una versione nuova.
 *
 * Il battito non passa dal sito monitoring.in3pida.it - quello e' solo pagine
 * statiche - ma dalla stessa banca dati che legge il cruscotto, chiamando la
 * funzione protetta mon_heartbeat. E' la strada che usa gia' in3pida Form:
 * la chiave pubblica non puo' scrivere dritta sulle tabelle, e la funzione
 * lavora soltanto sulla riga del sito che la chiama.
 *
 * Il plugin usa un proprio site_id e una propria chiave, diversi da quelli di
 * in3pida Form: nel cruscotto ogni riga e' un plugin su un sito, e i due non
 * devono sovrascriversi a vicenda.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Banca dati del monitoraggio: stesso progetto del cruscotto. */
if ( ! defined( 'IN3IMG_SB_URL' ) ) {
	define( 'IN3IMG_SB_URL', 'https://yyauvoqjdzrbmebeafit.supabase.co' );
}
if ( ! defined( 'IN3IMG_SB_KEY' ) ) {
	define( 'IN3IMG_SB_KEY', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl5YXV2b3FqZHpyYm1lYmVhZml0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzk3OTM2MDAsImV4cCI6MjA5NTM2OTYwMH0.M6kD56PEO_UcJ68Vjquo03vuORjv62MflIzGLzYKN9w' );
}

/** Da dove si accettano i pacchetti di aggiornamento. */
if ( ! defined( 'IN3IMG_MONITOR' ) ) {
	define( 'IN3IMG_MONITOR', 'https://monitoring.in3pida.it' );
}

/** Il nome con cui questo plugin si presenta al cruscotto. */
if ( ! defined( 'IN3IMG_NOME_PLUGIN' ) ) {
	define( 'IN3IMG_NOME_PLUGIN', 'in3pida-immagini' );
}

/* ------------------------------------------------------------------ *
 * Identita' del sito
 * ------------------------------------------------------------------ */

/**
 * Un UUID e basta: nella banca dati il campo e' di tipo uuid e un valore
 * con prefissi verrebbe rifiutato.
 */
function in3img_site_id() {

	$id = (string) get_option( 'in3img_site_id', '' );

	if ( ! preg_match( '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i', $id ) ) {
		$id = wp_generate_uuid4();
		update_option( 'in3img_site_id', $id, false );
	}

	return $id;
}

function in3img_api_key() {
	$k = get_option( 'in3img_api_key' );
	if ( ! $k ) {
		$k = wp_generate_password( 40, false, false );
		update_option( 'in3img_api_key', $k, false );
	}
	return $k;
}

function in3img_sb_url() {
	return untrailingslashit( (string) apply_filters( 'in3img_sb_url', IN3IMG_SB_URL ) );
}

function in3img_monitor() {
	return untrailingslashit( (string) apply_filters( 'in3img_monitor', IN3IMG_MONITOR ) );
}

/* ------------------------------------------------------------------ *
 * I numeri che mandiamo
 * ------------------------------------------------------------------ */

/**
 * Contatori tenuti in un'unica opzione, aggiornati mentre il plugin lavora.
 * Niente conteggi sul database al momento del battito: costerebbero e basta.
 */
function in3img_conta( $cosa, $quanto = 1 ) {

	$s = get_option( 'in3img_numeri' );
	if ( ! is_array( $s ) ) {
		$s = array();
	}

	$s[ $cosa ] = ( isset( $s[ $cosa ] ) ? (int) $s[ $cosa ] : 0 ) + (int) $quanto;

	update_option( 'in3img_numeri', $s, false );
}

function in3img_numeri() {

	$s = get_option( 'in3img_numeri' );
	if ( ! is_array( $s ) ) {
		$s = array();
	}

	return array(
		'foto_trattate'   => isset( $s['foto_trattate'] ) ? (int) $s['foto_trattate'] : 0,
		'tagli_generati'  => isset( $s['tagli_generati'] ) ? (int) $s['tagli_generati'] : 0,
		'punti_a_mano'    => isset( $s['punti_a_mano'] ) ? (int) $s['punti_a_mano'] : 0,
		'originali_tolti' => isset( $s['originali_tolti'] ) ? (int) $s['originali_tolti'] : 0,
		'kb_liberati'     => isset( $s['byte_liberati'] ) ? (int) round( $s['byte_liberati'] / 1024 ) : 0,
	);
}

/* ------------------------------------------------------------------ *
 * Il battito
 * ------------------------------------------------------------------ */

add_action( 'in3img_battito', 'in3img_manda_battito' );

add_action( 'init', 'in3img_programma_battito' );
function in3img_programma_battito() {
	if ( ! wp_next_scheduled( 'in3img_battito' ) ) {
		wp_schedule_event( time() + 300, 'daily', 'in3img_battito' );
	}
}

/**
 * Il primo saluto, senza che nessuno debba premere niente.
 *
 * Aspettare il giro quotidiano vorrebbe dire non vedere il sito nel cruscotto
 * per ore. Quindi: alla prima pagina aperta dopo l'installazione - e ogni volta
 * che la versione cambia - il battito parte subito.
 *
 * Il lucchetto da un quarto d'ora evita che un sito irraggiungibile ci riprovi
 * a ogni singola visita.
 */
add_action( 'init', 'in3img_saluta_se_serve', 20 );
function in3img_saluta_se_serve() {

	if ( wp_doing_ajax() || wp_doing_cron() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
		return;
	}

	$ultimo = in3img_ultimo_battito();

	$serve = ( ! $ultimo )
		|| empty( $ultimo['ok'] )
		|| ( isset( $ultimo['versione'] ) && IN3IMG_VERSIONE !== $ultimo['versione'] )
		|| ! isset( $ultimo['versione'] );

	if ( ! $serve ) {
		return;
	}

	if ( get_transient( 'in3img_saluto_in_corso' ) ) {
		return;
	}
	set_transient( 'in3img_saluto_in_corso', 1, 15 * MINUTE_IN_SECONDS );

	in3img_manda_battito();
}

function in3img_manda_battito() {

	$tema = wp_get_theme();

	$risposta = wp_remote_post( in3img_sb_url() . '/rest/v1/rpc/mon_heartbeat', array(
		'timeout'  => 8,
		'blocking' => true,
		'headers'  => array(
			'apikey'        => IN3IMG_SB_KEY,
			'Authorization' => 'Bearer ' . IN3IMG_SB_KEY,
			'Content-Type'  => 'application/json',
			'Prefer'        => 'return=minimal',
		),
		'body'     => wp_json_encode( array(
			'p' => array(
				'site_id'        => in3img_site_id(),
				'api_key'        => in3img_api_key(),
				'plugin_name'    => IN3IMG_NOME_PLUGIN,
				'plugin_version' => IN3IMG_VERSIONE,
				'wp_version'     => get_bloginfo( 'version' ),
				'php_version'    => PHP_VERSION,
				'theme_active'   => $tema ? $tema->get( 'Name' ) : '',
				'site_url'       => get_site_url(),
				'site_name'      => get_bloginfo( 'name' ),
				'last_heartbeat' => gmdate( 'c' ),
			),
		) ),
	) );

	if ( is_wp_error( $risposta ) ) {
		$esito = array( 'ok' => false, 'codice' => 0, 'messaggio' => $risposta->get_error_message(), 'versione' => IN3IMG_VERSIONE );
		update_option( 'in3img_ultimo_battito', array_merge( $esito, array( 'quando' => time() ) ), false );
		return $esito;
	}

	$codice = (int) wp_remote_retrieve_response_code( $risposta );
	$corpo  = trim( (string) wp_remote_retrieve_body( $risposta ) );

	if ( $codice < 200 || $codice > 299 ) {
		$esito = array(
			'ok'        => false,
			'codice'    => $codice,
			'messaggio' => '' !== $corpo ? mb_substr( $corpo, 0, 300 ) : 'nessuna spiegazione dal server',
			'versione'  => IN3IMG_VERSIONE,
		);
		update_option( 'in3img_ultimo_battito', array_merge( $esito, array( 'quando' => time() ) ), false );
		return $esito;
	}

	// I numeri vanno in un'altra tabella, e solo dopo che il sito esiste:
	// il permesso di scrivere gli eventi vale solo per i siti gia' censiti.
	in3img_manda_numeri();

	$esito = array( 'ok' => true, 'codice' => $codice, 'messaggio' => '', 'versione' => IN3IMG_VERSIONE );
	update_option( 'in3img_ultimo_battito', array_merge( $esito, array( 'quando' => time() ) ), false );

	return $esito;
}

/** L'esito dell'ultimo battito, per mostrarlo nelle impostazioni. */
function in3img_ultimo_battito() {
	$u = get_option( 'in3img_ultimo_battito' );
	return is_array( $u ) ? $u : null;
}

function in3img_manda_numeri() {

	wp_remote_post( in3img_sb_url() . '/rest/v1/mon_events', array(
		'timeout'  => 5,
		'blocking' => false,
		'headers'  => array(
			'apikey'        => IN3IMG_SB_KEY,
			'Authorization' => 'Bearer ' . IN3IMG_SB_KEY,
			'Content-Type'  => 'application/json',
			'Prefer'        => 'return=minimal',
		),
		'body'     => wp_json_encode( array(
			'site_id'    => in3img_site_id(),
			'event_type' => 'in3img_numeri',
			'payload'    => in3img_numeri(),
		) ),
	) );
}

/* ------------------------------------------------------------------ *
 * Gli indirizzi che il cruscotto chiama
 * ------------------------------------------------------------------ */

add_action( 'rest_api_init', 'in3img_rotte' );
function in3img_rotte() {

	// Lettura dello stato: versione del plugin e numeri.
	register_rest_route( 'in3img/v1', '/status', array(
		'methods'             => 'GET',
		'callback'            => 'in3img_rest_stato',
		'permission_callback' => '__return_true',
	) );

	// Aggiornamento comandato dal cruscotto.
	register_rest_route( 'in3img/v1', '/update', array(
		'methods'             => array( 'POST' ),
		'callback'            => 'in3img_rest_aggiorna',
		'permission_callback' => '__return_true',
	) );
}

function in3img_chiave_giusta( $chiave ) {
	$vera = in3img_api_key();
	return ( is_string( $chiave ) && '' !== $chiave && hash_equals( $vera, $chiave ) );
}

function in3img_rest_stato( WP_REST_Request $req ) {

	if ( ! in3img_chiave_giusta( (string) $req->get_param( 'api_key' ) ) ) {
		return new WP_REST_Response( array( 'error' => 'Non autorizzato' ), 401 );
	}

	return new WP_REST_Response( array_merge( array(
		'plugin_name'    => IN3IMG_NOME_PLUGIN,
		'plugin_version' => IN3IMG_VERSIONE,
		'wp_version'     => get_bloginfo( 'version' ),
		'php_version'    => PHP_VERSION,
	), in3img_numeri() ), 200 );
}

/**
 * Installa una nuova versione del plugin su comando del cruscotto.
 *
 * Accetta i due modi che il cruscotto usa gia' con in3pida Form:
 *   - il pacchetto zip caricato direttamente (campo plugin_zip)
 *   - l'indirizzo da cui prenderlo (campo download_url)
 *
 * Due sbarramenti: la chiave del sito dev'essere quella giusta, e l'indirizzo
 * deve stare sul dominio del cruscotto. Un pacchetto che arriva da altrove
 * viene rifiutato senza nemmeno essere scaricato.
 */
function in3img_rest_aggiorna( WP_REST_Request $req ) {

	if ( ! in3img_chiave_giusta( (string) $req->get_param( 'api_key' ) ) ) {
		return new WP_REST_Response( array( 'error' => 'Non autorizzato' ), 401 );
	}

	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	require_once ABSPATH . 'wp-admin/includes/misc.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/plugin.php';

	$file      = plugin_basename( IN3IMG_DIR . 'in3pida-immagini.php' );
	$caricati  = $req->get_file_params();
	$da_pulire = '';

	if ( ! empty( $caricati['plugin_zip']['tmp_name'] ) ) {

		$pacchetto = trailingslashit( get_temp_dir() ) . 'in3img-' . wp_generate_password( 8, false, false ) . '.zip';

		if ( ! @copy( $caricati['plugin_zip']['tmp_name'], $pacchetto ) ) {
			return new WP_REST_Response( array( 'error' => 'Non riesco a salvare il pacchetto' ), 500 );
		}
		$da_pulire = $pacchetto;

	} else {

		$url = esc_url_raw( (string) $req->get_param( 'download_url' ) );
		if ( ! $url ) {
			return new WP_REST_Response( array( 'error' => 'Serve plugin_zip oppure download_url' ), 400 );
		}

		$casa = wp_parse_url( in3img_monitor(), PHP_URL_HOST );
		$suo  = wp_parse_url( $url, PHP_URL_HOST );
		if ( ! $suo || ! $casa || strtolower( $suo ) !== strtolower( $casa ) ) {
			return new WP_REST_Response( array( 'error' => 'Indirizzo non consentito' ), 401 );
		}

		$pacchetto = $url;
	}

	$upgrader = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );

	$esito = $upgrader->run( array(
		'package'                     => $pacchetto,
		'destination'                 => WP_PLUGIN_DIR,
		'clear_destination'           => true,
		'clear_working'               => true,
		'abort_if_destination_exists' => false,
		'hook_extra'                  => array(
			'plugin' => $file,
			'type'   => 'plugin',
			'action' => 'update',
		),
	) );

	if ( $da_pulire && file_exists( $da_pulire ) ) {
		@unlink( $da_pulire );
	}

	if ( is_wp_error( $esito ) ) {
		return new WP_REST_Response( array( 'error' => $esito->get_error_message() ), 500 );
	}
	if ( false === $esito || null === $esito ) {
		return new WP_REST_Response( array( 'error' => 'Aggiornamento fallito: controlla i permessi dei file' ), 500 );
	}

	// Il plugin e' stato riscritto sotto i piedi: se si e' spento, si riaccende.
	if ( ! is_plugin_active( $file ) ) {
		activate_plugin( $file );
	}

	return new WP_REST_Response( array(
		'success' => true,
		'current' => IN3IMG_VERSIONE,
	), 200 );
}
