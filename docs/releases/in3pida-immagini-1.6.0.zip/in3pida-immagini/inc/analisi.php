<?php
/**
 * in3pida Immagini - analisi della foto.
 *
 * Decide DOVE guardare, con due regole e molta prudenza:
 *
 *   1. si resta al centro, e ci si sposta solo quando una meta' della foto ha
 *      nettamente piu' sostanza dell'altra - e comunque mai di tanto;
 *   2. se c'e' un orizzonte, non lo si taglia a meta': va su un terzo.
 *
 * Il criterio di fondo: meglio non intervenire che intervenire male. Su una
 * camera d'albergo o un piatto ben fotografato il centro e' gia' la scelta
 * giusta, e spostarsi peggiorerebbe il taglio.
 *
 * Tutto il lavoro avviene su una miniatura da 200px: costa una decina di
 * millisecondi e non carica mai in memoria la foto a piena risoluzione.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Lato della miniatura su cui si ragiona. */
if ( ! defined( 'IN3IMG_LATO_ANALISI' ) ) {
	define( 'IN3IMG_LATO_ANALISI', 200 );
}

/** Quanto ci si puo' allontanare dal centro, al massimo. */
if ( ! defined( 'IN3IMG_SPOSTAMENTO_MAX' ) ) {
	define( 'IN3IMG_SPOSTAMENTO_MAX', 0.15 );
}

/** Quanto deve essere sbilanciata una foto perche' valga la pena spostarsi. */
if ( ! defined( 'IN3IMG_SOGLIA_SBILANCIO' ) ) {
	define( 'IN3IMG_SOGLIA_SBILANCIO', 2.0 );
}

function in3img_filtro( $nome, $valore ) {
	return function_exists( 'apply_filters' ) ? apply_filters( $nome, $valore ) : $valore;
}

/* ------------------------------------------------------------------ *
 * Prudenza tecnica
 * ------------------------------------------------------------------ */

/**
 * L'analisi carica la foto in memoria: se non ci sta, non ci proviamo nemmeno.
 * Meglio un taglio centrato che una schermata bianca.
 */
function in3img_memoria_sufficiente( $file ) {

	$info = @getimagesize( $file );
	if ( ! $info || empty( $info[0] ) || empty( $info[1] ) ) {
		return false;
	}

	$servono = (float) $info[0] * (float) $info[1] * 5.0; // 4 byte a pixel + margine

	$grezzo = trim( (string) ini_get( 'memory_limit' ) );
	if ( '' === $grezzo || '-1' === $grezzo ) {
		return true;
	}

	$unita  = strtolower( substr( $grezzo, -1 ) );
	$limite = (float) $grezzo;
	if ( 'g' === $unita ) {
		$limite *= 1073741824;
	} elseif ( 'm' === $unita ) {
		$limite *= 1048576;
	} elseif ( 'k' === $unita ) {
		$limite *= 1024;
	}

	if ( $limite <= 0 ) {
		return true;
	}

	return ( memory_get_usage( true ) + $servono ) < ( $limite * 0.8 );
}

/** imagedestroy() serve solo su PHP 7: dalla 8 non fa niente ed e' deprecata. */
function in3img_libera( $img ) {
	if ( PHP_VERSION_ID < 80000 && function_exists( 'imagedestroy' ) ) {
		imagedestroy( $img );
	}
}

/**
 * La miniatura di lavoro, letta come luminosita' pixel per pixel.
 *
 * Si prova prima con GD e, se non c'e', con Imagick: cosi' il punto del
 * ritaglio funziona su entrambi i tipi di server. Se non c'e' nessuno dei due
 * si torna null e il taglio resta al centro.
 *
 * @return array|null array( luminosita[], larghezza, altezza )
 */
function in3img_miniatura( $file ) {

	if ( ! in3img_memoria_sufficiente( $file ) ) {
		return null;
	}

	$lato = (int) in3img_filtro( 'in3img_lato_analisi', IN3IMG_LATO_ANALISI );

	if ( function_exists( 'imagecreatefromstring' ) && function_exists( 'imagescale' ) ) {
		return in3img_miniatura_gd( $file, $lato );
	}

	if ( class_exists( 'Imagick' ) ) {
		return in3img_miniatura_imagick( $file, $lato );
	}

	return null;
}

/**
 * Stessa miniatura con Imagick, per i server senza GD.
 */
function in3img_miniatura_imagick( $file, $lato ) {

	try {
		$im = new Imagick( $file );
		$im->setImageColorspace( Imagick::COLORSPACE_SRGB );

		$w = $im->getImageWidth();
		$h = $im->getImageHeight();
		if ( $w < 16 || $h < 16 ) {
			$im->clear();
			return null;
		}

		if ( max( $w, $h ) > $lato ) {
			$scala = $lato / max( $w, $h );
			$w     = max( 16, (int) round( $w * $scala ) );
			$h     = max( 16, (int) round( $h * $scala ) );
			$im->thumbnailImage( $w, $h );
		}

		$pixel = $im->exportImagePixels( 0, 0, $w, $h, 'RGB', Imagick::PIXEL_CHAR );
		$im->clear();

		if ( ! is_array( $pixel ) || count( $pixel ) < ( $w * $h * 3 ) ) {
			return null;
		}

		$lum = array();
		for ( $i = 0, $n = $w * $h; $i < $n; $i++ ) {
			$j            = $i * 3;
			$lum[ $i ] = (int) ( 0.299 * $pixel[ $j ] + 0.587 * $pixel[ $j + 1 ] + 0.114 * $pixel[ $j + 2 ] );
		}

		return array( $lum, $w, $h );

	} catch ( Exception $e ) {
		return null; // qualunque cosa vada storta: si taglia al centro
	}
}

/**
 * Miniatura con GD.
 */
function in3img_miniatura_gd( $file, $lato ) {

	$dati = @file_get_contents( $file );
	if ( ! $dati ) {
		return null;
	}

	$img = @imagecreatefromstring( $dati );
	unset( $dati );
	if ( ! $img ) {
		return null;
	}

	$w = imagesx( $img );
	$h = imagesy( $img );
	if ( $w < 16 || $h < 16 ) {
		in3img_libera( $img );
		return null;
	}

	if ( max( $w, $h ) > $lato ) {
		$scala = $lato / max( $w, $h );
		$mini  = imagescale( $img, max( 16, (int) round( $w * $scala ) ), max( 16, (int) round( $h * $scala ) ) );
		in3img_libera( $img );
		if ( ! $mini ) {
			return null;
		}
		$img = $mini;
		$w   = imagesx( $img );
		$h   = imagesy( $img );
	}

	$lum = array();
	for ( $y = 0; $y < $h; $y++ ) {
		$riga = $y * $w;
		for ( $x = 0; $x < $w; $x++ ) {
			$c = imagecolorat( $img, $x, $y );
			$lum[ $riga + $x ] = (int) (
				0.299 * ( ( $c >> 16 ) & 0xFF ) +
				0.587 * ( ( $c >> 8 ) & 0xFF ) +
				0.114 * ( $c & 0xFF )
			);
		}
	}
	in3img_libera( $img );

	return array( $lum, $w, $h );
}

/* ------------------------------------------------------------------ *
 * L'analisi
 * ------------------------------------------------------------------ */

/**
 * @return array|null array(
 *     'x'         => 0..1,
 *     'y'         => 0..1,
 *     'tipo'      => 'soggetto' | 'centro',
 *     'orizzonte' => null | 0..1,
 * )
 */
function in3img_analizza( $file ) {

	$mini = in3img_miniatura( $file );
	if ( ! $mini ) {
		return null;
	}
	list( $lum, $w, $h ) = $mini;

	$n = $w * $h;

	// La mappa si calcola su una versione sfocata: cosi' le trame fitte
	// (tende a fiori, ghiaia, fogliame, tappeti, siepi) si spengono e restano
	// i bordi veri di mobili, muri e soggetti. Senza questo passaggio una
	// tenda a fiori si porta via il taglio.
	$struttura = in3img_energia( in3img_sfoca( in3img_sfoca( $lum, $w, $h ), $w, $h ), $w, $h );
	$somma     = array_sum( $struttura );

	$risultato = array(
		'x'         => 0.5,
		'y'         => 0.5,
		'tipo'      => 'centro',
		'orizzonte' => null,
	);

	if ( $somma > 0 ) {

		$soglia = (float) in3img_filtro( 'in3img_soglia_sbilancio', IN3IMG_SOGLIA_SBILANCIO );
		$max    = (float) in3img_filtro( 'in3img_spostamento_max', IN3IMG_SPOSTAMENTO_MAX );

		$bar = in3img_baricentro( $struttura, $w, $h );

		$fx = in3img_sposta_se_serve( $struttura, $w, $h, 'x', $bar['x'], $soglia, $max );
		$fy = in3img_sposta_se_serve( $struttura, $w, $h, 'y', $bar['y'], $soglia, $max );

		$risultato['x'] = $fx;
		$risultato['y'] = $fy;

		if ( abs( $fx - 0.5 ) > 0.01 || abs( $fy - 0.5 ) > 0.01 ) {
			$risultato['tipo'] = 'soggetto';
		}
	}

	$risultato['orizzonte'] = in3img_orizzonte( $lum, $w, $h );

	return $risultato;
}

/* ------------------------------------------------------------------ *
 * Gli attrezzi
 * ------------------------------------------------------------------ */

/** Quanto cambia la luce da un pixel al vicino. */
function in3img_energia( $lum, $w, $h ) {

	$n   = $w * $h;
	$out = array_fill( 0, $n, 0 );

	for ( $y = 0; $y < $h; $y++ ) {
		$riga = $y * $w;
		for ( $x = 0; $x < $w; $x++ ) {
			$i         = $riga + $x;
			$dx        = ( $x + 1 < $w ) ? abs( $lum[ $i + 1 ] - $lum[ $i ] ) : 0;
			$dy        = ( $y + 1 < $h ) ? abs( $lum[ $i + $w ] - $lum[ $i ] ) : 0;
			$out[ $i ] = $dx + $dy;
		}
	}

	return $out;
}

/** Media 3x3: spegne le trame fitte prima di decidere dove sta il soggetto. */
function in3img_sfoca( $lum, $w, $h ) {

	$out = $lum;

	for ( $y = 1; $y < $h - 1; $y++ ) {
		$riga = $y * $w;
		for ( $x = 1; $x < $w - 1; $x++ ) {
			$i         = $riga + $x;
			$out[ $i ] = (int) ( (
				$lum[ $i - $w - 1 ] + $lum[ $i - $w ] + $lum[ $i - $w + 1 ] +
				$lum[ $i - 1 ]      + $lum[ $i ]      + $lum[ $i + 1 ] +
				$lum[ $i + $w - 1 ] + $lum[ $i + $w ] + $lum[ $i + $w + 1 ]
			) / 9 );
		}
	}

	return $out;
}

/** Baricentro della mappa, in frazioni 0..1. */
function in3img_baricentro( $mappa, $w, $h ) {

	$sx = 0;
	$sy = 0;
	$st = 0;

	for ( $y = 0; $y < $h; $y++ ) {
		$riga = $y * $w;
		for ( $x = 0; $x < $w; $x++ ) {
			$e   = $mappa[ $riga + $x ];
			$sx += $e * ( $x + 0.5 );
			$sy += $e * ( $y + 0.5 );
			$st += $e;
		}
	}

	if ( $st <= 0 ) {
		return array( 'x' => 0.5, 'y' => 0.5 );
	}

	return array( 'x' => $sx / $st / $w, 'y' => $sy / $st / $h );
}

/**
 * Ci si sposta dal centro solo se una meta' della foto ha nettamente piu'
 * sostanza dell'altra, e comunque mai oltre il limite prudenziale.
 */
function in3img_sposta_se_serve( $mappa, $w, $h, $asse, $baricentro, $soglia, $max ) {

	$primo   = 0;
	$secondo = 0;

	for ( $y = 0; $y < $h; $y++ ) {
		$riga = $y * $w;
		for ( $x = 0; $x < $w; $x++ ) {
			$e = $mappa[ $riga + $x ];
			if ( 'x' === $asse ) {
				if ( $x < $w / 2 ) {
					$primo += $e;
				} else {
					$secondo += $e;
				}
			} elseif ( $y < $h / 2 ) {
				$primo += $e;
			} else {
				$secondo += $e;
			}
		}
	}

	$alto  = max( $primo, $secondo );
	$basso = min( $primo, $secondo );

	if ( $basso <= 0 || ( $alto / $basso ) < $soglia ) {
		return 0.5; // foto equilibrata: il centro va benissimo
	}

	return max( 0.5 - $max, min( 0.5 + $max, $baricentro ) );
}

/**
 * Orizzonte: la riga orizzontale che stacca nettamente su tutte le altre.
 *
 * @return float|null posizione 0..1, oppure null se non c'e'.
 */
function in3img_orizzonte( $lum, $w, $h ) {

	if ( $h < 24 ) {
		return null;
	}

	$forza = array();
	for ( $y = 0; $y < $h - 1; $y++ ) {
		$riga = $y * $w;
		$s    = 0;
		for ( $x = 0; $x < $w; $x++ ) {
			$s += abs( $lum[ $riga + $x + $w ] - $lum[ $riga + $x ] );
		}
		$forza[ $y ] = $s / $w;
	}

	$ordinate = $forza;
	sort( $ordinate );
	$mediana = $ordinate[ (int) floor( count( $ordinate ) / 2 ) ];

	$best = 0;
	$riga = -1;
	foreach ( $forza as $y => $s ) {
		if ( $s > $best ) {
			$best = $s;
			$riga = $y;
		}
	}

	if ( $riga < 0 || $mediana <= 0 || $best < ( $mediana * 3.0 ) ) {
		return null; // nessuna linea dominante: non e' un paesaggio
	}

	$pos = ( $riga + 0.5 ) / $h;

	// Una linea a ridosso del bordo non e' un orizzonte.
	if ( $pos < 0.15 || $pos > 0.85 ) {
		return null;
	}

	return round( $pos, 4 );
}
