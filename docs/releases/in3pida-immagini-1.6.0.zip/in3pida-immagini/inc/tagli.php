<?php
/**
 * in3pida Immagini - dal punto focale al ritaglio vero.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Il rettangolo da ritagliare dentro la foto originale.
 *
 * @param array|null $analisi esito di in3img_analizza(), oppure null per il centro.
 * @return array|false array( x, y, w, h )
 */
function in3img_finestra( $orig_w, $orig_h, $dest_w, $dest_h, $analisi = null ) {

	$orig_w = (int) $orig_w;
	$orig_h = (int) $orig_h;
	$dest_w = (int) $dest_w;
	$dest_h = (int) $dest_h;

	if ( $orig_w < 1 || $orig_h < 1 || $dest_w < 1 || $dest_h < 1 ) {
		return false;
	}

	$rapporto = $dest_w / $dest_h;

	if ( ( $orig_w / $orig_h ) > $rapporto ) {
		$w = (int) round( $orig_h * $rapporto );
		$h = $orig_h;
	} else {
		$w = $orig_w;
		$h = (int) round( $orig_w / $rapporto );
	}

	$w = max( 1, min( $w, $orig_w ) );
	$h = max( 1, min( $h, $orig_h ) );

	$tipo      = isset( $analisi['tipo'] ) ? $analisi['tipo'] : 'centro';
	$fx        = isset( $analisi['x'] ) ? (float) $analisi['x'] : 0.5;
	$fy        = isset( $analisi['y'] ) ? (float) $analisi['y'] : 0.5;
	$orizzonte = isset( $analisi['orizzonte'] ) ? $analisi['orizzonte'] : null;

	$x = $fx * $orig_w - $w / 2;

	if ( null !== $orizzonte && $h < $orig_h && 'mano' !== $tipo ) {

		// L'orizzonte non si taglia a meta'. Se il fotografo lo teneva alto
		// gli interessava la terra, se lo teneva basso gli interessava il cielo:
		// nel dubbio si rispetta la sua scelta e lo si porta sul terzo vicino.
		$terzo = ( $orizzonte < 0.5 ) ? ( 1 / 3 ) : ( 2 / 3 );
		$y     = $orizzonte * $orig_h - $h * $terzo;

	} else {

		$y = $fy * $orig_h - $h / 2;
	}

	$x = (int) round( max( 0, min( $x, $orig_w - $w ) ) );
	$y = (int) round( max( 0, min( $y, $orig_h - $h ) ) );

	return array( 'x' => $x, 'y' => $y, 'w' => $w, 'h' => $h );
}

/* ------------------------------------------------------------------ *
 * Da qui in giu' serve WordPress.
 * ------------------------------------------------------------------ */

if ( ! defined( 'ABSPATH' ) ) {
	return;
}

/**
 * Le nostre misure non le genera WordPress con il suo taglio al centro:
 * le generiamo noi. Le misure del tema e degli altri plugin restano intatte.
 */
add_filter( 'intermediate_image_sizes_advanced', 'in3img_togli_dal_giro_standard', 10, 1 );
function in3img_togli_dal_giro_standard( $sizes ) {
	foreach ( in3img_misure() as $m ) {
		unset( $sizes[ $m['slug'] ] );
	}
	return $sizes;
}

add_filter( 'wp_generate_attachment_metadata', 'in3img_genera_tagli', 20, 2 );
function in3img_genera_tagli( $metadata, $attachment_id ) {

	if ( ! is_array( $metadata ) || empty( $metadata['file'] ) ) {
		return $metadata;
	}

	$file = in3img_percorso( $metadata );
	if ( ! $file || ! in3img_immagine_gestibile( $file ) ) {
		return $metadata;
	}

	$analisi = in3img_analisi_salvata( $attachment_id, $file );

	$metadata = in3img_scrivi_tagli( $metadata, $file, $analisi );
	$metadata = in3img_butta_originale( $metadata, $attachment_id );

	update_post_meta( $attachment_id, '_in3img_fatto', IN3IMG_VERSIONE );
	in3img_conta( 'foto_trattate' );

	return $metadata;
}

/**
 * Cancella la foto originale, ma solo quando e' davvero superflua.
 *
 * WordPress, se carichi una foto piu' grande di 2560 px, ne fa una copia a
 * 2560 px e da quel momento lavora solo su quella: l'originale resta li' a
 * pesare senza che nessuno lo usi. Questa funzione lo toglie.
 *
 * E' l'unica cosa irreversibile del plugin, quindi prima di cancellare
 * verifica tutto, e al primo dubbio non tocca niente:
 *
 *   1. l'opzione dev'essere accesa apposta (spenta di default)
 *   2. dev'esistere davvero la copia a 2560 px, diversa dall'originale
 *    3. la copia dev'essere leggibile come immagine
 *   4. i nostri tagli devono esserci tutti, e i loro file devono esistere
 *   5. entrambi i percorsi devono stare dentro la cartella dei caricamenti
 *
 * Se la foto era piu' piccola di 2560 px, WordPress non ha fatto nessuna
 * copia: quello e' l'unico file esistente e non si tocca mai.
 */
function in3img_butta_originale( $metadata, $attachment_id ) {

	if ( ! function_exists( 'in3img_opzione' ) || ! in3img_opzione( 'butta_originale' ) ) {
		return $metadata;
	}

	// 2. Senza 'original_image' non c'e' nessuna copia: la foto era piccola.
	if ( empty( $metadata['original_image'] ) || empty( $metadata['file'] ) ) {
		return $metadata;
	}

	$caricamenti = wp_get_upload_dir();
	if ( empty( $caricamenti['basedir'] ) ) {
		return $metadata;
	}

	$base    = realpath( $caricamenti['basedir'] );
	$lavoro  = trailingslashit( $caricamenti['basedir'] ) . $metadata['file'];
	$cartella = trailingslashit( dirname( $lavoro ) );
	$originale = $cartella . wp_basename( $metadata['original_image'] );

	if ( ! $base || ! file_exists( $lavoro ) || ! file_exists( $originale ) ) {
		return $metadata;
	}

	$r_lavoro    = realpath( $lavoro );
	$r_originale = realpath( $originale );

	// 5. Tutto deve stare dentro la cartella dei caricamenti, e i due file
	// devono essere davvero due file diversi.
	if ( ! $r_lavoro || ! $r_originale || $r_lavoro === $r_originale ) {
		return $metadata;
	}
	if ( 0 !== strpos( $r_lavoro, $base ) || 0 !== strpos( $r_originale, $base ) ) {
		return $metadata;
	}

	// 3. La copia dev'essere un'immagine vera e sana.
	$dim = @getimagesize( $r_lavoro );
	if ( ! $dim || empty( $dim[0] ) || empty( $dim[1] ) ) {
		return $metadata;
	}

	// 4. I nostri tagli devono esserci tutti.
	foreach ( in3img_misure() as $m ) {
		if ( empty( $metadata['sizes'][ $m['slug'] ]['file'] ) ) {
			return $metadata;
		}
		if ( ! file_exists( $cartella . $metadata['sizes'][ $m['slug'] ]['file'] ) ) {
			return $metadata;
		}
	}

	$pesava = (int) @filesize( $r_originale );

	if ( ! @unlink( $r_originale ) ) {
		return $metadata;
	}

	in3img_conta( 'originali_tolti' );
	in3img_conta( 'byte_liberati', $pesava );

	// Tolto il file, va tolto anche il riferimento: altrimenti WordPress
	// continuerebbe a cercarlo.
	unset( $metadata['original_image'] );
	update_post_meta( $attachment_id, '_in3img_originale_tolto', 1 );

	return $metadata;
}

/**
 * Percorso del file che WordPress ha gia' normalizzato. Non usiamo l'originale
 * da 50 megapixel: stessa resa sui nostri tagli, molta meno memoria.
 */
function in3img_percorso( $metadata ) {
	$caricamenti = wp_get_upload_dir();
	if ( empty( $caricamenti['basedir'] ) ) {
		return false;
	}
	$file = trailingslashit( $caricamenti['basedir'] ) . $metadata['file'];
	return file_exists( $file ) ? $file : false;
}

function in3img_immagine_gestibile( $file ) {
	$tipo = wp_check_filetype( $file );
	return ! empty( $tipo['type'] ) && in_array( $tipo['type'], array( 'image/jpeg', 'image/png', 'image/webp' ), true );
}

/**
 * Il punto focale: prima quello messo a mano, poi quello gia' calcolato,
 * altrimenti si analizza la foto (una volta sola nella sua vita).
 */
function in3img_analisi_salvata( $attachment_id, $file ) {

	$mano = get_post_meta( $attachment_id, '_in3img_focale_mano', true );
	if ( is_array( $mano ) && isset( $mano['x'], $mano['y'] ) ) {
		return array(
			'x'         => (float) $mano['x'],
			'y'         => (float) $mano['y'],
			'tipo'      => 'mano',
			'orizzonte' => null,
		);
	}

	$salvata = get_post_meta( $attachment_id, '_in3img_focale', true );
	if ( is_array( $salvata ) && isset( $salvata['x'], $salvata['y'] ) ) {
		return $salvata;
	}

	$analisi = in3img_analizza( $file );
	if ( $analisi ) {
		update_post_meta( $attachment_id, '_in3img_focale', $analisi );
	}

	return $analisi;
}

/**
 * Genera (o rigenera) i tre tagli dentro i metadati dell'allegato.
 */
function in3img_scrivi_tagli( $metadata, $file, $analisi ) {

	if ( ! isset( $metadata['sizes'] ) || ! is_array( $metadata['sizes'] ) ) {
		$metadata['sizes'] = array();
	}

	foreach ( in3img_misure() as $m ) {

		$editor = wp_get_image_editor( $file );
		if ( is_wp_error( $editor ) ) {
			continue;
		}

		$dim = $editor->get_size();
		if ( empty( $dim['width'] ) || empty( $dim['height'] ) ) {
			continue;
		}

		$finestra = in3img_finestra( $dim['width'], $dim['height'], $m['w'], $m['h'], $analisi );
		if ( ! $finestra ) {
			continue;
		}

		// Se non c'e' niente da ritagliare e niente da rimpicciolire, questo
		// taglio sarebbe una copia identica dell'originale: solo un file in piu'
		// sul disco, per giunta piu' pesante perche' ricompresso. Si salta, e il
		// tema ricade da solo sulla foto intera.
		if ( $finestra['w'] >= $dim['width'] && $finestra['h'] >= $dim['height']
			&& $m['w'] >= $dim['width'] && $m['h'] >= $dim['height'] ) {
			continue;
		}

		// Se la foto e' piu' piccola del taglio richiesto non la ingrandiamo:
		// meglio una foto piccola che una foto sgranata.
		$dest_w = min( $m['w'], $finestra['w'] );
		$dest_h = min( $m['h'], $finestra['h'] );

		$esito = $editor->crop( $finestra['x'], $finestra['y'], $finestra['w'], $finestra['h'], $dest_w, $dest_h );
		if ( is_wp_error( $esito ) ) {
			continue;
		}

		$salvato = $editor->save( $editor->generate_filename( $m['slug'] ) );
		if ( is_wp_error( $salvato ) || empty( $salvato['file'] ) ) {
			continue;
		}

		$metadata['sizes'][ $m['slug'] ] = array(
			'file'      => $salvato['file'],
			'width'     => $salvato['width'],
			'height'    => $salvato['height'],
			'mime-type' => $salvato['mime-type'],
		);

		in3img_conta( 'tagli_generati' );
	}

	return $metadata;
}

/**
 * Rifa' i tre tagli di una foto gia' in libreria (usata quando si sposta
 * il punto a mano). Non tocca nient'altro dell'allegato.
 */
function in3img_rigenera( $attachment_id ) {

	$metadata = wp_get_attachment_metadata( $attachment_id );
	if ( ! is_array( $metadata ) || empty( $metadata['file'] ) ) {
		return false;
	}

	$file = in3img_percorso( $metadata );
	if ( ! $file || ! in3img_immagine_gestibile( $file ) ) {
		return false;
	}

	$analisi  = in3img_analisi_salvata( $attachment_id, $file );
	$metadata = in3img_scrivi_tagli( $metadata, $file, $analisi );
	$metadata = in3img_butta_originale( $metadata, $attachment_id );

	wp_update_attachment_metadata( $attachment_id, $metadata );
	update_post_meta( $attachment_id, '_in3img_fatto', IN3IMG_VERSIONE );

	// Non si cancella niente: i nomi dei tagli sono sempre gli stessi, quindi
	// i file vengono riscritti sopra. Una riga che cancella e' una riga che
	// prima o poi cancella la cosa sbagliata.

	return true;
}

/**
 * Quante foto della libreria non sono ancora passate dal plugin.
 */
function in3img_da_fare( $quante = 0 ) {

	$q = new WP_Query( array(
		'post_type'      => 'attachment',
		'post_status'    => 'inherit',
		'post_mime_type' => array( 'image/jpeg', 'image/png', 'image/webp' ),
		'posts_per_page' => $quante > 0 ? $quante : 1,
		'fields'         => 'ids',
		'orderby'        => 'ID',
		'order'          => 'ASC',
		'no_found_rows'  => false,
		'meta_query'     => array(
			array(
				'key'     => '_in3img_fatto',
				'compare' => 'NOT EXISTS',
			),
		),
	) );

	return array( 'totale' => (int) $q->found_posts, 'ids' => $quante > 0 ? $q->posts : array() );
}
