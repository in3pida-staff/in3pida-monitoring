/* in3pida Form 2 – Builder (React via wp.element, no build step) */
(function (wp) {
    'use strict';

    function t(key) {
        return (IF2Builder.strings && IF2Builder.strings[key]) ? IF2Builder.strings[key] : key;
    }

    var el        = wp.element.createElement;
    var useState  = wp.element.useState;
    var useRef    = wp.element.useRef;
    var useEffect = wp.element.useEffect;
    var Fragment  = wp.element.Fragment;
    var Component  = wp.element.Component;
    // Lingua: disponibile a TUTTI i componenti (prima era dichiarata solo dentro lo Styling,
    // e usarla nella Logica causava "_isIT is not defined" → crash del builder).
    var _isIT = (typeof IF2Builder !== 'undefined' && IF2Builder.lang === 'it');

    // Error boundary: se un singolo campo (es. importato malformato) va in errore in fase di
    // render, lo isola con un avviso + tasto Elimina, invece di mandare in crash tutto il builder.
    function FieldBoundary(props) { Component.call(this, props); this.state = { err: false }; }
    FieldBoundary.prototype = Object.create(Component.prototype);
    FieldBoundary.prototype.constructor = FieldBoundary;
    FieldBoundary.getDerivedStateFromError = function () { return { err: true }; };
    FieldBoundary.prototype.componentDidCatch = function (e, info) { try { console.error('IF2 builder: campo non renderizzabile', e, info); } catch (_) {} };
    FieldBoundary.prototype.render = function () {
        if (!this.state.err) return this.props.children;
        return el('div', { style: { border: '1px solid #e57373', background: '#fdecea', color: '#c62828', borderRadius: '4px', padding: '10px 12px', fontSize: '12px' } },
            el('div', { style: { marginBottom: '8px', fontWeight: 700 } }, '⚠ Campo non valido (dati importati corrotti)'),
            this.props.onDelete ? el('button', { onClick: this.props.onDelete, style: { background: '#c62828', color: '#fff', border: 'none', borderRadius: '3px', padding: '4px 10px', fontSize: '11px', fontWeight: 700, cursor: 'pointer' } }, 'Elimina campo') : null
        );
    };

    // -------------------------------------------------------------------------
    // Field types — nomi identici al v1
    // -------------------------------------------------------------------------
    var FIELD_TYPES_MAIN = [
        { type: 'heading',   label: 'Heading' },
        { type: 'text',      label: 'One Line Input' },
        { type: 'email',     label: 'Email Input' },
        { type: 'textarea',  label: 'Textarea' },
        { type: 'checkbox',  label: 'Checkbox' },
        { type: 'select',    label: 'Dropdown' },
        { type: 'date',      label: 'Datepicker' },
        { type: 'html',      label: 'Custom Text' },
        { type: 'submit',    label: 'Submit' },
    ];

    var FIELD_TYPES_MORE = [
        { type: 'password',   label: 'Password' },
        { type: 'file',       label: 'File Upload' },
        { type: 'slider',     label: 'Slider' },
        { type: 'time',       label: 'Timepicker' },
        { type: 'address',    label: 'Address' },
    ];

    var FIELD_TYPES_SURVEY = [
        { type: 'thumb',  label: 'Thumb Rating' },
        { type: 'star',   label: 'Star Rating' },
        { type: 'matrix', label: 'Choice Matrix' },
    ];

    var ALL_TYPES = FIELD_TYPES_MAIN.concat(FIELD_TYPES_MORE).concat(FIELD_TYPES_SURVEY);

    // Traduzioni italiane etichette tipi campo
    if (typeof IF2Builder !== 'undefined' && IF2Builder.lang === 'it') {
        var IT_LABELS = {
            'heading':    'Intestazione',
            'text':       'Campo Testo',
            'email':      'Campo Email',
            'textarea':   'Area di Testo',
            'checkbox':   'Caselle di Selezione',
            'select':     'Menu a Tendina',
            'date':       'Selettore Data',
            'html':       'Testo Libero',
            'submit':     'Pulsante Invio',
            'password':   'Password',
            'file':       'Carica File',
            'slider':     'Cursore',
            'time':       'Selettore Ora',
            'address':    'Indirizzo',
            'thumb':      'Valutazione Pollice',
            'star':       'Valutazione Stelle',
            'matrix':     'Matrice di Scelta',
            'radio':      'Scelta Singola',
        };
        FIELD_TYPES_MAIN.forEach(function(ft) { if (IT_LABELS[ft.type]) ft.label = IT_LABELS[ft.type]; });
        FIELD_TYPES_MORE.forEach(function(ft) { if (IT_LABELS[ft.type]) ft.label = IT_LABELS[ft.type]; });
        FIELD_TYPES_SURVEY.forEach(function(ft) { if (IT_LABELS[ft.type]) ft.label = IT_LABELS[ft.type]; });
    }
    var HAS_OPTIONS = ['select', 'checkbox', 'radio'];

    function makeField(type) {
        var ft   = ALL_TYPES.find(function (t) { return t.type === type; }) || { label: type };
        var base = {
            id:          'field_' + Math.random().toString(36).slice(2, 10),
            type:        type,
            label:       ft.label,
            placeholder: '',
            required:    false,
            col_width:   '100%',
            conditions:  null,
        };
        if (HAS_OPTIONS.indexOf(type) !== -1) base.options = [{ label: 'Opzione 1', value: '' }];
        if (type === 'textarea') base.rows = 1;
        if (type === 'file')     { base.accept = ''; base.multiple = false; base.max_size_mb = 5; }
        if (type === 'html')     { base.content = '<p>Testo libero</p>'; }
        if (type === 'hidden')   { base.value = ''; }
        if (type === 'heading')  { base.content = 'Titolo'; }
        if (type === 'star')     { base.max_stars = 5; }
        if (type === 'matrix')   { base.matrix_rows = ['Domanda 1', 'Domanda 2']; base.matrix_columns = ['Opzione 1', 'Opzione 2', 'Opzione 3']; }
        return base;
    }

    // -------------------------------------------------------------------------
    // App principale
    // -------------------------------------------------------------------------
    // Error boundary globale: se QUALSIASI parte del builder va in errore in render,
    // mostra il messaggio (utile per diagnosi) invece di lasciare lo schermo vuoto.
    function AppBoundary(props) { Component.call(this, props); this.state = { err: null }; }
    AppBoundary.prototype = Object.create(Component.prototype);
    AppBoundary.prototype.constructor = AppBoundary;
    AppBoundary.getDerivedStateFromError = function (e) { return { err: e }; };
    AppBoundary.prototype.componentDidCatch = function (e, info) { try { console.error('IF2 builder crash', e, info); } catch (_) {} };
    AppBoundary.prototype.render = function () {
        if (!this.state.err) return this.props.children;
        return el('div', { style: { padding: '24px', maxWidth: '680px', margin: '24px auto', background: '#fff', border: '1px solid #f0d0d8', borderRadius: '8px', fontFamily: '-apple-system,sans-serif' } },
            el('h2', { style: { color: '#c62828', margin: '0 0 8px', fontSize: '16px' } }, '⚠ Il builder ha avuto un errore'),
            el('p', { style: { fontSize: '13px', color: '#555', margin: '0 0 12px', lineHeight: 1.6 } }, 'Probabilmente un campo o una regola importati hanno dati non validi. Il modulo è al sicuro. Ricarica per riprovare; se serve, manda uno screenshot del messaggio qui sotto.'),
            el('pre', { style: { fontSize: '11px', color: '#a33', background: '#fafafa', padding: '10px', borderRadius: '4px', overflow: 'auto', whiteSpace: 'pre-wrap', margin: 0 } }, String((this.state.err && this.state.err.message) || this.state.err || '')),
            el('button', { onClick: function () { location.reload(); }, style: { marginTop: '14px', background: '#d82d6b', color: '#fff', border: 'none', borderRadius: '4px', padding: '8px 16px', fontSize: '13px', fontWeight: 700, cursor: 'pointer' } }, 'Ricarica')
        );
    };

    function BuilderApp() {
        var root       = document.getElementById('if2-builder-root');
        var formId     = parseInt(root.dataset.formId, 10);
        var initName   = root.dataset.formName || 'Form';
        var initFields = [];
        var initConfig = {};
        try { var _pf = JSON.parse(root.dataset.fields || '[]'); if (Array.isArray(_pf)) initFields = _pf; }
        catch (e) { try { console.error('IF2 builder: dati campi non validi, ignorati', e); } catch (_) {} }
        try { var _pc = JSON.parse(root.dataset.config || '{}'); if (_pc && typeof _pc === 'object' && !Array.isArray(_pc)) initConfig = _pc; }
        catch (e) { try { console.error('IF2 builder: config non valida, ignorata', e); } catch (_) {} }
        // Scarta i campi malformati (devono essere oggetti con almeno tipo o id)
        initFields = initFields.filter(function (f) { return f && typeof f === 'object' && (f.type || f.id); });

        var _f = useState(initFields);
        var fields = _f[0]; var setFields = _f[1];

        var _c = useState(initConfig);
        var config = _c[0]; var setConfig = _c[1];

        var _s = useState(null);
        var selectedId = _s[0]; var setSelectedId = _s[1];

        var _p = useState(null); // null | 'settings' | 'styling' | 'addons' | 'logic'
        var activePanel = _p[0]; var setActivePanel = _p[1];

        var _pr = useState(null); // DOMRect of clicked field card
        var popupRect = _pr[0]; var setPopupRect = _pr[1];

        var _ss = useState('');
        var saveStatus = _ss[0]; var setSaveStatus = _ss[1];

        var _mf = useState(false);
        var showMore = _mf[0]; var setShowMore = _mf[1];

        var _msv = useState(false);
        var showSurvey = _msv[0]; var setShowSurvey = _msv[1];

        var _af = useState(true);
        var showAddFields = _af[0]; var setShowAddFields = _af[1];

        var dragIdx     = useRef(null);
        var selectedField = fields.find(function (f) { return f.id === selectedId; }) || null;

        // Left panel shows only for form-level panels (field settings are in floating popup)
        var showLeft = !!activePanel;

        function addField(type) {
            var nf = makeField(type);
            setFields(function (prev) { return prev.concat([nf]); });
        }

        function onDragStart(idx) { dragIdx.current = idx; }
        function onDragOver(idx) {
            if (dragIdx.current === null || dragIdx.current === idx) return;
            setFields(function (prev) {
                var arr  = prev.slice();
                var item = arr.splice(dragIdx.current, 1)[0];
                arr.splice(idx, 0, item);
                dragIdx.current = idx;
                return arr;
            });
        }
        function onDragEnd() { dragIdx.current = null; }

        function updateField(id, changes) {
            setFields(function (prev) {
                return prev.map(function (f) { return f.id === id ? Object.assign({}, f, changes) : f; });
            });
        }

        function deleteField(id) {
            setFields(function (prev) { return prev.filter(function (f) { return f.id !== id; }); });
            if (selectedId === id) setSelectedId(null);
        }

        function duplicateField(id) {
            setFields(function (prev) {
                var idx  = prev.findIndex(function (f) { return f.id === id; });
                if (idx === -1) return prev;
                var clone = Object.assign({}, prev[idx], { id: 'field_' + Math.random().toString(36).slice(2, 10) });
                var arr  = prev.slice();
                arr.splice(idx + 1, 0, clone);
                return arr;
            });
        }

        function save() {
            var saveBtn  = document.getElementById('if2-topbar-save-btn');
            var origText = saveBtn ? saveBtn.textContent : '';
            if (saveBtn) { saveBtn.textContent = '…'; saveBtn.disabled = true; }
            // Deriva le condizioni per ogni campo dalle logic_rules del pannello Logica
            var opMap = { 'equals': '=', 'not_equals': '!=', 'contains': 'contains', 'not_empty': 'not_empty' };
            var logicRules = config.logic_rules || [];
            var fieldRuleGroups = {};
            logicRules.forEach(function(rule) {
                if ((rule.action_type || 'show') !== 'show') return;
                var targets = Array.isArray(rule.action_fields) ? rule.action_fields : (rule.action_field ? [rule.action_field] : []);
                targets = targets.filter(function(t) { return t; });
                if (!targets.length) return;
                var conds = (rule.conditions || []).map(function(c) {
                    return { field: String(c.field || ''), operator: opMap[c.op] || '=', value: String(c.value || '') };
                }).filter(function(c) { return c.field; });
                if (!conds.length) return;
                targets.forEach(function(target) {
                    if (!fieldRuleGroups[target]) fieldRuleGroups[target] = [];
                    fieldRuleGroups[target].push(conds);
                });
            });
            var savedFields = fields.map(function(f) {
                var groups = fieldRuleGroups[f.id];
                if (!groups) return Object.assign({}, f, { conditions: null });
                var allConds = [];
                groups.forEach(function(g) { allConds = allConds.concat(g); });
                return Object.assign({}, f, { conditions: { logic: groups.length > 1 ? 'OR' : 'AND', rules: allConds } });
            });
            var fd = new FormData();
            fd.set('action', 'if2_save_form'); fd.set('nonce', IF2Builder.nonce);
            fd.set('form_id', formId); fd.set('fields', JSON.stringify(savedFields));
            fd.set('config', JSON.stringify(config));
            fetch(IF2Builder.ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function (r) { return r.json(); })
                .then(function (json) {
                    if (saveBtn) { saveBtn.textContent = json.success ? '✓' : '✗'; saveBtn.disabled = false; }
                    setTimeout(function () { if (saveBtn) saveBtn.textContent = origText; }, 1800);
                })
                .catch(function () {
                    if (saveBtn) { saveBtn.textContent = '✗'; saveBtn.disabled = false; }
                    setTimeout(function () { if (saveBtn) saveBtn.textContent = origText; }, 1800);
                });
        }

        function togglePanel(name) {
            setActivePanel(function (prev) { return prev === name ? null : name; });
            setSelectedId(null);
        }

        // Wiring tutti i bottoni della topbar PHP → React
        wp.element.useEffect(function () {
            function wire(id, fn) {
                var btn = document.getElementById(id);
                if (btn) btn.onclick = fn;
            }
            wire('if2-topbar-save-btn', save);
            wire('if2-btn-settings', function () { togglePanel('settings'); });
            wire('if2-btn-styling',  function () { togglePanel('styling'); });
            wire('if2-btn-addons',   function () { togglePanel('addons'); });
            wire('if2-btn-logic',    function () { togglePanel('logic'); });
            wire('if2-btn-help',     function () { togglePanel('help'); });
        }, [fields, config, activePanel]);

        // Aggiorna classe active sui bottoni topbar
        wp.element.useEffect(function () {
            ['settings','styling','addons','logic','help'].forEach(function (name) {
                var btn = document.getElementById('if2-btn-' + name);
                if (btn) btn.className = 'if2-builder-topbar-btn' + (activePanel === name ? ' active-true' : '');
            });
        }, [activePanel]);

        return el('div', { style: { display: 'flex', flexDirection: 'row', alignItems: 'stretch', minHeight: 'calc(100vh - 90px)', position: 'relative' } },

            // LEFT — pannello overlay per form-level settings (no field settings)
            showLeft
                ? el(LeftPanel, {
                    field:       null,
                    config:      config,
                    activePanel: activePanel,
                    fields:      fields,
                    formId:      formId,
                    onUpdate:    function (changes) { if (selectedField) updateField(selectedField.id, changes); },
                    onConfig:    function (changes) { setConfig(function (prev) { return Object.assign({}, prev, changes); }); },
                    onClose:     function () { setSelectedId(null); setActivePanel(null); },
                    onImport:    function (importedFields, importedConfig) {
                        if (importedFields) setFields(importedFields);
                        if (importedConfig) setConfig(function (prev) { return Object.assign({}, prev, importedConfig); });
                    },
                  })
                : null,

            // FLOATING POPUP — field settings vicino al campo cliccato
            selectedField
                ? el(FieldPopup, {
                    field:       selectedField,
                    rect:        popupRect,
                    allFields:   fields,
                    onUpdate:    function (changes) { updateField(selectedField.id, changes); },
                    onClose:     function () { setSelectedId(null); setPopupRect(null); },
                    onDuplicate: function () { duplicateField(selectedField.id); },
                    onDelete:    function () { deleteField(selectedField.id); setSelectedId(null); setPopupRect(null); },
                  })
                : null,

            // CENTER — Canvas
            el('div', { style: { flex: '1 1 0%', padding: '30px', display: 'flex', flexDirection: 'column', alignItems: 'center', background: '#ebebeb', minWidth: 0 } },
                el('div', { style: { marginBottom: '8px', display: 'flex', alignItems: 'stretch', height: '28px', gap: '4px' } },
                    el('div', { style: { background: '#fff', border: '1px solid #e0cfd8', padding: '0 18px', fontSize: '11px', color: '#888', borderRadius: '2px', fontWeight: 700, letterSpacing: '.04em', display: 'flex', alignItems: 'center', boxSizing: 'border-box' } }, 'WIDTH'),
                    el('input', {
                        type: 'text',
                        value: config.form_width || '',
                        placeholder: '100%',
                        title: 'Larghezza form (es: 80%, 600px)',
                        style: { background: '#fff', border: '1px solid #e0cfd8', padding: '0 12px', fontSize: '12px', color: '#555', borderRadius: '2px', width: '80px', outline: 'none', fontFamily: 'inherit', boxSizing: 'border-box', minHeight: '0' },
                        onChange: function (e) { setConfig(function (prev) { return Object.assign({}, prev, { form_width: e.target.value }); }); }
                    })
                ),
                el('div', { style: { width: config.form_width || '100%', maxWidth: '100%', background: config.bg_color || '#fff', border: '1px solid #e0cfd8', borderRadius: '4px', minHeight: '180px', padding: '20px', fontFamily: config.font_family || 'inherit', fontSize: config.font_size || 'inherit', color: config.font_color || 'inherit' } },
                    fields.length === 0
                        ? el('div', { style: { color: '#aaa', textAlign: 'center', padding: '40px 0', fontSize: '13px' } }, '(No Fields)')
                        : el('div', { id: 'if2-sortable', style: { display: 'flex', flexWrap: 'wrap', alignItems: 'flex-start' } },
                            fields.map(function (field, idx) {
                                return el('div', {
                                    key: field.id,
                                    style: { width: field.col_width || '100%', boxSizing: 'border-box', paddingRight: field.col_width && field.col_width !== '100%' ? '8px' : '0' }
                                },
                                    el(FieldBoundary, { onDelete: function () { deleteField(field.id); } },
                                        el(FieldCard, {
                                            field: field, selected: field.id === selectedId, idx: idx, config: config,
                                            onSelect:    function (rect) { setSelectedId(field.id); setActivePanel(null); setPopupRect(rect || null); },
                                            onDelete:    function () { deleteField(field.id); },
                                            onDupe:      function () { duplicateField(field.id); },
                                            onDragStart: function () { onDragStart(idx); },
                                            onDragOver:  function () { onDragOver(idx); },
                                            onDragEnd:   onDragEnd,
                                        })
                                    )
                                );
                            })
                          )
                )
            ),

            // RIGHT — ADD FIELD panel
            el('div', { className: 'if2-add-fields-panel', style: { width: '160px', flexShrink: 0, display: 'flex', flexDirection: 'column' } },
                el('button', {
                    className: 'if2-add-fields-toggle',
                    onClick: function () { setShowAddFields(function (prev) { return !prev; }); }
                }, t('add_field') + (showAddFields ? ' ∧' : ' ∨')),
                showAddFields ? FIELD_TYPES_MAIN.map(function (ft) {
                    return el('button', { key: ft.type, className: 'if2-field-type-btn', onClick: function () { addField(ft.type); } }, ft.label);
                }) : null,
                // MORE FIELDS — flyout a sinistra (apre su hover)
                showAddFields ? el('div', {
                    style: { position: 'relative' },
                    onMouseEnter: function () { setShowMore(true); setShowSurvey(false); },
                    onMouseLeave: function () { setShowMore(false); }
                },
                    el('button', { className: 'if2-field-type-group-btn' }, t('more_fields')),
                    showMore ? el('div', { className: 'if2-field-type-flyout' },
                        FIELD_TYPES_MORE.map(function (ft) {
                            return el('button', {
                                key: ft.type,
                                className: 'if2-field-type-flyout-item',
                                onClick: function () { addField(ft.type); setShowMore(false); }
                            }, ft.label);
                        })
                    ) : null
                ) : null,
                // SURVEY — flyout a sinistra (apre su hover)
                showAddFields ? el('div', {
                    style: { position: 'relative' },
                    onMouseEnter: function () { setShowSurvey(true); setShowMore(false); },
                    onMouseLeave: function () { setShowSurvey(false); }
                },
                    el('button', { className: 'if2-field-type-group-btn' }, t('survey')),
                    showSurvey ? el('div', { className: 'if2-field-type-flyout' },
                        FIELD_TYPES_SURVEY.map(function (ft) {
                            return el('button', {
                                key: ft.type,
                                className: 'if2-field-type-flyout-item',
                                onClick: function () { addField(ft.type); setShowSurvey(false); }
                            }, ft.label);
                        })
                    ) : null
                ) : null,
                // Gray fill
                el('div', { style: { flex: 1, background: '#ebebeb' } })
            )
        );
    }

    // -------------------------------------------------------------------------
    // LeftPanel — dispatcha il pannello corretto
    // -------------------------------------------------------------------------
    function LeftPanel(props) {
        var field       = props.field;
        var activePanel = props.activePanel;
        var config      = props.config;

        var title = field ? (field.label || field.type)
                  : activePanel === 'settings' ? t('panel_settings')
                  : activePanel === 'styling'  ? t('panel_styling')
                  : activePanel === 'addons'   ? t('panel_addons')
                  : activePanel === 'logic'    ? t('panel_logic')
                  : activePanel === 'help'     ? t('panel_help')
                  : '';

        return el('div', {
            className: 'if2-settings-panel',
            style: { width: '520px', position: 'absolute', left: 0, top: 0, bottom: 0, zIndex: 50, flexShrink: 0, borderRight: '1px solid #e0cfd8', background: '#fff', overflowY: 'auto', display: 'flex', flexDirection: 'column', boxShadow: '6px 0 24px rgba(0,0,0,.14)', minHeight: '100%' },
        },
            el('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid #e0cfd8', background: '#fafafa' } },
                el('h3', { style: { margin: 0, padding: '12px 16px', fontSize: '11px', fontWeight: 700, color: '#181834', textTransform: 'uppercase', letterSpacing: '.04em' } }, title),
                el('button', {
                    onClick: props.onClose,
                    style: { background: 'none', border: 'none', cursor: 'pointer', color: '#aaa', padding: '8px 12px', fontSize: '16px', lineHeight: 1 },
                }, '×')
            ),

            // Contenuto: campo selezionato ha precedenza
            field
                ? el(FieldSettings, { field: field, allFields: props.fields || [], onUpdate: props.onUpdate })
                : activePanel === 'settings'
                    ? el(ConfigSettings, { config: config, onConfig: props.onConfig, formId: props.formId || 0, fields: props.fields || [], onImport: props.onImport })
                    : activePanel === 'styling'
                        ? el(StylingPanel, { config: config, onConfig: props.onConfig })
                        : activePanel === 'addons'
                            ? el(AddonsPanel, null)
                            : activePanel === 'logic'
                                ? el(LogicPanel, { config: config, onConfig: props.onConfig, fields: props.fields || [] })
                                : activePanel === 'help'
                                    ? el(HelpPanel, null)
                                    : null
        );
    }

    // -------------------------------------------------------------------------
    // FieldPopup — popup flottante vicino al campo (stile FormCraft)
    // -------------------------------------------------------------------------
    var POPUP_BTN = { background: 'none', border: 'none', cursor: 'pointer', width: '26px', height: '26px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '14px', fontWeight: 700, color: '#fff', flexShrink: 0, lineHeight: 1, padding: 0 };

    function FieldPopup(props) {
        var rect = props.rect;
        var popupWidth = 420;
        var leftPos, topPos;

        if (rect) {
            // Preferisce apparire a destra del campo, fallback a sinistra
            leftPos = rect.right + 12;
            if (leftPos + popupWidth > window.innerWidth - 10) {
                leftPos = rect.left - popupWidth - 12;
            }
            leftPos = Math.max(10, leftPos);
            topPos  = Math.max(60, Math.min(rect.top, window.innerHeight - 520));
        } else {
            leftPos = window.innerWidth / 2 - popupWidth / 2;
            topPos  = 100;
        }

        return el('div', {
            className: 'if2-field-popup',
            style: {
                position:  'fixed',
                top:       topPos,
                left:      leftPos,
                width:     popupWidth,
                maxHeight: Math.min(window.innerHeight - topPos - 20, 580),
                overflowY: 'auto',
                background: '#fff',
                boxShadow: '0 4px 24px rgba(0,0,0,.28)',
                borderRadius: '6px',
                zIndex: 99999,
                border: '1px solid #e0cfd8',
            }
        },
            // Header con 3 bottoni (stile FormCraft)
            el('div', {
                className: 'if2-popup-hdr',
                style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 12px', background: '#d82d6b', borderRadius: '6px 6px 0 0' }
            },
                el('span', { style: { fontSize: '11px', fontWeight: 700, color: '#fff', textTransform: 'uppercase', letterSpacing: '.06em', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginRight: '8px' } },
                    (props.field.label || props.field.type) + ' · ' + props.field.id
                ),
                el('div', { style: { display: 'flex', gap: '5px', flexShrink: 0 } },
                    el('button', {
                        title: 'Chiudi',
                        onClick: props.onClose,
                        style: Object.assign({}, POPUP_BTN, { background: '#BD1350' })
                    }, '−'),
                    el('button', {
                        title: 'Duplica',
                        onClick: props.onDuplicate,
                        style: Object.assign({}, POPUP_BTN, { background: '#E04A82' })
                    }, '⎘'),
                    el('button', {
                        title: 'Elimina',
                        onClick: props.onDelete,
                        style: Object.assign({}, POPUP_BTN, { background: '#8B0035' })
                    }, '×')
                )
            ),
            // Body con settings
            el('div', { style: { background: '#fafafa', borderRadius: '0 0 6px 6px' } },
                el(FieldBoundary, { onDelete: props.onDelete || null },
                    el(FieldSettings, {
                        field:     props.field,
                        allFields: props.allFields,
                        onUpdate:  props.onUpdate,
                    })
                )
            )
        );
    }

    // -------------------------------------------------------------------------
    // StylingPanel — 3 sotto-tab: GENERAL | COLOR SCHEME | BACKGROUND
    // -------------------------------------------------------------------------
    function StylingPanel(props) {
        var c  = props.config;
        var up = props.onConfig;

        var _t = useState('general');
        var activeSubTab = _t[0]; var setActiveSubTab = _t[1];

        var _open = useState(null);
        var openSection = _open[0]; var setOpenSection = _open[1];

        var COLOR_PRESETS = [
            '#4488ee', '#4682b4', '#a9a9a9', '#e9967a',
            '#3cb371', '#8fbc8f', '#f08080', '#778899',
            '#ff6347', '#5f9ea0', '#deb887', '#ff69b4',
            '#cd5c5c', '#637bb3',
        ];

        var _isIT = IF2Builder.lang === 'it';
        var SUB_TABS = [
            { key: 'general',      label: _isIT ? 'GENERALE'             : 'GENERAL' },
            { key: 'color_scheme', label: _isIT ? 'COMBINAZIONE COLORI'  : 'COLOR SCHEME' },
            { key: 'background',   label: _isIT ? 'SFONDO'               : 'BACKGROUND' },
        ];

        function section(key, title, children) {
            var isOpen = openSection === key;
            return el('div', { style: { borderBottom: '1px solid #f0f0f0' } },
                el('button', {
                    onClick: function () { setOpenSection(isOpen ? null : key); },
                    style: {
                        width: '100%', textAlign: 'left', background: isOpen ? '#fdf0f5' : '#fafafa',
                        border: 'none', borderBottom: '1px solid #f0f0f0', padding: '14px 16px',
                        fontSize: '12px', fontWeight: 700, color: isOpen ? '#d82d6b' : '#444',
                        cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                        textTransform: 'uppercase', letterSpacing: '.05em',
                    },
                }, title, el('span', { style: { fontSize: '10px', color: '#aaa' } }, isOpen ? '▲' : '▼')),
                isOpen ? el('div', null, children) : null
            );
        }
        function row(lbl, children) {
            return el('div', { className: 'if2-settings-row' }, el('label', null, lbl), children);
        }
        function txt(key, ph) {
            return el('input', { type: 'text', value: c[key] || '', placeholder: ph || '',
                onChange: function (e) { var o = {}; o[key] = e.target.value; up(o); } });
        }
        function chk(key, lbl, defaultVal) {
            var val = c[key] !== undefined ? c[key] : defaultVal;
            return el('div', { style: { display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 16px', borderBottom: '1px solid #f5f5f5' } },
                el('input', { type: 'checkbox', id: 'if2chk_' + key, checked: !!val,
                    style: { width: '16px', height: '16px', cursor: 'pointer', margin: 0, accentColor: '#d82d6b' },
                    onChange: function (e) { var o = {}; o[key] = e.target.checked; up(o); }
                }),
                el('label', { htmlFor: 'if2chk_' + key, style: { fontSize: '13px', fontWeight: 500, color: '#555', cursor: 'pointer', margin: 0 } }, lbl)
            );
        }
        function clr(key, defaultVal) {
            return el('div', { style: { display: 'flex', gap: '6px', alignItems: 'center' } },
                el('input', { type: 'color', value: c[key] || defaultVal || '#ffffff',
                    onChange: function (e) { var o = {}; o[key] = e.target.value; up(o); },
                    style: { width: '32px', height: '28px', padding: '1px', border: '1px solid #e0cfd8', borderRadius: '3px', cursor: 'pointer' } }),
                el('input', { type: 'text', value: c[key] || defaultVal || '', placeholder: defaultVal || '',
                    onChange: function (e) { var o = {}; o[key] = e.target.value; up(o); },
                    style: { flex: 1, fontFamily: 'monospace', fontSize: '12px' } })
            );
        }

        var subTabBar = el('div', { className: 'if2-styling-subtabs' },
            SUB_TABS.map(function (t) {
                return el('button', {
                    key: t.key,
                    className: 'if2-styling-subtab-btn' + (activeSubTab === t.key ? ' active' : ''),
                    onClick: function () { setActiveSubTab(t.key); },
                }, t.label);
            })
        );

        var content = null;

        if (activeSubTab === 'general') {
            content = el('div', null,
                section('general', _isIT ? 'Stile Generale' : 'General Styling',
                    el('div', null,
                        row('Larghezza form',      txt('form_width', '100%')),
                        row('Sfondo form',         clr('bg_color', '#ffffff')),
                        row('Colore testo',        clr('font_color', '#333333')),
                        row('Colore bordo campi',  clr('field_border_color', '#dddddd')),
                        row('Spessore bordo', el('select', { value: c.field_border_width || '1.5px', onChange: function(e){ up({ field_border_width: e.target.value }); }, style: { width:'100%', border:'1px solid #e0cfd8', borderRadius:'3px', padding:'4px 6px', fontSize:'12px', color:'#555', background:'#fff', cursor:'pointer', outline:'none' } },
                            el('option', { value: '0px' }, 'Nessun bordo (0px)'),
                            el('option', { value: '0.5px' }, 'Sottilissimo (0.5px)'),
                            el('option', { value: '1px' }, 'Sottile (1px)'),
                            el('option', { value: '1.5px' }, 'Normale (1.5px) — default'),
                            el('option', { value: '2px' }, 'Medio (2px)'),
                            el('option', { value: '2.5px' }, 'Spesso (2.5px)'),
                            el('option', { value: '3px' }, 'Molto spesso (3px)')
                        )),
                        row('Curvatura degli angoli dei campi', txt('field_radius', '4px')),
                        row('Padding campi',       txt('field_padding', '10px 14px')),
                        chk('remove_form_frame',   'Rimuovi cornice form', true),
                        chk('hide_labels',         'Nascondi etichette', true),
                        chk('hide_field_icons',    'Nascondi icone campi', true),
                        chk('remove_field_borders','Rimuovi bordi campi', true)
                    )
                ),
                section('datepicker', 'Datepicker',
                    el('div', null,
                        row('Colore sfondo titolo',     clr('dp_header_bg', '#d82d6b')),
                        row('Colore data di oggi',      clr('dp_today_color', '#009bb9')),
                        row('Colore data selezionata',  clr('dp_selected_color', '#d82d6b')),
                        row('Curvatura angoli',         txt('datepicker_radius', '14px'))
                    )
                ),
                section('font', _isIT ? 'Stile Font' : 'Font Styling',
                    el('div', null,
                        row('Font', el('select', { value: c.font_family || '', onChange: function(e){ up({ font_family: e.target.value }); }, style: { width:'100%', border:'1px solid #e0cfd8', borderRadius:'3px', padding:'4px 6px', fontSize:'12px', color:'#555', fontFamily:'inherit', background:'#fff', cursor:'pointer', outline:'none' } },
                            el('option', { value: '' }, '— Default tema —'),
                            el('option', { value: 'Roboto, sans-serif' }, 'Roboto'),
                            el('option', { value: 'Open Sans, sans-serif' }, 'Open Sans'),
                            el('option', { value: 'Lato, sans-serif' }, 'Lato'),
                            el('option', { value: 'Montserrat, sans-serif' }, 'Montserrat'),
                            el('option', { value: 'Poppins, sans-serif' }, 'Poppins'),
                            el('option', { value: 'Inter, sans-serif' }, 'Inter'),
                            el('option', { value: 'Nunito, sans-serif' }, 'Nunito'),
                            el('option', { value: 'Source Sans 3, sans-serif' }, 'Source Sans 3'),
                            el('option', { value: 'Raleway, sans-serif' }, 'Raleway'),
                            el('option', { value: 'Ubuntu, sans-serif' }, 'Ubuntu'),
                            el('option', { value: 'Playfair Display, serif' }, 'Playfair Display'),
                            el('option', { value: 'Merriweather, serif' }, 'Merriweather'),
                            el('option', { value: 'Oswald, sans-serif' }, 'Oswald'),
                            el('option', { value: 'Noto Sans, sans-serif' }, 'Noto Sans'),
                            el('option', { value: 'Work Sans, sans-serif' }, 'Work Sans'),
                            el('option', { value: 'PT Sans, sans-serif' }, 'PT Sans'),
                            el('option', { value: 'Fira Sans, sans-serif' }, 'Fira Sans'),
                            el('option', { value: 'Rubik, sans-serif' }, 'Rubik'),
                            el('option', { value: 'DM Sans, sans-serif' }, 'DM Sans'),
                            el('option', { value: 'Mulish, sans-serif' }, 'Mulish'),
                            el('option', { value: 'Quicksand, sans-serif' }, 'Quicksand'),
                            el('option', { value: 'Manrope, sans-serif' }, 'Manrope'),
                            el('option', { value: 'Bebas Neue, display' }, 'Bebas Neue'),
                            el('option', { value: 'Karla, sans-serif' }, 'Karla'),
                            el('option', { value: 'Archivo, sans-serif' }, 'Archivo'),
                            el('option', { value: 'Space Grotesk, sans-serif' }, 'Space Grotesk'),
                            el('option', { value: 'Outfit, sans-serif' }, 'Outfit'),
                            el('option', { value: 'Assistant, sans-serif' }, 'Assistant'),
                            el('option', { value: 'Cabin, sans-serif' }, 'Cabin'),
                            el('option', { value: 'Hind Madurai, sans-serif' }, 'Hind Madurai'),
                            el('option', { value: 'Josefin Sans, sans-serif' }, 'Josefin Sans'),
                            el('option', { value: 'Cormorant Garamond, serif' }, 'Cormorant Garamond'),
                            el('option', { value: 'Cinzel, serif' }, 'Cinzel'),
                            el('option', { value: 'Georgia, serif' }, 'Georgia'),
                            el('option', { value: 'Arial, sans-serif' }, 'Arial')
                        )),
                        row('Dimensione', el('select', { value: c.font_size || '14px', onChange: function(e){ up({ font_size: e.target.value }); }, style: { width:'100%', border:'1px solid #e0cfd8', borderRadius:'3px', padding:'4px 6px', fontSize:'12px', color:'#555', background:'#fff', cursor:'pointer', outline:'none' } },
                            el('option', { value: '8px' },  '8px'),
                            el('option', { value: '9px' },  '9px'),
                            el('option', { value: '10px' }, '10px'),
                            el('option', { value: '11px' }, '11px'),
                            el('option', { value: '12px' }, '12px'),
                            el('option', { value: '13px' }, '13px'),
                            el('option', { value: '14px' }, '14px (default)'),
                            el('option', { value: '15px' }, '15px'),
                            el('option', { value: '16px' }, '16px'),
                            el('option', { value: '18px' }, '18px'),
                            el('option', { value: '20px' }, '20px'),
                            el('option', { value: '22px' }, '22px'),
                            el('option', { value: '24px' }, '24px'),
                            el('option', { value: '26px' }, '26px'),
                            el('option', { value: '28px' }, '28px'),
                            el('option', { value: '30px' }, '30px'),
                            el('option', { value: '32px' }, '32px'),
                            el('option', { value: '36px' }, '36px'),
                            el('option', { value: '40px' }, '40px'),
                            el('option', { value: '48px' }, '48px'),
                            el('option', { value: '60px' }, '60px')
                        )),
                        row('Peso label',     txt('label_weight', '600')),
                        row('Colore label',   clr('label_color', '#333333'))
                    )
                ),
                section('fields', _isIT ? 'Stile Campi' : 'Field Styling',
                    el('div', null,
                        row('Sfondo campo',        clr('input_bg', '#ffffff')),
                        row('Colore focus',         clr('focus_color', '#009bb9')),
                        row('Raggio bordo campi',   txt('field_radius', '6px'))
                    )
                ),
                section('logo', _isIT ? 'Il Tuo Logo' : 'Your Logo',
                    el('div', null,
                        row('URL Logo', txt('logo_url', 'https://…')),
                        row('Larghezza', txt('logo_width', '120px')),
                        row('Posizione', el('select', { value: c.logo_position || 'center', style: { width: '100%' },
                            onChange: function (e) { up({ logo_position: e.target.value }); } },
                            el('option', { value: 'left' }, 'Sinistra'),
                            el('option', { value: 'center' }, 'Centro'),
                            el('option', { value: 'right' }, 'Destra')
                        ))
                    )
                ),
                section('css', _isIT ? 'CSS Personalizzato' : 'Custom CSS',
                    el('div', null,
                        el('div', { className: 'if2-settings-row' },
                            el('textarea', { rows: 8, value: c.custom_css || '',
                                placeholder: '/* CSS personalizzato */\n.if2-form { }',
                                style: { width: '100%', fontFamily: 'monospace', fontSize: '11px', lineHeight: 1.5, padding: '8px', border: '1px solid #e0cfd8', borderRadius: '3px', resize: 'vertical' },
                                onChange: function (e) { up({ custom_css: e.target.value }); }
                            })
                        )
                    )
                ),
                section('submit_msg', _isIT ? 'Pulsante invio' : 'Submit & Message',
                    el('div', null,
                        row(_isIT ? 'Colore pulsante'      : 'Button Color',      clr('submit_bg',       '#d82d6b')),
                        row(_isIT ? 'Colore testo pulsante': 'Button Text Color', clr('submit_color',    '#ffffff')),
                        row(_isIT ? 'Raggio pulsante'      : 'Button Radius',     txt('submit_radius',   '4px')),
                        row(_isIT ? 'Colore hover pulsante': 'Hover Color',       clr('submit_hover_bg', '')),
                        row('Sfondo conferma',      clr('success_bg',     '#f0fdf4')),
                        row('Testo conferma',       clr('success_color',  '#15803d')),
                        row('Bordo conferma',       clr('success_border', '#86efac')),
                        row('Sfondo errore',        clr('error_bg',       '#fff0f5')),
                        row('Testo errore',         clr('error_color',    '#d82d6b')),
                        row('Bordo errore',         clr('error_border',   '#f9a8c9')),
                        row('Dimensione testo',     txt('msg_font_size',  '0.9rem'))
                    )
                )
            );
        } else if (activeSubTab === 'color_scheme') {
            var currentColor = (c.submit_bg || '#d82d6b').toLowerCase();
            content = el('div', { style: { padding: '16px' } },
                el('p', { style: { fontSize: '11px', color: '#888', margin: '0 0 14px' } },
                    'Clicca un colore per applicarlo al form (pulsante, focus, accenti).'
                ),
                el('div', { className: 'if2-color-scheme-grid' },
                    COLOR_PRESETS.map(function (hex) {
                        var isActive = currentColor === hex.toLowerCase();
                        return el('button', {
                            key: hex,
                            title: hex,
                            className: 'if2-color-swatch' + (isActive ? ' active' : ''),
                            style: { background: hex },
                            onClick: function () { up({ submit_bg: hex, focus_color: hex }); },
                        }, isActive ? el('span', { className: 'if2-swatch-check' }, '✓') : null);
                    })
                ),
                el('div', { style: { marginTop: '20px', borderTop: '2px solid #f0f0f0', paddingTop: '16px' } },
                    el('p', { style: { fontSize: '11px', fontWeight: 700, color: '#333', margin: '0 0 14px', textTransform: 'uppercase', letterSpacing: '.06em' } }, _isIT ? 'O costruisci uno personalizzato' : 'Or build a custom one'),
                    row(_isIT ? 'Colore base'                  : 'Base Color',              clr('submit_bg',       '#d82d6b')),
                    row(_isIT ? 'Colore testo pulsante'        : 'Button Font Color',       clr('btn_font_color',  '#ffffff')),
                    row(_isIT ? 'Colore pulsante paginazione'  : 'Pagination Button Color', clr('pagination_bg',   '#d82d6b')),
                    row(_isIT ? 'Colore sfondo campi'          : 'Field Background Color',  clr('input_bg',        '#ffffff')),
                    row(_isIT ? 'Colore testo generale'        : 'General Font Color',      clr('font_color',      '#333333')),
                    row(_isIT ? 'Colore testo campi'           : 'Field Font Color',        clr('field_font_color','#333333'))
                )
            );
        } else if (activeSubTab === 'background') {
            content = el('div', null,
                chk('bg_transparent', 'Trasparente', false),
                el('div', { style: { padding: '16px' } },
                    el('p', { style: { fontSize: '11px', color: '#888', margin: '0 0 14px' } },
                        'Personalizza lo sfondo del form.'
                    ),
                    row('Colore sfondo form', clr('bg_color', '#ffffff')),
                    el('div', { style: { height: '1px', background: '#f0f0f0', margin: '14px 0' } }),
                    row('Immagine sfondo (URL)', txt('bg_image', 'https://…')),
                    el('p', { style: { fontSize: '10px', color: '#aaa', margin: '4px 0 12px', lineHeight: 1.4 } },
                        'URL immagine da applicare come sfondo del form.'
                    ),
                    row('Dimensione sfondo', el('select', { value: c.bg_size || 'cover', style: { width: '100%' },
                        onChange: function (e) { up({ bg_size: e.target.value }); } },
                        el('option', { value: 'cover' },   'Cover'),
                        el('option', { value: 'contain' }, 'Contain'),
                        el('option', { value: 'auto' },    'Auto'),
                        el('option', { value: 'repeat' },  'Repeat (tile)')
                    ))
                )
            );
        }

        return el('div', null, subTabBar, content);
    }

    // -------------------------------------------------------------------------
    // LogicPanel — regole condizionali SE/ALLORA
    // -------------------------------------------------------------------------
    function LogicPanel(props) {
        var fields = props.fields || [];
        var c      = props.config;
        var up     = props.onConfig;
        var rules  = c.logic_rules || [];

        var OPERATORS = [
            { value: 'equals',       label: 'è uguale a' },
            { value: 'not_equals',   label: 'non è uguale a' },
            { value: 'contains',     label: 'contiene' },
            { value: 'not_contains', label: 'non contiene' },
            { value: 'is_empty',     label: 'è vuoto' },
            { value: 'not_empty',    label: 'non è vuoto' },
        ];
        var ACTION_TYPES = _isIT ? [
            { value: 'show',       label: 'Mostra campi' },
            { value: 'hide',       label: 'Nascondi campi' },
            { value: 'set_value',  label: 'Imposta valore' },
            { value: 'redirect',   label: 'Reindirizza a' },
            { value: 'send_email', label: 'Invia email a' },
            { value: 'webhook',    label: 'Attiva integrazione' },
        ] : [
            { value: 'show',       label: 'Show fields' },
            { value: 'hide',       label: 'Hide fields' },
            { value: 'set_value',  label: 'Set value of' },
            { value: 'redirect',   label: 'Redirect to' },
            { value: 'send_email', label: 'Send email to' },
            { value: 'webhook',    label: 'Trigger integration' },
        ];

        function normalizeRule(rule) {
            var r = rule;
            if (!r.conditions) {
                r = Object.assign({}, r, {
                    conditions: [{ field: r.condition_field || '', op: r.condition_op || 'equals', value: r.condition_value || '' }]
                });
            }
            // Azione: supporta più campi (action_fields). Compatibile con le vecchie regole (action_field singolo).
            if (!Array.isArray(r.action_fields)) {
                r = Object.assign({}, r, { action_fields: r.action_field ? [r.action_field] : [] });
            }
            return r;
        }

        function addRule() {
            var def = fields.length > 1 ? fields[1].id : (fields.length > 0 ? fields[0].id : '');
            var newRule = {
                id:           'rule_' + Math.random().toString(36).slice(2, 10),
                conditions:   [{ field: fields.length > 0 ? fields[0].id : '', op: 'equals', value: '' }],
                action_type:  'show',
                action_field: def,
                action_fields: [def],
            };
            up({ logic_rules: rules.concat([newRule]) });
        }
        function updateActionField(ruleId, idx, value) {
            up({ logic_rules: rules.map(function(r) {
                if (r.id !== ruleId) return r;
                var norm = normalizeRule(r);
                var afs  = norm.action_fields.map(function(v, i) { return i === idx ? value : v; });
                return Object.assign({}, norm, { action_fields: afs, action_field: afs[0] || '' });
            }) });
        }
        function addActionField(ruleId) {
            up({ logic_rules: rules.map(function(r) {
                if (r.id !== ruleId) return r;
                var norm = normalizeRule(r);
                var def  = fields.length > 0 ? fields[0].id : '';
                var afs  = norm.action_fields.concat([def]);
                return Object.assign({}, norm, { action_fields: afs, action_field: afs[0] || '' });
            }) });
        }
        function removeActionField(ruleId, idx) {
            up({ logic_rules: rules.map(function(r) {
                if (r.id !== ruleId) return r;
                var norm = normalizeRule(r);
                var afs  = norm.action_fields.filter(function(_, i) { return i !== idx; });
                if (!afs.length) afs = [''];
                return Object.assign({}, norm, { action_fields: afs, action_field: afs[0] || '' });
            }) });
        }
        function updateRule(id, changes) {
            up({ logic_rules: rules.map(function (r) { return r.id === id ? Object.assign({}, r, changes) : r; }) });
        }
        function deleteRule(id) {
            up({ logic_rules: rules.filter(function (r) { return r.id !== id; }) });
        }
        function addCondition(ruleId) {
            up({ logic_rules: rules.map(function(r) {
                if (r.id !== ruleId) return r;
                var norm = normalizeRule(r);
                return Object.assign({}, norm, { conditions: norm.conditions.concat([{ field: fields.length > 0 ? fields[0].id : '', op: 'equals', value: '' }]) });
            }) });
        }
        function updateCondition(ruleId, condIdx, changes) {
            up({ logic_rules: rules.map(function(r) {
                if (r.id !== ruleId) return r;
                var norm = normalizeRule(r);
                var conds = norm.conditions.map(function(c, i) { return i === condIdx ? Object.assign({}, c, changes) : c; });
                return Object.assign({}, norm, { conditions: conds });
            }) });
        }
        function deleteCondition(ruleId, condIdx) {
            up({ logic_rules: rules.map(function(r) {
                if (r.id !== ruleId) return r;
                var norm = normalizeRule(r);
                var conds = norm.conditions.filter(function(_, i) { return i !== condIdx; });
                if (!conds.length) conds = [{ field: '', op: 'equals', value: '' }];
                return Object.assign({}, norm, { conditions: conds });
            }) });
        }

        var fieldOptions = fields.map(function (f) {
            return el('option', { key: f.id, value: f.id }, f.label || f.type);
        });
        var selStyle = { width: '100%', fontSize: '11px', padding: '4px 6px', border: '1px solid #ccc', borderRadius: '3px', marginBottom: '4px', background: '#fff' };
        var rowBg = { display: 'flex', borderBottom: '1px solid #d8d8d8', alignItems: 'flex-start', background: '#eeeeee' };

        return el('div', null,
            el('div', { style: { display: 'flex', background: '#e4e4e4', borderBottom: '1px solid #ccc' } },
                el('div', { style: { flex: 1, padding: '8px 12px', fontSize: '10px', fontWeight: 700, color: '#666', letterSpacing: '.06em', textTransform: 'uppercase', borderRight: '1px solid #ccc' } }, 'SE (condizione)'),
                el('div', { style: { flex: 1, padding: '8px 12px', fontSize: '10px', fontWeight: 700, color: '#666', letterSpacing: '.06em', textTransform: 'uppercase' } }, 'ALLORA (azione)')
            ),
            rules.length === 0
                ? el('div', { style: { padding: '24px 16px', textAlign: 'center', color: '#aaa', fontSize: '12px' } },
                    el('p', { style: { margin: '0 0 6px' } }, 'Nessuna regola di logica.'),
                    el('p', { style: { margin: 0, fontSize: '11px' } }, 'Aggiungi una regola per mostrare/nascondere campi in base alle risposte.')
                  )
                : el('div', null,
                    rules.map(function (rule) {
                        var norm = normalizeRule(rule);
                        return el('div', { key: rule.id, style: rowBg },
                            // IF side — multiple conditions
                            el('div', { style: { flex: 1, padding: '8px', borderRight: '1px solid #d8d8d8' } },
                                norm.conditions.map(function(cond, ci) {
                                    var needsVal = cond.op !== 'is_empty' && cond.op !== 'not_empty';
                                    return el('div', { key: ci, style: { marginBottom: '6px', padding: '6px 8px', background: '#f5f5f5', border: '1px solid #ddd', borderRadius: '3px' } },
                                        el('div', { style: { display: 'flex', alignItems: 'center', gap: '4px', marginBottom: '4px' } },
                                            el('select', { value: cond.field, style: Object.assign({}, selStyle, { flex: 1, marginBottom: 0 }),
                                                onChange: function(e) { updateCondition(rule.id, ci, { field: e.target.value }); } }, fieldOptions),
                                            norm.conditions.length > 1 ? el('button', {
                                                style: { background: 'none', border: 'none', color: '#bbb', cursor: 'pointer', fontSize: '13px', padding: '0 2px', lineHeight: 1 },
                                                onClick: function() { deleteCondition(rule.id, ci); }
                                            }, '×') : null
                                        ),
                                        el('select', { value: cond.op, style: selStyle,
                                            onChange: function(e) { updateCondition(rule.id, ci, { op: e.target.value }); } },
                                            OPERATORS.map(function(op) { return el('option', { key: op.value, value: op.value }, op.label); })
                                        ),
                                        needsVal ? el('input', { type: 'text', value: cond.value || '', placeholder: 'Valore…', style: selStyle,
                                            onChange: function(e) { updateCondition(rule.id, ci, { value: e.target.value }); }
                                        }) : null
                                    );
                                }),
                                el('button', {
                                    style: { width: '100%', padding: '5px', border: '1.5px dashed #aaa', borderRadius: '3px', background: 'none', color: '#888', fontSize: '10px', fontWeight: 700, cursor: 'pointer', textTransform: 'uppercase', letterSpacing: '.04em' },
                                    onClick: function() { addCondition(rule.id); }
                                }, '+ ADD CONDITION ROW')
                            ),
                            // THEN side
                            el('div', { style: { flex: 1, padding: '8px' } },
                                el('select', { value: norm.action_type, style: selStyle,
                                    onChange: function (e) { updateRule(rule.id, { action_type: e.target.value }); } },
                                    ACTION_TYPES.map(function (at) { return el('option', { key: at.value, value: at.value }, at.label); })
                                ),
                                // Campi target — solo per Mostra / Nascondi / Imposta valore
                                (norm.action_type === 'show' || norm.action_type === 'hide' || norm.action_type === 'set_value') ? el('div', null,
                                    norm.action_fields.map(function (af, ai) {
                                        return el('div', { key: ai, style: { display: 'flex', alignItems: 'center', gap: '4px', marginBottom: '4px' } },
                                            el('select', { value: af, style: Object.assign({}, selStyle, { flex: 1, marginBottom: 0 }),
                                                onChange: function (e) { updateActionField(rule.id, ai, e.target.value); } }, fieldOptions),
                                            norm.action_fields.length > 1 ? el('button', {
                                                style: { background: 'none', border: 'none', color: '#bbb', cursor: 'pointer', fontSize: '13px', padding: '0 2px', lineHeight: 1 },
                                                onClick: function () { removeActionField(rule.id, ai); }
                                            }, '×') : null
                                        );
                                    }),
                                    el('button', {
                                        style: { width: '100%', padding: '5px', border: '1.5px dashed #aaa', borderRadius: '3px', background: 'none', color: '#888', fontSize: '10px', fontWeight: 700, cursor: 'pointer', textTransform: 'uppercase', letterSpacing: '.04em', marginBottom: '6px' },
                                        onClick: function () { addActionField(rule.id); }
                                    }, _isIT ? '+ aggiungi campo' : '+ add field')
                                ) : null,
                                // Valore da impostare — set_value
                                norm.action_type === 'set_value' ? el('input', { type: 'text', value: norm.action_value || '', placeholder: _isIT ? 'Valore da impostare…' : 'Value to set…', style: selStyle,
                                    onChange: function (e) { updateRule(rule.id, { action_value: e.target.value }); } }) : null,
                                // URL — redirect / webhook
                                (norm.action_type === 'redirect' || norm.action_type === 'webhook') ? el('input', { type: 'text', value: norm.action_url || '',
                                    placeholder: norm.action_type === 'redirect' ? (_isIT ? 'URL di destinazione…' : 'Destination URL…') : (_isIT ? 'URL integrazione / webhook…' : 'Integration / webhook URL…'),
                                    style: selStyle, onChange: function (e) { updateRule(rule.id, { action_url: e.target.value }); } }) : null,
                                // Email destinatario — send_email
                                norm.action_type === 'send_email' ? el('input', { type: 'text', value: norm.action_email || '', placeholder: _isIT ? 'Email destinatario…' : 'Recipient email…', style: selStyle,
                                    onChange: function (e) { updateRule(rule.id, { action_email: e.target.value }); } }) : null,
                                el('button', {
                                    style: { background: 'none', border: 'none', color: '#bbb', cursor: 'pointer', fontSize: '11px', padding: '2px 0', display: 'block' },
                                    onClick: function () { deleteRule(rule.id); }
                                }, '× elimina regola')
                            )
                        );
                    })
                  ),
            el('div', { style: { padding: '12px 16px' } },
                el('button', {
                    style: { width: '100%', padding: '10px', border: '2px dashed #d82d6b', borderRadius: '4px', background: 'none', color: '#d82d6b', fontSize: '12px', fontWeight: 700, cursor: 'pointer', textTransform: 'uppercase', letterSpacing: '.04em' },
                    onClick: addRule
                }, '+ Aggiungi nuova logica'),
                el('p', { style: { fontSize: '10px', color: '#aaa', margin: '10px 0 0', textAlign: 'center' } },
                    'Le regole vengono valutate al submit e durante la compilazione del form.'
                )
            )
        );
    }

    // -------------------------------------------------------------------------
    // HelpPanel — documentazione rapida
    // -------------------------------------------------------------------------
    function HelpPanel() {
        var emailVarsContent = el('div', null,
            el('div', { style: { marginBottom: '8px', fontSize: '12px', color: '#555' } }, 'Usa questi placeholder nel corpo dell\'email (notifica e autoresponder):'),
            el('table', { style: { width: '100%', fontSize: '11px', borderCollapse: 'collapse' } },
                el('thead', null,
                    el('tr', null,
                        el('th', { style: { textAlign: 'left', padding: '4px 8px 4px 0', color: '#999', fontWeight: 700, borderBottom: '1px solid #e0cfd8', whiteSpace: 'nowrap' } }, 'Vecchio form'),
                        el('th', { style: { textAlign: 'left', padding: '4px 0', color: '#999', fontWeight: 700, borderBottom: '1px solid #e0cfd8' } }, 'in3pida-form-2')
                    )
                ),
                el('tbody', null,
                    [
                        ['[Form Content]', '{all_fields}'],
                        ['[URL]',          '{source_url}'],
                        ['[Entry ID]',     '{submission_id}'],
                        ['[Date]',         '{date}'],
                        ['[Time]',         '{time}'],
                        ['—',              '{form_name}'],
                        ['—',              '{channel}'],
                        ['—',              '{field_ID}'],
                    ].map(function (r, i) {
                        return el('tr', { key: i, style: { borderBottom: '1px solid #f5f5f5' } },
                            el('td', { style: { padding: '4px 8px 4px 0', color: '#aaa', fontFamily: 'monospace', whiteSpace: 'nowrap' } }, r[0]),
                            el('td', { style: { padding: '4px 0', color: '#d82d6b', fontFamily: 'monospace', fontWeight: 700 } }, r[1])
                        );
                    })
                )
            ),
            el('div', { style: { marginTop: '8px', fontSize: '11px', color: '#aaa' } }, 'Es: {field_ID} → sostituisci ID con l\'ID del campo (es. {field_abc123})')
        );

        var sections = [
            { title: 'Iniziare',             text: 'Aggiungi campi dal pannello a destra, trascina per riordinarli, clicca per modificarli.' },
            { title: 'Campi principali',     text: 'One Line Input, Email, Textarea, Checkbox, Dropdown, Datepicker, Custom Text, Submit.' },
            { title: 'Campi extra',          text: 'Password, File Upload, Slider, Timepicker, Address — disponibili in MORE FIELDS.' },
            { title: 'Survey',               text: 'Thumb Rating, Star Rating, Choice Matrix per sondaggi e valutazioni.' },
            { title: 'Impostazioni',         text: 'Email, webhook, Supabase, Hotel ID, Reply-To e altro dalla tab SETTINGS.' },
            { title: 'Hotel ID',             text: 'Il campo Hotel ID identifica la struttura nelle submissions e in Supabase.\n\n• Hotel singolo: inserisci l\'ID una volta sola in Impostazioni in3pida → sezione "Identificazione Hotel". Viene applicato automaticamente a tutti i form — non serve toccarlo qui nel builder.\n\n• Multi-hotel (sito con più strutture selezionabili): lascia vuoto il campo globale in Impostazioni e imposta l\'Hotel ID direttamente nelle impostazioni di ogni singolo form (tab SETTINGS → IN3PIDA). In questo modo ogni form invia l\'ID corretto per la propria struttura.' },
            { title: 'Amelia — utente senza numero di telefono', text: 'Se un utente non compila il numero di telefono, il contatto viene comunque aggiunto ad Amelia con il numero placeholder 393471234567. Potrai aggiornare il numero manualmente in Amelia quando disponibile.' },
            { title: 'Supabase — problema colonna non trovata', text: 'Se Supabase restituisce l\'errore "Could not find column in schema cache" (codice PGRST204), significa che hai aggiunto una nuova colonna alla tabella ma Supabase non l\'ha ancora registrata internamente.\n\nSoluzione: vai su Supabase → SQL Editor, crea una nuova query, incolla questa riga e clicca Run:\n\nNOTIFY pgrst, \'reload schema\';\n\nDopo qualche secondo Supabase riconosce la nuova colonna e le richieste entrano correttamente.' },
            { title: 'Email — Variabili',    content: emailVarsContent },
            { title: 'Email — SMTP personalizzato', content: el('div', null,
                el('p', { style: { fontSize: '12px', color: '#555', margin: '0 0 8px', lineHeight: 1.6 } },
                    'Di default le mail partono tramite ', el('strong', null, 'wp_mail'), ', il sistema di invio di WordPress. Se le mail non arrivano (finiscono in spam o non partono affatto), attiva ', el('strong', null, 'SMTP personalizzato'), ' per usare il tuo server di posta reale.'
                ),
                el('p', { style: { fontSize: '11px', fontWeight: 700, color: '#444', margin: '8px 0 5px', textTransform: 'uppercase', letterSpacing: '.04em' } }, 'Come configurarlo'),
                el('ol', { style: { margin: '0 0 10px', paddingLeft: '16px', fontSize: '11px', color: '#555', lineHeight: 1.9 } },
                    el('li', null, 'Nel builder aperto, vai nel tab ', el('strong', null, 'EMAIL'), '.'),
                    el('li', null, 'In "Metodo di invio" seleziona ', el('strong', null, 'SMTP personalizzato'), '.'),
                    el('li', null, 'Compila: Host, Porta, Utente (email completa), Password, Cifratura (TLS consigliato).'),
                    el('li', null, 'Usa il pulsante ', el('strong', null, '"Invia mail di test"'), ' per verificare che tutto funzioni.'),
                    el('li', null, 'Salva il form.')
                ),
                el('p', { style: { fontSize: '11px', fontWeight: 700, color: '#444', margin: '8px 0 5px', textTransform: 'uppercase', letterSpacing: '.04em' } }, 'Dove trovare i dati SMTP'),
                el('p', { style: { fontSize: '11px', color: '#555', margin: '0', lineHeight: 1.8 } },
                    el('strong', null, 'Opzione 1 — '), 'Pannello hosting (cPanel, Plesk…) → sezione ', el('strong', null, 'Account Email'), ': trovi server SMTP, porta, utente e password.', el('br', null),
                    el('strong', null, 'Opzione 2 — '), 'Se l\'account è già configurato su Thunderbird o Outlook: ', el('strong', null, 'Impostazioni account → Server in uscita (SMTP)'), '.'
                )
            ) },
            { title: 'Logica condizionale',  text: 'Mostra o nascondi campi in base alle risposte con le regole in LOGIC.' },
            { title: 'Importazione form', content: el('ol', { style: { margin: '4px 0 0', paddingLeft: '16px', fontSize: '12px', color: '#555', lineHeight: 1.7 } },
                el('li', null, el('strong', null, 'File JSON nativo'), ' (export da in3pida-form-2): nella bacheca dei form, clicca il link ', el('strong', null, 'Export'), ' accanto al form. Per importare, clicca ', el('strong', null, '"+ Nuovo form" → Importa'), ', scegli il file .json o incolla il JSON direttamente.'),
                el('li', null, el('strong', null, 'File TXT da vecchio plugin form'), ': nel builder aperto, vai nel tab ', el('strong', null, 'SETTINGS → IN3PIDA'), ' e clicca ', el('strong', null, '"Import (.json / .txt)"'), '. Scegli il file esportato dal vecchio plugin.'),
                el('li', null, 'I campi vengono importati con: label, tipo, opzioni, larghezza, richiesto, nascondi al caricamento.'),
                el('li', null, 'La logica condizionale viene importata e appare nel tab ', el('strong', null, 'LOGICA'), ' e nelle impostazioni di ogni campo.'),
                el('li', null, 'Le impostazioni email (notifica, autoresponder), redirect e webhook vengono importate automaticamente dal vecchio plugin se presenti nel file.')
            ) },
            { title: 'Log integrazioni', content: el('div', null,
                el('p', { style: { fontSize: '12px', color: '#555', margin: '0 0 8px', lineHeight: 1.6 } },
                    'Nella pagina ', el('strong', null, 'Risposte'), ' trovi tre colonne: ', el('strong', null, 'DB'), ' (Supabase), ', el('strong', null, 'CRM'), ' (webhook), ', el('strong', null, 'AM'), ' (Amelia / SMSHosting). Per ogni invio vedi subito se i dati sono arrivati a destinazione, senza dover controllare manualmente le piattaforme esterne.'
                ),
                el('table', { style: { width: '100%', fontSize: '11px', borderCollapse: 'collapse', marginBottom: '8px' } },
                    el('tbody', null,
                        [
                            ['DB',  'Supabase',         'I dati del form sono stati inviati correttamente a Supabase.'],
                            ['CRM', 'Webhook / CRM',    'I dati sono stati inviati al CRM esterno tramite webhook. Verde = ricevuto, anche se il CRM risponde con un codice di errore.'],
                            ['AM',  'Amelia / SMS',      'Il contatto è stato aggiunto alla lista SMSHosting / Amelia.'],
                        ].map(function (r, i) {
                            return el('tr', { key: i, style: { borderBottom: '1px solid #f5f5f5' } },
                                el('td', { style: { padding: '4px 8px 4px 0', width: '36px' } },
                                    el('span', { style: { padding: '2px 5px', borderRadius: '3px', fontSize: '9px', fontWeight: 700, background: '#22c55e', color: '#fff' } }, r[0])
                                ),
                                el('td', { style: { padding: '4px 8px 4px 0', fontWeight: 700, color: '#444', fontSize: '11px', whiteSpace: 'nowrap' } }, r[1]),
                                el('td', { style: { padding: '4px 0', color: '#888', fontSize: '11px' } }, r[2])
                            );
                        })
                    )
                ),
                el('p', { style: { fontSize: '11px', color: '#555', margin: '4px 0 4px', lineHeight: 1.8 } },
                    el('strong', null, 'Colori pallini:')
                ),
                el('p', { style: { fontSize: '11px', color: '#555', margin: '0 0 2px', lineHeight: 1.8 } },
                    el('span', { style: { color: '#22c55e', fontWeight: 700 } }, '● Verde '),
                    '— dati arrivati correttamente a destinazione.'
                ),
                el('p', { style: { fontSize: '11px', color: '#555', margin: '0 0 2px', lineHeight: 1.8 } },
                    el('span', { style: { color: '#d82d6b', fontWeight: 700 } }, '● Rosso '),
                    '— errore di connessione: i dati non sono partiti. Passa il mouse sul pallino per vedere il dettaglio.'
                ),
                el('p', { style: { fontSize: '11px', color: '#555', margin: '0 0 2px', lineHeight: 1.8 } },
                    el('span', { style: { color: '#60a5fa', fontWeight: 700 } }, '● Blu '),
                    '— contatto già presente (Amelia): nessuna azione compiuta, il contatto era già in lista.'
                ),
                el('p', { style: { fontSize: '11px', color: '#555', margin: '0 0 2px', lineHeight: 1.8 } },
                    el('span', { style: { color: '#f59e0b', fontWeight: 700 } }, '● Arancione '),
                    '— in attesa: il log non è ancora arrivato (normale per il CRM subito dopo l\'invio).'
                ),
                el('p', { style: { fontSize: '11px', color: '#555', margin: '0 0 8px', lineHeight: 1.8 } },
                    el('span', { style: { color: '#94a3b8', fontWeight: 700 } }, '● Grigio '),
                    '— saltato: l\'integrazione non era applicabile (es. consenso non dato).'
                ),
                el('p', { style: { fontSize: '11px', color: '#555', margin: '4px 0 8px', lineHeight: 1.6 } },
                    el('strong', null, 'Telefono mancante (Amelia):'), ' Se l\'utente non compila il numero di telefono, il contatto viene aggiunto comunque ad Amelia con un numero temporaneo (393471234567). Puoi aggiornare il numero reale direttamente in Amelia quando disponibile.'
                ),
                el('p', { style: { fontSize: '11px', color: '#555', margin: '8px 0 2px', lineHeight: 1.6 } },
                    el('strong', null, 'Pulsante ↻ Riprova:'), ' Se una risposta ha il pallino rosso su DB, CRM o AM, apri il dettaglio dalla pagina Risposte e clicca il pulsante "↻ Riprova" accanto all\'errore. Il sistema reinvia i dati e aggiorna il pallino a verde se va a buon fine.'
                ),
                el('p', { style: { fontSize: '11px', color: '#888', margin: '4px 0 0', lineHeight: 1.6 } },
                    'Le integrazioni non configurate non appaiono. Passa il mouse su qualsiasi pallino per vedere il dettaglio completo.'
                )
            ) },
            { title: 'Integrazioni CRM', content: el('div', null,
                el('p', { style: { fontSize: '12px', color: '#555', margin: '0 0 12px', lineHeight: 1.6 } },
                    'Quando qualcuno compila il form, la richiesta arriva automaticamente nel CRM — senza copiare niente a mano.'
                ),

                el('p', { style: { fontSize: '11px', fontWeight: 700, color: '#444', margin: '0 0 5px', textTransform: 'uppercase', letterSpacing: '.04em' } }, 'Passo 1 — configura il CRM (una volta sola)'),
                el('ol', { style: { margin: '0 0 12px', paddingLeft: '16px', fontSize: '11px', color: '#555', lineHeight: 1.8 } },
                    el('li', null, 'Vai su ', el('strong', null, 'Integrazioni CRM'), ' nel menu a sinistra.'),
                    el('li', null, 'Clicca il tab del CRM che usi (HotelDoor, Mr Preno, Be Direct, ecc.).'),
                    el('li', null, 'Inserisci le credenziali (token, API key…) e spunta ', el('strong', null, '"Attivata"'), '.'),
                    el('li', null, 'Nella sezione "Mappa campi", abbina ogni campo del CRM al nome del campo che hai nel form. Es: Check-in → "Arrivo".'),
                    el('li', null, 'Salva. ', el('strong', null, 'Si fa una volta sola — vale per tutti i form.'))
                ),

                el('p', { style: { fontSize: '11px', fontWeight: 700, color: '#444', margin: '0 0 5px', textTransform: 'uppercase', letterSpacing: '.04em' } }, 'Passo 2 — attiva il CRM su questo form'),
                el('ol', { style: { margin: '0 0 12px', paddingLeft: '16px', fontSize: '11px', color: '#555', lineHeight: 1.8 } },
                    el('li', null, 'Qui nel builder, apri il tab ', el('strong', null, 'CRM'), '.'),
                    el('li', null, 'Spunta il CRM che vuoi usare per questo form.'),
                    el('li', null, 'Se questo hotel ha un ID o codice diverso da quello globale, inseriscilo qui. Altrimenti lascia vuoto.'),
                    el('li', null, 'Salva il form.')
                ),

                el('p', { style: { fontSize: '11px', fontWeight: 700, color: '#444', margin: '0 0 5px', textTransform: 'uppercase', letterSpacing: '.04em' } }, 'Note importanti'),
                el('ul', { style: { margin: '0 0 10px', paddingLeft: '16px', fontSize: '11px', color: '#555', lineHeight: 1.9 } },
                    el('li', null, el('strong', null, 'Booking Designer'), ' — vuole Nome e Cognome in due campi separati nel form. Un campo unico "Nome e Cognome" non funziona.'),
                    el('li', null, el('strong', null, 'Combo'), ' — non ha una vera API: la richiesta parte via email. Devi configurare le credenziali email nelle impostazioni globali.'),
                    el('li', null, 'Il risultato di ogni invio è visibile in ', el('strong', null, 'Risposte → colonna CRM'), '. Pallino verde = arrivato, rosso = errore (passa il mouse per i dettagli).')
                )
            ) },
            { title: 'Stile', content: el('div', null,
                el('p', { style: { fontSize: '12px', color: '#555', margin: '0 0 10px', lineHeight: 1.6 } },
                    'Vai sul tab ', el('strong', null, 'STYLING'), ' per personalizzare l\'aspetto del form.'
                ),
                el('ul', { style: { margin: '0', paddingLeft: '16px', fontSize: '11px', color: '#555', lineHeight: 1.9 } },
                    el('li', null, el('strong', null, 'Colori'), ' — colore testo, campi, pulsante invio, focus dei campi.'),
                    el('li', null, el('strong', null, 'Sfondo'), ' — colore o immagine di sfondo. Spunta ', el('strong', null, '"Trasparente"'), ' per togliere lo sfondo e la cornice del form (utile se il form è già su uno sfondo colorato nel sito).'),
                    el('li', null, el('strong', null, 'Nascondi etichette'), ' — nasconde i titoli dei campi (es. "Arrivo", "Nome"). Usalo insieme ai Placeholder nei campi per mettere il testo dentro al campo invece che sopra.'),
                    el('li', null, el('strong', null, 'Datepicker'), ' — nello Styling c\'è una sezione ', el('strong', null, 'Datepicker'), ' con tutti i suoi comandi: colore di sfondo del titolo (la barra in alto), colore della data di oggi, colore della data selezionata e curvatura degli angoli.')
                )
            ) },
            { title: 'Shortcode', text: 'Copia lo shortcode dalla pagina Forms per incorporare il form nel sito.' },
            { title: 'Target soggiorno', content: el('div', null,
                el('p', { style: { fontSize: '12px', color: '#555', margin: '0 0 8px', lineHeight: 1.6 } },
                    'Il target viene calcolato automaticamente dal numero di adulti e bambini nel form. Ecco come vengono raggruppati:'
                ),
                el('table', { style: { width: '100%', fontSize: '11px', borderCollapse: 'collapse' } },
                    el('thead', null,
                        el('tr', { style: { background: '#fdf0f5' } },
                            el('th', { style: { padding: '5px 8px', textAlign: 'left', color: '#d82d6b', fontWeight: 700 } }, 'Adulti'),
                            el('th', { style: { padding: '5px 8px', textAlign: 'left', color: '#d82d6b', fontWeight: 700 } }, 'Bambini'),
                            el('th', { style: { padding: '5px 8px', textAlign: 'left', color: '#d82d6b', fontWeight: 700 } }, 'Target')
                        )
                    ),
                    el('tbody', null,
                        el('tr', null, el('td', { style: { padding: '4px 8px' } }, '1'), el('td', { style: { padding: '4px 8px' } }, '0'), el('td', { style: { padding: '4px 8px', fontWeight: 600 } }, 'Single')),
                        el('tr', { style: { background: '#fafafa' } }, el('td', { style: { padding: '4px 8px' } }, '1'), el('td', { style: { padding: '4px 8px' } }, '1+'), el('td', { style: { padding: '4px 8px', fontWeight: 600 } }, 'Genitore single')),
                        el('tr', null, el('td', { style: { padding: '4px 8px' } }, '2'), el('td', { style: { padding: '4px 8px' } }, '0'), el('td', { style: { padding: '4px 8px', fontWeight: 600 } }, 'Coppie')),
                        el('tr', { style: { background: '#fafafa' } }, el('td', { style: { padding: '4px 8px' } }, '3+'), el('td', { style: { padding: '4px 8px' } }, '0'), el('td', { style: { padding: '4px 8px', fontWeight: 600 } }, 'Amici')),
                        el('tr', null, el('td', { style: { padding: '4px 8px' } }, 'qualsiasi'), el('td', { style: { padding: '4px 8px' } }, '1'), el('td', { style: { padding: '4px 8px', fontWeight: 600 } }, 'Famiglia con 1 bambino')),
                        el('tr', { style: { background: '#fafafa' } }, el('td', { style: { padding: '4px 8px' } }, 'qualsiasi'), el('td', { style: { padding: '4px 8px' } }, '2'), el('td', { style: { padding: '4px 8px', fontWeight: 600 } }, 'Famiglia con 2 bambini')),
                        el('tr', null, el('td', { style: { padding: '4px 8px' } }, 'qualsiasi'), el('td', { style: { padding: '4px 8px' } }, '3+'), el('td', { style: { padding: '4px 8px', fontWeight: 600 } }, 'Famiglia numerosa'))
                    )
                ),
                el('p', { style: { fontSize: '11px', color: '#888', margin: '8px 0 0', lineHeight: 1.5 } },
                    'Nota: la presenza di qualsiasi bambino (anche con 3+ adulti) porta sempre alla categoria famiglia corrispondente, mai ad "Amici".'
                )
            ) },
            { title: 'Amelia / SMSHosting', content: el('ol', { style: { margin: '4px 0 0', paddingLeft: '16px', fontSize: '12px', color: '#555', lineHeight: 1.7 } },
                el('li', null, 'Vai in ', el('strong', null, 'Impostazioni → Amelia / SMSHosting'), ' e inserisci Auth Key, Auth Secret e List ID (Group ID) forniti da SMSHosting.'),
                el('li', null, 'Clicca ', el('strong', null, '"Test connessione"'), ' per verificare le credenziali.'),
                el('li', null, 'Apri il campo ', el('strong', null, 'Checkbox del consenso'), ' → spunta ', el('strong', null, '"Amelia Consenso"'), '.'),
                el('li', null, 'Apri il campo ', el('strong', null, 'Telefono'), ' → spunta ', el('strong', null, '"Amelia Telefono"'), '. Il numero viene normalizzato in formato internazionale (+39) automaticamente.'),
                el('li', null, 'Il campo ', el('strong', null, 'Email'), ' viene rilevato automaticamente — nessuna azione richiesta.'),
                el('li', null, el('em', null, '(Opzionale)'), ' Apri il campo ', el('strong', null, 'Nome/Cognome'), ' → spunta ', el('strong', null, '"Amelia Nome"'), '. Se è un campo unico viene splittato sul primo spazio.'),
                el('li', null, el('em', null, '(Opzionale — multi-paese)'), ' In ', el('strong', null, 'Impostazioni → Amelia / SMSHosting'), ', sezione "Liste per paese", aggiungi una riga per ogni nazione con il relativo List ID. Al submit il sistema rileva il TLD della email (.it → IT, .de → DE, ecc.) e usa la lista giusta automaticamente.'),
                el('li', null, el('em', null, '(Opzionale)'), ' Nel tab ', el('strong', null, 'IN3PIDA'), ' del form imposta ', el('strong', null, '"Lista Amelia default"'), ': lista usata quando il TLD non corrisponde a nessun paese configurato.'),
                el('li', null, 'Salva il form. Al submit, se il consenso è spuntato, il contatto viene aggiunto alla lista con telefono, email e nome.')
            ) },
        ];
        return el('div', { style: { padding: '16px' } },
            el('p', { style: { fontSize: '12px', color: '#888', margin: '0 0 16px', lineHeight: 1.6 } },
                'Documentazione in3pida Form 2.0'
            ),
            sections.map(function (s) {
                return el('div', { key: s.title, style: { marginBottom: '10px', padding: '10px 12px', background: '#fafafa', borderRadius: '4px', borderLeft: '3px solid #d82d6b' } },
                    el('div', { style: { fontSize: '11px', fontWeight: 700, color: '#d82d6b', textTransform: 'uppercase', letterSpacing: '.04em', marginBottom: '4px' } }, s.title),
                    el('div', { style: { fontSize: '12px', color: '#555', lineHeight: 1.5 } }, s.content || s.text)
                );
            })
        );
    }

    // -------------------------------------------------------------------------
    // AddonsPanel
    // -------------------------------------------------------------------------
    function AddonsPanel() {
        var _t = useState('installed');
        var activeTab = _t[0]; var setActiveTab = _t[1];

        var tabBtn = function (key, label) {
            return el('button', {
                key: key,
                onClick: function () { setActiveTab(key); },
                style: {
                    flex: 1, padding: '10px 8px', border: 'none',
                    borderBottom: activeTab === key ? '2px solid #d82d6b' : '2px solid transparent',
                    background: 'none',
                    color: activeTab === key ? '#d82d6b' : '#999',
                    fontSize: '11px', fontWeight: 700, cursor: 'pointer',
                    textTransform: 'uppercase', letterSpacing: '.04em',
                }
            }, label);
        };

        return el('div', null,
            el('div', { style: { display: 'flex', borderBottom: '1px solid #e0cfd8', background: '#fafafa' } },
                tabBtn('installed', 'Installati'),
                tabBtn('add', 'Aggiungi Nuovo')
            ),
            activeTab === 'installed'
                ? el('div', { style: { padding: '24px 16px', textAlign: 'center', color: '#aaa', fontSize: '12px' } },
                    el('p', { style: { margin: '0 0 6px' } }, 'Nessun addon installato.'),
                    el('p', { style: { margin: 0, fontSize: '11px' } }, 'Gli addon estendono le funzionalità del form builder.')
                  )
                : el('div', { style: { padding: '24px 16px', textAlign: 'center', color: '#aaa', fontSize: '12px' } },
                    el('p', { style: { margin: '0 0 6px' } }, 'Nessun addon disponibile.'),
                    el('p', { style: { margin: 0, fontSize: '11px' } }, 'I nuovi addon saranno disponibili qui non appena rilasciati.')
                  )
        );
    }

    // -------------------------------------------------------------------------
    // FieldCard — mostra la preview reale del campo nel canvas
    // -------------------------------------------------------------------------
    function FieldPreview(props) {
        var field = props.field;
        var cfg   = props.config || {};
        var type  = field.type;
        var label = field.label || '';
        var ph    = field.placeholder || '';
        var req   = field.required;

        var inputStyle = {
            display: 'block', width: '100%', boxSizing: 'border-box',
            height: '38px', padding: cfg.field_padding || '8px 12px',
            border: (cfg.field_border_width || '1.5px') + ' solid ' + (cfg.field_border_color || '#e0cfd8'),
            borderRadius: cfg.field_radius || '6px',
            fontSize: cfg.font_size || '13px',
            color: cfg.field_font_color || cfg.font_color || '#555',
            background: cfg.input_bg || '#fafafa',
            fontFamily: 'inherit', outline: 'none',
        };
        var labelStyle = {
            display: 'block',
            fontSize: cfg.font_size ? 'calc(' + parseFloat(cfg.font_size) * 0.85 + 'px)' : '12px',
            fontWeight: cfg.label_weight || 700,
            color: cfg.label_color || '#444',
            marginBottom: '5px', fontFamily: 'inherit',
        };

        function labelEl() {
            if (!label) return null;
            return el('label', { style: labelStyle },
                label,
                req ? el('span', { style: { color: '#d82d6b', marginLeft: '2px' } }, '*') : null
            );
        }
        function inputEl(t) {
            return el('input', { type: t || 'text', placeholder: ph, disabled: true, style: inputStyle });
        }

        if (type === 'heading') {
            return el('div', { style: { fontSize: '17px', fontWeight: 800, color: '#181834', fontFamily: 'inherit', lineHeight: 1.2 } },
                field.content || label || 'Titolo sezione');
        }
        if (type === 'html') {
            return el('div', { style: { fontSize: '12px', color: '#888', fontStyle: 'italic' } }, '[ Custom Text Block ]');
        }
        if (type === 'submit') {
            var alignMap = { left: 'flex-start', center: 'center', right: 'flex-end' };
            var sAlign = field.submit_align || 'right';
            var sWide  = !!field.submit_wide;
            return el('div', { style: { display: 'flex', justifyContent: alignMap[sAlign] || 'flex-end' } },
                el('button', { disabled: true, style: {
                    background: cfg.submit_bg || '#d82d6b',
                    color: cfg.submit_color || '#fff',
                    border: 'none',
                    padding: '10px 26px',
                    borderRadius: cfg.submit_radius || '6px',
                    fontWeight: 700,
                    fontSize: cfg.font_size || '13px',
                    cursor: 'not-allowed', fontFamily: 'inherit',
                    width: sWide ? '100%' : 'auto',
                } }, label || 'Invia')
            );
        }
        if (type === 'textarea') {
            return el('div', null,
                labelEl(),
                el('textarea', { placeholder: ph, disabled: true, rows: Math.min(field.rows || 3, 3),
                    style: Object.assign({}, inputStyle, { height: 'auto', resize: 'none', lineHeight: 1.5 }) })
            );
        }
        if (type === 'select') {
            return el('div', null,
                labelEl(),
                el('select', { disabled: true, style: Object.assign({}, inputStyle, { cursor: 'not-allowed', appearance: 'auto' }) },
                    el('option', null, ph || '— Seleziona —'),
                    (field.options || []).slice(0, 4).map(function (o, i) {
                        return el('option', { key: i }, o.label);
                    })
                )
            );
        }
        if (type === 'checkbox' || type === 'radio') {
            return el('div', null,
                labelEl(),
                el('div', { style: { display: 'flex', flexDirection: 'column', gap: '5px', marginTop: '2px' } },
                    (field.options || [{ label: 'Opzione 1' }]).slice(0, 3).map(function (o, i) {
                        return el('label', { key: i, style: { display: 'flex', gap: '7px', alignItems: 'center', fontSize: cfg.font_size || '12px', color: cfg.font_color || '#555', cursor: 'default' } },
                            el('input', { type: type === 'radio' ? 'radio' : 'checkbox', disabled: true, style: { accentColor: '#d82d6b', width: '14px', height: '14px', cursor: 'default' } }),
                            o.label
                        );
                    })
                )
            );
        }
        if (type === 'file') {
            return el('div', null,
                labelEl(),
                el('div', { style: Object.assign({}, inputStyle, { color: '#aaa', display: 'flex', alignItems: 'center' }) }, '📎 Scegli file…')
            );
        }
        if (type === 'date') {
            return el('div', null,
                labelEl(),
                el('div', { style: Object.assign({}, inputStyle, { color: '#aaa', display: 'flex', alignItems: 'center' }) }, '📅 ' + (ph || 'GG/MM/AAAA'))
            );
        }
        if (type === 'slider') {
            return el('div', null,
                labelEl(),
                el('input', { type: 'range', disabled: true, style: { width: '100%', accentColor: '#d82d6b' } })
            );
        }
        if (type === 'thumb') {
            return el('div', null,
                labelEl(),
                el('div', { style: { display: 'flex', gap: '16px', marginTop: '4px' } },
                    el('span', { style: { fontSize: '1.8rem', opacity: .5 } }, '👍'),
                    el('span', { style: { fontSize: '1.8rem', opacity: .5 } }, '👎')
                )
            );
        }
        if (type === 'star') {
            var maxS = field.max_stars || 5;
            return el('div', null,
                labelEl(),
                el('div', { style: { display: 'flex', gap: '2px', marginTop: '4px' } },
                    Array.from({ length: maxS }).map(function (_, i) {
                        return el('span', { key: i, style: { fontSize: '1.6rem', color: '#f5a623', lineHeight: 1 } }, '★');
                    })
                )
            );
        }
        if (type === 'matrix') {
            var mrows = field.matrix_rows    || ['Domanda 1'];
            var mcols = field.matrix_columns || ['Opzione 1', 'Opzione 2'];
            return el('div', null,
                labelEl(),
                el('div', { style: { overflowX: 'auto', marginTop: '4px' } },
                    el('table', { style: { borderCollapse: 'collapse', width: '100%', fontSize: '11px' } },
                        el('thead', null,
                            el('tr', null,
                                el('th', { style: { padding: '4px 8px', textAlign: 'left' } }, ''),
                                mcols.map(function (c, i) {
                                    return el('th', { key: i, style: { padding: '4px 8px', textAlign: 'center', color: '#999', fontWeight: 700 } }, c);
                                })
                            )
                        ),
                        el('tbody', null,
                            mrows.map(function (r, ri) {
                                return el('tr', { key: ri },
                                    el('td', { style: { padding: '4px 8px', color: '#555', fontWeight: 500 } }, r),
                                    mcols.map(function (c, ci) {
                                        return el('td', { key: ci, style: { padding: '4px 8px', textAlign: 'center' } },
                                            el('input', { type: 'radio', disabled: true, style: { accentColor: '#d82d6b' } })
                                        );
                                    })
                                );
                            })
                        )
                    )
                )
            );
        }
        // default: text / email / password / tel / number / address
        return el('div', null, labelEl(), inputEl(type === 'email' ? 'email' : 'text'));
    }

    function FieldCard(props) {
        var field   = props.field;
        var isSel   = props.selected;
        var cardRef = useRef(null);

        function handleClick(e) {
            if (e.target.tagName === 'BUTTON') return;
            var rect = cardRef.current ? cardRef.current.getBoundingClientRect() : null;
            props.onSelect(rect);
        }

        return el('div', {
            ref:  cardRef,
            style: {
                position:     'relative',
                padding:      '12px 14px 12px 22px',
                marginBottom: '6px',
                minHeight:    '90px',
                boxSizing:    'border-box',
                display:      'flex',
                flexDirection:'column',
                justifyContent: 'center',
                background:   '#fff',
                border:       isSel ? '2px solid #d82d6b' : '1px solid #e0cfd8',
                borderRadius: '4px',
                cursor:       'pointer',
                boxShadow:    isSel ? '0 0 0 3px rgba(216,45,107,.08)' : 'none',
                transition:   'border-color .12s',
            },
            draggable:   true,
            onClick:     handleClick,
            onDragStart: props.onDragStart,
            onDragOver:  function (e) { e.preventDefault(); props.onDragOver(); },
            onDragEnd:   props.onDragEnd,
        },
            // Drag handle (sinistra)
            el('span', { style: { position: 'absolute', top: '50%', left: '5px', transform: 'translateY(-50%)', color: '#ccc', fontSize: '13px', cursor: 'grab', userSelect: 'none' } }, '⠿'),

            // Azioni (destra, solo su hover via CSS non disponibile — le mostriamo sempre piccole)
            el('div', {
                onClick: function (e) { e.stopPropagation(); },
                style: { position: 'absolute', top: '6px', right: '7px', display: 'flex', gap: '3px' },
            },
                el('button', {
                    onClick: props.onDupe, title: 'Duplica',
                    style: { background: 'none', border: '1px solid #e8e0e5', borderRadius: '3px', cursor: 'pointer', color: '#bbb', fontSize: '11px', padding: '1px 6px', lineHeight: '18px' },
                }, '⎘'),
                el('button', {
                    onClick: props.onDelete, title: 'Elimina',
                    style: { background: 'none', border: '1px solid #e8e0e5', borderRadius: '3px', cursor: 'pointer', color: '#bbb', fontSize: '11px', padding: '1px 6px', lineHeight: '18px' },
                }, '✕')
            ),

            // Preview campo reale
            el('div', { style: { paddingRight: '52px', pointerEvents: 'none', userSelect: 'none' } },
                el(FieldPreview, { field: field, config: props.config || {} })
            )
        );
    }

    // -------------------------------------------------------------------------
    // SettingsPanel (sinistra)
    // -------------------------------------------------------------------------
    function SettingsPanel(props) {
        var field  = props.field;
        var config = props.config;
        var tab    = props.tab;

        return el('div', {
            className: 'if2-settings-panel',
            style: { width: '520px', flexShrink: 0, borderRight: '1px solid #e0cfd8', background: '#fff', overflowY: 'auto', display: 'flex', flexDirection: 'column' },
        },
            el('div', { className: 'if2-settings-tabs' },
                el('button', { className: 'if2-settings-tab' + (tab === 'field'  ? ' active' : ''), onClick: function () { props.onTabChange('field'); } },  'Campo'),
                el('button', { className: 'if2-settings-tab' + (tab === 'config' ? ' active' : ''), onClick: function () { props.onTabChange('config'); } }, 'Form')
            ),

            tab === 'field'
                ? (field
                    ? el(FieldSettings, { field: field, allFields: props.fields || [], onUpdate: props.onUpdate })
                    : el('p', { style: { padding: '16px', color: '#aaa', fontSize: '12px' } }, 'Seleziona un campo nel canvas.'))
                : el(ConfigSettings, { config: config, onConfig: props.onConfig })
        );
    }

    // -------------------------------------------------------------------------
    // If2DateInput — input data con datepicker jQuery UI in stile in3pida
    // Valore memorizzato in formato ISO (yyyy-mm-dd), mostrato in gg/mm/aaaa
    // -------------------------------------------------------------------------
    function _isoFromDate(d) {
        return d ? (d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2)) : '';
    }
    function If2DateInput(props) {
        var ref = useRef(null);
        useEffect(function () {
            if (!window.jQuery || !jQuery.fn.datepicker) return;
            var $i = jQuery(ref.current);
            $i.datepicker({
                dateFormat: 'dd/mm/yy',
                firstDay: 1,
                changeMonth: true,
                changeYear: true,
                showOtherMonths: true,
                selectOtherMonths: true,
                dayNamesMin:     ['Do', 'Lu', 'Ma', 'Me', 'Gi', 'Ve', 'Sa'],
                monthNames:      ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'],
                monthNamesShort: ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'],
                onSelect: function () { props.onChange(_isoFromDate($i.datepicker('getDate'))); }
            });
            if (props.value) {
                var p0 = props.value.split('-');
                if (p0.length === 3) { try { $i.datepicker('setDate', new Date(+p0[0], +p0[1] - 1, +p0[2])); } catch (e) {} }
            }
            return function () { try { $i.datepicker('destroy'); } catch (e) {} };
        }, []);
        useEffect(function () {
            if (!ref.current || !window.jQuery) return;
            var curIso = _isoFromDate(jQuery(ref.current).datepicker('getDate'));
            if (curIso === (props.value || '')) return;
            if (props.value) {
                var p = props.value.split('-');
                if (p.length === 3) { try { jQuery(ref.current).datepicker('setDate', new Date(+p[0], +p[1] - 1, +p[2])); } catch (e) {} }
            } else {
                jQuery(ref.current).val('');
            }
        }, [props.value]);
        return el('input', {
            type: 'text', ref: ref, readOnly: true,
            placeholder: props.placeholder || 'gg/mm/aaaa',
            style: Object.assign({ cursor: 'pointer', background: '#fff' }, props.style || {})
        });
    }

    // -------------------------------------------------------------------------
    // BlockedRangesEditor — gestione date chiuse per campo datepicker
    // -------------------------------------------------------------------------
    function BlockedRangesEditor(props) {
        var ranges = props.ranges || [];
        function addRange() {
            props.onChange(ranges.concat([{ from: '', to: '' }]));
        }
        function delRange(i) {
            props.onChange(ranges.filter(function (_, j) { return j !== i; }));
        }
        function updateRange(i, key, val) {
            props.onChange(ranges.map(function (r, j) {
                if (j !== i) return r;
                var o = {}; o[key] = val;
                return Object.assign({}, r, o);
            }));
        }
        return el('div', { className: 'if2-settings-row' },
            el('label', null, 'Date chiuse'),
            el('div', null,
                ranges.length === 0
                    ? el('p', { style: { fontSize: '11px', color: '#aaa', margin: '0 0 6px' } }, 'Nessun periodo chiuso.')
                    : null,
                ranges.map(function (range, i) {
                    return el('div', { key: i, style: { display: 'flex', gap: '4px', alignItems: 'center', marginBottom: '6px' } },
                        el(If2DateInput, {
                            value: range.from || '',
                            style: { flex: 1, fontSize: '11px', padding: '4px 6px', border: '1px solid #e0cfd8', borderRadius: '3px' },
                            onChange: function (v) { updateRange(i, 'from', v); }
                        }),
                        el('span', { style: { color: '#aaa', fontSize: '11px', flexShrink: 0 } }, '→'),
                        el(If2DateInput, {
                            value: range.to || '',
                            style: { flex: 1, fontSize: '11px', padding: '4px 6px', border: '1px solid #e0cfd8', borderRadius: '3px' },
                            onChange: function (v) { updateRange(i, 'to', v); }
                        }),
                        el('button', {
                            onClick: function () { delRange(i); },
                            style: { background: 'none', border: 'none', cursor: 'pointer', color: '#d82d6b', fontSize: '15px', padding: '0 3px', lineHeight: 1, flexShrink: 0 }
                        }, '✕')
                    );
                }),
                el('button', {
                    onClick: addRange,
                    style: { fontSize: '11px', color: '#009bb9', background: 'none', border: '1px solid #009bb9', borderRadius: '3px', padding: '4px 10px', cursor: 'pointer', marginTop: '2px' }
                }, '+ Aggiungi periodo chiuso')
            )
        );
    }

    // -------------------------------------------------------------------------
    // MinStayEditor — minimum stay per data di arrivo (campo datepicker)
    // -------------------------------------------------------------------------
    function MinStayEditor(props) {
        var rules = props.rules || [];
        function addRule() { props.onChange(rules.concat([{ date: '', nights: '' }])); }
        function delRule(i) { props.onChange(rules.filter(function (_, j) { return j !== i; })); }
        function updateRule(i, key, val) {
            props.onChange(rules.map(function (r, j) {
                if (j !== i) return r;
                var o = {}; o[key] = val;
                return Object.assign({}, r, o);
            }));
        }
        return el('div', { className: 'if2-settings-row' },
            el('label', null, 'Minimum stay'),
            el('div', null,
                rules.length === 0
                    ? el('p', { style: { fontSize: '11px', color: '#aaa', margin: '0 0 6px' } }, 'Nessun minimum stay.')
                    : null,
                rules.map(function (rule, i) {
                    return el('div', { key: i, style: { display: 'flex', gap: '4px', alignItems: 'center', marginBottom: '6px' } },
                        el(If2DateInput, {
                            value: rule.date || '',
                            style: { flex: 1, fontSize: '11px', padding: '4px 6px', border: '1px solid #e0cfd8', borderRadius: '3px' },
                            onChange: function (v) { updateRule(i, 'date', v); }
                        }),
                        el('input', {
                            type: 'number', min: 1, value: rule.nights || '', placeholder: 'notti',
                            style: { width: '66px', fontSize: '11px', padding: '4px 6px', border: '1px solid #e0cfd8', borderRadius: '3px' },
                            onChange: function (e) { updateRule(i, 'nights', e.target.value === '' ? '' : parseInt(e.target.value, 10)); }
                        }),
                        el('button', {
                            onClick: function () { delRule(i); },
                            style: { background: 'none', border: 'none', cursor: 'pointer', color: '#d82d6b', fontSize: '15px', padding: '0 3px', lineHeight: 1, flexShrink: 0 }
                        }, '✕')
                    );
                }),
                el('button', {
                    onClick: addRule,
                    style: { fontSize: '11px', color: '#009bb9', background: 'none', border: '1px solid #009bb9', borderRadius: '3px', padding: '4px 10px', cursor: 'pointer', marginTop: '2px' }
                }, '+ Aggiungi minimum stay')
            )
        );
    }

    // -------------------------------------------------------------------------
    // FieldSettings — impostazioni per tipo campo (stile FormCraft)
    // -------------------------------------------------------------------------
    function FieldSettings(props) {
        var field     = props.field;
        var up        = props.onUpdate;
        var allFields = props.allFields || [];

        function row(labelText, children, desc) {
            return el('div', { className: 'if2-settings-row' },
                el('label', null, labelText),
                children,
                desc ? el('small', { style: { display: 'block', color: '#aaa', fontSize: '10px', marginTop: '2px', lineHeight: 1.4 } }, desc) : null
            );
        }
        function txt(prop, ph, type) {
            return el('input', { type: type || 'text', value: field[prop] || '', placeholder: ph || '',
                onChange: function (e) { var o = {}; o[prop] = e.target.value; up(o); } });
        }
        function chk(prop, lbl) {
            return el('label', { style: { display: 'flex', gap: '6px', alignItems: 'center', fontSize: '12px', cursor: 'pointer', fontWeight: 400, letterSpacing: 0, textTransform: 'none' } },
                el('input', { type: 'checkbox', checked: !!field[prop],
                    onChange: function (e) { var o = {}; o[prop] = e.target.checked; up(o); } }),
                lbl
            );
        }
        function num(prop, ph, min, max) {
            return el('input', { type: 'number', value: field[prop] !== undefined ? field[prop] : '', placeholder: ph || '', min: min, max: max,
                onChange: function (e) { var o = {}; o[prop] = e.target.value === '' ? '' : parseInt(e.target.value, 10); up(o); } });
        }
        function sel(prop, options) {
            return el('select', { value: field[prop] || '', style: { width: '100%' },
                onChange: function (e) { var o = {}; o[prop] = e.target.value; up(o); } },
                options.map(function (opt) { return el('option', { key: opt.value, value: opt.value }, opt.label); })
            );
        }
        function colWidth() {
            return row('Larghezza colonna',
                el('div', { style: { display: 'flex', gap: '4px', flexWrap: 'wrap', alignItems: 'center' } },
                    ['100%','75%','66.6%','50%','33.3%','25%'].map(function (w) {
                        var active = (field.col_width || '100%') === w;
                        return el('button', { key: w,
                            onClick: function () { up({ col_width: w }); },
                            style: { fontSize: '10px', padding: '2px 7px', border: '1px solid ' + (active ? '#d82d6b' : '#ccc'), borderRadius: '3px', background: active ? '#d82d6b' : '#fff', color: active ? '#fff' : '#555', cursor: 'pointer', fontWeight: active ? 700 : 400 }
                        }, w);
                    }),
                    el('input', { type: 'text', value: field.col_width || '100%', placeholder: '100%',
                        style: { width: '65px', fontSize: '11px' },
                        onChange: function (e) { up({ col_width: e.target.value }); }
                    })
                ),
                'Larghezza campo nel form (es: 50% per 2 colonne)'
            );
        }

        var rows = [];

        // ==================== HEADING ====================
        if (field.type === 'heading') {
            rows.push(row('Testo heading', txt('content', 'Titolo sezione')));
            rows.push(colWidth());
            rows.push(row('Alt Label',     txt('alt_label', 'Etichetta alternativa')));
            rows.push(row('Formato',       sel('heading_size', [
                { value: 'h1', label: 'H1 — Grande' },
                { value: 'h2', label: 'H2' },
                { value: 'h3', label: 'H3 (default)' },
                { value: 'h4', label: 'H4' },
                { value: 'h5', label: 'H5' },
                { value: 'h6', label: 'H6 — Piccolo' },
            ])));
            rows.push(row('Peso',          sel('heading_weight', [
                { value: '',     label: 'Default' },
                { value: '400',  label: 'Normal (400)' },
                { value: '600',  label: 'Semi-bold (600)' },
                { value: '700',  label: 'Bold (700)' },
            ])));
            rows.push(row('Allineamento',  sel('heading_align', [
                { value: 'left',   label: 'Sinistra' },
                { value: 'center', label: 'Centro' },
                { value: 'right',  label: 'Destra' },
            ])));
            rows.push(row('Colore testo',  el('input', { type: 'color', value: field.heading_color || '#181834',
                onChange: function (e) { up({ heading_color: e.target.value }); },
                style: { width: '100%', height: '32px', cursor: 'pointer' } })));
            rows.push(row('Colore sfondo', el('input', { type: 'color', value: field.heading_bg || '#ffffff',
                onChange: function (e) { up({ heading_bg: e.target.value }); },
                style: { width: '100%', height: '32px', cursor: 'pointer' } })));
            rows.push(row('Padding top',    txt('padding_top',    '0px')));
            rows.push(row('Padding bottom', txt('padding_bottom', '0px')));
            rows.push(row('Nascondi al caricamento', chk('hidden_default', 'Nascondi campo al caricamento pagina')));
            return el('div', null, rows);
        }

        // ==================== SUBMIT ====================
        if (field.type === 'submit') {
            rows.push(row('Label pulsante', txt('label', 'Invia')));
            rows.push(colWidth());
            rows.push(row('Allineamento', sel('submit_align', [
                { value: 'left',   label: 'Sinistra' },
                { value: 'center', label: 'Centro (default)' },
                { value: 'right',  label: 'Destra' },
            ])));
            rows.push(row('Pulsante largo', chk('submit_wide', 'Larghezza 100% del form')));
            rows.push(row('Nascondi al caricamento', chk('hidden_default', 'Nascondi campo al caricamento pagina')));
            return el('div', null, rows);
        }

        // ==================== HTML / CUSTOM TEXT ====================
        if (field.type === 'html') {
            rows.push(row('Contenuto HTML',
                el('textarea', { rows: 6, value: field.content || '', style: { width: '100%', fontFamily: 'monospace', fontSize: '11px' },
                    onChange: function (e) { up({ content: e.target.value }); } })
            ));
            rows.push(colWidth());
            rows.push(row('Alt Label',     txt('alt_label', 'Etichetta alternativa')));
            rows.push(row('Colore testo',  el('input', { type: 'color', value: field.html_color || '#333333',
                onChange: function (e) { up({ html_color: e.target.value }); },
                style: { width: '100%', height: '32px', cursor: 'pointer' } })));
            rows.push(row('Colore sfondo', el('input', { type: 'color', value: field.html_bg || '#ffffff',
                onChange: function (e) { up({ html_bg: e.target.value }); },
                style: { width: '100%', height: '32px', cursor: 'pointer' } })));
            rows.push(row('Posizione', sel('html_position', [
                { value: '',       label: 'Default' },
                { value: 'top',    label: 'Top' },
                { value: 'right',  label: 'Right' },
                { value: 'bottom', label: 'Bottom' },
                { value: 'left',   label: 'Left' },
            ])));
            rows.push(row('Nascondi al caricamento', chk('hidden_default', 'Nascondi campo al caricamento pagina')));
            return el('div', null, rows);
        }

        // ==================== PAGE BREAK ====================
        if (field.type === 'page_break') {
            return el('div', { style: { padding: '16px', color: '#aaa', fontSize: '12px' } }, 'Separatore di pagina — nessuna impostazione.');
        }

        // ==================== COMMON FIELDS ====================
        // Label | Sub Label | Col Width — sulla stessa riga (stile FormCraft)
        rows.push(el('div', { key: 'top3', style: { padding: '10px 14px', borderBottom: '1px solid #f0f0f0', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px', alignItems: 'start' } },
            el('div', null,
                el('label', { style: { display: 'block', fontSize: '10px', fontWeight: 700, color: '#666', textTransform: 'uppercase', letterSpacing: '.04em', marginBottom: '5px' } }, 'Label'),
                el('input', { type: 'text', value: field.label || '', placeholder: 'Etichetta',
                    style: { width: '100%', padding: '5px 8px', border: '1px solid #ddd', borderRadius: '3px', fontSize: '12px', boxSizing: 'border-box' },
                    onChange: function (e) { up({ label: e.target.value }); } })
            ),
            el('div', null,
                el('label', { style: { display: 'block', fontSize: '10px', fontWeight: 700, color: '#666', textTransform: 'uppercase', letterSpacing: '.04em', marginBottom: '5px' } }, 'Sub Label'),
                el('input', { type: 'text', value: field.sub_label || '', placeholder: 'Sotto il titolo',
                    style: { width: '100%', padding: '5px 8px', border: '1px solid #ddd', borderRadius: '3px', fontSize: '12px', boxSizing: 'border-box' },
                    onChange: function (e) { up({ sub_label: e.target.value }); } })
            ),
            el('div', null,
                el('label', { style: { display: 'block', fontSize: '10px', fontWeight: 700, color: '#666', textTransform: 'uppercase', letterSpacing: '.04em', marginBottom: '5px' } }, 'Col Width'),
                el('div', { style: { display: 'flex', alignItems: 'center', gap: '6px' } },
                    el('input', { type: 'range', min: 10, max: 100, step: 1,
                        value: parseFloat(field.col_width || '100') || 100,
                        style: { flex: 1, accentColor: '#d82d6b', cursor: 'pointer', minWidth: 0 },
                        onChange: function (e) { up({ col_width: e.target.value + '%' }); }
                    }),
                    el('span', { style: { fontSize: '11px', fontWeight: 700, color: '#d82d6b', minWidth: '38px', textAlign: 'right', flexShrink: 0 } },
                        (parseFloat(field.col_width || '100') || 100) + '%'
                    )
                )
            )
        ));
        rows.push(row('Istruzione',  txt('instruction', 'Testo di aiuto sotto il campo')));
        rows.push(row('Alt Label',   txt('alt_label', 'Nome tecnico del campo (chiave per webhook, email, Supabase)')));

        if (field.type !== 'hidden') {
            rows.push(row('Placeholder', txt('placeholder', 'Testo segnaposto')));
        }

        // ==================== DATE ====================
        if (field.type === 'date') {
            rows.push(row('Formato', sel('date_format', [
                { value: 'dd/mm/yy', label: 'GG/MM/AAAA (default)' },
                { value: 'mm/dd/yy', label: 'MM/GG/AAAA' },
                { value: 'yy-mm-dd', label: 'AAAA-MM-GG' },
                { value: 'd M yy',   label: 'G Mese AAAA' },
                { value: 'M d yy',   label: 'Mese G AAAA' },
            ])));
            rows.push(row('Data minima',        el(If2DateInput, { value: field.date_min || '', style: { width: '100%' },
                onChange: function (v) { up({ date_min: v }); } })));
            rows.push(row('Data massima',       el(If2DateInput, { value: field.date_max || '', style: { width: '100%' },
                onChange: function (v) { up({ date_max: v }); } })));
            rows.push(row('Data min. da campo', txt('date_min_field', 'ID campo data (es: field_abc)'), 'Rende la data minima uguale al valore di un altro campo data'));
            // Days allowed — 7 checkboxes
            var dayNames = ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'];
            var daysAllowed = field.days_allowed || [true, true, true, true, true, true, true];
            rows.push(el('div', { key: 'days', className: 'if2-settings-row' },
                el('label', null, 'Giorni disponibili'),
                el('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap' } },
                    dayNames.map(function (d, i) {
                        return el('label', { key: i, style: { display: 'flex', gap: '3px', alignItems: 'center', fontSize: '11px', cursor: 'pointer', minWidth: '40px' } },
                            el('input', { type: 'checkbox', checked: daysAllowed[i] !== false,
                                onChange: function (e) {
                                    var arr = daysAllowed.slice();
                                    arr[i] = e.target.checked;
                                    up({ days_allowed: arr });
                                }
                            }),
                            d
                        );
                    })
                )
            ));
            rows.push(row('Nessuna data passata', chk('date_no_past', 'Blocca date precedenti a oggi')));
            // Blocked ranges (already implemented)
            if ((IF2Builder.features || {}).date_chiuse !== false) {
                rows.push(el(BlockedRangesEditor, {
                    key: 'blocked',
                    ranges: field.blocked_ranges || [],
                    onChange: function (ranges) { up({ blocked_ranges: ranges }); }
                }));
            }
            // Minimum stay per data di arrivo
            if ((IF2Builder.features || {}).minimum_stay !== false) {
                rows.push(el(MinStayEditor, {
                    key: 'minstay',
                    rules: field.min_stay_rules || [],
                    onChange: function (rules) { up({ min_stay_rules: rules }); }
                }));
                rows.push(el('small', { key: 'minstay-help', style: { display: 'block', color: '#aaa', fontSize: '10px', marginTop: '-2px', lineHeight: 1.4 } },
                    'Per ogni data di arrivo impone un numero minimo di notti. Funziona se un altro campo data (es. partenza) usa questo come "Data min. da campo".'));
            }
        }

        // ==================== TEXT (oneLineText) ====================
        if (field.type === 'text') {
            rows.push(row('Icona campo', txt('field_icon', 'es: ✉ o URL immagine')));
            rows.push(row('Input Mask', txt('input_mask', 'es: (000) 000-0000')));
            rows.push(row('Mask Placeholder', txt('mask_placeholder', 'es: (___) ___-____')));
            rows.push(row('Validazione', sel('validation_type', [
                { value: '',            label: 'Nessuna' },
                { value: 'alpha',       label: 'Solo lettere' },
                { value: 'numeric',     label: 'Solo numeri' },
                { value: 'alphanumeric',label: 'Lettere e numeri' },
                { value: 'url',         label: 'URL' },
                { value: 'regex',       label: 'RegEx personalizzato' },
            ])));
            if (field.validation_type === 'regex') {
                rows.push(row('RegEx', txt('validation_regex', '^[a-z]+$')));
            }
            rows.push(row('Min caratteri', num('min_chars', '0', 0)));
            rows.push(row('Max caratteri', num('max_chars', '—', 0)));
            rows.push(row('Spazi consentiti', chk('allow_spaces', 'Permetti spazi nel campo')));
            rows.push(row('Read Only',        chk('readonly',     'Campo sola lettura')));
        }

        // ==================== PHONE ====================
        if (field.type === 'phone') {
            rows.push(row('Input Mask', txt('input_mask', 'es: 000 000 0000')));
            rows.push(row('Min caratteri', num('min_chars', '0', 0)));
            rows.push(row('Max caratteri', num('max_chars', '—', 0)));
        }

        // ==================== EMAIL ====================
        if (field.type === 'email') {
            rows.push(row('Imposta come Reply-To', chk('set_reply_to',     'Usa questa email come Reply-To nelle notifiche')));
            rows.push(row('Invia autoresponder',   chk('set_autoresponder','Invia conferma automatica a questa email')));
            rows.push(row('Read Only',             chk('readonly',         'Campo sola lettura')));
        }

        // ==================== PASSWORD ====================
        if (field.type === 'password') {
            rows.push(row('Validazione', sel('validation_type', [
                { value: '',            label: 'Nessuna' },
                { value: 'alpha',       label: 'Solo lettere' },
                { value: 'numeric',     label: 'Solo numeri' },
                { value: 'alphanumeric',label: 'Lettere e numeri' },
                { value: 'regex',       label: 'RegEx personalizzato' },
            ])));
            if (field.validation_type === 'regex') {
                rows.push(row('RegEx', txt('validation_regex', '^[a-z]+$')));
            }
            rows.push(row('Min caratteri', num('min_chars', '0', 0)));
            rows.push(row('Max caratteri', num('max_chars', '—', 0)));
        }

        // ==================== TEXTAREA ====================
        if (field.type === 'textarea') {
            rows.push(row('Righe',         num('rows', '4', 2, 20)));
            rows.push(row('Min caratteri', num('min_chars', '0', 0)));
            rows.push(row('Max caratteri', num('max_chars', '—', 0)));
            rows.push(row('Mostra contatore', chk('show_char_count', 'Mostra contatore caratteri')));
        }

        // ==================== CHECKBOX ====================
        if (field.type === 'checkbox') {
            rows.push(el(OptionsEditor, { key: 'opts', options: field.options || [], onChange: function (opts) { up({ options: opts }); } }));
            rows.push(row('Larghezza opzione', txt('option_width', '100%'), 'Larghezza di ogni opzione (es: 50%)'));
            rows.push(row('Selezione multipla', chk('allow_multiple', 'Permetti selezione di più opzioni')));
            rows.push(row('Amelia Consenso', chk('amelia_consent', 'Consenso marketing per Amelia/SMSHosting'), 'Segna questo checkbox come consenso marketing: se spuntato, il contatto verrà aggiunto alla lista Amelia/SMSHosting'));
        }

        // ==================== SELECT / DROPDOWN ====================
        if (field.type === 'select') {
            rows.push(el(OptionsEditor, { key: 'opts', options: field.options || [], onChange: function (opts) { up({ options: opts }); } }));
            rows.push(row('Autocomplete', sel('autocomplete', [
                { value: '',    label: 'Default browser' },
                { value: 'on',  label: 'On' },
                { value: 'off', label: 'Off' },
            ])));
        }

        // ==================== RADIO ====================
        if (field.type === 'radio') {
            rows.push(el(OptionsEditor, { key: 'opts', options: field.options || [], onChange: function (opts) { up({ options: opts }); } }));
            rows.push(row('Larghezza opzione', txt('option_width', '100%'), 'Larghezza di ogni opzione (es: 50%)'));
        }

        // ==================== FILE ====================
        if (field.type === 'file') {
            rows.push(row('Label pulsante',   txt('button_label', 'Scegli file')));
            rows.push(row('Tipi accettati',   txt('accept', 'image/*, .pdf')));
            rows.push(row('Max size (MB)',     num('max_size_mb', '5', 1, 50)));
            rows.push(row('File minimi',       num('min_files', '1', 1)));
            rows.push(row('File massimi',      num('max_files', '5', 1)));
            rows.push(row('Multiplo',          chk('multiple', 'Permetti più file')));
        }

        // ==================== SLIDER ====================
        if (field.type === 'slider') {
            rows.push(row('Valore minimo',  num('range_min', '0')));
            rows.push(row('Valore massimo', num('range_max', '100')));
            rows.push(row('Step',           num('range_step', '1', 1)));
            rows.push(row('Prefisso',       txt('prefix', '')));
            rows.push(row('Suffisso',       txt('suffix', '')));
        }

        // ==================== TIME ====================
        if (field.type === 'time') {
            rows.push(row('Ora minima',  num('hrs_min', '0', 0, 23)));
            rows.push(row('Ora massima', num('hrs_max', '23', 0, 23)));
            rows.push(row('Step ore',    num('hrs_step', '1', 1)));
            rows.push(row('Step minuti', num('minute_step', '15', 1)));
            rows.push(row('Formato 24h', chk('format_24', 'Usa formato 24 ore')));
        }

        // ==================== STAR ====================
        if (field.type === 'star') {
            rows.push(row('Numero stelle', num('max_stars', '5', 3, 10)));
        }

        // ==================== MATRIX ====================
        if (field.type === 'matrix') {
            rows.push(el('div', { key: 'matrix-rows', className: 'if2-settings-row' },
                el('label', null, 'Righe (una per riga)'),
                el('textarea', { rows: 4, value: (field.matrix_rows || []).join('\n'), style: { width: '100%' },
                    onChange: function (e) {
                        var r = e.target.value.split('\n').map(function (s) { return s.trim(); }).filter(Boolean);
                        up({ matrix_rows: r.length ? r : ['Domanda 1'] });
                    }
                })
            ));
            rows.push(el('div', { key: 'matrix-cols', className: 'if2-settings-row' },
                el('label', null, 'Colonne (una per riga)'),
                el('textarea', { rows: 4, value: (field.matrix_columns || []).join('\n'), style: { width: '100%' },
                    onChange: function (e) {
                        var c = e.target.value.split('\n').map(function (s) { return s.trim(); }).filter(Boolean);
                        up({ matrix_columns: c.length ? c : ['Opzione 1'] });
                    }
                })
            ));
        }

        // ==================== HIDDEN ====================
        if (field.type === 'hidden') {
            rows.push(row('Valore fisso', txt('value', 'Valore')));
        }

        // ==================== AMELIA: telefono + nome (tutti i campi input tranne checkbox e strutturali) ====================
        var noAmeliaPhone = ['checkbox', 'submit', 'heading', 'html', 'page_break', 'hidden', 'custom_text', 'customtext'];
        if (noAmeliaPhone.indexOf(field.type) === -1) {
            rows.push(row('Amelia Telefono', chk('amelia_phone', 'Questo campo contiene il numero di telefono per Amelia/SMSHosting'), 'Il valore di questo campo verrà inviato come "phone" alla lista Amelia/SMSHosting'));
            rows.push(row('Amelia Nome', chk('amelia_name', 'Questo campo contiene il nome (e cognome) per Amelia/SMSHosting'), 'Il valore verrà inviato come firstName (e lastName se separato da spazio) alla lista Amelia/SMSHosting'));
        }

        // ==================== COMMON BOTTOM: required, readonly (where applicable), hidden_default ====================
        var noRequired = ['heading', 'html', 'submit', 'page_break', 'hidden'];
        if (noRequired.indexOf(field.type) === -1) {
            rows.push(row('Obbligatorio', chk('required', 'Campo obbligatorio')));
        }

        var noHide = ['page_break', 'hidden'];
        if (noHide.indexOf(field.type) === -1) {
            rows.push(row('Nascondi al caricamento', chk('hidden_default', 'Nascondi campo al caricamento pagina')));
        }

        // Conditional logic (skip for page_break, hidden)
        var noConditions = ['page_break', 'hidden'];
        if (noConditions.indexOf(field.type) === -1) {
            rows.push(el(ConditionsEditor, {
                key:        'cond',
                conditions: field.conditions,
                allFields:  allFields.filter(function (f) { return f.id !== field.id; }),
                onChange:   function (cond) { up({ conditions: cond }); },
            }));
        }

        return el('div', null, rows);
    }

    // -------------------------------------------------------------------------
    // OptionsEditor
    // -------------------------------------------------------------------------
    function OptionsEditor(props) {
        var opts = props.options;
        return el('div', { className: 'if2-settings-row' },
            el('label', null, 'Opzioni'),
            el('div', { className: 'if2-option-list' },
                opts.map(function (opt, idx) {
                    return el('div', { key: idx, className: 'if2-option-row' },
                        el('input', { type: 'text', value: opt.label,
                            onChange: function (e) {
                                var newLabel = e.target.value;
                                var next = opts.map(function (o, i) {
                                    if (i !== idx) return o;
                                    // Sincronizza value con label se value era vuoto o uguale al vecchio label
                                    var newVal = (o.value === '' || o.value === o.label) ? newLabel : o.value;
                                    return Object.assign({}, o, { label: newLabel, value: newVal });
                                });
                                props.onChange(next);
                            }, placeholder: 'Etichetta' }),
                        el('button', { onClick: function () { props.onChange(opts.filter(function (_, i) { return i !== idx; })); }, title: 'Rimuovi' }, '✕')
                    );
                })
            ),
            el('button', { className: 'button', onClick: function () { props.onChange(opts.concat([{ label: 'Nuova opzione', value: 'Nuova opzione' }])); } }, '+ Opzione')
        );
    }

    // -------------------------------------------------------------------------
    // ConditionsEditor
    // -------------------------------------------------------------------------
    function ConditionsEditor(props) {
        var cond      = props.conditions || null;
        var allFields = props.allFields;

        if (!cond) {
            return el('div', { className: 'if2-settings-row' },
                el('label', null, 'Logica condizionale'),
                el('button', { className: 'button',
                    onClick: function () { props.onChange({ logic: 'AND', rules: [{ field: '', operator: '=', value: '' }] }); }
                }, '+ Condizione')
            );
        }

        return el('div', { className: 'if2-settings-row' },
            el('label', null, 'Logica condizionale'),
            el('div', { style: { display: 'flex', gap: '6px', alignItems: 'center', marginBottom: '6px' } },
                el('span', { style: { fontSize: '11px' } }, 'Mostra se'),
                el('select', { value: cond.logic, onChange: function (e) { props.onChange(Object.assign({}, cond, { logic: e.target.value })); }, style: { fontSize: '11px', padding: '2px 5px' } },
                    el('option', { value: 'AND' }, 'TUTTE'),
                    el('option', { value: 'OR' },  'UNA QUALSIASI')
                ),
                el('button', { onClick: function () { props.onChange(null); }, style: { marginLeft: 'auto', fontSize: '11px', background: 'none', border: 'none', cursor: 'pointer', color: '#aaa' } }, 'Rimuovi')
            ),
            el('div', { className: 'if2-conditions-list' },
                cond.rules.map(function (rule, idx) {
                    return el('div', { key: idx, className: 'if2-condition-row' },
                        el('select', { value: rule.field, onChange: function (e) {
                            var rules = cond.rules.map(function (r, i) { return i === idx ? Object.assign({}, r, { field: e.target.value }) : r; });
                            props.onChange(Object.assign({}, cond, { rules: rules }));
                        }},
                            el('option', { value: '' }, '— Campo —'),
                            allFields.map(function (f) { return el('option', { key: f.id, value: f.id }, f.label || f.id); })
                        ),
                        el('select', { value: rule.operator, onChange: function (e) {
                            var rules = cond.rules.map(function (r, i) { return i === idx ? Object.assign({}, r, { operator: e.target.value }) : r; });
                            props.onChange(Object.assign({}, cond, { rules: rules }));
                        }},
                            el('option', { value: '=' }, '='),
                            el('option', { value: '!=' }, '≠'),
                            el('option', { value: 'contains' }, 'contiene'),
                            el('option', { value: 'not_empty' }, 'non è vuoto')
                        ),
                        rule.operator !== 'not_empty'
                            ? el('input', { type: 'text', value: rule.value || '', placeholder: 'Valore',
                                onChange: function (e) {
                                    var rules = cond.rules.map(function (r, i) { return i === idx ? Object.assign({}, r, { value: e.target.value }) : r; });
                                    props.onChange(Object.assign({}, cond, { rules: rules }));
                                }})
                            : null,
                        el('button', { onClick: function () {
                            var rules = cond.rules.filter(function (_, i) { return i !== idx; });
                            if (!rules.length) { props.onChange(null); return; }
                            props.onChange(Object.assign({}, cond, { rules: rules }));
                        }, title: 'Rimuovi' }, '✕')
                    );
                })
            ),
            el('button', { className: 'button',
                onClick: function () {
                    var rules = cond.rules.concat([{ field: '', operator: '=', value: '' }]);
                    props.onChange(Object.assign({}, cond, { rules: rules }));
                },
                style: { fontSize: '11px' }
            }, '+ Regola')
        );
    }

    // -------------------------------------------------------------------------
    // RichEditor — editor rich-text senza build step (contentEditable + execCommand)
    // -------------------------------------------------------------------------
    function RichEditor(props) {
        var vizRef    = useRef(null);   // ref del contentEditable
        var taRef     = useRef(null);   // ref del textarea HTML
        var htmlCache = useRef(props.value || '');
        var initDone  = useRef(false);
        var _hm = useState(false);
        var htmlMode = _hm[0]; var setHtmlMode = _hm[1];
        var fields = props.fields || [];

        useEffect(function() {
            if (!htmlMode && vizRef.current && !initDone.current) {
                vizRef.current.innerHTML = htmlCache.current;
                initDone.current = true;
            }
            if (htmlMode && taRef.current) {
                taRef.current.value = htmlCache.current;
            }
        });

        function exec(cmd, val) {
            if (vizRef.current) vizRef.current.focus();
            document.execCommand(cmd, false, val || null);
        }
        function onVisualBlur() {
            if (vizRef.current) {
                htmlCache.current = vizRef.current.innerHTML;
                if (props.onChange) props.onChange(htmlCache.current);
            }
        }
        function switchToHtml() {
            if (vizRef.current) htmlCache.current = vizRef.current.innerHTML;
            setHtmlMode(true);
        }
        function switchToVisual() {
            if (taRef.current) {
                htmlCache.current = taRef.current.value;
                if (props.onChange) props.onChange(htmlCache.current);
            }
            initDone.current = false;
            setHtmlMode(false);
        }
        function insertTag(tag) {
            if (!vizRef.current) return;
            vizRef.current.focus();
            document.execCommand('insertHTML', false, tag);
        }

        var SEP = el('span', { style: { width: '1px', background: '#ddd', alignSelf: 'stretch', margin: '1px 4px' } });
        var TBS = { background: 'none', border: '1px solid #e0cfd8', borderRadius: '3px', cursor: 'pointer', padding: '3px 8px', fontSize: '12px', fontWeight: 700, color: '#555', fontFamily: 'inherit', lineHeight: '1.4', margin: '0 1px' };
        function tb(label, cmd, val, title) {
            return el('button', { key: label, type: 'button', title: title || label, style: TBS,
                onMouseDown: function(e) { e.preventDefault(); exec(cmd, val); }
            }, label);
        }

        var staticFields = [
            { id: 'all_fields', label: 'Tutti i campi' },
            { id: 'date',       label: 'Data invio' },
            { id: 'form_name',  label: 'Nome form' },
            { id: 'ip',         label: 'IP utente' },
        ];
        var fieldOptions = staticFields.concat(
            fields.filter(function(f) { return ['heading','html','submit'].indexOf(f.type) === -1; })
                  .map(function(f) { return { id: f.id, label: f.label || f.type }; })
        );

        var toolbar = el('div', { style: { background: '#f7f3f5', borderBottom: '1px solid #e0cfd8', padding: '5px 7px', display: 'flex', flexWrap: 'wrap', gap: '2px', alignItems: 'center' } },
            el('select', {
                title: 'Stile paragrafo',
                style: { border: '1px solid #e0cfd8', borderRadius: '3px', fontSize: '12px', padding: '3px 5px', cursor: 'pointer', marginRight: '3px', background: '#fff' },
                onChange: function(e) { if (e.target.value) { exec('formatBlock', e.target.value); e.target.value = ''; } }
            },
                el('option', { value: '' }, 'Titolo'),
                el('option', { value: 'h1' }, 'H1'),
                el('option', { value: 'h2' }, 'H2'),
                el('option', { value: 'h3' }, 'H3'),
                el('option', { value: 'p' },  'P — Paragrafo')
            ),
            SEP,
            tb('G', 'bold', null, 'Grassetto'),
            tb('C', 'italic', null, 'Corsivo'),
            tb('S', 'underline', null, 'Sottolineato'),
            SEP,
            tb('← Sx', 'justifyLeft',   null, 'Allinea a sinistra'),
            tb('Cx',   'justifyCenter', null, 'Centra testo'),
            tb('Dx →', 'justifyRight',  null, 'Allinea a destra'),
            SEP,
            tb('• Lista', 'insertUnorderedList', null, 'Lista puntata'),
            tb('1. Lista', 'insertOrderedList',  null, 'Lista numerata'),
            SEP,
            el('select', {
                key: 'insert-campo',
                title: 'Inserisci tag campo nel testo',
                style: { border: '1px solid #009bb9', borderRadius: '3px', fontSize: '11px', padding: '3px 5px', cursor: 'pointer', background: '#fff', color: '#009bb9', fontWeight: 700 },
                onChange: function(e) {
                    if (!e.target.value || htmlMode) return;
                    var tag = '{' + e.target.value + '}';
                    e.target.value = '';
                    setTimeout(function() { insertTag(tag); }, 0);
                }
            },
                el('option', { value: '' }, '{ } Inserisci campo'),
                fieldOptions.map(function(f) {
                    return el('option', { key: f.id, value: f.id }, '{' + f.id + '} — ' + f.label);
                })
            ),
            el('button', {
                key: 'html-toggle', type: 'button',
                title: htmlMode ? 'Torna alla vista visuale' : 'Modifica sorgente HTML',
                style: { marginLeft: '4px', background: htmlMode ? '#d82d6b' : 'none', color: htmlMode ? '#fff' : '#888',
                         border: '1px solid ' + (htmlMode ? '#d82d6b' : '#ddd'), borderRadius: '3px',
                         cursor: 'pointer', padding: '3px 8px', fontSize: '11px', fontWeight: 700, fontFamily: 'inherit' },
                onClick: htmlMode ? switchToVisual : switchToHtml
            }, '< > HTML')
        );

        return el('div', { style: { border: '1px solid #e0cfd8', borderRadius: '4px', overflow: 'hidden', background: '#fff' } },
            toolbar,
            htmlMode
                ? el('textarea', {
                    ref: taRef,
                    style: { width: '100%', minHeight: '120px', padding: '10px 12px', fontSize: '11px', fontFamily: 'monospace', border: 'none', outline: 'none', resize: 'vertical', lineHeight: 1.6, display: 'block' },
                    onChange: function(e) {
                        htmlCache.current = e.target.value;
                        if (props.onChange) props.onChange(e.target.value);
                    }
                  })
                : el('div', {
                    ref: vizRef,
                    contentEditable: true,
                    suppressContentEditableWarning: true,
                    style: { minHeight: '120px', padding: '10px 12px', fontSize: '12px', fontFamily: 'inherit', outline: 'none', lineHeight: 1.6 },
                    onBlur: onVisualBlur
                  })
        );
    }

    // -------------------------------------------------------------------------
    // ConfigSettings — 6 tab identici al v1
    // -------------------------------------------------------------------------
    function ConfigSettings(props) {
        var c      = props.config;
        var up     = props.onConfig;
        var formId = props.formId;

        var _t = useState('general');
        var activeTab = _t[0]; var setActiveTab = _t[1];

        var _os = useState(null);
        var openSection = _os[0]; var setOpenSection = _os[1];

        var _te = useState('');
        var testEmailTo = _te[0]; var setTestEmailTo = _te[1];
        var _ts = useState('');
        var testEmailStatus = _ts[0]; var setTestEmailStatus = _ts[1];

        function sendTestEmail() {
            if (!testEmailTo) return;
            setTestEmailStatus('…');
            var fd = new FormData();
            fd.set('action', 'if2_send_test_email');
            fd.set('nonce', IF2Builder.nonce);
            fd.set('to', testEmailTo);
            fd.set('form_id', formId || 0);
            fetch(IF2Builder.ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' })
                .then(function(r) { return r.json(); })
                .then(function(json) {
                    setTestEmailStatus(json.success ? '✓ Inviata' : '✗ ' + ((json.data && json.data.message) || 'Errore'));
                    setTimeout(function() { setTestEmailStatus(''); }, 3500);
                })
                .catch(function() {
                    setTestEmailStatus('✗ Errore');
                    setTimeout(function() { setTestEmailStatus(''); }, 3500);
                });
        }

        var TABS = [
            { key: 'general',     label: t('tab_general') },
            { key: 'email',       label: t('tab_email') },
            { key: 'embed',       label: t('tab_embed') },
            { key: 'custom_text', label: t('tab_custom') },
            { key: 'advanced',    label: t('tab_advanced') },
            { key: 'in3pida',     label: t('tab_in3pida') },
            { key: 'crm',         label: 'CRM' },
        ];

        function row(lbl, children, desc) {
            return el('div', { className: 'if2-settings-row' },
                el('label', null, lbl),
                children,
                desc ? el('small', { style: { display: 'block', color: '#aaa', fontSize: '10px', marginTop: '3px', lineHeight: 1.4 } }, desc) : null
            );
        }
        function txt(key, ph, type) {
            return el('input', { type: type || 'text', value: c[key] || '', placeholder: ph || '',
                onChange: function (e) { var o = {}; o[key] = e.target.value; up(o); } });
        }
        function chk(key, lbl, defaultOn) {
            var val = defaultOn ? c[key] !== false : !!c[key];
            return el('label', { style: { display: 'flex', gap: '6px', alignItems: 'center', fontSize: '12px', cursor: 'pointer', marginTop: '4px', textTransform: 'none', fontWeight: 400, letterSpacing: 0 } },
                el('input', { type: 'checkbox', checked: val, style: { accentColor: '#d82d6b' }, onChange: function (e) { var o = {}; o[key] = e.target.checked; up(o); } }),
                lbl
            );
        }
        function num(key, ph) {
            return el('input', { type: 'number', min: 0, value: c[key] !== undefined ? c[key] : '', placeholder: ph || '',
                onChange: function (e) { var o = {}; o[key] = e.target.value; up(o); } });
        }
        function ta(key, ph, rows) {
            return el('textarea', { rows: rows || 3, value: c[key] || '', placeholder: ph || '',
                style: { width: '100%', padding: '6px 8px', border: '1px solid #e0cfd8', borderRadius: '3px', fontSize: '12px', fontFamily: 'inherit', resize: 'vertical' },
                onChange: function (e) { var o = {}; o[key] = e.target.value; up(o); } });
        }
        function rdonly(val) {
            return el('input', { type: 'text', readOnly: true, value: val,
                onClick: function (e) { e.target.select(); try { navigator.clipboard.writeText(val); } catch(ex) {} },
                style: { fontFamily: 'monospace', fontSize: '11px', cursor: 'pointer', background: '#f7f7f7', width: '100%' } });
        }
        function sel(key, options) {
            return el('select', { value: c[key] || '', style: { width: '100%' },
                onChange: function (e) { var o = {}; o[key] = e.target.value; up(o); } },
                options.map(function (opt) { return el('option', { key: opt.value, value: opt.value }, opt.label); })
            );
        }
        function section(key, title, children) {
            var isOpen = openSection === key;
            return el('div', { style: { borderBottom: '1px solid #f0f0f0' } },
                el('button', {
                    onClick: function () { setOpenSection(isOpen ? null : key); },
                    style: {
                        width: '100%', textAlign: 'left', background: isOpen ? '#fdf0f5' : '#fafafa',
                        border: 'none', borderBottom: '1px solid #f0f0f0', padding: '11px 16px',
                        fontSize: '11px', fontWeight: 700, color: isOpen ? '#d82d6b' : '#444',
                        cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                        textTransform: 'uppercase', letterSpacing: '.05em',
                    },
                }, title, el('span', { style: { fontSize: '10px', color: '#aaa' } }, isOpen ? '▲' : '▼')),
                isOpen ? el('div', null, children) : null
            );
        }

        var content = null;

        if (activeTab === 'general') {
            content = el('div', null,
                row('Disabilita form',        chk('disable_form',       'Disabilita questo modulo')),
                row('Disabilita pagina form', chk('disable_form_page',  'Non mostrare la pagina dedicata')),
                row('Blocca invii multipli',  chk('disable_multiple',   'Un invio per utente')),
                row('Max submissions',        num('max_submissions', '0 = illimitato'), '0 = illimitato. Disabilita dopo N invii.'),
                row('Disabilita auto-scroll', chk('disable_autoscroll', 'Non scrollare al primo errore')),
                row('Auto-save',              chk('enable_autosave',    'Salva bozza automaticamente')),
                row(t('webhook_label'),
                    el('div', null,
                        el('input', { type: 'text', value: c.webhook_url || '', placeholder: 'https://…',
                            onChange: function (e) { up({ webhook_url: e.target.value }); },
                            style: { width: '100%', marginBottom: '8px' } }),
                        el('div', { style: { display: 'flex', gap: '16px', alignItems: 'center', fontSize: '12px' } },
                            ['post', 'post_json', 'get'].map(function (method) {
                                var labels = { post: 'POST', post_json: 'POST (JSON)', get: 'GET' };
                                return el('label', { key: method, style: { display: 'flex', gap: '5px', alignItems: 'center', cursor: 'pointer' } },
                                    el('input', {
                                        type: 'radio', name: 'webhook_method', value: method,
                                        checked: (c.webhook_method || 'post') === method,
                                        onChange: function () { up({ webhook_method: method }); },
                                        style: { accentColor: '#d82d6b' }
                                    }),
                                    labels[method]
                                );
                            })
                        )
                    )
                )
            );
        } else if (activeTab === 'email') {
            var emailMethod = c.email_method || 'wp_mail';
            content = el('div', null,
                section('email_setup', 'Email Setup',
                    el('div', null,
                        row('Metodo di invio',
                            el('div', { style: { display: 'flex', gap: '16px', alignItems: 'center', fontSize: '12px' } },
                                ['wp_mail', 'smtp'].map(function(method) {
                                    var labels = { wp_mail: 'wp_mail (default)', smtp: 'SMTP personalizzato' };
                                    return el('label', { key: method, style: { display: 'flex', gap: '5px', alignItems: 'center', cursor: 'pointer', fontStyle: 'normal' } },
                                        el('input', { type: 'radio', name: 'if2_email_method', value: method,
                                            checked: emailMethod === method,
                                            onChange: function() { up({ email_method: method }); },
                                            style: { accentColor: '#d82d6b' }
                                        }),
                                        labels[method]
                                    );
                                })
                            )
                        ),
                        emailMethod === 'smtp' ? el('div', null,
                            row('SMTP Host',     txt('smtp_host', 'smtp.example.com')),
                            row('SMTP Porta',    txt('smtp_port', '587')),
                            row('SMTP Utente',   txt('smtp_user', 'utente@example.com')),
                            row('SMTP Password', txt('smtp_pass', '••••••')),
                            row('Cifratura',     sel('smtp_enc', [
                                { value: 'tls',  label: 'TLS (raccomandato)' },
                                { value: 'ssl',  label: 'SSL' },
                                { value: 'none', label: 'Nessuna' },
                            ]))
                        ) : null,
                        row('Nome mittente',       txt('email_from_name', 'in3pida Form')),
                        row('Email mittente',      txt('email_from',      'noreply@…', 'email')),
                        row('Reply-To',
                            el('select', {
                                value: c.email_reply_to || '',
                                style: { width: '100%' },
                                onChange: function (e) { up({ email_reply_to: e.target.value }); }
                            },
                                el('option', { value: '' }, '— Auto (primo campo email) —'),
                                (props.fields || []).filter(function (f) { return f.type === 'email'; })
                                    .map(function (f) { return el('option', { key: f.id, value: f.id }, f.label || f.id); })
                            ),
                            'Lascia su Auto per usare il primo campo email del form'
                        ),
                        el('div', { className: 'if2-settings-row' },
                            el('label', null, 'Invia mail di test'),
                            el('div', { style: { display: 'flex', gap: '6px', alignItems: 'center' } },
                                el('input', { type: 'email', value: testEmailTo, placeholder: 'indirizzo@email.com',
                                    style: { flex: 1 },
                                    onChange: function(e) { setTestEmailTo(e.target.value); },
                                    onKeyDown: function(e) { if (e.key === 'Enter') { e.preventDefault(); sendTestEmail(); } }
                                }),
                                el('button', {
                                    style: { background: '#009bb9', color: '#fff', border: 'none', borderRadius: '4px', padding: '6px 12px', fontSize: '11px', fontWeight: 700, cursor: 'pointer', whiteSpace: 'nowrap', flexShrink: 0 },
                                    onClick: sendTestEmail
                                }, 'Invia'),
                                testEmailStatus ? el('span', { style: { fontSize: '11px', color: testEmailStatus.indexOf('✓') !== -1 ? '#1a7a45' : '#d82d6b', whiteSpace: 'nowrap' } }, testEmailStatus) : null
                            )
                        )
                    )
                ),
                section('email_notification', 'Email Notification',
                    el('div', null,
                        row('Notifiche email', chk('send_email',    'Abilita notifiche email')),
                        row('Destinatario',    txt('email_to',      'admin@…', 'email')),
                        row('Oggetto',         txt('email_subject', 'Nuova submission')),
                        row('Corpo email',
                            el(RichEditor, { value: c.email_body || '', onChange: function(html) { up({ email_body: html }); }, fields: props.fields || [] }),
                            '{all_fields} · {form_name} · {submission_id} · {date} · {time} · {source_url} · {channel} · {field_ID}'
                        ),
                        row('Opzioni email', el('div', null,
                            chk('email_attach_files', 'Allega file caricati dal form alle email'),
                            chk('email_multi_column', 'Usa layout multi-colonna del form nel corpo email'),
                            chk('email_hide_empty',   'Non mostrare tag con valore vuoto o nascosto')
                        ))
                    )
                ),
                section('email_autoresponder', 'Email Autoresponder',
                    el('div', null,
                        row('Autoresponder',      chk('autoresponder', 'Invia conferma all\'utente')),
                        row('Campo email utente',
                            el('select', {
                                value: c.autoresponder_email_field || '',
                                style: { width: '100%' },
                                onChange: function (e) { up({ autoresponder_email_field: e.target.value }); }
                            },
                                el('option', { value: '' }, '— Auto (primo campo email) —'),
                                (props.fields || []).filter(function (f) { return f.type === 'email'; })
                                    .map(function (f) { return el('option', { key: f.id, value: f.id }, f.label || f.id); })
                            ),
                            'Auto: usa il primo campo email del form'
                        ),
                        row('Nome mittente',      txt('autoresponder_from_name',  'es. Il tuo hotel')),
                        row('Email mittente',     txt('autoresponder_from_email', 'noreply@…', 'email')),
                        row('Oggetto',            txt('autoresponder_subject',    'Grazie per averci contattato')),
                        row('Corpo email',
                            el(RichEditor, { value: c.autoresponder_body || '', onChange: function(html) { up({ autoresponder_body: html }); }, fields: props.fields || [] }),
                            '{all_fields} · {form_name} · {date} · {time} · {field_ID}'
                        ),
                        row('Opzioni autoresponder', el('div', null,
                            chk('email_attach_files', 'Allega file caricati dal form alle email'),
                            chk('email_hide_empty',   'Non mostrare tag con valore vuoto o nascosto')
                        ))
                    )
                )
            );
        } else if (activeTab === 'embed') {
            var fid       = formId || (typeof IF2Builder !== 'undefined' ? IF2Builder.form_id : 0) || '?';
            var shortcode = '[if2 id="' + fid + '"]';
            var phpfn     = "<?php echo do_shortcode('" + shortcode + "'); ?>";
            var pageUrl   = (typeof IF2Builder !== 'undefined' && IF2Builder.home_url ? IF2Builder.home_url : '') + '/?if2_preview=' + fid;
            content = el('div', null,
                section('embed_page', 'Pagina Form Dedicata',
                    el('div', null,
                        row('URL pagina dedicata', rdonly(pageUrl), 'Clicca per copiare — disponibile se il form è attivo'),
                        row('Disabilita pagina',   chk('disable_form_page', 'Non mostrare la pagina dedicata'))
                    )
                ),
                section('embed_shortcode', 'Shortcode',
                    el('div', null,
                        row('Shortcode', rdonly(shortcode), 'Clicca per copiare — incolla in qualsiasi pagina o post'),
                        el('div', { style: { padding: '0 16px 12px', fontSize: '11px', color: '#888' } },
                            'Esempio: ', el('code', { style: { background: '#f0f0f0', padding: '1px 5px', borderRadius: '3px' } }, shortcode)
                        )
                    )
                ),
                section('embed_editor', 'Post / Page Editor',
                    el('div', null,
                        el('div', { style: { padding: '12px 16px', fontSize: '12px', color: '#555', lineHeight: 1.6 } },
                            el('p', { style: { margin: '0 0 8px' } }, 'Nell\'editor WordPress, inserisci un blocco Shortcode e incolla:'),
                            el('code', { style: { display: 'block', background: '#f0f0f0', padding: '8px 12px', borderRadius: '4px', fontSize: '11px', fontFamily: 'monospace' } }, shortcode)
                        )
                    )
                ),
                section('embed_php', 'PHP Function',
                    el('div', null,
                        row('PHP', rdonly(phpfn), 'Clicca per copiare — incolla nel tuo template PHP')
                    )
                )
            );
        } else if (activeTab === 'custom_text') {
            content = el('div', null,
                row('Messaggio successo',    ta('success_message',      'Grazie! Il tuo messaggio è stato inviato.')),
                row('Messaggio errore',      ta('error_message',        'Per favore correggi gli errori e riprova.', 2)),
                row('Campo obbligatorio',    txt('text_required',       'Questo campo è obbligatorio')),
                row('Email non valida',      txt('text_invalid_email',  'Indirizzo email non valido')),
                row('Solo lettere',          txt('text_only_letters',   'Questo campo accetta solo lettere')),
                row('Solo numeri',           txt('text_only_numbers',   'Questo campo accetta solo numeri')),
                row('Formato non corretto',  txt('text_invalid_format', 'Il formato non è corretto')),
                row('URL non valido',        txt('text_invalid_url',    'URL non valido')),
                row('Valore non valido',     txt('text_invalid',        'Il valore inserito non è valido')),
                row('Testo pulsante',        txt('submit_text',         'Invia'))
            );
        } else if (activeTab === 'advanced') {
            content = el('div', null,
                row('Nome form',             txt('form_name',      'Nome interno')),
                row('URL redirect',          txt('redirect_url',   'https://…'), 'Reindirizza dopo invio'),
                row('Ritardo redirect (ms)', num('redirect_delay', '0'), '0 = immediato'),
                row('Separatore migliaia',   txt('thousand_sep',   '.')),
                row('Separatore decimali',   txt('decimal_sep',    ',')),
                row('Registra IP',           chk('collect_ip',     'Salva IP del visitatore')),
                row('Larghezza form',        txt('form_width',     '100%')),
                row('Custom JavaScript',     ta('custom_js', '// Codice JS eseguito al caricamento del form\n', 6)),
                el('div', { className: 'if2-settings-row' },
                    el('label', null, 'Export / Import'),
                    el('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap' } },
                        el('button', {
                            style: { background: '#d82d6b', color: '#fff', border: 'none', borderRadius: '4px', padding: '7px 14px', fontSize: '11px', fontWeight: 700, cursor: 'pointer', textTransform: 'uppercase', letterSpacing: '.04em' },
                            onClick: function () {
                                var json = JSON.stringify({ fields: props.fields || [], config: c }, null, 2);
                                var blob = new Blob([json], { type: 'application/json' });
                                var url  = URL.createObjectURL(blob);
                                var a    = document.createElement('a');
                                a.href   = url; a.download = 'form-' + (formId || 'export') + '.json';
                                a.click(); URL.revokeObjectURL(url);
                            }
                        }, 'Export'),
                        el('button', {
                            style: { background: '#fff', color: '#d82d6b', border: '1px solid #d82d6b', borderRadius: '4px', padding: '7px 14px', fontSize: '11px', fontWeight: 700, cursor: 'pointer', textTransform: 'uppercase', letterSpacing: '.04em' },
                            onClick: function () { if2ImportFormFile(props.onImport); }
                        }, 'Import (.json / .txt)')
                    )
                )
            );
        } else if (activeTab === 'crm') {
            var crmDrivers = IF2Builder.crm_drivers || {};

            content = Object.keys(crmDrivers).length === 0
                ? el('div', { style: { padding: '16px', fontSize: '12px', color: '#aaa' } }, 'Nessun driver CRM disponibile.')
                : el('div', null,
                    el('div', { style: { padding: '10px 16px 8px', background: '#fafafa', borderBottom: '1px solid #f0f0f0', fontSize: '11px', color: '#888', lineHeight: '1.5' } },
                        'Attiva il CRM che deve ricevere le richieste di ', el('strong', null, 'questo form'), '. Le credenziali si configurano una volta sola in ', el('strong', null, 'Integrazioni CRM'), ' nel menu a sinistra.',
                        el('br', null),
                        el('strong', { style: { color: '#e53e3e' } }, 'Attenzione:'), ' questa impostazione funziona solo se il CRM è configurato tramite Integrazioni CRM. Se il sito usa uno script CRM esterno, questa sezione non ha effetto.'
                    ),
                    Object.keys(crmDrivers).map(function(driverKey) {
                        var drv    = crmDrivers[driverKey];
                        var dCfg   = (c.crm || {})[driverKey] || {};
                        var active = !!dCfg.enabled;
                        var uid    = 'if2-crm-tog-' + driverKey;

                        return el('div', { key: driverKey, style: { padding: '14px 16px', borderBottom: '1px solid #f0f0f0' } },
                            el('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: active ? '12px' : '0' } },
                                el('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } },
                                    el('span', { style: { width: '9px', height: '9px', borderRadius: '50%', background: drv.color || '#aaa', display: 'inline-block', flexShrink: 0 } }),
                                    el('span', { style: { fontSize: '11px', fontWeight: 700, color: '#333', textTransform: 'uppercase', letterSpacing: '.05em' } }, drv.label || driverKey)
                                ),
                                el('label', { htmlFor: uid, className: 'in3pida-toggle', style: { cursor: 'pointer' } },
                                    el('input', {
                                        id: uid,
                                        type: 'checkbox',
                                        checked: active,
                                        onChange: function() {
                                            var newCrm = Object.assign({}, c.crm || {});
                                            newCrm[driverKey] = Object.assign({}, newCrm[driverKey] || {}, { enabled: !active });
                                            up({ crm: newCrm });
                                        }
                                    }),
                                    el('span', { className: 'in3pida-toggle-slider' }),
                                    el('span', { className: 'in3pida-toggle-label' }, active ? 'Attivo' : 'Non attivo')
                                )
                            ),
                            !active ? null : (function() {
                                var perFormCreds = Object.keys(drv.credentials || {}).filter(function(ck) {
                                    return !!(drv.credentials[ck] && drv.credentials[ck].per_form);
                                });
                                if (perFormCreds.length === 0) return null;
                                return el('div', null,
                                    perFormCreds.map(function(credKey) {
                                        var cred = drv.credentials[credKey];
                                        return el('div', { key: credKey, style: { marginBottom: '8px' } },
                                            el('label', { style: { display: 'block', fontSize: '10px', fontWeight: 700, color: '#888', textTransform: 'uppercase', marginBottom: '3px' } }, cred.label || credKey),
                                            el('input', {
                                                type: cred.type === 'password' ? 'password' : 'text',
                                                value: dCfg[credKey] || '',
                                                placeholder: cred.placeholder || '',
                                                autoComplete: 'off',
                                                onChange: (function(ck) { return function(e) {
                                                    var newCrm = Object.assign({}, c.crm || {});
                                                    var patch = {}; patch[ck] = e.target.value;
                                                    newCrm[driverKey] = Object.assign({}, newCrm[driverKey] || {}, patch);
                                                    up({ crm: newCrm });
                                                }; })(credKey),
                                                style: { width: '100%', fontSize: '11px' }
                                            }),
                                            el('p', { style: { fontSize: '10px', color: '#aaa', margin: '3px 0 0' } }, 'Sovrascrive il valore globale impostato in Integrazioni CRM.')
                                        );
                                    })
                                );
                            })()
                        );
                    })
                );

        } else if (activeTab === 'in3pida') {
            var ameliaListsGlobal = (IF2Builder.amelia_lists || []);
            var ameliaDefaultOpts = [{ value: '', label: '— Auto (rileva TLD dalla email) —' }].concat(
                ameliaListsGlobal.map(function (l) {
                    return { value: l.listid, label: l.country + ' — List ID ' + l.listid };
                })
            );
            content = el('div', null,
                row('Thank You Page URL', txt('thankyou_url', 'https://…'), 'Redirect personalizzato dopo invio (sovrascrive URL redirect)'),
                row('Canale', sel('channel', [
                    { value: '',            label: '— Seleziona canale —' },
                    { value: 'Sito',        label: 'Sito' },
                    { value: 'Meta',        label: 'Meta' },
                    { value: 'Google Ads',  label: 'Google Ads' },
                    { value: 'Newsletter',  label: 'Newsletter' },
                    { value: 'Altro',       label: 'Altro' },
                ].concat((IF2Builder.custom_channels || []).map(function(ch) { return { value: ch, label: ch }; })))),
                row('Hotel ID', txt('hotel_id', 'ID struttura')),
                el('div', { style: { height: '1px', background: '#f0f0f0', margin: '2px 0' } }),
                row('Supabase', chk('supabase_enabled', 'Invia dati a Supabase (attivo di default)', true)),
                row('Tabella Supabase', txt('supabase_table', 'form_submissions')),
                el('div', { style: { height: '1px', background: '#f0f0f0', margin: '2px 0' } }),
                row('Lista Amelia default', sel('amelia_default_list', ameliaDefaultOpts), 'Lista Amelia usata se il TLD email non corrisponde a nessun paese. "Auto" usa il List ID globale come fallback. Configura le liste in Impostazioni → Amelia / SMSHosting.'),
                row('Lingua form', sel('form_lang', [
                    { value: '', label: '— Usa impostazione globale —' },
                    { value: 'it', label: 'Italiano' },
                    { value: 'en', label: 'English' },
                    { value: 'de', label: 'Deutsch' },
                    { value: 'fr', label: 'Français' },
                    { value: 'pl', label: 'Polski' },
                    { value: 'cs', label: 'Čeština' },
                    { value: 'hu', label: 'Magyar' },
                    { value: 'es', label: 'Español' },
                    { value: 'pt', label: 'Português' },
                    { value: 'sl', label: 'Slovenščina' },
                    { value: 'hr', label: 'Hrvatski' },
                ]), 'Lascia vuoto se va bene la lingua nelle impostazioni globali del plugin.')
            );
        }

        return el('div', null,
            el('div', { className: 'if2-settings-tabs' },
                TABS.map(function (tab) {
                    var isActive = activeTab === tab.key;
                    return el('button', {
                        key:       tab.key,
                        className: 'if2-settings-tab' + (isActive ? ' active' : ''),
                        onClick:   function () { setActiveTab(tab.key); },
                    }, tab.label);
                })
            ),
            content
        );
    }

    // -------------------------------------------------------------------------
    // FormCraft Import helpers
    // -------------------------------------------------------------------------
    function if2FcTypeMap(el_b) {
        if (el_b.indexOf('One-line Text') !== -1) return 'text';
        if (el_b.indexOf('Email Input') !== -1)   return 'email';
        if (el_b.indexOf('Paragraph Text') !== -1) return 'textarea';
        if (el_b.indexOf('Custom Text') !== -1 || el_b.indexOf('Image') !== -1) return 'html';
        if (el_b.indexOf('Divider') !== -1)        return 'heading';
        if (el_b.indexOf('DatePicker') !== -1)     return 'date';
        if (el_b.indexOf('Dropdown Box') !== -1)   return 'select';
        if (el_b.indexOf('Radio Group') !== -1)    return 'radio';
        if (el_b.indexOf('CheckBox Group') !== -1) return 'checkbox';
        if (el_b.indexOf('File Upload') !== -1)    return 'file';
        if (el_b.indexOf('Submit Button') !== -1)  return 'submit';
        if (el_b.indexOf('Star Rating') !== -1 || el_b.indexOf('Smiley') !== -1) return 'star_rating';
        if (el_b.indexOf('Choice Matrix') !== -1)  return 'matrix';
        if (el_b.indexOf('Hidden Field') !== -1)   return 'hidden';
        return 'text';
    }
    function if2FcConvertPlaceholders(str) {
        if (!str) return str;
        return str
            .replace(/\[Form Content\]/g, '{all_fields}')
            .replace(/\[URL\]/g, '{source_url}')
            .replace(/\[Entry ID\]/g, '{submission_id}')
            .replace(/\[Date\]/g, '{date}')
            .replace(/\[Time\]/g, '{time}');
    }
    function if2FcMetaConfigToConfig(mbConfig) {
        if (!mbConfig) return {};
        var cfg = {};
        var p = if2FcConvertPlaceholders;
        // Rimuove {submission_id} dall'oggetto: il plugin lo aggiunge in automatico
        var pSubject = function(s) { return p(s).replace(/[\s\-#]*\{submission_id\}[\s\-#]*/g, '').trim(); };
        if (mbConfig.form_name)             cfg.form_name     = mbConfig.form_name;
        if (mbConfig.redirect_main)         cfg.redirect_url  = mbConfig.redirect_main;
        if (mbConfig.Redirect_delay_seconds !== undefined)
            cfg.redirect_delay = parseInt(mbConfig.Redirect_delay_seconds) || 0;
        if (mbConfig.webhook)               cfg.webhook_url   = mbConfig.webhook;
        // Sfondo trasparente
        if (mbConfig.bg_transparent || mbConfig.transparent || mbConfig.is_transparent || mbConfig.container_transparent)
            cfg.bg_transparent = true;
        // Nascondi etichette a livello form
        if (mbConfig.hide_labels || mbConfig.hide_label || mbConfig.hideLabel)
            cfg.hide_labels = true;
        var notif = mbConfig.notifications || {};
        if (notif.recipients || notif.email_subject || notif.email_body) {
            cfg.send_email = true;
            if (notif.recipients)           cfg.email_to          = notif.recipients;
            if (notif.email_subject)        cfg.email_subject     = pSubject(notif.email_subject);
            if (notif.email_body)           cfg.email_body        = p(notif.email_body);
            if (notif.general_sender_name)  cfg.email_from_name   = notif.general_sender_name;
            if (notif.general_sender_email) cfg.email_from        = notif.general_sender_email;
        }
        var ar = mbConfig.autoresponder || {};
        if (ar.email_subject || ar.email_body) {
            cfg.autoresponder = true;
            if (ar.email_subject)           cfg.autoresponder_subject    = pSubject(ar.email_subject);
            if (ar.email_body)              cfg.autoresponder_body       = p(ar.email_body);
            if (ar.email_sender_name)       cfg.autoresponder_from_name  = ar.email_sender_name;
            if (ar.email_sender_email)      cfg.autoresponder_from_email = ar.email_sender_email;
        }
        return cfg;
    }
    function if2FcNewTypeMap(elType) {
        var m = { oneLineText:'text', password:'text', email:'email', textarea:'textarea',
            customText:'html', heading:'heading', datepicker:'date', timepicker:'text',
            dropdown:'select', fileupload:'file', submit:'submit', star:'star_rating',
            matrix:'matrix', slider:'number', number:'number', phone:'phone' };
        return m[elType] || 'text';
    }
    function if2ParseOptions(str) {
        if (!str) return [];
        if (Array.isArray(str)) return str.map(function(s) {
            var lbl = (s && typeof s === 'object') ? (s.label || s.value || String(s)) : String(s);
            return { label: lbl.trim(), value: lbl.trim() };
        }).filter(function(o) { return o.label; });
        if (typeof str !== 'string') return [];
        return str.split('\n').map(function(s) { return s.replace(/^==/, '').trim(); })
            .filter(Boolean).map(function(s) { return { label: s, value: s }; });
    }
    function if2FcOldToField(f) {
        var type = if2FcTypeMap(f.el_b || '');
        var field = makeField(type);
        field.label = f.cap1 || field.label;
        field.sub_label = f.cap2 || '';
        field.instruction = f.inst || '';
        field.required = f.req === 1;
        field.placeholder = f.ph || f.ph1 || f.placeholder || '';
        if (f.hide_label) field.hide_labels = true;
        var im = { inline2:'50%', inline3:'33.3%', inline4:'25%' };
        field.col_width = (f.inline && im[f.inline]) ? im[f.inline] : '100%';
        if (type === 'html')    field.content = f.customText || (f.image ? '<img src="' + f.image + '">' : '');
        if (type === 'heading') field.content = f.cap1 || '';
        if (f.options_raw && ['select','radio','checkbox'].indexOf(type) !== -1) {
            field.options = if2ParseOptions(f.options_raw);
        }
        return field;
    }
    function if2FcWidthNormalize(w) {
        if (!w) return '100%';
        var kwMap = {
            full: '100%', one_half: '50%', two_thirds: '66.6%', three_quarters: '75%',
            one_third: '33.3%', one_quarter: '25%',
        };
        var str = String(w).trim();
        if (kwMap[str]) return kwMap[str];
        if (str.indexOf('%') !== -1) return str;
        var n = parseFloat(str);
        if (!isNaN(n) && n > 0 && n <= 100) return n + '%';
        return '100%';
    }
    function if2FcMapOp(op) {
        var m = { equal:'equals', '=':'equals', '==':'equals',
                  notEqual:'not_equals', not_equal:'not_equals', '!=':'not_equals',
                  contains:'contains', not_contains:'not_contains', notContains:'not_contains',
                  empty:'is_empty', is_empty:'is_empty', notEmpty:'not_empty', not_empty:'not_empty' };
        return m[op] || 'equals';
    }
    function if2FcMapCondOp(op) {
        var m = { equal:'=', '=':'=', '==':'=', notEqual:'!=', not_equal:'!=', '!=':'!=',
                  contains:'contains', not_empty:'not_empty', notEmpty:'not_empty', empty:'not_empty' };
        return m[op] || 'contains';
    }
    function if2FcMetaLogicApply(logicArr, fields) {
        if (!Array.isArray(logicArr) || !logicArr.length) return [];
        var fieldMap = {};
        fields.forEach(function(f) { fieldMap[f.id] = f; });
        var condMap  = {};
        var logicRules = [];
        var opBuilder = { equal:'equals','=':'equals','==':'equals', notEqual:'not_equals',not_equal:'not_equals','!=':'not_equals',
                          contains:'contains', not_contains:'not_contains', notContains:'not_contains',
                          empty:'is_empty', is_empty:'is_empty', notEmpty:'not_empty', not_empty:'not_empty' };
        logicArr.forEach(function(ruleArr) {
            if (!Array.isArray(ruleArr) || ruleArr.length < 2) return;
            var conditionsArr = Array.isArray(ruleArr[0]) ? ruleArr[0] : [];
            var actionsArr    = Array.isArray(ruleArr[1]) ? ruleArr[1] : [];
            var frontendRules = conditionsArr.map(function(c) {
                return { field: String(c[0]||''), operator: if2FcMapCondOp(c[1]||'contains'), value: String(c[2]!==undefined?c[2]:'') };
            }).filter(function(r){ return r.field; });
            var builderConds = conditionsArr.map(function(c) {
                return { field: String(c[0]||''), op: (opBuilder[c[1]]||'contains'), value: String(c[2]!==undefined?c[2]:'') };
            }).filter(function(r){ return r.field; });
            if (!frontendRules.length) return;
            actionsArr.forEach(function(action) {
                var actionType = String(action[0]||'').toLowerCase();
                if (actionType.indexOf('hide') !== -1) return;
                var targets = String(action[1]||'').split(',');
                targets.forEach(function(target) {
                    target = target.trim();
                    if (!target) return;
                    if (!condMap[target]) condMap[target] = [];
                    frontendRules.forEach(function(r){ condMap[target].push(r); });
                    logicRules.push({ id:'rule_'+Math.random().toString(36).slice(2,10), conditions:builderConds, action_type:'show', action_field:target });
                });
            });
        });
        Object.keys(condMap).forEach(function(targetId) {
            if (!fieldMap[targetId]) return;
            var allRules = condMap[targetId];
            fieldMap[targetId].conditions = { logic: allRules.length > 1 ? 'OR' : 'AND', rules: allRules };
        });
        return logicRules;
    }
    function if2FcActionsToRules(actions) {
        return [];
    }
    function if2FcNewToField(fe) {
        // fe.type è la chiave pulita (es. 'datepicker'), fe.element è un template HTML
        var elType = fe.type || fe.element || '';
        if (!elType) return null;
        var d = fe.elementDefaults || {};
        var type = if2FcNewTypeMap(elType);
        if (elType === 'checkbox' && d.allow_multiple === 'checkbox') type = 'checkbox';
        else if (elType === 'checkbox') type = 'radio';
        var field = makeField(type);
        field.id = fe.identifier || field.id;
        field.label = d.main_label || field.label;
        field.sub_label = d.sub_label || '';
        field.instruction = d.instructions || '';
        field.required = !!d.required;
        field.col_width = if2FcWidthNormalize(fe.field_width || d.field_width);
        field.alt_label = d.altLabel || '';
        field.placeholder = d.placeholder || d.placeholder_text || '';
        if (d.hidden || d.hide_field || d.hidden_default) field.hidden_default = true;
        if (d.hide_label || d.hideLabel || d.label_hidden) field.hide_labels = true;
        if (type === 'html')    field.content = d.html || '';
        if (type === 'heading') field.content = d.field_value || d.main_label || '';
        if (['select','radio','checkbox'].indexOf(type) !== -1) {
            var rawOpts = d.options_list || d.options || d.choices || '';
            if (rawOpts) field.options = if2ParseOptions(rawOpts);
        }
        field._fc_actions = Array.isArray(fe.actions) ? fe.actions : [];
        return field;
    }
    function if2ImportFormFile(onImport) {
        var input = document.createElement('input');
        input.type = 'file';
        input.accept = '.txt,.json';
        input.onchange = function (e) {
            var file = e.target.files[0];
            if (!file) return;
            var reader = new FileReader();
            reader.onload = function (ev) {
                try {
                    var parsed = JSON.parse(ev.target.result);

                    // in3pida-form-2 native JSON
                    if (Array.isArray(parsed.fields)) {
                        onImport(parsed.fields, parsed.config || null);
                        return;
                    }

                    // FormCraft .txt
                    if (parsed.plugin === 'FormCraft' && parsed.builder) {
                        var importedFields = [];
                        var usedMetaBuilder = false;

                        // Percorso primario: meta_builder è già plain JSON — più affidabile
                        var mbLogicRules = [];
                        var mbCfgExtra   = {};
                        if (parsed.meta_builder) {
                            try {
                                var mb = typeof parsed.meta_builder === 'string' ? JSON.parse(parsed.meta_builder) : parsed.meta_builder;
                                var mbFields = Array.isArray(mb.fields) ? mb.fields : [];
                                var inputTypes100 = ['text','email','phone','number','select','radio','checkbox','date','star_rating','matrix','textarea'];
                                mbFields.forEach(function(fe) {
                                    var f = if2FcNewToField(fe);
                                    if (f) {
                                        delete f._fc_actions;
                                        // Normalizza 100% → 50% per campi input (non strutturali)
                                        if (f.col_width === '100%' && inputTypes100.indexOf(f.type) !== -1) f.col_width = '50%';
                                        importedFields.push(f);
                                    }
                                });
                                if (importedFields.length) {
                                    var mbLogic = (mb.config && Array.isArray(mb.config.Logic)) ? mb.config.Logic : [];
                                    mbLogicRules = if2FcMetaLogicApply(mbLogic, importedFields);
                                    mbCfgExtra   = if2FcMetaConfigToConfig(mb.config || {});
                                    usedMetaBuilder = true;
                                }
                            } catch (exMb) {
                                importedFields = [];
                            }
                        }

                        // Fallback: decompressione builder (file senza meta_builder)
                        if (!usedMetaBuilder) {
                            var bstr = parsed.builder;
                            try {
                                var rawObj;
                                if (bstr.substring(0, 10) === 'rawdeflate') {
                                    var inflated = window.inflate(bstr);
                                    if (!inflated) throw new Error('Decompressione rawdeflate fallita.');
                                    rawObj = JSON.parse(inflated);
                                    var fes  = rawObj.FormElements;
                                    var list = Array.isArray(fes[0]) ? fes[0] : fes;
                                    list.forEach(function(fe) { var f = if2FcNewToField(fe); if (f) { delete f._fc_actions; importedFields.push(f); } });
                                } else if (bstr.indexOf('[BREAK]') !== -1) {
                                    var parts  = bstr.split('[BREAK]');
                                    var rawArr = JSON.parse(window.inflate(decodeURIComponent(parts[0].trim())));
                                    rawArr.forEach(function(f) { importedFields.push(if2FcOldToField(f)); });
                                } else {
                                    rawObj = JSON.parse(window.inflate(decodeURIComponent(bstr.trim())));
                                    var fes2  = rawObj.FormElements;
                                    var list2 = Array.isArray(fes2[0]) ? fes2[0] : fes2;
                                    list2.forEach(function(fe) { var f = if2FcNewToField(fe); if (f) { delete f._fc_actions; importedFields.push(f); } });
                                }
                            } catch (ex2) {
                                alert('Errore parsing FormCraft: ' + ex2.message);
                                return;
                            }
                        }

                        if (importedFields.length) {
                            var fcImportCfg = Object.assign({}, mbCfgExtra, mbLogicRules.length ? { logic_rules: mbLogicRules } : {});
                            onImport(importedFields, Object.keys(fcImportCfg).length ? fcImportCfg : null);
                        } else {
                            alert('Nessun campo trovato nel file FormCraft.');
                        }
                        return;
                    }

                    alert('Formato non riconosciuto. Usa Export dal builder o un file .txt esportato da FormCraft.');
                } catch (ex) {
                    alert('File non valido: ' + ex.message);
                }
            };
            reader.readAsText(file);
        };
        input.click();
    }

    // -------------------------------------------------------------------------
    // Mount
    // -------------------------------------------------------------------------
    var root = document.getElementById('if2-builder-root');
    if (root) {
        wp.element.render(el(AppBoundary, null, el(BuilderApp, null)), root);
    }

    document.addEventListener('keydown', function (e) {
        if ((e.ctrlKey || e.metaKey) && e.key === 's') {
            e.preventDefault();
            var btn = document.getElementById('if2-topbar-save-btn');
            if (btn) btn.click();
        }
    });

})(window.wp);
