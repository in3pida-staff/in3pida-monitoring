<?php
defined('ABSPATH') || exit;
?>
<style>
.if2-builder-topbar,#main-options-panel{border-bottom:none!important;box-shadow:none!important;padding-top:8px!important;background:#ebebeb!important;}
.if2-settings-tab{font-size:11px!important;font-weight:400!important;color:#4a4a6a!important;white-space:nowrap!important;text-transform:uppercase!important;}
.if2-settings-tab.active{color:#d82d6b!important;}
.if2-settings-row label{font-size:12px!important;font-weight:400!important;color:#181834!important;text-transform:none!important;}
.if2-settings-row input,.if2-settings-row select,.if2-settings-row textarea{padding:6px 10px!important;border:1px solid #ddd!important;font-size:12px!important;}
</style>
<?php
$form_id = (int) ($_GET['form_id'] ?? 0);
if (!$form_id) {
    echo '<div class="wrap"><p>ID form non specificato. <a href="' . esc_url(admin_url('admin.php?page=if2-forms')) . '">Torna alla lista.</a></p></div>';
    return;
}
$form = IF2_Form::get($form_id);
if (!$form) {
    echo '<div class="wrap"><p>Form non trovato.</p></div>';
    return;
}
$back_url     = esc_url(admin_url('admin.php?page=if2-forms'));
$preview_url  = esc_url(home_url('/?if2_preview=' . $form_id));
?>
<div class="if2-admin-wrap">

    <div id="main-options-panel" class="if2-builder-topbar">
        <div class="if2-topbar-btn-group">
            <a href="<?php echo $back_url; ?>" class="if2-builder-topbar-btn">
                <?php echo IF2_Lang::t('builder_back'); ?>
            </a>
            <button class="if2-builder-topbar-btn" id="if2-btn-settings"><?php echo IF2_Lang::t('builder_settings'); ?></button>
            <button class="if2-builder-topbar-btn" id="if2-btn-styling"><?php echo IF2_Lang::t('builder_styling'); ?></button>
            <button class="if2-builder-topbar-btn" id="if2-btn-addons"><?php echo IF2_Lang::t('builder_addons'); ?></button>
            <button class="if2-builder-topbar-btn" id="if2-btn-logic"><?php echo IF2_Lang::t('builder_logic'); ?></button>
            <button class="if2-builder-topbar-btn if2-save-btn" id="if2-topbar-save-btn"><?php echo IF2_Lang::t('builder_save'); ?></button>
            <a href="<?php echo $preview_url; ?>" target="_blank" class="if2-builder-topbar-btn"><?php echo IF2_Lang::t('builder_preview'); ?></a>
            <button class="if2-builder-topbar-btn" id="if2-btn-help"><?php echo IF2_Lang::t('builder_help'); ?></button>
        </div>
    </div>

    <div id="if2-builder-root"
         data-form-id="<?php echo esc_attr($form_id); ?>"
         data-form-name="<?php echo esc_attr($form['name']); ?>"
         data-fields="<?php echo esc_attr(wp_json_encode($form['fields'], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP)); ?>"
         data-config="<?php echo esc_attr(wp_json_encode(array_merge(IF2_Form::default_config(), (array) $form['config']), JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP)); ?>">
        <p style="padding:40px;color:#aaa;text-align:center">Caricamento builder…</p>
    </div>

</div>
