<?php
defined('ABSPATH') || exit;

class IF2_Extensions {

    public static $last_supabase_result     = null;
    public static ?string $last_supabase_submitted_at = null;

    // ─── FASE 2: COLLEGAMENTO BI ──────────────────────────────────────────────

    const BI_BASE = 'https://bi.in3pida.it/api/webhooks/';

    /** Restituisce (creandola se assente) la chiave casuale del sito per il BI (64 hex). */
    public static function bi_site_key(): string {
        $key = (string) get_option('if2_bi_site_key', '');
        if (strlen($key) !== 64) {
            $key = bin2hex(random_bytes(32));
            update_option('if2_bi_site_key', $key, false);
            update_option('if2_bi_link_state', 'none', false); // chiave nuova → torna in attesa
        }
        return $key;
    }

    public static function bi_link_state(): string {
        return (string) get_option('if2_bi_link_state', 'none');
    }

    public static function bi_is_approved(): bool {
        return self::bi_link_state() === 'approvato';
    }

    /** Header di autenticazione BI da usare su ogni richiesta del sito approvato. */
    private static function bi_headers(): array {
        return [
            'Content-Type'   => 'application/json',
            'X-IF2-Site-Id'  => class_exists('IF2_Telemetry') ? IF2_Telemetry::site_id() : '',
            'X-IF2-Site-Key' => self::bi_site_key(),
        ];
    }

    /**
     * Invia (o ri-invia) la richiesta di collegamento al BI.
     * Chiamata da ogni heartbeat; aggiorna lo stato 'none'/'attesa'/'approvato'/'bloccato'.
     */
    public static function send_bi_link_request(): void {
        $site_id = class_exists('IF2_Telemetry') ? IF2_Telemetry::site_id() : '';
        if (!$site_id) return;
        // Non ri-inviare se già bloccato (il sito non cambierà idea da solo)
        if (self::bi_link_state() === 'bloccato') return;

        $key      = self::bi_site_key();
        $hotel_id = get_option('if2_hotel_id', '') ?: get_option('in3pida_hotel_id', '');
        $payload  = [
            'site_id'        => $site_id,
            'site_url'       => get_site_url(),
            'hotel_id'       => $hotel_id,
            'plugin_version' => IF2_VERSION,
            'key_hash'       => hash('sha256', $key),
        ];
        $resp = wp_remote_post(self::BI_BASE . 'form-link-request', [
            'headers'   => ['Content-Type' => 'application/json'],
            'body'      => wp_json_encode($payload),
            'timeout'   => 8,
            'blocking'  => true,
            'sslverify' => true,
        ]);
        if (!is_wp_error($resp)) {
            $body  = json_decode(wp_remote_retrieve_body($resp), true) ?? [];
            $stato = sanitize_text_field($body['stato'] ?? '');
            if (in_array($stato, ['attesa', 'approvato', 'bloccato'], true)) {
                update_option('if2_bi_link_state', $stato, false);
            }
        }
    }

    /**
     * Invia la submission al BI (endpoint form-submission).
     * Usato al posto di Supabase diretto quando il collegamento è approvato.
     * Idempotente: stesso entry_id + submitted_at → risposta ok con dup:true, senza duplicati.
     */
    public static function send_bi_submission(array $form, array $data, array $meta, int $submission_id, string $submitted_at = ''): array {
        if ($submitted_at === '') $submitted_at = gmdate('c');

        // Costruisce fields (esclude tipi non dati, applica alt_label)
        $fields_data = [];
        $email_val   = '';
        foreach ($form['fields'] as $field) {
            if (in_array($field['type'] ?? '', ['submit', 'heading', 'html', 'page_break'], true)) continue;
            $fid = $field['id'] ?? '';
            if (!array_key_exists($fid, $data)) continue;
            $val = is_array($data[$fid]) ? implode(', ', $data[$fid]) : (string) $data[$fid];
            if ($email_val === '' && $val !== '' && (($field['type'] ?? '') === 'email' || is_email($val))) {
                $email_val = sanitize_email($val);
            }
            $alt  = trim($field['alt_label'] ?? '');
            $fkey = $alt !== '' ? $alt : trim($field['label'] ?? $fid);
            if (isset($fields_data[$fkey])) { $fi = 2; while (isset($fields_data[$fkey.'_'.$fi])) $fi++; $fkey .= '_'.$fi; }
            $fields_data[$fkey] = $val;
        }

        $config = $form['config'] ?? [];
        $payload = [
            'entry_id'     => $submission_id,
            'form_id'      => (int) ($form['id'] ?? 0),
            'form_name'    => (string) ($form['name'] ?? ($config['name'] ?? '')),
            'canale'       => ($config['channel'] ?? '') ?: '',
            'submitted_at' => $submitted_at,
            'fields'       => (object) $fields_data,
            'ip'           => sanitize_text_field((string) ($meta['ip'] ?? '')),
            'user_agent'   => sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''),
            'domain'       => get_site_url(),
            'email'        => $email_val,
        ];

        $resp = wp_remote_post(self::BI_BASE . 'form-submission', [
            'headers'   => self::bi_headers(),
            'body'      => wp_json_encode($payload),
            'timeout'   => 15,
            'blocking'  => true,
            'sslverify' => true,
        ]);

        if (is_wp_error($resp)) return ['status' => 'error', 'message' => $resp->get_error_message()];
        $code = (int) wp_remote_retrieve_response_code($resp);
        $body = json_decode(wp_remote_retrieve_body($resp), true) ?? [];
        if ($code === 200 && !empty($body['ok'])) {
            self::$last_supabase_submitted_at = $submitted_at;
            return ['status' => 'ok', 'dup' => !empty($body['dup'])];
        }
        return ['status' => 'error', 'code' => $code, 'message' => substr(wp_remote_retrieve_body($resp), 0, 200)];
    }

    public static function init(): void {
        add_action('if2_submit_extensions', [self::class, 'maybe_send_supabase'], 10, 4);

        add_action('wp_ajax_if2_get_blocked_dates',        [self::class, 'ajax_blocked_dates']);
        add_action('wp_ajax_nopriv_if2_get_blocked_dates', [self::class, 'ajax_blocked_dates']);

        // Amelia → webhook BI: invia la chiave dell'hotel in automatico (senza salvare a mano), una sola volta finché
        // non cambia. Gira all'apertura admin E su un cron ogni 5 minuti (così parte da sola anche senza entrare nel sito).
        add_action('admin_init',      [self::class, 'sync_amelia_key_to_bi']);
        add_action('admin_init',      [self::class, 'sync_mrpreno_key_to_bi']);
        add_filter('cron_schedules', function ($s) { if (empty($s['if2_5min'])) $s['if2_5min'] = ['interval' => 300, 'display' => 'Ogni 5 minuti']; return $s; });
        add_action('if2_amelia_sync',  [self::class, 'sync_amelia_key_to_bi']);
        add_action('if2_mrpreno_sync', [self::class, 'sync_mrpreno_key_to_bi']);
        if (!wp_next_scheduled('if2_amelia_sync'))  wp_schedule_event(time() + 60, 'if2_5min', 'if2_amelia_sync');
        if (!wp_next_scheduled('if2_mrpreno_sync')) wp_schedule_event(time() + 90, 'if2_5min', 'if2_mrpreno_sync');

        // Backfill AUTOMATICO (senza pulsanti): scrive la geo delle richieste vecchie su Supabase, a piccoli lotti.
        add_action('if2_geo_backfill_sb', [self::class, 'geo_backfill_supabase']);
        if (!wp_next_scheduled('if2_geo_backfill_sb')) {
            wp_schedule_event(time() + 120, 'hourly', 'if2_geo_backfill_sb');
        }
    }

    public static function ajax_blocked_dates(): void {
        $form_id = (int) ($_GET['form_id'] ?? 0);
        wp_send_json_success(['dates' => self::get_blocked_dates($form_id)]);
    }

    /**
     * Invia i dati a Supabase se abilitato nella config del form.
     */
    public static function maybe_send_supabase(array $form, array $data, array $meta, int $submission_id): void {
        $config = $form['config'];
        if (isset($config['supabase_enabled']) && !$config['supabase_enabled']) {
            self::$last_supabase_result = ['status' => 'disabled'];
            return;
        }

        // FASE 2: se il collegamento BI è approvato, invia via BI invece di Supabase diretto.
        if (self::bi_is_approved()) {
            $result = self::send_bi_submission($form, $data, $meta, $submission_id);
            self::$last_supabase_result = $result;
            return;
        }

        // Credenziali: preferisce opzioni v2, fallback a v1
        $url     = get_option('if2_supabase_url', '') ?: get_option('in3pida_supabase_url', '');
        $api_key = if2_decrypt( get_option('if2_supabase_anon_key', '') ) ?: get_option('in3pida_supabase_key', '');
        if (!$url || !$api_key) {
            self::$last_supabase_result = ['status' => 'disabled'];
            return;
        }

        $table = sanitize_key($config['supabase_table'] ?? 'form_submissions') ?: 'form_submissions';

        // IP sempre incluso
        // IP: usa quello GIÀ calcolato correttamente all'invio (salta il proxy 35.214.191.80 e gli IP privati).
        // NON ricatturarlo qui col vecchio metodo: era QUESTO a salvare il proxy su Supabase.
        $ip = sanitize_text_field((string) ($meta['ip'] ?? ''));
        if ($ip === '') $ip = sanitize_text_field((string) ($_SERVER['REMOTE_ADDR'] ?? ''));

        // Geolocalizzazione (nazione/città/regione) dall'IP. Non blocca mai: se fallisce, resta vuota.
        $geo = self::geolocate($ip);

        // Costruisce oggetto fields: (alt_label ?: label) → value
        $fields_data = [];
        $email_val   = '';
        foreach ($form['fields'] as $field) {
            if (in_array($field['type'] ?? '', ['submit', 'heading', 'html', 'page_break'], true)) continue;
            $fid    = $field['id'] ?? '';
            $flabel = trim($field['label'] ?? $fid);
            if (empty($flabel) || !array_key_exists($fid, $data)) continue;
            $val = is_array($data[$fid]) ? implode(', ', $data[$fid]) : (string) $data[$fid];

            // Privacy: NON salvare su Supabase i dati sensibili (nome/cognome, e-mail, telefono).
            // Restano invariati per email hotel, autoresponder e CRM (gestiti a monte).
            if (self::if2_is_pii_field($field, $val)) continue;

            // Cattura email: tipo 'email' o valore che è un indirizzo email valido
            if ($email_val === '' && $val !== '' && (($field['type'] ?? '') === 'email' || is_email($val))) {
                $email_val = sanitize_email($val);
            }

            $alt  = trim($field['alt_label'] ?? '');
            $fkey = $alt !== '' ? $alt : $flabel;

            // Evita chiavi duplicate in fields
            if (isset($fields_data[$fkey])) {
                $fi = 2;
                while (isset($fields_data[$fkey . '_' . $fi])) $fi++;
                $fkey = $fkey . '_' . $fi;
            }
            $fields_data[$fkey] = $val;
        }

        // hotel_id solo da config form o impostazioni globali — mai dal POST (sicurezza).
        $hotel_id = ($config['hotel_id'] ?? '') ?: get_option('if2_hotel_id', '');
        $canale   = ($config['channel']  ?? '') ?: '';

        // Base payload
        $payload = [
            'entry_id'     => $submission_id,
            'form_id'      => $form['id'],
            'form_name'    => $form['name'] ?? '',
            'hotel_id'     => $hotel_id,
            'canale'       => $canale,
            'fields'       => $fields_data,
            'submitted_at' => ($sb_submitted_at = gmdate('c')),
            'ip'           => $ip,
            'user_agent'   => sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''),
            'domain'       => get_site_url(),
        ];
        // site_id: colonna UUID — inclusa solo se non vuota (stringa vuota → NULL in PostgREST)
        $site_id_val = class_exists('IF2_Telemetry') ? IF2_Telemetry::site_id() : '';
        if ($site_id_val !== '') $payload['site_id'] = $site_id_val;
        self::$last_supabase_submitted_at = $sb_submitted_at;
        if ($email_val !== '') {
            $payload['email'] = $email_val;
        }
        // Geolocalizzazione (richiede le colonne country/city/region su Supabase; se mancano,
        // il fallback PGRST204 le scarta e salva comunque il resto)
        if (!empty($geo['country'])) $payload['country'] = $geo['country'];
        if (!empty($geo['city']))    $payload['city']    = $geo['city'];
        if (!empty($geo['region']))  $payload['region']  = $geo['region'];

        $resp = wp_remote_post(
            trailingslashit($url) . 'rest/v1/' . $table,
            [
                'headers' => [
                    'apikey'        => $api_key,
                    'Authorization' => 'Bearer ' . $api_key,
                    'Content-Type'  => 'application/json',
                    'Prefer'        => 'return=minimal',
                ],
                'body'     => wp_json_encode($payload),
                'timeout'  => 15,
                'blocking' => true,
            ]
        );

        $code = is_wp_error($resp) ? 0 : wp_remote_retrieve_response_code($resp);

        // Se PGRST204 (colonna sconosciuta), riprova con solo le colonne base garantite
        if ( !is_wp_error($resp) && $code === 400 ) {
            $body_raw = wp_remote_retrieve_body($resp);
            if ( strpos($body_raw, 'PGRST204') !== false || strpos($body_raw, 'Could not find') !== false ) {
                $safe_keys    = ['entry_id','form_id','form_name','hotel_id','site_id','canale','fields','submitted_at','ip','user_agent','domain','email'];
                $safe_payload = array_intersect_key($payload, array_flip($safe_keys));
                $resp = wp_remote_post(
                    trailingslashit($url) . 'rest/v1/' . $table,
                    [
                        'headers' => [
                            'apikey'        => $api_key,
                            'Authorization' => 'Bearer ' . $api_key,
                            'Content-Type'  => 'application/json',
                            'Prefer'        => 'return=minimal',
                        ],
                        'body'    => wp_json_encode($safe_payload),
                        'timeout' => 15,
                    ]
                );
                $code = is_wp_error($resp) ? 0 : wp_remote_retrieve_response_code($resp);
            }
        }

        $ok   = !is_wp_error($resp) && $code >= 200 && $code < 300;
        $body = $ok ? '' : (is_wp_error($resp) ? $resp->get_error_message() : wp_remote_retrieve_body($resp));
        self::$last_supabase_result = [
            'status'  => $ok ? 'ok' : 'error',
            'code'    => $code,
            'message' => $ok ? '' : 'HTTP ' . $code . ($body ? ': ' . substr($body, 0, 300) : ''),
        ];
    }

    /**
     * Dato un campo del form + il suo valore, dice se è un dato personale sensibile
     * (nome/cognome, e-mail, telefono) che NON va scritto su Supabase.
     * Usata SOLO nella costruzione del payload Supabase: non altera in alcun modo
     * email hotel, autoresponder o CRM, che leggono i dati a monte.
     */
    private static function if2_is_pii_field(array $field, string $val): bool {
        $type = strtolower(trim($field['type'] ?? ''));
        if ($type === 'email' || $type === 'tel') return true;
        if ($val !== '' && is_email($val))       return true;

        $label = strtolower(trim(($field['alt_label'] ?? '') . ' ' . ($field['label'] ?? '')));
        if ($label === '') return false;

        // Nome/cognome (it/en/de: "Nome e Cognome", "Full Name", "Vor- und Nachname"…)
        foreach (['nome', 'cognome', 'name'] as $t)                if (strpos($label, $t) !== false) return true;
        // Telefono (it/en/de: "Telefono", "Phone", "Telefon", "Cellulare")
        foreach (['telefon', 'phone', 'cellulare'] as $t)          if (strpos($label, $t) !== false) return true;
        // E-mail per etichetta
        foreach (['e-mail', 'email', 'mail'] as $t)                if (strpos($label, $t) !== false) return true;

        return false;
    }

    /** Geolocalizza un IP (nazione/città/regione) via ipapi.co. Ritorna [] se non disponibile (IP privati, errori, timeout). */
    private static function geolocate(string $ip): array {
        $ip = trim($ip);
        if ($ip === '' || $ip === '127.0.0.1' || $ip === '::1'
            || strpos($ip, '10.') === 0 || strpos($ip, '192.168.') === 0
            || preg_match('/^172\.(1[6-9]|2[0-9]|3[01])\./', $ip)) {
            return [];
        }
        $resp = wp_remote_get('https://ipapi.co/' . rawurlencode($ip) . '/json/', [
            'timeout' => 3,
            'headers' => ['Accept' => 'application/json', 'User-Agent' => 'in3pida-form/' . IF2_VERSION],
        ]);
        if (is_wp_error($resp) || wp_remote_retrieve_response_code($resp) !== 200) return [];
        $j = json_decode(wp_remote_retrieve_body($resp), true);
        if (!is_array($j) || !empty($j['error'])) return [];
        return [
            'country' => sanitize_text_field($j['country_name'] ?? ''),
            'city'    => sanitize_text_field($j['city'] ?? ''),
            'region'  => sanitize_text_field($j['region'] ?? ''),
        ];
    }

    /** Wrapper pubblico per geolocalizzare un IP (usato dal backfill delle statistiche di provenienza). */
    public static function geolocate_ip(string $ip): array { return self::geolocate($ip); }

    /**
     * Invia la chiave Amelia di QUESTO hotel al WEBHOOK della BI (che la salva lei). Automatico: admin + cron 5 min,
     * una sola volta finché la chiave non cambia. Registra l'esito su mon_logs (AMLK) per diagnosi.
     */
    public static function sync_amelia_key_to_bi(): void {
        $key    = (string) get_option('if2_amelia_key', '');
        $secret = (string) get_option('if2_amelia_secret', '');
        $hotel  = (string) get_option('if2_hotel_id', '');
        if ($key === '' || $secret === '' || $hotel === '') {
            self::amlk_log('skip: key=' . ($key ? 'ok' : '∅') . ' secret=' . ($secret ? 'ok' : '∅') . ' hotel=' . ($hotel !== '' ? $hotel : '∅'));
            return;
        }
        $hash = md5($key . '|' . $secret . '|' . $hotel);
        if (get_option('if2_amelia_bi_synced', '') === $hash) return; // già inviata e invariata

        $amelia_headers = self::bi_is_approved()
            ? self::bi_headers()
            : ['Content-Type' => 'application/json', 'x-webhook-key' => 'amelia_whk_9fb7ebf37479cdfe6d2e92c503a362a6063f39050d4f9e85'];
        $amelia_body = self::bi_is_approved()
            ? ['auth_key' => $key, 'auth_secret' => $secret]
            : ['hotel_id' => $hotel, 'auth_key' => $key, 'auth_secret' => $secret];
        $resp = wp_remote_post('https://bi.in3pida.it/api/webhooks/amelia-key', [
            'headers'  => $amelia_headers,
            'body'     => wp_json_encode($amelia_body),
            'timeout'  => 15,
            'blocking' => true,
        ]);
        $code = is_wp_error($resp) ? 0 : (int) wp_remote_retrieve_response_code($resp);
        $body = is_wp_error($resp) ? $resp->get_error_message() : wp_remote_retrieve_body($resp);
        self::amlk_log(sprintf('webhook hotel=%s code=%d resp=%s', $hotel, $code, substr((string) $body, 0, 160)));
        if ($code >= 200 && $code < 300) update_option('if2_amelia_bi_synced', $hash, false);
    }

    public static function sync_mrpreno_key_to_bi(): void {
        $crm_config = (array) get_option('if2_crm_config', []);
        $api_email  = (string) ($crm_config['mrpreno']['email_api'] ?? '');
        $api_key    = (string) ($crm_config['mrpreno']['apikey']    ?? '');
        $hotel      = (string) get_option('if2_hotel_id', '');
        if ($api_email === '' || $api_key === '' || $hotel === '') return;
        $hash = md5($api_email . '|' . $api_key . '|' . $hotel);
        if (get_option('if2_mrpreno_bi_synced', '') === $hash) return;
        $mrp_headers = self::bi_is_approved()
            ? self::bi_headers()
            : ['Content-Type' => 'application/json', 'x-webhook-key' => 'amelia_whk_9fb7ebf37479cdfe6d2e92c503a362a6063f39050d4f9e85'];
        $mrp_body = self::bi_is_approved()
            ? ['api_email' => $api_email, 'api_key' => $api_key]
            : ['hotel_id' => $hotel, 'api_email' => $api_email, 'api_key' => $api_key];
        $resp = wp_remote_post('https://bi.in3pida.it/api/webhooks/mrpreno-key', [
            'headers'  => $mrp_headers,
            'body'     => wp_json_encode($mrp_body),
            'timeout'  => 15,
            'blocking' => true,
        ]);
        $code = is_wp_error($resp) ? 0 : (int) wp_remote_retrieve_response_code($resp);
        if ($code >= 200 && $code < 300) update_option('if2_mrpreno_bi_synced', $hash, false);
    }

    private static function amlk_log(string $m): void {
        if (class_exists('IF2_Telemetry')) IF2_Telemetry::log_error('AMLK ' . $m, 'debug');
    }

    /**
     * BACKFILL AUTOMATICO (cron, senza pulsanti): per le richieste VECCHIE già su Supabase scrive paese/città/regione,
     * geolocalizzando l'IP già salvato. Così anche la BI (che legge quelle colonne) vede la provenienza delle vecchie.
     * - Solo righe con IP REALE (salta il proxy 35.214.191.80 e gli IP privati: lì la geo sarebbe sbagliata).
     * - A piccoli lotti per rispettare i limiti del servizio di geolocalizzazione.
     * - Confine: solo le richieste esistenti all'attivazione (le nuove hanno già la geo scritta all'invio).
     */
    public static function geo_backfill_supabase(): void {
        global $wpdb;
        $url = get_option('if2_supabase_url', '') ?: get_option('in3pida_supabase_url', '');
        $key = function_exists('if2_decrypt')
            ? ( if2_decrypt(get_option('if2_supabase_anon_key', '')) ?: get_option('in3pida_supabase_key', '') )
            : get_option('in3pida_supabase_key', '');
        if (!$url || !$key) return;
        $tbl = IF2_DB::submissions_table();

        // Confine: solo le richieste GIÀ esistenti quando parte il backfill (le nuove hanno già la geo all'invio).
        $maxid = (int) get_option('if2_geo_bf_maxid', 0);
        if ($maxid === 0) {
            $maxid = (int) $wpdb->get_var("SELECT MAX(id) FROM {$tbl}");
            update_option('if2_geo_bf_maxid', ($maxid > 0 ? $maxid : -1), false);
        }
        if ($maxid <= 0) { self::geo_backfill_stop(); return; }

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, meta, form_id FROM {$tbl} WHERE id <= %d AND (meta IS NULL OR meta NOT LIKE %s) ORDER BY id DESC LIMIT 20",
            $maxid, '%"geo_sb"%'
        ), ARRAY_A);
        if (!$rows) { self::geo_backfill_stop(); return; } // finito → spegne il cron

        $proxy = '35.214.191.80';
        foreach ($rows as $r) {
            $meta = json_decode((string) $r['meta'], true) ?: [];
            $ip   = trim((string) ($meta['ip'] ?? ''));
            $done = true; // marca la riga come processata (per non riprovarla all'infinito)
            if ($ip !== '' && $ip !== $proxy
                && filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                $geo = self::geolocate($ip);
                if (!empty($geo['country'])) {
                    $form  = IF2_Form::get((int) $r['form_id']);
                    $table = sanitize_key(($form['config']['supabase_table'] ?? '') ?: 'form_submissions') ?: 'form_submissions';
                    $body  = ['country' => $geo['country']];
                    if (!empty($geo['city']))   $body['city']   = $geo['city'];
                    if (!empty($geo['region'])) $body['region'] = $geo['region'];
                    // PATCH della riga già presente su Supabase, individuata dall'entry_id (= id submission locale).
                    // Riga individuata da entry_id + HOTEL (+ SITO se noto): mai toccare righe di altri hotel con lo stesso numero
                    $g_hotel = ($form['config']['hotel_id'] ?? '') ?: get_option('if2_hotel_id', '');
                    $g_site  = class_exists('IF2_Telemetry') ? (string) IF2_Telemetry::site_id() : '';
                    $g_q = '?entry_id=eq.' . (int) $r['id'] . ($g_hotel !== '' ? '&hotel_id=' . rawurlencode(self::if2_hotel_in($g_hotel)) : '&hotel_id=eq.__nessuno__');
                    if ($g_site !== '') $g_q .= '&or=' . rawurlencode('(site_id.eq.' . $g_site . ',site_id.is.null)');
                    $resp = wp_remote_request(
                        trailingslashit($url) . 'rest/v1/' . $table . $g_q,
                        [
                            'method'  => 'PATCH',
                            'headers' => ['apikey' => $key, 'Authorization' => 'Bearer ' . $key, 'Content-Type' => 'application/json', 'Prefer' => 'return=minimal'],
                            'body'    => wp_json_encode($body),
                            'timeout' => 15,
                            'blocking'=> true,
                        ]
                    );
                    // Errore di rete/timeout (code 0) → NON marcare done, riprova al prossimo giro. 4xx (es. colonne
                    // mancanti) → inutile riprovare, marca done.
                    if (is_wp_error($resp) || (int) wp_remote_retrieve_response_code($resp) === 0) $done = false;
                }
            }
            if ($done) {
                $meta['geo_sb'] = 1;
                $wpdb->update($tbl, ['meta' => wp_json_encode($meta)], ['id' => (int) $r['id']]);
            }
        }
    }

    // hotel_id e le sue grafie (il BI riporta i trattini a underscore): filtro PostgREST "in.(...)"
    private static function if2_hotel_in(string $h): string {
        $v = array_values(array_unique([$h, str_replace('-', '_', $h), str_replace('_', '-', $h)]));
        return 'in.(' . implode(',', array_map(function ($x) { return '"' . str_replace('"', '', $x) . '"'; }, $v)) . ')';
    }

    private static function geo_backfill_stop(): void {
        $ts = wp_next_scheduled('if2_geo_backfill_sb');
        if ($ts) wp_unschedule_event($ts, 'if2_geo_backfill_sb');
    }

    /**
     * Reinvia una submission a Supabase: elimina il record esistente (se presente) e lo reinserisce.
     * Usato dal pulsante "Riprova" nel pannello Risposte.
     */
    public static function retry_supabase(array $form, array $data, array $meta, int $submission_id): array {
        // FASE 2: se il collegamento BI è approvato, il Riprova è un semplice rinvio — niente DELETE.
        // Il BI è idempotente: stesso entry_id + submitted_at → dup:true, nessun duplicato.
        if (self::bi_is_approved()) {
            $del_ts = (string) ($meta['integration_log']['sb_submitted_at'] ?? '');
            return self::send_bi_submission($form, $data, $meta, $submission_id, $del_ts);
        }

        $config  = $form['config'];
        $url     = get_option('if2_supabase_url', '') ?: get_option('in3pida_supabase_url', '');
        $api_key = if2_decrypt( get_option('if2_supabase_anon_key', '') ) ?: get_option('in3pida_supabase_key', '');
        if (!$url || !$api_key) return ['status' => 'disabled'];

        $table   = sanitize_key($config['supabase_table'] ?? 'form_submissions') ?: 'form_submissions';
        $headers = [
            'apikey'        => $api_key,
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type'  => 'application/json',
        ];

        $del_hotel    = ($config['hotel_id'] ?? '') ?: get_option('if2_hotel_id', '');
        // sb_submitted_at: timestamp esatto usato nell'invio originale a Supabase (salvato dalla 2.2.401).
        // - Presente → la riga esiste già in Supabase → DELETE esatto + reinsert.
        // - Assente + DB già ok → la riga c'è ma non sappiamo il timestamp → saltiamo per non fare doppioni.
        // - Assente + DB fallito → la riga non esiste → solo insert (nessun DELETE).
        $del_ts        = (string) ($meta['integration_log']['sb_submitted_at'] ?? '');
        $sb_status_ok  = (($meta['integration_log']['supabase']['status'] ?? '') === 'ok');
        if ($del_ts === '' && $sb_status_ok) {
            // Già in Supabase ma senza timestamp salvato (richiesta pre-2.2.401): non toccare per evitare doppioni.
            return ['status' => 'skipped'];
        }
        if ($del_hotel !== '' && $del_ts !== '') {
            $del_q = '?entry_id=eq.' . $submission_id
                   . '&hotel_id=' . rawurlencode(self::if2_hotel_in($del_hotel))
                   . '&submitted_at=eq.' . rawurlencode($del_ts);
            wp_remote_request(
                trailingslashit($url) . 'rest/v1/' . $table . $del_q,
                ['method' => 'DELETE', 'headers' => $headers, 'timeout' => 8]
            );
        }

        // Ricostruisce payload identico a maybe_send_supabase
        // IP: usa quello GIÀ calcolato correttamente all'invio (salta il proxy 35.214.191.80 e gli IP privati).
        // NON ricatturarlo qui col vecchio metodo: era QUESTO a salvare il proxy su Supabase.
        $ip = sanitize_text_field((string) ($meta['ip'] ?? ''));
        if ($ip === '') $ip = sanitize_text_field((string) ($_SERVER['REMOTE_ADDR'] ?? ''));

        $fields_data = [];
        $email_val   = '';
        foreach ($form['fields'] as $field) {
            if (in_array($field['type'] ?? '', ['submit', 'heading', 'html', 'page_break'], true)) continue;
            $fid    = $field['id'] ?? '';
            $flabel = trim($field['label'] ?? $fid);
            if (empty($flabel) || !array_key_exists($fid, $data)) continue;
            $val = is_array($data[$fid]) ? implode(', ', $data[$fid]) : (string) $data[$fid];

            // Privacy: NON salvare su Supabase i dati sensibili (nome/cognome, e-mail, telefono).
            if (self::if2_is_pii_field($field, $val)) continue;

            if (($field['type'] ?? '') === 'email' && $email_val === '' && $val !== '') {
                $email_val = sanitize_email($val);
            }
            $alt  = trim($field['alt_label'] ?? '');
            $fkey = $alt !== '' ? $alt : $flabel;

            if (isset($fields_data[$fkey])) {
                $fi = 2;
                while (isset($fields_data[$fkey . '_' . $fi])) $fi++;
                $fkey = $fkey . '_' . $fi;
            }
            $fields_data[$fkey] = $val;
        }

        $hotel_id = ($config['hotel_id'] ?? '') ?: get_option('if2_hotel_id', '');
        $canale   = ($config['channel']  ?? '') ?: '';

        $payload = [
            'entry_id'     => $submission_id,
            'form_id'      => $form['id'],
            'form_name'    => $form['name'] ?? '',
            'hotel_id'     => $hotel_id,
            'canale'       => $canale,
            'fields'       => $fields_data,
            // Priorità timestamp: sb_submitted_at (esatto) > created_at locale (approssimato) > ora attuale.
            'submitted_at' => $del_ts !== '' ? $del_ts
                            : ($meta['_row_created_at'] ? gmdate('c', strtotime((string) $meta['_row_created_at'])) : gmdate('c')),
            'ip'           => $ip,
            'user_agent'   => sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''),
            'domain'       => get_site_url(),
        ];
        $site_id_val = class_exists('IF2_Telemetry') ? IF2_Telemetry::site_id() : '';
        if ($site_id_val !== '') $payload['site_id'] = $site_id_val;
        if ($email_val !== '') $payload['email'] = $email_val;

        $resp = wp_remote_post(
            trailingslashit($url) . 'rest/v1/' . $table,
            [
                'headers' => array_merge($headers, ['Prefer' => 'return=minimal']),
                'body'    => wp_json_encode($payload),
                'timeout' => 15,
            ]
        );

        $code = is_wp_error($resp) ? 0 : wp_remote_retrieve_response_code($resp);

        // Se PGRST204 (colonna sconosciuta), riprova con solo le colonne base garantite
        if ( !is_wp_error($resp) && $code === 400 ) {
            $body_raw = wp_remote_retrieve_body($resp);
            if ( strpos($body_raw, 'PGRST204') !== false || strpos($body_raw, 'Could not find') !== false ) {
                $safe_keys    = ['entry_id','form_id','form_name','hotel_id','site_id','canale','fields','submitted_at','ip','user_agent','domain','email'];
                $safe_payload = array_intersect_key($payload, array_flip($safe_keys));
                $resp = wp_remote_post(
                    trailingslashit($url) . 'rest/v1/' . $table,
                    [
                        'headers' => array_merge($headers, ['Prefer' => 'return=minimal']),
                        'body'    => wp_json_encode($safe_payload),
                        'timeout' => 15,
                    ]
                );
                $code = is_wp_error($resp) ? 0 : wp_remote_retrieve_response_code($resp);
            }
        }

        $ok   = !is_wp_error($resp) && $code >= 200 && $code < 300;
        $body = $ok ? '' : (is_wp_error($resp) ? $resp->get_error_message() : wp_remote_retrieve_body($resp));
        return [
            'status'  => $ok ? 'ok' : 'error',
            'code'    => $code,
            'message' => $ok ? '' : 'HTTP ' . $code . ($body ? ': ' . substr($body, 0, 300) : ''),
        ];
    }

    public static function get_blocked_dates(int $form_id): array {
        $form = IF2_Form::get($form_id);
        if (!$form) return [];

        $dates = (array) ($form['config']['blocked_dates'] ?? []);
        return apply_filters('if2_blocked_dates', $dates, $form_id);
    }
}
