<?php
defined('ABSPATH') || exit;

class IF2_CRM {

    /**
     * Registry dei driver CRM disponibili.
     * Ogni driver aggiunge le proprie credenziali e i suoi slot campo.
     */
    public static function get_drivers(): array {
        $common_slots = [
            'checkin'     => 'Check-in (Arrivo)',
            'checkout'    => 'Check-out (Partenza)',
            'fullname'    => 'Nome e Cognome',
            'email'       => 'Email',
            'phone'       => 'Telefono',
            'adults'      => 'Adulti',
            'children'    => 'Bambini (numero)',
            'child_age_1' => 'Età bambino 1',
            'child_age_2' => 'Età bambino 2',
            'child_age_3' => 'Età bambino 3',
            'child_age_4' => 'Età bambino 4',
            'notes'       => 'Note',
            'newsletter'  => 'Newsletter (consenso)',
        ];
        $common_slots_with_treatment = $common_slots + ['treatment' => 'Trattamento'];

        return apply_filters('if2_crm_drivers', [

            'hoteldoor' => [
                'label'  => 'HotelDoor',
                'class'  => 'IF2_CRM_HotelDoor',
                'file'   => IF2_PATH . 'includes/crm/class-if2-crm-hoteldoor.php',
                'color'  => '#0ea5e9',
                'slots'  => $common_slots_with_treatment,
                'credentials' => [
                    'token'    => ['label' => 'Token API (Bearer)', 'type' => 'password', 'per_form' => false, 'placeholder' => ''],
                    'hotel_id' => ['label' => 'Hotel ID (default)',  'type' => 'text',     'per_form' => true,  'placeholder' => 'ID numerico struttura'],
                ],
            ],

            'mrpreno' => [
                'label'  => 'Mr Preno',
                'class'  => 'IF2_CRM_MrPreno',
                'file'   => IF2_PATH . 'includes/crm/class-if2-crm-mrpreno.php',
                'color'  => '#8b5cf6',
                'slots'  => $common_slots_with_treatment,
                'credentials' => [
                    'email_api'          => ['label' => 'Email API (es. hotel@mrpreno.net)', 'type' => 'text',     'per_form' => false, 'placeholder' => 'hotel@mrpreno.net'],
                    'apikey'             => ['label' => 'API Key',                            'type' => 'password', 'per_form' => false, 'placeholder' => ''],
                    'requestrefer'       => ['label' => 'URL consenso newsletter',            'type' => 'text',     'per_form' => false, 'placeholder' => 'https://tuosito.it'],
                    'source_description' => ['label' => 'Descrizione sorgente',               'type' => 'text',     'per_form' => false, 'placeholder' => 'In3pida'],
                ],
            ],

            'bedirect' => [
                'label'  => 'Be Direct',
                'class'  => 'IF2_CRM_BeDirect',
                'file'   => IF2_PATH . 'includes/crm/class-if2-crm-bedirect.php',
                'color'  => '#f59e0b',
                'slots'  => $common_slots,
                'credentials' => [
                    'hotel'        => ['label' => 'Hotel ID',      'type' => 'text',     'per_form' => true, 'placeholder' => 'es. 17278'],
                    'layout'       => ['label' => 'Layout ID',     'type' => 'text',     'per_form' => true, 'placeholder' => 'es. 12743'],
                    'widgetapikey' => ['label' => 'Widget API Key','type' => 'password', 'per_form' => true, 'placeholder' => ''],
                    'channel'      => ['label' => 'Channel ID',    'type' => 'text',     'per_form' => true, 'placeholder' => 'es. 16485'],
                ],
            ],

            'bookingdesigner' => [
                'label'  => 'Booking Designer',
                'class'  => 'IF2_CRM_BookingDesigner',
                'file'   => IF2_PATH . 'includes/crm/class-if2-crm-bookingdesigner.php',
                'color'  => '#10b981',
                'slots'  => [
                    'checkin'     => 'Check-in (Arrivo)',
                    'checkout'    => 'Check-out (Partenza)',
                    'firstname'   => 'Nome (campo separato)',
                    'lastname'    => 'Cognome (campo separato)',
                    'email'       => 'Email',
                    'phone'       => 'Telefono',
                    'adults'      => 'Adulti',
                    'children'    => 'Bambini (numero)',
                    'child_age_1' => 'Età bambino 1',
                    'child_age_2' => 'Età bambino 2',
                    'child_age_3' => 'Età bambino 3',
                    'child_age_4' => 'Età bambino 4',
                    'treatment'   => 'Trattamento (Formula)',
                    'notes'       => 'Note',
                    'newsletter'  => 'Newsletter (consenso)',
                ],
                'credentials' => [
                    'apikey'        => ['label' => 'API Key',       'type' => 'password', 'per_form' => false, 'placeholder' => ''],
                    'property_code' => ['label' => 'Property Code', 'type' => 'text',     'per_form' => true,  'placeholder' => 'es. vascelleroresort'],
                ],
            ],

            'combo' => [
                'label'  => 'Combo (Hotel.cc)',
                'class'  => 'IF2_CRM_Combo',
                'file'   => IF2_PATH . 'includes/crm/class-if2-crm-combo.php',
                'color'  => '#ec4899',
                'slots'  => $common_slots_with_treatment,
                'credentials' => [
                    'apid'           => ['label' => 'Combo ApiID (API)',  'type' => 'text',     'per_form' => true,  'placeholder' => 'es. BKP2-XCDZ-8LEF'],
                    'mvcrm_token'    => ['label' => 'Combo Token (API)',  'type' => 'password', 'per_form' => true,  'placeholder' => 'il token fornito da Combo'],
                    'smtp_host'      => ['label' => 'SMTP Host',       'type' => 'text',     'per_form' => false, 'placeholder' => 'mail.offerta-hotel.com'],
                    'smtp_user'      => ['label' => 'SMTP Username',   'type' => 'text',     'per_form' => false, 'placeholder' => 'richiesta@offerta-hotel.com'],
                    'smtp_pass'      => ['label' => 'SMTP Password',   'type' => 'password', 'per_form' => false, 'placeholder' => ''],
                    'smtp_port'      => ['label' => 'SMTP Port',       'type' => 'text',     'per_form' => false, 'placeholder' => '587'],
                    'from_email'     => ['label' => 'Email mittente',  'type' => 'text',     'per_form' => false, 'placeholder' => 'richiesta@offerta-hotel.com'],
                    'from_name'      => ['label' => 'Nome mittente',   'type' => 'text',     'per_form' => false, 'placeholder' => 'In3pida'],
                    'recipient_email'=> ['label' => 'Email Combo (destinatario)', 'type' => 'text', 'per_form' => true, 'placeholder' => 'hotel@hotel.cc'],
                    'hotel_name'     => ['label' => 'Nome hotel',      'type' => 'text',     'per_form' => true,  'placeholder' => 'es. Hotel Pinco'],
                ],
            ],

        ]);
    }

    /**
     * Esegue il dispatch verso tutti i CRM attivi per un form.
     * Ritorna log entries prefissati con 'crm_'.
     */
    public static function dispatch(array $form, array $data, array $meta, int $submission_id): array {
        $logs    = [];
        $drivers = self::get_drivers();
        $global  = get_option('if2_crm_config', []);

        // Nome del form disponibile ai driver (HotelDoor lo usa, ripulito, come utm_campaign)
        $meta['form_name'] = $form['name'] ?? ($meta['form_name'] ?? '');

        foreach ($drivers as $key => $driver) {
            $gcfg = $global[$key] ?? [];
            $fcfg = $form['config']['crm'][$key] ?? [];

            // Globale disabilitato → disabled
            if (empty($gcfg['enabled'])) {
                $logs['crm_' . $key] = ['status' => 'disabled'];
                continue;
            }
            // Per-form: il toggle comanda. Invia SOLO se attivato nel tab CRM del builder.
            // (Non attivo / mai toccato = non invia.)
            if (empty($fcfg['enabled'])) {
                $logs['crm_' . $key] = ['status' => 'disabled'];
                continue;
            }

            if (isset($driver['file']) && file_exists($driver['file'])) {
                require_once $driver['file'];
            }

            if (!class_exists($driver['class'])) {
                $logs['crm_' . $key] = ['status' => 'error', 'code' => 0, 'message' => 'driver non trovato'];
                continue;
            }

            // Mapping: globale + override per-form
            $mapping = array_merge(
                (array)($gcfg['mapping'] ?? []),
                (array)($fcfg['mapping']  ?? [])
            );

            // Credenziali: globale + override per-form
            $creds = array_merge((array)$gcfg, (array)$fcfg);

            $resolved            = self::resolve($form['fields'] ?? [], $data, $mapping);
            $logs['crm_' . $key] = call_user_func([$driver['class'], 'send'], $creds, $resolved, $meta);
        }

        return $logs;
    }

    /**
     * Risolve il mapping slot→label nei dati reali del form.
     * mapping: ['checkin' => 'Arrivo', 'email' => 'E-mail', ...]
     */
    public static function resolve(array $fields, array $data, array $mapping): array {
        // Match dell'etichetta TOLLERANTE (minuscolo, senza accenti, spazi compressi): aiuta a far combaciare
        // lo slot col campo anche con piccole differenze di scrittura. NIENTE auto-rilevamento e NIENTE
        // alterazione dei valori: il valore va al CRM grezzo, esattamente come il vecchio script che funzionava.
        $norm = function ($s) {
            return preg_replace('/\s+/', ' ', remove_accents(strtolower(trim((string) $s))));
        };

        $by_label = [];
        foreach ($fields as $field) {
            $id  = $field['id'] ?? '';
            $lbl = $norm($field['label'] ?? '');
            if ($lbl !== '' && $id) $by_label[$lbl] = $id;
        }

        $out = [];
        foreach ($mapping as $slot => $label) {
            if ((string) $label === '') continue;
            $fid        = $by_label[$norm((string) $label)] ?? null;
            $out[$slot] = ($fid !== null && array_key_exists($fid, $data)) ? $data[$fid] : '';
        }

        // AUTO-RILEVAMENTO per parole chiave (RIPRISTINATO — la sua rimozione il 23/06 aveva spento il CRM su Golf):
        // se uno slot è rimasto VUOTO (mapping mancante o etichetta non combaciante), lo trova dall'etichetta del
        // campo. NON sovrascrive mai uno slot già valorizzato dal mapping → non rompe i siti con mapping esplicito.
        $slot_keywords = [
            'treatment' => ['trattament', 'treatment', 'pensione', 'board'],
            'checkin'   => ['arriv', 'check-in', 'checkin', 'check in'],
            'checkout'  => ['partenz', 'check-out', 'checkout', 'check out'],
            'fullname'  => ['nome e cognome', 'nominativo', 'nome', 'cognome', 'name and surname', 'full name', 'first and last', 'vor- und nachname', 'name'],
            'email'     => ['email', 'e-mail', 'mail'],
            'phone'     => ['telefon', 'cellul', 'phone'],
            'adults'    => ['adult'],
            'children'  => ['bambin', 'child', 'ragazz'],
            'notes'     => ['note', 'messagg'],
        ];
        foreach ($slot_keywords as $slot => $kws) {
            if (!empty($out[$slot])) continue;
            foreach ($fields as $field) {
                $id = $field['id'] ?? '';
                if (!$id || !array_key_exists($id, $data)) continue;
                $lbl = $norm($field['label'] ?? '');
                if ($lbl === '') continue;
                foreach ($kws as $kw) {
                    if (strpos($lbl, $kw) !== false) {
                        $v = is_array($data[$id]) ? implode(', ', $data[$id]) : (string) $data[$id];
                        if (trim($v) !== '') { $out[$slot] = $v; break 2; }
                    }
                }
            }
        }

        // AUTO-RILEVAMENTO ETÀ BAMBINI: se child_age_N non è mappato, lo prende dal campo con
        // alt_label "etaN" oppure etichetta "Età N". Così tutti i bambini entrano anche senza mapping
        // manuale (bug Vibe: il primo bambino spariva perché child_age_1 non era mappato).
        foreach ([1, 2, 3, 4] as $n) {
            $slot = 'child_age_' . $n;
            if (isset($out[$slot]) && trim((string) $out[$slot]) !== '') continue;
            foreach ($fields as $field) {
                $id = $field['id'] ?? '';
                if (!$id || !array_key_exists($id, $data)) continue;
                $alt = $norm($field['alt_label'] ?? '');
                $lbl = $norm($field['label'] ?? '');
                if ($alt === 'eta' . $n || $lbl === 'eta ' . $n || $lbl === 'eta' . $n
                    || (strpos($lbl, 'eta') !== false && strpos($lbl, 'bambino') !== false && strpos($lbl, (string) $n) !== false)) {
                    $v = is_array($data[$id]) ? implode(', ', $data[$id]) : (string) $data[$id];
                    if (trim($v) !== '') { $out[$slot] = $v; break; }
                }
            }
        }

        // Trattamento: come il vecchio script (che leggeva direttamente il campo "Trattamento"),
        // se lo slot è vuoto lo prendiamo dal campo trattamento, valore GREZZO. Cerca su etichetta E alt_label,
        // con parole chiave (trattament/treatment/pensione/board). SOLO questo slot: non tocca nient'altro.
        if (empty($out['treatment'])) {
            foreach ($fields as $field) {
                $id = $field['id'] ?? '';
                if (!$id || !array_key_exists($id, $data)) continue;
                $hay = $norm(($field['label'] ?? '') . ' ' . ($field['alt_label'] ?? '') . ' ' . ($field['main_label'] ?? ''));
                if (strpos($hay, 'trattament') !== false || strpos($hay, 'treatment') !== false
                    || strpos($hay, 'pensione') !== false || strpos($hay, 'board') !== false) {
                    $v = is_array($data[$id]) ? implode(', ', $data[$id]) : (string) $data[$id];
                    if (trim($v) !== '') { $out['treatment'] = $v; break; }
                }
            }
        }

        // Ancora vuoto? Lo riconosciamo dal VALORE: solo su campi SELECT e RADIO (non testo libero),
        // così evitiamo che "colazione" in un campo "tipo camera" o note venga scambiato per il trattamento.
        if (empty($out['treatment'])) {
            $board_words = ['mezza pensione', 'pensione completa', 'bed & breakfast',
                            'bed and breakfast', 'b&b', 'camera e colazione', 'pernottamento e colazione',
                            'all inclusive', 'half board', 'full board'];
            foreach ($fields as $field) {
                if (!in_array($field['type'] ?? '', ['select', 'radio'], true)) continue;
                $id = $field['id'] ?? '';
                if (!$id || !array_key_exists($id, $data)) continue;
                $v  = is_array($data[$id]) ? implode(' ', $data[$id]) : (string) $data[$id];
                $vn = $norm($v);
                if ($vn === '') continue;
                foreach ($board_words as $w) {
                    if (strpos($vn, $w) !== false) { $out['treatment'] = trim($v); break 2; }
                }
            }
        }

        // Trattamento: se il valore rilevato è un codice opaco (es. "100", "200" — codici interni MrPreno
        // impostati nel builder come value dell'opzione), recupera l'etichetta italiana dall'opzione del campo.
        // Così map_meal_ota riceve "Camera e colazione" anche se il campo ha value="100".
        if (!empty($out['treatment'])) {
            $tv  = (string) $out['treatment'];
            $dec = fn($s) => html_entity_decode(trim((string) $s), ENT_QUOTES, 'UTF-8');
            foreach ($fields as $field) {
                if (in_array($field['type'] ?? '', ['submit', 'heading', 'html', 'page_break', 'hidden'], true)) continue;
                $id = $field['id'] ?? '';
                if (!$id || !array_key_exists($id, $data) || empty($field['options'])) continue;
                $sv = is_array($data[$id]) ? implode(', ', $data[$id]) : (string) $data[$id];
                if (trim($sv) !== $tv) continue;
                foreach ($field['options'] as $opt) {
                    $lo = $dec(is_array($opt) ? ($opt['label'] ?? '') : $opt);
                    $vo = $dec(is_array($opt) ? ($opt['value'] ?? '') : '');
                    $sr = strpos($lo, '==') !== false ? $lo : (strpos($vo, '==') !== false ? $vo : '');
                    if ($sr !== '') { [$vo_r, $lo_r] = array_map('trim', explode('==', $sr, 2)); }
                    else             { $vo_r = $vo !== '' ? $vo : $lo; $lo_r = $lo; }
                    if ($vo_r === $tv && $lo_r !== '' && $lo_r !== $tv) { $out['treatment'] = $lo_r; break 2; }
                }
                break;
            }
        }

        // NUMERO ANIMALI/CANI: rilevato dal campo con etichetta "Cani"/"Animali", messo nello slot 'pets'
        // (Booking Designer lo invia come PetsCount, dato strutturato). Additivo, non tocca gli altri slot.
        if (!isset($out['pets'])) {
            foreach ($fields as $field) {
                $id = $field['id'] ?? '';
                if (!$id || !array_key_exists($id, $data)) continue;
                $hay = $norm(($field['label'] ?? '') . ' ' . ($field['alt_label'] ?? ''));
                if ($hay !== '' && (strpos($hay, 'cani') !== false || strpos($hay, 'animali') !== false || strpos($hay, 'cane') !== false)) {
                    $pv = is_array($data[$id]) ? implode('', $data[$id]) : (string) $data[$id];
                    $pv = trim($pv);
                    if ($pv !== '' && ctype_digit($pv)) { $out['pets'] = (int) $pv; break; }
                }
            }
        }

        // CAMPI EXTRA (personalizzati: es. "Cani/animali", "Passeggino", opzioni speciali): se un campo del
        // form ha un valore e NON è finito in nessuno slot standard, aggregalo nelle Note così non va perso
        // (prima veniva scartato). Additivo: non tocca la mappatura sopra.
        $used = [];
        foreach ($out as $ov) {
            $sv = $norm(is_array($ov) ? implode(', ', $ov) : (string) $ov);
            if ($sv !== '') $used[$sv] = true;
        }
        $sys_kw = ['trattament', 'treatment', 'pensione', 'board', 'formula', 'arriv', 'check-in', 'checkin',
            'check in', 'partenz', 'check-out', 'checkout', 'check out', 'nome', 'cognome', 'nominativo',
            'email', 'e-mail', 'mail', 'telefon', 'cellul', 'phone', 'adult', 'bambin', 'child', 'ragazz',
            'note', 'messagg', 'eta', 'anni', 'privacy', 'informativa', 'newsletter', 'promo', 'selezione', 'consenso'];
        $extra = [];
        foreach ($fields as $field) {
            if (in_array($field['type'] ?? '', ['submit', 'heading', 'html', 'page_break', 'date', 'hidden'], true)) continue;
            $id = $field['id'] ?? '';
            if (!$id || !array_key_exists($id, $data)) continue;
            $v = is_array($data[$id]) ? implode(', ', $data[$id]) : (string) $data[$id];
            if (trim($v) === '') continue;
            // Salta solo se è un valore LUNGO già finito in uno slot (evita duplicati es. "Pensione completa");
            // NON i valori corti come "1" (altrimenti "Cani: 1" verrebbe scartato perché coincide con "1 bambino").
            if (strlen($norm($v)) > 3 && isset($used[$norm($v)])) continue;
            $hay = $norm(($field['label'] ?? '') . ' ' . ($field['alt_label'] ?? ''));
            $is_sys = false;
            foreach ($sys_kw as $kw) { if ($hay !== '' && strpos($hay, $kw) !== false) { $is_sys = true; break; } }
            if ($is_sys) continue;
            // Se il campo ha opzioni "valore==etichetta" (es. "<20==Fino a 20 kg"), mostra l'ETICHETTA
            // leggibile invece del valore grezzo ("<20"), su ciascun valore scelto.
            $dec = function ($s) { return html_entity_decode(trim((string) $s), ENT_QUOTES, 'UTF-8'); };
            if (!empty($field['options']) && is_array($field['options'])) {
                $chosen = is_array($data[$id]) ? $data[$id] : [$data[$id]];
                $labels = [];
                foreach ($chosen as $cv) {
                    $cv = $dec($cv);
                    $out_lbl = $cv;
                    foreach ($field['options'] as $opt) {
                        $lbl_o = $dec(is_array($opt) ? ($opt['label'] ?? '') : $opt);
                        $val_o = $dec(is_array($opt) ? ($opt['value'] ?? '') : '');
                        $src   = strpos($lbl_o, '==') !== false ? $lbl_o : (strpos($val_o, '==') !== false ? $val_o : '');
                        if ($src !== '') { $pp = explode('==', $src, 2); $ovv = trim($pp[0]); $oll = trim($pp[1]); }
                        else { $ovv = $val_o !== '' ? $val_o : $lbl_o; $oll = $lbl_o; }
                        if ($ovv === $cv) { $out_lbl = $oll; break; }
                    }
                    if (trim($out_lbl) !== '') $labels[] = $out_lbl;
                }
                if ($labels) $v = implode(', ', $labels);
            } else {
                $v = $dec($v); // decodifica eventuali entity (&lt; &amp; ...) anche senza opzioni
            }
            $lbl = trim($field['label'] ?? '');
            $extra[] = ($lbl !== '' ? $lbl . ': ' : '') . $v;
        }
        if ($extra) {
            $extra_str = implode(' | ', $extra);
            $out['notes'] = (trim((string) ($out['notes'] ?? '')) !== '')
                ? ($out['notes'] . ' | ' . $extra_str)
                : $extra_str;
        }
        return $out;
    }

    /**
     * Raccoglie tutti i label unici da tutti i form esistenti.
     * Usato per popolare i dropdown di mapping.
     * Nota: get_all() non carica la colonna fields, quindi query dedicata.
     */
    public static function all_labels(): array {
        global $wpdb;
        $rows  = $wpdb->get_results(
            "SELECT fields FROM " . IF2_DB::forms_table() . " ORDER BY id DESC",
            ARRAY_A
        ) ?: [];
        $labels = [];
        $skip   = ['submit', 'heading', 'html', 'page_break'];
        foreach ($rows as $row) {
            $fields = json_decode($row['fields'] ?? '[]', true) ?: [];
            foreach ($fields as $field) {
                if (in_array($field['type'] ?? '', $skip, true)) continue;
                $l = trim($field['label'] ?? '');
                if ($l !== '') $labels[$l] = $l;
            }
        }
        ksort($labels);
        return $labels;
    }

    /**
     * Calcola lo status aggregato di tutti i CRM attivi (worst-case).
     * Ritorna ['status', 'message', 'detail'].
     */
    public static function aggregate(array $ilog): array {
        $crm_logs = [];
        foreach ($ilog as $k => $v) {
            if (strpos($k, 'crm_') === 0) {
                $crm_logs[$k] = $v;
            }
        }

        $active = array_filter($crm_logs, fn($l) => ($l['status'] ?? 'disabled') !== 'disabled');

        if (empty($active)) {
            return ['status' => 'disabled'];
        }

        $priority = ['error' => 5, 'pending' => 4, 'info' => 3, 'skipped' => 2, 'ok' => 1];
        $worst    = 'ok';
        $msgs     = [];

        foreach ($active as $k => $log) {
            $s    = $log['status'] ?? 'disabled';
            $code = (int) ($log['code'] ?? 0);
            // HotelDoor (e simili) rispondono 5xx pur SALVANDO la richiesta: se il dato è entrato,
            // mostriamo "ok" (verde) anche per i log vecchi salvati come errore. Errore reale solo su 4xx/connessione.
            if ($s === 'error' && $code >= 500) $s = 'ok';
            if (($priority[$s] ?? 0) > ($priority[$worst] ?? 0)) {
                $worst = $s;
            }
            $driver = strtoupper(str_replace('crm_', '', $k));
            $codestr = $code ? ' HTTP ' . $code : '';
            $msg    = isset($log['message']) && $log['message'] ? ' — ' . $log['message'] : '';
            $msgs[] = $driver . ': ' . $s . $codestr . $msg;
        }

        return [
            'status'  => $worst,
            'message' => implode(' | ', $msgs),
            'detail'  => $active,
        ];
    }
}
