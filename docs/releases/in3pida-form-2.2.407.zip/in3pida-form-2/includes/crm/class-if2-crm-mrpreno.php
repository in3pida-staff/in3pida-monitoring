<?php
defined('ABSPATH') || exit;

class IF2_CRM_MrPreno {

    const ENDPOINT = 'https://api.mrpreno.net/api/insertCustomerRequest';

    public static function send(array $creds, array $fields, array $meta): array {
        $email_api  = trim($creds['email_api'] ?? '');
        $apikey     = trim($creds['apikey']    ?? '');

        if (!$email_api || !$apikey) {
            return ['status' => 'error', 'code' => 0, 'message' => 'email_api o apikey mancanti'];
        }

        $checkin  = self::fmt_date($fields['checkin']  ?? '');
        $checkout = self::fmt_date($fields['checkout'] ?? '');

        $full  = trim($fields['fullname'] ?? '');
        $space = strpos($full, ' ');
        $nome    = $space !== false ? substr($full, 0, $space) : $full;
        $cognome = $space !== false ? substr($full, $space + 1) : '';

        $newsletter   = filter_var($fields['newsletter'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $requestrefer = trim($creds['requestrefer'] ?? '');
        $source_desc  = trim($creds['source_description'] ?? 'In3pida');
        $lang         = substr(get_locale(), 0, 2);

        $channel  = $meta['channel'] ?? '';
        [$sorgente, $preno_source] = self::channel_map($channel);
        // Campagna = eventuale campagna esplicita, altrimenti il NOME DEL FORM (come su HotelDoor),
        // così in Mr Preno si vede da quale form/campagna arriva la richiesta. Fallback '*'.
        $campaign = trim($meta['campaign'] ?? '');
        if ($campaign === '' || $campaign === '*') {
            $form_name = trim($meta['form_name'] ?? '');
            if ($form_name !== '') $campaign = $form_name;
        }
        if ($campaign === '') $campaign = '*';

        $source_desc .= ' - ' . $sorgente . ' - ' . $campaign;

        // Trattamento: lo mettiamo nelle annotazioni (visibile) e in una variabile dedicata. Il valore è
        // catturato da IF2_CRM::resolve() anche senza mappatura esplicita (per etichetta/valore).
        $tratt     = trim((string) ($fields['treatment'] ?? ''));
        $meal_code = $tratt !== '' ? self::map_meal_ota($tratt) : '';
        $annotations = trim((string) ($fields['notes'] ?? ''));

        $adults = max(1, (int)($fields['adults'] ?? 1));
        $occupazione = [['occupant_qty' => $adults, 'ota_code' => 10]];

        $children = (int)($fields['children'] ?? 0);
        if ($children > 0) {
            foreach (['child_age_1', 'child_age_2', 'child_age_3', 'child_age_4'] as $slot) {
                $eta = trim((string)($fields[$slot] ?? ''));
                if ($eta === '' || $eta === null) continue;
                if ($eta === '<1') $eta = '0';
                $occupazione[] = ['occupant_qty' => 1, 'ota_code' => 8, 'age' => (int)$eta];
            }
        }

        $payload = [
            'Email'  => $email_api,
            'ApiKey' => $apikey,
            'Customer' => [
                'name'                      => $nome,
                'lastname'                  => $cognome,
                'email'                     => $fields['email']  ?? '',
                'phone'                     => $fields['phone']  ?? '',
                'language'                  => $lang,
                'newsletter_optin'          => $newsletter,
                'newsletter_source_consent' => $requestrefer,
            ],
            'Request' => [
                'arrival_date'             => $checkin,
                'departure_date'           => $checkout,
                'LivingsUnit'              => [['Occupants' => $occupazione]],
                'source_type_section_code' => $preno_source,
                'source_type_code'         => $source_desc,
                'annotations'              => $annotations,
                'CustomerRequestVariable'  => [
                    'campagna'    => $campaign,
                    'sorgente'    => $sorgente,
                    'referral'    => $requestrefer,
                    'trattamento' => $tratt,
                ],
                'attribution' => $meta['attribution'] ?? '',
            ],
        ];

        if ($meal_code !== '') {
            $payload['Request']['accommodation_ota_code'] = $meal_code;
        }

        $resp = wp_remote_post(self::ENDPOINT, [
            'headers' => ['Content-Type' => 'application/json', 'cache-control' => 'no-cache'],
            'body'    => wp_json_encode($payload),
            'timeout' => 8,
            'blocking'=> true,
        ]);

        if (is_wp_error($resp)) {
            return ['status' => 'error', 'code' => 0, 'message' => $resp->get_error_message()];
        }

        $code = wp_remote_retrieve_response_code($resp);
        $ok   = $code >= 200 && $code < 300;
        return [
            'status'  => $ok ? 'ok' : 'error',
            'code'    => $code,
            'message' => $ok ? '' : substr(wp_remote_retrieve_body($resp), 0, 200),
        ];
    }

    private static $ota_labels = [
        '1'  => 'All Inclusive',
        '3'  => 'Pernottamento e Colazione',
        '10' => 'Pensione Completa',
        '12' => 'Mezza Pensione',
        '14' => 'Solo Pernottamento',
    ];

    // Mappa il trattamento al codice OTA di Mr Preno.
    // Accetta sia codici OTA numerici diretti (1/3/10/12/14) sia etichette testuali.
    private static function map_meal_ota(string $tratt): string {
        $t = strtolower(trim($tratt));
        if ($t === '') return '14';
        if (isset(self::$ota_labels[$t])) return $t;
        if (strpos($t, 'pensione completa') !== false || strpos($t, 'full board') !== false) return '10';
        if (strpos($t, 'mezza pensione')    !== false || strpos($t, 'half board') !== false) return '12';
        if (strpos($t, 'all inclusive')     !== false || strpos($t, 'tutto incluso') !== false) return '1';
        if (strpos($t, 'bed')        !== false || strpos($t, 'b&b')        !== false
            || strpos($t, 'breakfast') !== false || strpos($t, 'colazione') !== false
            || strpos($t, 'pernottamento') !== false) return '3';
        return '14';
    }

    private static function fmt_date(string $d): string {
        if (preg_match('/^(\d{2})\/(\d{2})\/(\d{4})$/', $d, $m)) {
            return $m[3] . '-' . $m[2] . '-' . $m[1];
        }
        return $d;
    }

    private static function channel_map(string $ch): array {
        $map = [
            'fb'         => ['facebook',           'social-facebook-ads'],
            'Meta'       => ['facebook',           'social-facebook-ads'],
            'ads'        => ['google-ads',         'paid-search-google-ads'],
            'Google Ads' => ['google-ads',         'paid-search-google-ads'],
            'nl'         => ['newsletter',          'newsletter'],
            'Newsletter' => ['newsletter',          'newsletter'],
            'rmk'        => ['google-remarketing', 'paid-search-google-ads'],
            'web'        => ['sito',               'sito-ufficiale'],
            'Sito'       => ['sito',               'sito-ufficiale'],
            'landing'    => ['landing',             'sito-ufficiale'],
        ];
        return $map[$ch] ?? [$ch ?: 'sito', 'sito-ufficiale'];
    }
}
