<?php
defined('ABSPATH') || exit;

class IF2_CRM_HotelDoor {

    const ENDPOINT = 'https://hub.hoteldoor.it/api/v1/request/add';

    public static function send(array $creds, array $fields, array $meta): array {
        $token    = trim($creds['token'] ?? '');
        $hotel_id = (int)($creds['hotel_id'] ?? 0);

        if (!$token || !$hotel_id) {
            return ['status' => 'error', 'code' => 0, 'message' => 'token o hotel_id mancanti'];
        }

        // Date DD/MM/YYYY → YYYY-MM-DD. Mandiamo ESATTAMENTE quello che ha scritto il cliente:
        // NON inventiamo/scambiamo le date (un typo non è correggibile a indovinare). Le date assurde
        // sono bloccate a monte dalla validazione del form; quelle vecchie già arrivate si gestiscono a mano.
        $checkin  = self::convert_date($fields['checkin']  ?? '');
        $checkout = self::convert_date($fields['checkout'] ?? '');

        // Nome → first + last
        $full  = trim($fields['fullname'] ?? '');
        $space = strpos($full, ' ');
        $first = $space !== false ? substr($full, 0, $space) : '';
        $last  = $space !== false ? substr($full, $space + 1) : $full;

        // Bambini
        $children = [];
        foreach (['child_age_1', 'child_age_2', 'child_age_3', 'child_age_4'] as $slot) {
            $age = $fields[$slot] ?? '';
            if ($age === '' || $age === null) continue;
            $children[] = $age === '-1' ? 0 : (int)$age;
        }

        $newsletter = filter_var($fields['newsletter'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $lang       = substr(get_locale(), 0, 2);

        // RequestReferer costruito ESATTAMENTE come il vecchio hd-insert.php (che HotelDoor accetta):
        //   https://<dominio>/<campagna>?utm_source=...&utm_medium=...&utm_campaign=<campagna>
        // NIENTE source_url lunga della landing (gclid & co.): quella mandava HotelDoor in HTTP 500.
        $channel = $meta['channel'] ?? '';
        [$src, $medium] = self::channel_utm($channel);
        $host    = wp_parse_url(get_site_url(), PHP_URL_HOST) ?: (string) ($_SERVER['SERVER_NAME'] ?? '');
        $form_name = trim($meta['form_name'] ?? '');
        $campaign  = $form_name !== '' ? sanitize_title($form_name) : sanitize_title($channel);
        $referer   = 'https://' . $host;
        if ($src && $campaign !== '') {
            $referer .= '/' . rawurlencode($campaign)
                      . '?utm_source='   . rawurlencode($src)
                      . '&utm_medium='   . rawurlencode($medium)
                      . '&utm_campaign=' . rawurlencode($campaign);
        }

        $occupancy = ['AdultsCount' => max(1, (int)($fields['adults'] ?? 1))];
        if (!empty($children)) {
            $occupancy['ChildrenAgeArray'] = $children;
        }

        // Trattamento: a BoardBasis va un valore PULITO che HotelDoor accetta (altrimenti rifiuta TUTTA la
        // richiesta), mentre il testo completo scelto dal cliente va nelle note → la richiesta entra E il
        // trattamento si vede sempre.
        $tratt = trim((string) ($fields['treatment'] ?? ''));
        $board = self::map_board($tratt); // '' se sconosciuto (così HotelDoor non scarta la richiesta)
        $notes = trim((string) ($fields['notes'] ?? ''));
        $guest_notes = $notes;
        if ($tratt !== '') {
            $guest_notes = ($notes !== '' ? $notes . ' — ' : '') . 'Trattamento: ' . $tratt;
        }

        $payload = [
            'StayRequest' => [
                'Key'              => null,
                'ReceivedDateTime' => current_time('Y-m-d\TH:i'), // come hd-insert.php: al minuto, SENZA secondi (HotelDoor lo vuole così)
                'CheckIn'          => $checkin,
                'CheckOut'         => $checkout,
                'HotelsId'         => [$hotel_id],
                'GuestNotes'       => $guest_notes,
                'RequestReferer'   => $referer,
                'RoomsDetails'     => [[
                    'BoardBasis' => $board, // valore PULITO (es. "Mezza Pensione"); il testo completo è nelle note
                    'Occupancy'  => $occupancy,
                ]],
            ],
            'Contact' => [
                'Key'                    => null,
                'Email'                  => $fields['email'] ?? '',
                'Language'               => $lang,
                'FirstName'              => $first,
                'LastName'               => $last,
                'MobilePhone'            => $fields['phone'] ?? '',
                'NewsletterSubscription' => $newsletter,
            ],
        ];

        $resp = wp_remote_post(self::ENDPOINT, [
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $token,
            ],
            'body'    => wp_json_encode($payload),
            'timeout' => 8,
            'blocking'=> true,
        ]);

        if (is_wp_error($resp)) {
            return ['status' => 'error', 'code' => 0, 'message' => $resp->get_error_message()];
        }

        $code = wp_remote_retrieve_response_code($resp);
        // HotelDoor SALVA la richiesta ma a volte risponde 500: come il vecchio hd-insert.php (che ignorava i 5xx),
        // trattiamo i 5xx come "entrata OK". Errore reale solo su 4xx. Così i pallini riflettono il dato realmente entrato.
        $ok    = ($code >= 200 && $code < 400) || $code >= 500;
        // Diagnostico: in caso di errore mostriamo anche le DATE e il trattamento spediti, così si capisce
        // subito se il problema è una data vuota/sbagliata o il BoardBasis.
        $diag  = 'CheckIn=' . $checkin . ' CheckOut=' . $checkout . ' Tratt=«' . $tratt . '»';
        return [
            'status'  => $ok ? 'ok' : 'error',
            'code'    => $code,
            'message' => $ok
                ? '' // entrato: nessun testo diagnostico (mostra solo "ENTRATO", pulito)
                : (substr(wp_remote_retrieve_body($resp), 0, 160) . ' [' . $diag . ']'),
        ];
    }

    /**
     * Converte una data in YYYY-MM-DD (il formato che HotelDoor accetta davvero: con "28-06-2026" rispondeva
     * "CheckIn - The field [non valido]"). Accetta vari formati in ingresso e li normalizza tutti a YYYY-MM-DD.
     */
    private static function convert_date(string $date): string {
        $date = trim($date);
        if ($date === '') return '';
        $date = preg_replace('/\s+/', '', $date); // togli spazi interni (es. "01 /08/26" → "01/08/26")
        if (preg_match('#^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$#', $date, $m)) {   // GG/MM/AAAA (anno 4 cifre)
            return sprintf('%04d-%02d-%02d', (int) $m[3], (int) $m[2], (int) $m[1]);
        }
        if (preg_match('#^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2})$#', $date, $m)) {   // GG/MM/AA (anno 2 cifre) → 20AA-MM-GG
            // Esplicito come data ITALIANA (giorno prima): strtotime interpreterebbe "/" all'americana (m/g/a) → data sbagliata.
            return sprintf('20%02d-%02d-%02d', (int) $m[3], (int) $m[2], (int) $m[1]);
        }
        if (preg_match('#^(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})$#', $date, $m)) {     // AAAA-MM-GG
            return sprintf('%04d-%02d-%02d', (int) $m[1], (int) $m[2], (int) $m[3]);
        }
        $ts = strtotime($date);
        return $ts ? gmdate('Y-m-d', $ts) : $date;
    }

    /** Trattamento → valore pulito che HotelDoor accetta. '' se sconosciuto (così non scarta la richiesta). */
    private static function map_board(string $t): string {
        $n = remove_accents(strtolower(trim($t)));
        if ($n === '') return '';
        // "all inclusive" PRIMA di "mezza pensione": così "Mezza pensione all inclusive" → All Inclusive (non Mezza Pensione).
        if (strpos($n, 'all inclusive') !== false)                                            return 'All Inclusive';
        if (strpos($n, 'pensione completa') !== false || strpos($n, 'full board') !== false) return 'Pensione Completa';
        if (strpos($n, 'mezza pensione') !== false   || strpos($n, 'half board') !== false) return 'Mezza Pensione';
        if (strpos($n, 'bed & breakfast') !== false || strpos($n, 'bed and breakfast') !== false
            || strpos($n, 'b&b') !== false || strpos($n, 'breakfast') !== false || strpos($n, 'colazione') !== false) return 'Bed & Breakfast';
        if (strpos($n, 'pensione') !== false) return 'Mezza Pensione';
        return ''; // sconosciuto → vuoto
    }

    private static function channel_utm(string $ch): array {
        // Mappatura case-insensitive (il canale può arrivare come "GOOGLE ADS", "Fb", "NL", ecc.)
        $map = [
            'fb'           => ['facebook',           'social'],
            'meta'         => ['facebook',           'social'],
            'facebook'     => ['facebook',           'social'],
            'ads'          => ['google-adwords',     'ppc'],
            'google ads'   => ['google-adwords',     'ppc'],
            'google-ads'   => ['google-adwords',     'ppc'],
            'adwords'      => ['google-adwords',     'ppc'],
            'nl'           => ['newsletter',         'email'],
            'newsletter'   => ['newsletter',         'email'],
            'rmk'          => ['google-remarketing', 'ppc'],
            'remarketing'  => ['google-remarketing', 'ppc'],
            'web'          => ['Sito',               'organic'],
            'sito'         => ['Sito',               'organic'],
            'landing'      => ['landing',            'landing'],
        ];
        $key = strtolower(trim($ch));
        // Fallback URL-safe: niente spazi/caratteri strani nell'utm_source (avrebbero rotto l'URL).
        return $map[$key] ?? [($ch !== '' ? sanitize_title($ch) : ''), 'referral'];
    }
}
