<?php
defined('ABSPATH') || exit;

/**
 * Iperbooking — API Richieste v1 (SaveRequest.cfm), formato "Standard":
 * date yyyymmdd, boardType in sigla (AI/FB/HB/BB), una camera con adulti + età bambini.
 * Risposta OK = {"id": N}; errore = {"error": "...", ...}.
 */
class IF2_CRM_Iperbooking {

    public static function send(array $creds, array $fields, array $meta): array {
        $idhotel  = (int) trim((string) ($creds['idhotel'] ?? ''));
        $username = trim((string) ($creds['username'] ?? ''));
        $password = trim((string) ($creds['password'] ?? ''));
        if (!$idhotel || $username === '' || $password === '') {
            return ['status' => 'error', 'code' => 0, 'message' => 'ID hotel, username o password mancanti'];
        }

        $email = trim($fields['email'] ?? '');
        if ($email === '') {
            return ['status' => 'error', 'code' => 0, 'message' => 'email cliente mancante'];
        }

        $first = trim($fields['firstname'] ?? '');
        $last  = trim($fields['lastname']  ?? '');
        if ($first === '' && $last === '') {
            $full  = trim($fields['fullname'] ?? '');
            $space = strpos($full, ' ');
            $first = $space !== false ? substr($full, 0, $space) : $full;
            $last  = $space !== false ? trim(substr($full, $space + 1)) : '';
        }
        if ($first === '') $first = '.';
        if ($last === '')  $last  = '.';

        $adults   = max(1, (int) ($fields['adults'] ?? 1));
        $children = max(0, (int) ($fields['children'] ?? 0));
        $ages = [];
        foreach (['child_age_1', 'child_age_2', 'child_age_3', 'child_age_4'] as $slot) {
            $eta = trim((string) ($fields[$slot] ?? ''));
            if ($eta !== '' && preg_match('/\d+/', $eta, $m)) $ages[] = (int) $m[0];
        }
        // Iperbooking conta i bambini dalle età: se il form non le chiede, mette 0 per ciascuno.
        while (count($ages) < $children) $ages[] = 0;

        $treatment = trim($fields['treatment'] ?? '');
        $board     = self::board_code($treatment);

        $notes = [];
        if (trim($fields['notes'] ?? '') !== '') $notes[] = trim($fields['notes']);
        if ($treatment !== '' && $board === '')  $notes[] = 'Trattamento: ' . $treatment;

        $lang = $meta['lang'] ?? '';
        if ($lang === '') $lang = substr(get_locale(), 0, 2);

        $payload = [
            'idhotel'    => $idhotel,
            'username'   => $username,
            'password'   => $password,
            'email'      => $email,
            'firstname'  => $first,
            'lastname'   => $last,
            'phone'      => trim($fields['phone'] ?? ''),
            'request'    => implode("\n", $notes),
            'language'   => strtolower(substr($lang, 0, 2)),
            'source'     => trim((string) ($creds['source'] ?? '')) ?: 'Sito',
            'newsletter' => filter_var($fields['newsletter'] ?? false, FILTER_VALIDATE_BOOLEAN) ? 1 : 0,
        ];
        $arrival   = self::to_ymd($fields['checkin']  ?? '');
        $departure = self::to_ymd($fields['checkout'] ?? '');
        if ($arrival !== '' && $departure !== '') {
            $payload['arrival']   = $arrival;
            $payload['departure'] = $departure;
            if ($board !== '') $payload['boardType'] = $board;
            $payload['rooms'] = [['adults' => $adults, 'children' => $ages]];
        }

        $resp = wp_remote_post('https://api.iperbooking.net/v1/SaveRequest.cfm', [
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode($payload),
            'timeout' => 15,
        ]);
        if (is_wp_error($resp)) {
            return ['status' => 'error', 'code' => 0, 'message' => $resp->get_error_message()];
        }
        $code = (int) wp_remote_retrieve_response_code($resp);
        $body = trim(wp_remote_retrieve_body($resp));
        $json = json_decode($body, true);

        // Successo solo se arriva l'id della richiesta e nessun errore (HTTP 200 da solo non basta).
        $ok = $code >= 200 && $code < 300 && is_array($json) && !empty($json['id']) && empty($json['error']);
        if ($ok) return ['status' => 'ok', 'code' => $code, 'message' => 'id ' . $json['id']];

        $msg = is_array($json) && !empty($json['error']) ? (string) $json['error'] : ($body !== '' ? $body : 'HTTP ' . $code);
        return ['status' => 'error', 'code' => $code, 'message' => substr($msg, 0, 300)];
    }

    /** Converte dd/mm/yyyy (o altro formato data) in yyyymmdd. */
    private static function to_ymd(string $d): string {
        $d = trim($d);
        if ($d === '') return '';
        if (preg_match('#^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$#', $d, $m)) {
            return $m[3] . str_pad($m[2], 2, '0', STR_PAD_LEFT) . str_pad($m[1], 2, '0', STR_PAD_LEFT);
        }
        $ts = strtotime($d);
        return $ts ? date('Ymd', $ts) : '';
    }

    /** Mappa il trattamento nella sigla Iperbooking (AI/FB/HB/BB); vuoto se non riconosciuto. */
    private static function board_code(string $t): string {
        $t = strtolower(remove_accents(trim($t)));
        if ($t === '') return '';
        if (strpos($t, 'all inclusive') !== false || strpos($t, 'tutto incluso') !== false) return 'AI';
        if (strpos($t, 'pensione completa') !== false || strpos($t, 'full board') !== false
            || strpos($t, 'vollpension') !== false)                                          return 'FB';
        if (strpos($t, 'mezza pensione') !== false || strpos($t, 'half board') !== false
            || strpos($t, 'halbpension') !== false)                                          return 'HB';
        if (strpos($t, 'colazione') !== false || strpos($t, 'b&b') !== false
            || strpos($t, 'breakfast') !== false || strpos($t, 'fruhstuck') !== false)      return 'BB';
        return '';
    }
}
