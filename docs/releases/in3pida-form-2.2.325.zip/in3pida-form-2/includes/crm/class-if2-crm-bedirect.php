<?php
defined('ABSPATH') || exit;

class IF2_CRM_BeDirect {

    const ENDPOINT = 'https://bedirect.bookingexpert.it/beacr/ws/customerRequestApi';

    // Age group IDs hardcoded (BookingExpert standard IT)
    const AGE_RANGES = [
        [0,  2,  '16907'],
        [3,  5,  '16906'],
        [6,  10, '20859'],
        [11, 15, '20860'],
    ];
    const ADULT_TYPE_ID = '16905';

    public static function send(array $creds, array $fields, array $meta): array {
        $hotel      = trim($creds['hotel']        ?? '');
        $layout     = trim($creds['layout']       ?? '');
        $apikey     = trim($creds['widgetapikey'] ?? '');
        $channel_id = trim($creds['channel']      ?? '');

        if (!$hotel || !$layout || !$apikey) {
            return ['status' => 'error', 'code' => 0, 'message' => 'hotel, layout o widgetapikey mancanti'];
        }

        $checkin  = self::fmt_date($fields['checkin']  ?? '');
        $checkout = self::fmt_date($fields['checkout'] ?? '');

        $full    = trim($fields['fullname'] ?? '');
        $space   = strpos($full, ' ');
        $nome    = $space !== false ? substr($full, 0, $space) : $full;
        $cognome = $space !== false ? trim(substr($full, $space + 1)) : '.';
        if ($cognome === '') $cognome = '.';

        $newsletter = (trim((string)($fields['newsletter'] ?? '')) === '1')
            ? 'Consenso marketing'
            : 'Non consenso marketing';

        $channel_key = $meta['channel'] ?? '';
        [$sorgente, $medium] = self::channel_map($channel_key);
        // Campagna = vero utm_campaign dell'URL di provenienza (come il vecchio script); fallback "Diretta".
        $campaign = $meta['campaign'] ?? '';
        if ($campaign === '' && ($qs = parse_url($meta['source_url'] ?? '', PHP_URL_QUERY))) {
            parse_str($qs, $utm_q);
            if (!empty($utm_q['utm_campaign'])) $campaign = sanitize_text_field($utm_q['utm_campaign']);
        }
        if ($campaign === '') $campaign = 'Diretta';
        $lang     = substr(get_locale(), 0, 2);

        $request  = $campaign . ' - ' . $sorgente . ' - ' . $lang;
        $request .= ' | Note del Cliente: ' . ($fields['notes'] ?? '');
        $request .= ' | ' . $newsletter;

        $adults = max(1, (int)($fields['adults'] ?? 1));
        $guests = [
            ['id' => self::ADULT_TYPE_ID, 'quantity' => (string)$adults, 'ages' => []],
        ];

        $children = (int)($fields['children'] ?? 0);
        if ($children > 0) {
            $by_range = [];
            foreach (['child_age_1', 'child_age_2', 'child_age_3', 'child_age_4'] as $slot) {
                $eta = trim((string)($fields[$slot] ?? ''));
                if ($eta === '') continue;
                $age = ($eta === '<1') ? 0 : (int)$eta;
                $id  = self::age_to_id($age);
                if ($id === null) continue;
                if (!isset($by_range[$id])) {
                    $by_range[$id] = ['id' => $id, 'quantity' => 0, 'ages' => []];
                }
                $by_range[$id]['quantity']++;
                $by_range[$id]['ages'][] = $age;
            }
            foreach ($by_range as $group) {
                $group['quantity'] = (string)$group['quantity'];
                $guests[] = $group;
            }
        }

        $postfields = [
            'hotel'        => $hotel,
            'layout'       => $layout,
            'widgetapikey' => $apikey,
            'firstname'    => $nome,
            'lastname'     => $cognome,
            'email'        => $fields['email'] ?? '',
            'phone'        => $fields['phone'] ?? '',
            'request'      => $request,
            'checkin'      => $checkin,
            'checkout'     => $checkout,
            'channel'      => $channel_id,
            'guesttypes'   => wp_json_encode($guests),
        ];

        $resp = wp_remote_post(self::ENDPOINT, [
            'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
            'body'    => $postfields,
            'timeout' => 15,
            'blocking'=> true,
        ]);

        if (is_wp_error($resp)) {
            return ['status' => 'error', 'code' => 0, 'message' => $resp->get_error_message()];
        }

        $code = wp_remote_retrieve_response_code($resp);
        $body = wp_remote_retrieve_body($resp);
        $json = json_decode($body, true);
        $ok   = $code >= 200 && $code < 300 && ($json['response'] ?? '') === 'ok';

        return [
            'status'  => $ok ? 'ok' : 'error',
            'code'    => $code,
            'message' => $ok ? '' : ($json['error'] ?? substr($body, 0, 200)),
        ];
    }

    private static function age_to_id(int $age): ?string {
        foreach (self::AGE_RANGES as [$min, $max, $id]) {
            if ($age >= $min && $age <= $max) return $id;
        }
        return null;
    }

    private static function fmt_date(string $d): string {
        if (preg_match('/^(\d{2})\/(\d{2})\/(\d{4})$/', $d, $m)) {
            return $m[3] . '-' . $m[2] . '-' . $m[1];
        }
        return $d;
    }

    private static function channel_map(string $ch): array {
        $map = [
            'fb'         => ['facebook',           'social'],
            'Meta'       => ['facebook',           'social'],
            'ads'        => ['google-adwords',     'ppc'],
            'Google Ads' => ['google-adwords',     'ppc'],
            'nl'         => ['newsletter',          'email'],
            'Newsletter' => ['newsletter',          'email'],
            'rmk'        => ['google-remarketing', 'ppc'],
            'web'        => ['Sito',               'organic'],
            'Sito'       => ['Sito',               'organic'],
            'landing'    => ['landing',             'landing'],
        ];
        return $map[$ch] ?? [$ch ?: 'Sito', 'organic'];
    }
}
