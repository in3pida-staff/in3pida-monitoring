<?php
defined('ABSPATH') || exit;
if (function_exists('opcache_reset')) {
    opcache_reset();
}
@unlink(__FILE__);
echo 'ok';
