<?php
defined('ABSPATH') || exit;

class IF2_DB {

    const TABLE_FORMS       = 'if2_forms';
    const TABLE_SUBMISSIONS = 'if2_submissions';
    const TABLE_FILES       = 'if2_files';
    const TABLE_STATS       = 'if2_stats';

    public static function forms_table(): string {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_FORMS;
    }

    public static function submissions_table(): string {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_SUBMISSIONS;
    }

    public static function files_table(): string {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_FILES;
    }

    public static function stats_table(): string {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_STATS;
    }

    public static function install(): void {
        global $wpdb;
        $c = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta("CREATE TABLE " . self::forms_table() . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  name varchar(255) NOT NULL DEFAULT '',
  fields longtext NOT NULL,
  config longtext NOT NULL,
  created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id)
) $c;");

        dbDelta("CREATE TABLE " . self::submissions_table() . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  form_id bigint(20) unsigned NOT NULL DEFAULT 0,
  data longtext NOT NULL,
  meta longtext NOT NULL,
  created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY form_id (form_id)
) $c;");

        dbDelta("CREATE TABLE " . self::files_table() . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  submission_id bigint(20) unsigned NULL,
  form_id bigint(20) unsigned NOT NULL DEFAULT 0,
  field_id varchar(100) NOT NULL DEFAULT '',
  filename varchar(255) NOT NULL DEFAULT '',
  file_url varchar(1000) NOT NULL DEFAULT '',
  file_path varchar(1000) NOT NULL DEFAULT '',
  mime_type varchar(100) NOT NULL DEFAULT '',
  file_size bigint(20) unsigned NOT NULL DEFAULT 0,
  created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY form_id (form_id),
  KEY submission_id (submission_id)
) $c;");

        // Garantisce che fields e config abbiano sempre un valore valido
        $wpdb->query( "UPDATE " . self::forms_table() . " SET fields = '[]' WHERE fields = '' OR fields IS NULL" );
        $wpdb->query( "UPDATE " . self::forms_table() . " SET config = '{}' WHERE config = '' OR config IS NULL" );

        dbDelta("CREATE TABLE " . self::stats_table() . " (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  form_id bigint(20) unsigned NOT NULL DEFAULT 0,
  event varchar(20) NOT NULL DEFAULT 'view',
  created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY  (id),
  KEY form_id (form_id),
  KEY event (event)
) $c;");

        update_option('if2_db_version', IF2_VERSION);
    }

    public static function deactivate(): void {
        // Mantieni i dati alla disattivazione
    }
}
