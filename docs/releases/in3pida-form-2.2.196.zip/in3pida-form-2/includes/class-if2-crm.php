<?php
defined('ABSPATH') || exit;

class IF2_CRM {

    /**
     * Registry dei driver CRM disponibili.
     * Ogni driver aggiunge le proprie credenziali e i suoi slot campo.
     */
    public static function get_drivers(): array {
        $common_slots = [
            'checkin'     => 'Check-in (Arrivo)',
            'checkout'    => 'Check-out (Partenza)',
            'fullname'    => 'Nome e Cognome',
            'email'       => 'Email',
            'phone'       => 'Telefono',
            'adults'      => 'Adulti',
            'children'    => 'Bambini (numero)',
            'child_age_1' => 'Età bambino 1',
            'child_age_2' => 'Età bambino 2',
            'child_age_3' => 'Età bambino 3',
            'child_age_4' => 'Età bambino 4',
            'notes'       => 'Note',
            'newsletter'  => 'Newsletter (consenso)',
        ];
        $common_slots_with_treatment = $common_slots + ['treatment' => 'Trattamento'];

        return apply_filters('if2_crm_drivers', [

            'hoteldoor' => [
                'label'  => 'HotelDoor',
                'class'  => 'IF2_CRM_HotelDoor',
                'file'   => IF2_PATH . 'includes/crm/class-if2-crm-hoteldoor.php',
                'color'  => '#0ea5e9',
                'slots'  => $common_slots_with_treatment,
                'credentials' => [
                    'token'    => ['label' => 'Token API (Bearer)', 'type' => 'password', 'per_form' => false, 'placeholder' => ''],
                    'hotel_id' => ['label' => 'Hotel ID (default)',  'type' => 'text',     'per_form' => true,  'placeholder' => 'ID numerico struttura'],
                ],
            ],

            'mrpreno' => [
                'label'  => 'Mr Preno',
                'class'  => 'IF2_CRM_MrPreno',
                'file'   => IF2_PATH . 'includes/crm/class-if2-crm-mrpreno.php',
                'color'  => '#8b5cf6',
                'slots'  => $common_slots,
                'credentials' => [
                    'email_api'          => ['label' => 'Email API (es. hotel@mrpreno.net)', 'type' => 'text',     'per_form' => false, 'placeholder' => 'hotel@mrpreno.net'],
                    'apikey'             => ['label' => 'API Key',                            'type' => 'password', 'per_form' => false, 'placeholder' => ''],
                    'requestrefer'       => ['label' => 'URL consenso newsletter',            'type' => 'text',     'per_form' => false, 'placeholder' => 'https://tuosito.it'],
                    'source_description' => ['label' => 'Descrizione sorgente',               'type' => 'text',     'per_form' => false, 'placeholder' => 'In3pida'],
                ],
            ],

            'bedirect' => [
                'label'  => 'Be Direct',
                'class'  => 'IF2_CRM_BeDirect',
                'file'   => IF2_PATH . 'includes/crm/class-if2-crm-bedirect.php',
                'color'  => '#f59e0b',
                'slots'  => $common_slots,
                'credentials' => [
                    'hotel'        => ['label' => 'Hotel ID',      'type' => 'text',     'per_form' => true, 'placeholder' => 'es. 17278'],
                    'layout'       => ['label' => 'Layout ID',     'type' => 'text',     'per_form' => true, 'placeholder' => 'es. 12743'],
                    'widgetapikey' => ['label' => 'Widget API Key','type' => 'password', 'per_form' => true, 'placeholder' => ''],
                    'channel'      => ['label' => 'Channel ID',    'type' => 'text',     'per_form' => true, 'placeholder' => 'es. 16485'],
                ],
            ],

            'bookingdesigner' => [
                'label'  => 'Booking Designer',
                'class'  => 'IF2_CRM_BookingDesigner',
                'file'   => IF2_PATH . 'includes/crm/class-if2-crm-bookingdesigner.php',
                'color'  => '#10b981',
                'slots'  => [
                    'checkin'     => 'Check-in (Arrivo)',
                    'checkout'    => 'Check-out (Partenza)',
                    'firstname'   => 'Nome (campo separato)',
                    'lastname'    => 'Cognome (campo separato)',
                    'email'       => 'Email',
                    'phone'       => 'Telefono',
                    'adults'      => 'Adulti',
                    'children'    => 'Bambini (numero)',
                    'child_age_1' => 'Età bambino 1',
                    'child_age_2' => 'Età bambino 2',
                    'child_age_3' => 'Età bambino 3',
                    'child_age_4' => 'Età bambino 4',
                    'treatment'   => 'Trattamento (Formula)',
                    'notes'       => 'Note',
                    'newsletter'  => 'Newsletter (consenso)',
                ],
                'credentials' => [
                    'apikey'        => ['label' => 'API Key',       'type' => 'password', 'per_form' => false, 'placeholder' => ''],
                    'property_code' => ['label' => 'Property Code', 'type' => 'text',     'per_form' => true,  'placeholder' => 'es. vascelleroresort'],
                ],
            ],

            'combo' => [
                'label'  => 'Combo (Hotel.cc)',
                'class'  => 'IF2_CRM_Combo',
                'file'   => IF2_PATH . 'includes/crm/class-if2-crm-combo.php',
                'color'  => '#ec4899',
                'slots'  => $common_slots_with_treatment,
                'credentials' => [
                    'smtp_host'      => ['label' => 'SMTP Host',       'type' => 'text',     'per_form' => false, 'placeholder' => 'mail.offerta-hotel.com'],
                    'smtp_user'      => ['label' => 'SMTP Username',   'type' => 'text',     'per_form' => false, 'placeholder' => 'richiesta@offerta-hotel.com'],
                    'smtp_pass'      => ['label' => 'SMTP Password',   'type' => 'password', 'per_form' => false, 'placeholder' => ''],
                    'smtp_port'      => ['label' => 'SMTP Port',       'type' => 'text',     'per_form' => false, 'placeholder' => '587'],
                    'from_email'     => ['label' => 'Email mittente',  'type' => 'text',     'per_form' => false, 'placeholder' => 'richiesta@offerta-hotel.com'],
                    'from_name'      => ['label' => 'Nome mittente',   'type' => 'text',     'per_form' => false, 'placeholder' => 'In3pida'],
                    'recipient_email'=> ['label' => 'Email Combo (destinatario)', 'type' => 'text', 'per_form' => true, 'placeholder' => 'hotel@hotel.cc'],
                    'hotel_name'     => ['label' => 'Nome hotel',      'type' => 'text',     'per_form' => true,  'placeholder' => 'es. Hotel Pinco'],
                ],
            ],

        ]);
    }

    /**
     * Esegue il dispatch verso tutti i CRM attivi per un form.
     * Ritorna log entries prefissati con 'crm_'.
     */
    public static function dispatch(array $form, array $data, array $meta, int $submission_id): array {
        $logs    = [];
        $drivers = self::get_drivers();
        $global  = get_option('if2_crm_config', []);

        // Nome del form disponibile ai driver (HotelDoor lo usa, ripulito, come utm_campaign)
        $meta['form_name'] = $form['name'] ?? ($meta['form_name'] ?? '');

        foreach ($drivers as $key => $driver) {
            $gcfg = $global[$key] ?? [];
            $fcfg = $form['config']['crm'][$key] ?? [];

            // Globale disabilitato → disabled
            if (empty($gcfg['enabled'])) {
                $logs['crm_' . $key] = ['status' => 'disabled'];
                continue;
            }
            // Per-form: il toggle comanda. Invia SOLO se attivato nel tab CRM del builder.
            // (Non attivo / mai toccato = non invia.)
            if (empty($fcfg['enabled'])) {
                $logs['crm_' . $key] = ['status' => 'disabled'];
                continue;
            }

            if (isset($driver['file']) && file_exists($driver['file'])) {
                require_once $driver['file'];
            }

            if (!class_exists($driver['class'])) {
                $logs['crm_' . $key] = ['status' => 'error', 'code' => 0, 'message' => 'driver non trovato'];
                continue;
            }

            // Mapping: globale + override per-form
            $mapping = array_merge(
                (array)($gcfg['mapping'] ?? []),
                (array)($fcfg['mapping']  ?? [])
            );

            // Credenziali: globale + override per-form
            $creds = array_merge((array)$gcfg, (array)$fcfg);

            $resolved            = self::resolve($form['fields'] ?? [], $data, $mapping);
            $logs['crm_' . $key] = call_user_func([$driver['class'], 'send'], $creds, $resolved, $meta);
        }

        return $logs;
    }

    /**
     * Risolve il mapping slot→label nei dati reali del form.
     * mapping: ['checkin' => 'Arrivo', 'email' => 'E-mail', ...]
     */
    public static function resolve(array $fields, array $data, array $mapping): array {
        // Match dell'etichetta TOLLERANTE (minuscolo, senza accenti, spazi compressi): aiuta a far combaciare
        // lo slot col campo anche con piccole differenze di scrittura. NIENTE auto-rilevamento e NIENTE
        // alterazione dei valori: il valore va al CRM grezzo, esattamente come il vecchio script che funzionava.
        $norm = function ($s) {
            return preg_replace('/\s+/', ' ', remove_accents(strtolower(trim((string) $s))));
        };

        $by_label = [];
        foreach ($fields as $field) {
            $id  = $field['id'] ?? '';
            $lbl = $norm($field['label'] ?? '');
            if ($lbl !== '' && $id) $by_label[$lbl] = $id;
        }

        $out = [];
        foreach ($mapping as $slot => $label) {
            if ((string) $label === '') continue;
            $fid        = $by_label[$norm((string) $label)] ?? null;
            $out[$slot] = ($fid !== null && array_key_exists($fid, $data)) ? $data[$fid] : '';
        }

        // Trattamento: come il vecchio script (che leggeva direttamente il campo "Trattamento"),
        // se lo slot è vuoto lo prendiamo dal campo trattamento, valore GREZZO. Cerca su etichetta E alt_label,
        // con parole chiave (trattament/treatment/pensione/board). SOLO questo slot: non tocca nient'altro.
        if (empty($out['treatment'])) {
            foreach ($fields as $field) {
                $id = $field['id'] ?? '';
                if (!$id || !array_key_exists($id, $data)) continue;
                $hay = $norm(($field['label'] ?? '') . ' ' . ($field['alt_label'] ?? '') . ' ' . ($field['main_label'] ?? ''));
                if (strpos($hay, 'trattament') !== false || strpos($hay, 'treatment') !== false
                    || strpos($hay, 'pensione') !== false || strpos($hay, 'board') !== false) {
                    $v = is_array($data[$id]) ? implode(', ', $data[$id]) : (string) $data[$id];
                    if (trim($v) !== '') { $out['treatment'] = $v; break; }
                }
            }
        }

        // Ancora vuoto? Lo riconosciamo dal VALORE: la tendina trattamento contiene parole come
        // "mezza pensione", "bed & breakfast", "pensione completa"... Così funziona SEMPRE, anche se
        // l'etichetta del campo è scritta in modo strano. È il valore che finisce in BoardBasis.
        if (empty($out['treatment'])) {
            $board_words = ['mezza pensione', 'pensione completa', 'pensione', 'bed & breakfast',
                            'bed and breakfast', 'b&b', 'breakfast', 'colazione', 'mezza pension',
                            'all inclusive', 'half board', 'full board'];
            foreach ($data as $val) {
                $v  = is_array($val) ? implode(' ', $val) : (string) $val;
                $vn = $norm($v);
                if ($vn === '') continue;
                foreach ($board_words as $w) {
                    if (strpos($vn, $w) !== false) { $out['treatment'] = trim($v); break 2; }
                }
            }
        }
        return $out;
    }

    /**
     * Raccoglie tutti i label unici da tutti i form esistenti.
     * Usato per popolare i dropdown di mapping.
     * Nota: get_all() non carica la colonna fields, quindi query dedicata.
     */
    public static function all_labels(): array {
        global $wpdb;
        $rows  = $wpdb->get_results(
            "SELECT fields FROM " . IF2_DB::forms_table() . " ORDER BY id DESC",
            ARRAY_A
        ) ?: [];
        $labels = [];
        $skip   = ['submit', 'heading', 'html', 'page_break'];
        foreach ($rows as $row) {
            $fields = json_decode($row['fields'] ?? '[]', true) ?: [];
            foreach ($fields as $field) {
                if (in_array($field['type'] ?? '', $skip, true)) continue;
                $l = trim($field['label'] ?? '');
                if ($l !== '') $labels[$l] = $l;
            }
        }
        ksort($labels);
        return $labels;
    }

    /**
     * Calcola lo status aggregato di tutti i CRM attivi (worst-case).
     * Ritorna ['status', 'message', 'detail'].
     */
    public static function aggregate(array $ilog): array {
        $crm_logs = [];
        foreach ($ilog as $k => $v) {
            if (strpos($k, 'crm_') === 0) {
                $crm_logs[$k] = $v;
            }
        }

        $active = array_filter($crm_logs, fn($l) => ($l['status'] ?? 'disabled') !== 'disabled');

        if (empty($active)) {
            return ['status' => 'disabled'];
        }

        $priority = ['error' => 5, 'pending' => 4, 'info' => 3, 'skipped' => 2, 'ok' => 1];
        $worst    = 'ok';
        $msgs     = [];

        foreach ($active as $k => $log) {
            $s    = $log['status'] ?? 'disabled';
            $code = (int) ($log['code'] ?? 0);
            // HotelDoor (e simili) rispondono 5xx pur SALVANDO la richiesta: se il dato è entrato,
            // mostriamo "ok" (verde) anche per i log vecchi salvati come errore. Errore reale solo su 4xx/connessione.
            if ($s === 'error' && $code >= 500) $s = 'ok';
            if (($priority[$s] ?? 0) > ($priority[$worst] ?? 0)) {
                $worst = $s;
            }
            $driver = strtoupper(str_replace('crm_', '', $k));
            $codestr = $code ? ' HTTP ' . $code : '';
            $msg    = isset($log['message']) && $log['message'] ? ' — ' . $log['message'] : '';
            $msgs[] = $driver . ': ' . $s . $codestr . $msg;
        }

        return [
            'status'  => $worst,
            'message' => implode(' | ', $msgs),
            'detail'  => $active,
        ];
    }
}
