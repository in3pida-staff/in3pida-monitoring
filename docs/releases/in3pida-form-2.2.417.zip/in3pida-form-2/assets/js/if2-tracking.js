(function () {
    var COOKIE = 'if2_prima_campagna';

    function getDomain() {
        var p = window.location.hostname.split('.');
        return p.length > 2 ? '.' + p.slice(-2).join('.') : window.location.hostname;
    }

    function setCookie(val) {
        var exp = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toUTCString();
        document.cookie = COOKIE + '=' + encodeURIComponent(val) + '; expires=' + exp + '; domain=' + getDomain() + '; path=/; SameSite=Lax';
    }

    function capture() {
        if (document.cookie.indexOf(COOKIE + '=') !== -1) return;
        // localStorage già valorizzato: ri-imposta il cookie (es. dopo CookieScript reset)
        var lsVal = null;
        try { lsVal = localStorage.getItem(COOKIE); } catch (e) {}
        if (lsVal) { setCookie(lsVal); return; }

        var qp  = new URLSearchParams(window.location.search);
        var src = (qp.get('utm_source') || '').toLowerCase();
        var med = (qp.get('utm_medium') || '').toLowerCase();
        var camp = qp.get('utm_campaign') || '';
        var canale = '';
        if (qp.get('gclid') || qp.get('gbraid') || qp.get('wbraid') || med === 'cpc' || med === 'paid' || med === 'ppc') {
            canale = 'Google Ads';
        } else if (qp.get('fbclid') || src === 'facebook' || src === 'instagram' || src === 'meta') {
            canale = 'Meta';
        } else if (med === 'email' || src === 'newsletter' || src === 'mailup' || src === 'amelia') {
            canale = 'Newsletter';
        } else if (med === 'dem' || src === 'dem') {
            canale = 'DEM';
        }
        if (!canale) return;

        var val = JSON.stringify({ canale: canale, campagna: camp, data: new Date().toISOString().slice(0, 10) });
        setCookie(val);
        try { localStorage.setItem(COOKIE, val); } catch (e) {}
    }

    capture();

    // CookieScript cancella i cookie non-necessari al caricamento prima del consenso.
    // Quando l'utente accetta, ri-impostiamo il cookie dal backup in localStorage.
    window.addEventListener('CookieScriptConsent', function () {
        try {
            if (document.cookie.indexOf(COOKIE + '=') !== -1) return;
            var lsVal = null;
            try { lsVal = localStorage.getItem(COOKIE); } catch (e) {}
            if (lsVal) setCookie(lsVal);
        } catch (e) {}
    });
})();
