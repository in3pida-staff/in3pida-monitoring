<?php
defined('ABSPATH') || exit;

class IF2_Extensions {

    public static $last_supabase_result = null;

    public static function init(): void {
        add_action('if2_submit_extensions', [self::class, 'maybe_send_supabase'], 10, 4);

        add_action('wp_ajax_if2_get_blocked_dates',        [self::class, 'ajax_blocked_dates']);
        add_action('wp_ajax_nopriv_if2_get_blocked_dates', [self::class, 'ajax_blocked_dates']);
    }

    public static function ajax_blocked_dates(): void {
        $form_id = (int) ($_GET['form_id'] ?? 0);
        wp_send_json_success(['dates' => self::get_blocked_dates($form_id)]);
    }

    /**
     * Invia i dati a Supabase se abilitato nella config del form.
     */
    public static function maybe_send_supabase(array $form, array $data, array $meta, int $submission_id): void {
        $config = $form['config'];
        if (isset($config['supabase_enabled']) && !$config['supabase_enabled']) {
            self::$last_supabase_result = ['status' => 'disabled'];
            return;
        }

        // Credenziali: preferisce opzioni v2, fallback a v1
        $url     = get_option('if2_supabase_url', '') ?: get_option('in3pida_supabase_url', '');
        $api_key = if2_decrypt( get_option('if2_supabase_anon_key', '') ) ?: get_option('in3pida_supabase_key', '');
        if (!$url || !$api_key) {
            self::$last_supabase_result = ['status' => 'disabled'];
            return;
        }

        $table = sanitize_key($config['supabase_table'] ?? 'form_submissions') ?: 'form_submissions';

        // IP sempre incluso
        $ip = isset($_SERVER['HTTP_X_FORWARDED_FOR'])
            ? sanitize_text_field(trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]))
            : sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '');

        // Costruisce oggetto fields: (alt_label ?: label) → value
        $fields_data = [];
        $email_val   = '';
        foreach ($form['fields'] as $field) {
            if (in_array($field['type'] ?? '', ['submit', 'heading', 'html', 'page_break'], true)) continue;
            $fid    = $field['id'] ?? '';
            $flabel = trim($field['label'] ?? $fid);
            if (empty($flabel) || !array_key_exists($fid, $data)) continue;
            $val = is_array($data[$fid]) ? implode(', ', $data[$fid]) : (string) $data[$fid];

            // Cattura email: tipo 'email' o valore che è un indirizzo email valido
            if ($email_val === '' && $val !== '' && (($field['type'] ?? '') === 'email' || is_email($val))) {
                $email_val = sanitize_email($val);
            }

            $alt  = trim($field['alt_label'] ?? '');
            $fkey = $alt !== '' ? $alt : $flabel;

            // Evita chiavi duplicate in fields
            if (isset($fields_data[$fkey])) {
                $fi = 2;
                while (isset($fields_data[$fkey . '_' . $fi])) $fi++;
                $fkey = $fkey . '_' . $fi;
            }
            $fields_data[$fkey] = $val;
        }

        // hotel_id: meta del submit → config form → impostazioni globali in3pida
        $hotel_id = ($meta['hotel_id'] ?? '') ?: ($config['hotel_id'] ?? '') ?: get_option('if2_hotel_id', '');
        $canale   = ($meta['channel']  ?? '') ?: ($config['channel']  ?? '') ?: '';

        // Base payload
        $payload = [
            'entry_id'     => $submission_id,
            'form_id'      => $form['id'],
            'form_name'    => $form['name'] ?? '',
            'hotel_id'     => $hotel_id,
            'canale'       => $canale,
            'fields'       => $fields_data,
            'submitted_at' => gmdate('c'),
            'ip'           => $ip,
            'user_agent'   => sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''),
            'domain'       => get_site_url(),
        ];
        if ($email_val !== '') {
            $payload['email'] = $email_val;
        }

        $resp = wp_remote_post(
            trailingslashit($url) . 'rest/v1/' . $table,
            [
                'headers' => [
                    'apikey'        => $api_key,
                    'Authorization' => 'Bearer ' . $api_key,
                    'Content-Type'  => 'application/json',
                    'Prefer'        => 'return=minimal',
                ],
                'body'     => wp_json_encode($payload),
                'timeout'  => 8,
                'blocking' => true,
            ]
        );

        $code = is_wp_error($resp) ? 0 : wp_remote_retrieve_response_code($resp);

        // Se PGRST204 (colonna sconosciuta), riprova con solo le colonne base garantite
        if ( !is_wp_error($resp) && $code === 400 ) {
            $body_raw = wp_remote_retrieve_body($resp);
            if ( strpos($body_raw, 'PGRST204') !== false || strpos($body_raw, 'Could not find') !== false ) {
                $safe_keys    = ['entry_id','form_id','form_name','hotel_id','canale','fields','submitted_at','ip','user_agent','domain','email'];
                $safe_payload = array_intersect_key($payload, array_flip($safe_keys));
                $resp = wp_remote_post(
                    trailingslashit($url) . 'rest/v1/' . $table,
                    [
                        'headers' => [
                            'apikey'        => $api_key,
                            'Authorization' => 'Bearer ' . $api_key,
                            'Content-Type'  => 'application/json',
                            'Prefer'        => 'return=minimal',
                        ],
                        'body'    => wp_json_encode($safe_payload),
                        'timeout' => 8,
                    ]
                );
                $code = is_wp_error($resp) ? 0 : wp_remote_retrieve_response_code($resp);
            }
        }

        $ok   = !is_wp_error($resp) && $code >= 200 && $code < 300;
        $body = $ok ? '' : (is_wp_error($resp) ? $resp->get_error_message() : wp_remote_retrieve_body($resp));
        self::$last_supabase_result = [
            'status'  => $ok ? 'ok' : 'error',
            'code'    => $code,
            'message' => $ok ? '' : 'HTTP ' . $code . ($body ? ': ' . substr($body, 0, 300) : ''),
        ];
    }

    /**
     * Reinvia una submission a Supabase: elimina il record esistente (se presente) e lo reinserisce.
     * Usato dal pulsante "Riprova" nel pannello Risposte.
     */
    public static function retry_supabase(array $form, array $data, array $meta, int $submission_id): array {
        $config  = $form['config'];
        $url     = get_option('if2_supabase_url', '') ?: get_option('in3pida_supabase_url', '');
        $api_key = if2_decrypt( get_option('if2_supabase_anon_key', '') ) ?: get_option('in3pida_supabase_key', '');
        if (!$url || !$api_key) return ['status' => 'disabled'];

        $table   = sanitize_key($config['supabase_table'] ?? 'form_submissions') ?: 'form_submissions';
        $headers = [
            'apikey'        => $api_key,
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type'  => 'application/json',
        ];

        // Elimina eventuali righe esistenti con lo stesso entry_id
        wp_remote_request(
            trailingslashit($url) . 'rest/v1/' . $table . '?entry_id=eq.' . $submission_id,
            ['method' => 'DELETE', 'headers' => $headers, 'timeout' => 8]
        );

        // Ricostruisce payload identico a maybe_send_supabase
        $ip = isset($_SERVER['HTTP_X_FORWARDED_FOR'])
            ? sanitize_text_field(trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]))
            : sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? '');

        $fields_data = [];
        $email_val   = '';
        foreach ($form['fields'] as $field) {
            if (in_array($field['type'] ?? '', ['submit', 'heading', 'html', 'page_break'], true)) continue;
            $fid    = $field['id'] ?? '';
            $flabel = trim($field['label'] ?? $fid);
            if (empty($flabel) || !array_key_exists($fid, $data)) continue;
            $val = is_array($data[$fid]) ? implode(', ', $data[$fid]) : (string) $data[$fid];
            if (($field['type'] ?? '') === 'email' && $email_val === '' && $val !== '') {
                $email_val = sanitize_email($val);
            }
            $alt  = trim($field['alt_label'] ?? '');
            $fkey = $alt !== '' ? $alt : $flabel;

            if (isset($fields_data[$fkey])) {
                $fi = 2;
                while (isset($fields_data[$fkey . '_' . $fi])) $fi++;
                $fkey = $fkey . '_' . $fi;
            }
            $fields_data[$fkey] = $val;
        }

        $hotel_id = ($meta['hotel_id'] ?? '') ?: ($config['hotel_id'] ?? '') ?: get_option('if2_hotel_id', '');
        $canale   = ($meta['channel']  ?? '') ?: ($config['channel']  ?? '') ?: '';

        $payload = [
            'entry_id'     => $submission_id,
            'form_id'      => $form['id'],
            'form_name'    => $form['name'] ?? '',
            'hotel_id'     => $hotel_id,
            'canale'       => $canale,
            'fields'       => $fields_data,
            'submitted_at' => $meta['_row_created_at'] ? gmdate('c', strtotime($meta['_row_created_at'])) : gmdate('c'),
            'ip'           => $ip,
            'user_agent'   => sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''),
            'domain'       => get_site_url(),
        ];
        if ($email_val !== '') $payload['email'] = $email_val;

        $resp = wp_remote_post(
            trailingslashit($url) . 'rest/v1/' . $table,
            [
                'headers' => array_merge($headers, ['Prefer' => 'return=minimal']),
                'body'    => wp_json_encode($payload),
                'timeout' => 8,
            ]
        );

        $code = is_wp_error($resp) ? 0 : wp_remote_retrieve_response_code($resp);

        // Se PGRST204 (colonna sconosciuta), riprova con solo le colonne base garantite
        if ( !is_wp_error($resp) && $code === 400 ) {
            $body_raw = wp_remote_retrieve_body($resp);
            if ( strpos($body_raw, 'PGRST204') !== false || strpos($body_raw, 'Could not find') !== false ) {
                $safe_keys    = ['entry_id','form_id','form_name','hotel_id','canale','fields','submitted_at','ip','user_agent','domain','email'];
                $safe_payload = array_intersect_key($payload, array_flip($safe_keys));
                $resp = wp_remote_post(
                    trailingslashit($url) . 'rest/v1/' . $table,
                    [
                        'headers' => array_merge($headers, ['Prefer' => 'return=minimal']),
                        'body'    => wp_json_encode($safe_payload),
                        'timeout' => 8,
                    ]
                );
                $code = is_wp_error($resp) ? 0 : wp_remote_retrieve_response_code($resp);
            }
        }

        $ok   = !is_wp_error($resp) && $code >= 200 && $code < 300;
        $body = $ok ? '' : (is_wp_error($resp) ? $resp->get_error_message() : wp_remote_retrieve_body($resp));
        return [
            'status'  => $ok ? 'ok' : 'error',
            'code'    => $code,
            'message' => $ok ? '' : 'HTTP ' . $code . ($body ? ': ' . substr($body, 0, 300) : ''),
        ];
    }

    public static function get_blocked_dates(int $form_id): array {
        $form = IF2_Form::get($form_id);
        if (!$form) return [];

        $dates = (array) ($form['config']['blocked_dates'] ?? []);
        return apply_filters('if2_blocked_dates', $dates, $form_id);
    }
}
