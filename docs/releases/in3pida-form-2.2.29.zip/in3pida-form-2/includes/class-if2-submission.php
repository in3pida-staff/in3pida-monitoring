<?php
defined('ABSPATH') || exit;

class IF2_Submission {

    public static function get_all(int $form_id, int $limit = 50, int $offset = 0): array {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . IF2_DB::submissions_table() .
            " WHERE form_id = %d ORDER BY created_at DESC LIMIT %d OFFSET %d",
            $form_id, $limit, $offset
        ), ARRAY_A) ?: [];
    }

    public static function get_filtered(int $form_id, int $limit = 50, int $offset = 0): array {
        global $wpdb;
        $st = IF2_DB::submissions_table();
        $ft = IF2_DB::forms_table();
        if ($form_id) {
            return $wpdb->get_results($wpdb->prepare(
                "SELECT s.*, f.name as form_name FROM {$st} s
                 LEFT JOIN {$ft} f ON s.form_id = f.id
                 WHERE s.form_id = %d ORDER BY s.created_at DESC LIMIT %d OFFSET %d",
                $form_id, $limit, $offset
            ), ARRAY_A) ?: [];
        }
        return $wpdb->get_results($wpdb->prepare(
            "SELECT s.*, f.name as form_name FROM {$st} s
             LEFT JOIN {$ft} f ON s.form_id = f.id
             ORDER BY s.created_at DESC LIMIT %d OFFSET %d",
            $limit, $offset
        ), ARRAY_A) ?: [];
    }

    public static function count_filtered(int $form_id): int {
        global $wpdb;
        $st = IF2_DB::submissions_table();
        if ($form_id) {
            return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$st} WHERE form_id = %d", $form_id));
        }
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$st}");
    }

    public static function get_one(int $id): ?array {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . IF2_DB::submissions_table() . " WHERE id = %d", $id
        ), ARRAY_A) ?: null;
    }

    public static function count(int $form_id): int {
        global $wpdb;
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . IF2_DB::submissions_table() . " WHERE form_id = %d",
            $form_id
        ));
    }

    public static function save(int $form_id, array $data, array $meta = []): int {
        global $wpdb;
        $wpdb->insert(IF2_DB::submissions_table(), [
            'form_id' => $form_id,
            'data'    => wp_json_encode($data),
            'meta'    => wp_json_encode($meta),
        ]);
        return (int) $wpdb->insert_id;
    }

    public static function delete(int $id): bool {
        global $wpdb;
        return $wpdb->delete(IF2_DB::submissions_table(), ['id' => $id]) !== false;
    }

    public static function update_meta_log(int $id, array $log_patch): void {
        global $wpdb;
        $row  = $wpdb->get_var($wpdb->prepare(
            "SELECT meta FROM " . IF2_DB::submissions_table() . " WHERE id = %d", $id
        ));
        $meta            = json_decode($row ?: '{}', true) ?: [];
        $existing        = $meta['integration_log'] ?? [];
        $meta['integration_log'] = array_merge($existing, $log_patch);
        $wpdb->update(IF2_DB::submissions_table(), ['meta' => wp_json_encode($meta)], ['id' => $id]);
    }

    /**
     * Invia email di notifica all'admin per una submission.
     */
    public static function send_notification(array $form, array $data, int $submission_id, array $meta = []): bool {
        $config = $form['config'];

        if (empty($config['send_email']) || empty($config['email_to'])) {
            return false;
        }

        $to      = sanitize_email($config['email_to']);
        $subject = sanitize_text_field($config['email_subject'] ?? 'Nuovo messaggio dal form') . ' #' . $submission_id;

        // Genera tabella campi (usata da {all_fields} e dal fallback auto)
        $table  = "<table cellpadding='8' cellspacing='0' border='0' style='border-collapse:collapse;width:100%;max-width:560px;font-family:sans-serif;font-size:13px'>\n";
        foreach ($form['fields'] as $field) {
            if (in_array($field['type'], ['page_break', 'html', 'submit'], true)) continue;
            $label  = esc_html($field['label'] ?? $field['id']);
            $value  = isset($data[$field['id']]) ? esc_html(
                is_array($data[$field['id']]) ? implode(', ', $data[$field['id']]) : $data[$field['id']]
            ) : '—';
            $table .= "<tr style='border-bottom:1px solid #f0f0f0'>"
                    . "<td style='font-weight:700;color:#444;width:38%;vertical-align:top;padding:8px 12px 8px 0'>{$label}</td>"
                    . "<td style='color:#222;vertical-align:top'>{$value}</td>"
                    . "</tr>\n";
        }
        $table .= "</table>\n";

        // Corpo email: usa email_body personalizzato se configurato, altrimenti genera la tabella
        if (!empty($config['email_body'])) {
            $body = $config['email_body'];

            // Sostituisci placeholder {field_id} con i valori dei singoli campi
            foreach ($data as $key => $val) {
                $val_str = is_array($val) ? implode(', ', $val) : $val;
                $body    = str_replace('{' . $key . '}', esc_html($val_str), $body);
            }

            // Placeholder speciali
            $body = str_replace('{all_fields}',    $table,                                              $body);
            $body = str_replace('{form_name}',     esc_html($form['name']),                             $body);
            $body = str_replace('{submission_id}', (string) $submission_id,                             $body);
            $body = str_replace('{date}',          current_time('d/m/Y'),                               $body);
            $body = str_replace('{time}',          current_time('H:i'),                                 $body);
            $body = str_replace('{source_url}',    esc_html($meta['source_url'] ?? ''),                 $body);
            $body = str_replace('{channel}',       esc_html($meta['channel']    ?? ''),                 $body);

            $body = wp_kses_post($body);
        } else {
            $body  = "<p style='font-family:sans-serif;font-size:13px;color:#555;margin:0 0 16px'><strong>Data:</strong> " . current_time('d/m/Y H:i') . "</p>\n";
            $body .= $table;
        }

        $headers = ['Content-Type: text/html; charset=UTF-8'];

        // From header
        if (!empty($config['email_from_name']) && !empty($config['email_from'])) {
            $headers[] = 'From: ' . sanitize_text_field($config['email_from_name']) . ' <' . sanitize_email($config['email_from']) . '>';
        } elseif (!empty($config['email_from'])) {
            $headers[] = 'From: ' . sanitize_email($config['email_from']);
        }

        // Reply-To automatico: usa campo specificato o primo campo email
        if (!empty($config['email_reply_to'])) {
            $reply_field = $config['email_reply_to'];
            if (!empty($data[$reply_field])) {
                $headers[] = 'Reply-To: ' . sanitize_email($data[$reply_field]);
            }
        } else {
            foreach ($form['fields'] as $field) {
                if ($field['type'] === 'email' && !empty($data[$field['id']])) {
                    $headers[] = 'Reply-To: ' . sanitize_email($data[$field['id']]);
                    break;
                }
            }
        }

        return wp_mail($to, $subject, $body, $headers);
    }

    /**
     * Invia email di conferma (autoresponder) all'utente.
     */
    public static function send_autoresponder(array $form, array $data, int $submission_id = 0): bool {
        $config = $form['config'];
        if (empty($config['autoresponder'])) return false;

        $email_field = $config['autoresponder_email_field'] ?? '';
        $to_email    = '';

        if ($email_field && !empty($data[$email_field])) {
            $to_email = sanitize_email($data[$email_field]);
        } else {
            foreach ($form['fields'] as $field) {
                if ($field['type'] === 'email' && !empty($data[$field['id']])) {
                    $to_email = sanitize_email($data[$field['id']]);
                    break;
                }
            }
        }

        if (!$to_email || !is_email($to_email)) return false;

        $subject = sanitize_text_field($config['autoresponder_subject'] ?: 'Grazie per averci contattato') . ($submission_id ? ' #' . $submission_id : '');
        $body    = $config['autoresponder_body'] ?: '<p>Grazie! Abbiamo ricevuto il tuo messaggio.</p>';

        // Genera tabella campi per {all_fields}
        $ar_table  = "<table cellpadding='8' cellspacing='0' border='0' style='border-collapse:collapse;width:100%;max-width:560px;font-family:sans-serif;font-size:13px'>\n";
        foreach ($form['fields'] as $field) {
            if (in_array($field['type'], ['page_break', 'html', 'submit'], true)) continue;
            $lbl = esc_html($field['label'] ?? $field['id']);
            $val = isset($data[$field['id']]) ? esc_html(
                is_array($data[$field['id']]) ? implode(', ', $data[$field['id']]) : $data[$field['id']]
            ) : '—';
            $ar_table .= "<tr style='border-bottom:1px solid #f0f0f0'>"
                       . "<td style='font-weight:700;color:#444;width:38%;vertical-align:top;padding:8px 12px 8px 0'>{$lbl}</td>"
                       . "<td style='color:#222;vertical-align:top'>{$val}</td>"
                       . "</tr>\n";
        }
        $ar_table .= "</table>\n";

        // Sostituisci placeholder {field_id} con i valori dei singoli campi
        foreach ($data as $key => $val) {
            $val_str = is_array($val) ? implode(', ', $val) : $val;
            $body    = str_replace('{' . $key . '}', esc_html($val_str), $body);
        }

        // Placeholder speciali
        $body = str_replace('{all_fields}', $ar_table,                    $body);
        $body = str_replace('{form_name}',  esc_html($form['name']),       $body);
        $body = str_replace('{date}',       current_time('d/m/Y'),         $body);
        $body = str_replace('{time}',       current_time('H:i'),           $body);

        $headers = ['Content-Type: text/html; charset=UTF-8'];

        // From: usa i campi specifici dell'autoresponder, con fallback a quelli generici
        $ar_from_name  = !empty($config['autoresponder_from_name'])  ? $config['autoresponder_from_name']  : ($config['email_from_name']  ?? '');
        $ar_from_email = !empty($config['autoresponder_from_email']) ? $config['autoresponder_from_email'] : ($config['email_from']       ?? '');
        if ($ar_from_name && $ar_from_email) {
            $headers[] = 'From: ' . sanitize_text_field($ar_from_name) . ' <' . sanitize_email($ar_from_email) . '>';
        } elseif ($ar_from_email) {
            $headers[] = 'From: ' . sanitize_email($ar_from_email);
        }

        return wp_mail($to_email, $subject, wp_kses_post($body), $headers);
    }
}
