<?php
defined('ABSPATH') || exit;

class IF2_Form {

    public static function get_all(int $limit = 0, int $offset = 0): array {
        global $wpdb;
        $sql = "SELECT id, name, created_at, updated_at FROM " . IF2_DB::forms_table() . " ORDER BY id DESC";
        if ($limit > 0) {
            $sql .= $wpdb->prepare(" LIMIT %d OFFSET %d", $limit, $offset);
        }
        return $wpdb->get_results($sql, ARRAY_A) ?: [];
    }

    public static function count_all(): int {
        global $wpdb;
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM " . IF2_DB::forms_table());
    }

    public static function get(int $id): ?array {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM " . IF2_DB::forms_table() . " WHERE id = %d", $id),
            ARRAY_A
        );
        if (!$row) return null;
        $row['fields'] = json_decode($row['fields'], true) ?: [];
        $row['config'] = json_decode($row['config'], true) ?: [];
        return $row;
    }

    public static function create(string $name): int {
        global $wpdb;
        $wpdb->insert(IF2_DB::forms_table(), [
            'name'   => sanitize_text_field($name),
            'fields' => '[]',
            'config' => json_encode(self::default_config()),
        ]);
        return (int) $wpdb->insert_id;
    }

    /**
     * Duplica un form copiando la riga 1:1 (fields + config IDENTICI, byte per byte) in una nuova riga.
     * NON passa da sanitize_config né dal merge del save: la copia è identica alla sorgente e l'originale
     * non viene mai toccato. (Era il giro get→new→save a far "tornare ai default" alcune impostazioni.)
     */
    public static function duplicate(int $src_id, string $name): int {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare('SELECT fields, config FROM ' . IF2_DB::forms_table() . ' WHERE id = %d', $src_id),
            ARRAY_A
        );
        if (!$row) return 0;
        $fields = ($row['fields'] !== null && $row['fields'] !== '') ? $row['fields'] : '[]';
        $config = ($row['config'] !== null && $row['config'] !== '') ? $row['config'] : json_encode(self::default_config());
        // Allinea il NOME INTERNO (config['form_name']) al nuovo nome: altrimenti al primo salvataggio save_form
        // rinomina la copia col nome interno della sorgente (es. "2026 - Brand…") e il nome scelto va perso.
        $cfg = json_decode($config, true);
        if (is_array($cfg)) { $cfg['form_name'] = sanitize_text_field($name); $config = wp_json_encode($cfg); }
        $wpdb->insert(IF2_DB::forms_table(), [
            'name'   => sanitize_text_field($name),
            'fields' => $fields,
            'config' => $config,
        ]);
        return (int) $wpdb->insert_id;
    }

    public static function save(int $id, array $fields, array $config): bool {
        global $wpdb;
        // BACKUP AUTOMATICO: prima di sovrascrivere, conserva lo stato PRECEDENTE del form (rete di sicurezza
        // anti-perdita). Tiene le ultime 5 versioni in un'opzione dedicata, recuperabili in caso di problemi.
        $prev = $wpdb->get_row($wpdb->prepare('SELECT fields, config FROM ' . IF2_DB::forms_table() . ' WHERE id = %d', $id), ARRAY_A);
        if ($prev && !empty($prev['fields']) && $prev['fields'] !== '[]') {
            $baks = get_option('if2_form_baks_' . $id, []);
            if (!is_array($baks)) $baks = [];
            array_unshift($baks, ['fields' => $prev['fields'], 'config' => $prev['config'], 'ts' => current_time('mysql')]);
            update_option('if2_form_baks_' . $id, array_slice($baks, 0, 5), false);
        }
        $rows = $wpdb->update(
            IF2_DB::forms_table(),
            [
                'fields' => wp_json_encode($fields),
                'config' => wp_json_encode($config),
            ],
            ['id' => $id]
        );
        return $rows !== false;
    }

    /** Ultime versioni salvate del form (backup automatico). Per recuperare una configurazione persa. */
    public static function backups(int $id): array {
        $baks = get_option('if2_form_baks_' . $id, []);
        return is_array($baks) ? $baks : [];
    }

    /** Ripristina una versione di backup del form (indice 0 = la più recente). */
    public static function restore_backup(int $id, int $index): bool {
        $baks = self::backups($id);
        if (!isset($baks[$index])) return false;
        $b = $baks[$index];
        $fields = json_decode((string) ($b['fields'] ?? '[]'), true) ?: [];
        $config = json_decode((string) ($b['config'] ?? '{}'), true) ?: [];
        return self::save($id, $fields, $config);
    }

    public static function rename(int $id, string $name): bool {
        global $wpdb;
        return $wpdb->update(
            IF2_DB::forms_table(),
            ['name' => sanitize_text_field($name)],
            ['id' => $id]
        ) !== false;
    }

    public static function delete(int $id): bool {
        global $wpdb;
        $wpdb->delete(IF2_DB::submissions_table(), ['form_id' => $id]);
        $wpdb->delete(IF2_DB::files_table(),       ['form_id' => $id]);
        return $wpdb->delete(IF2_DB::forms_table(), ['id' => $id]) !== false;
    }

    public static function default_config(): array {
        return [
            // General
            'submit_text'            => 'Invia',
            'success_message'        => 'Grazie! Il tuo messaggio è stato inviato.',
            'error_message'          => 'Si è verificato un errore. Riprova.',
            'text_required'          => 'Questo campo è obbligatorio',
            'text_invalid'           => 'Il valore inserito non è valido',
            'redirect_url'           => '',
            'redirect_delay'         => 0,
            // WhatsApp dopo l'invio (l'utente scrive per primo all'hotel)
            'wa_enabled'             => false,
            'wa_number'              => '',
            'wa_message'             => 'Ciao, ho appena inviato una richiesta di preventivo dal sito.',
            'wa_delay'               => 1500,
            'disable_form'           => false,
            'disable_form_page'      => false,
            'disable_multiple'       => false,
            'max_submissions'        => 0,
            'disable_autoscroll'     => false,
            'enable_autosave'        => false,
            'webhook_url'            => '',
            // Email
            'send_email'               => true,
            'email_method'             => 'wp_mail',
            'email_from_name'          => '',
            'email_from'               => '',
            'email_to'                 => get_option('admin_email'),
            'email_subject'            => 'Nuovo messaggio dal form',
            'email_body'               => '',
            'email_reply_to'           => '',
            // SMTP
            'smtp_host'                => '',
            'smtp_port'                => '587',
            'smtp_user'                => '',
            'smtp_pass'                => '',
            'smtp_enc'                 => 'tls',
            // Email options
            'email_attach_files'       => false,
            'email_multi_column'       => false,
            'email_hide_empty'         => false,
            // Autoresponder
            'autoresponder'            => false,
            'autoresponder_email_field'=> '',
            'autoresponder_from_name'  => '',
            'autoresponder_from_email' => '',
            'autoresponder_subject'    => '',
            'autoresponder_body'       => '',
            // Advanced
            'form_name'              => '',
            'thousand_sep'           => '.',
            'decimal_sep'            => ',',
            'collect_ip'             => false,
            // Styling
            'form_width'             => '100%',
            'bg_transparent'         => false,
            'hide_labels'            => false,
            'bg_color'               => '#ffffff',
            'font_color'             => '#333333',
            'font_family'            => '',
            'font_size'              => '',
            'label_weight'           => '',
            'label_color'            => '',
            'link_color'             => '',
            'field_border_color'     => '',
            'field_border_width'     => '',
            'consent_color'          => '', // colore CASELLA consenso (privacy/newsletter); vuoto = usa il colore pulsante
            'consent_font_color'     => '', // colore TESTO privacy/newsletter; vuoto = usa il colore testo generale
            'field_radius'           => '6px',
            'datepicker_radius'      => '14px',
            'dp_header_bg'           => '',
            'dp_today_color'         => '',
            'dp_selected_color'      => '',
            'field_padding'          => '',
            'input_bg'               => '',
            'focus_color'            => '#009bb9',
            'submit_bg'              => '#d82d6b',
            'submit_hover_bg'        => '',
            'submit_color'           => '#ffffff',
            'submit_radius'          => '',
            'logo_url'               => '',
            'logo_width'             => '',
            'logo_position'          => 'center',
            'custom_css'             => '',
            // Messaggio risposta (Pulsante invio)
            'success_bg'             => '',
            'success_color'          => '',
            'success_border'         => '',
            'error_bg'               => '',
            'error_color'            => '',
            'error_border'           => '',
            'msg_font_size'          => '',
            // in3pida
            'channel'                => '',
            'hotel_id'               => '',
            'thankyou_url'           => '',
            'supabase_enabled'       => true,
            'supabase_table'         => 'form_submissions',
            'blocked_dates'          => [],
            'amelia_default_list'    => '',
            'amelia_subscribe_all'   => false,
            'form_lang'              => '',
            // Logic builder
            'logic_rules'            => [],
            // CRM integrazioni native (per-form)
            'crm'                    => [],
        ];
    }

    /**
     * Genera un ID univoco per un campo.
     */
    public static function generate_field_id(): string {
        return 'field_' . wp_generate_password(8, false);
    }
}
