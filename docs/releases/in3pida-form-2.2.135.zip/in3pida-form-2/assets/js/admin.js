/* in3pida Form 2 – Admin JS */
jQuery(function ($) {
    'use strict';

    var ajaxurl = IF2Admin.ajaxurl;
    var nonce   = IF2Admin.nonce;
    var statsChart = null;
    var currentRange  = '1m';
    var currentFormId = 0;

    // -------------------------------------------------------------------------
    // Crea nuovo form — MODAL
    // -------------------------------------------------------------------------
    var $modal     = $('#if2-modal-new-form');
    var $nameInput = $('#if2-modal-form-name');

    // Apre modal
    $('#if2-btn-new-form').on('click', function () {
        $nameInput.val('');
        $modal.addClass('open');
        setTimeout(function () { $nameInput.focus(); }, 100);
    });

    // Chiude modal
    $('#if2-modal-close, #if2-modal-new-form').on('click', function (e) {
        if (e.target === this) $modal.removeClass('open');
    });
    $(document).on('keydown', function (e) {
        if (e.key === 'Escape') $modal.removeClass('open');
    });

    // Selezione tipo (VUOTO/TEMPLATE/DUPLICA/IMPORTA)
    $(document).on('click', '.if2-modal-option', function () {
        $('.if2-modal-option').removeClass('active');
        $(this).addClass('active');
        var type = $(this).data('type');
        $('#if2-import-area').toggle(type === 'importa');
        $('#if2-dup-area').toggle(type === 'duplica');
        if (type === 'importa') {
            $nameInput.attr('placeholder', 'Nome modulo (opzionale, usa quello del file)');
        } else if (type === 'duplica') {
            $nameInput.attr('placeholder', 'Nome della copia (opzionale)');
        } else {
            $nameInput.attr('placeholder', $nameInput.data('orig-ph') || 'Nome modulo');
        }
    });

    // Crea form
    $('#if2-modal-create').on('click', function () {
        var activeType = $('.if2-modal-option.active').data('type') || 'vuoto';

        if (activeType === 'importa') {
            var jsonStr = $.trim($('#if2-import-json').val());
            if (!jsonStr) { $('#if2-import-json').focus(); return; }
            var parsed;
            try { parsed = JSON.parse(jsonStr); } catch(ex) { alert('JSON non valido. Verifica il file esportato.'); return; }

            var importName = $.trim($nameInput.val()) || parsed.name || 'Form importato';
            var $btn = $(this).prop('disabled', true).text('Importazione…');

            $.post(ajaxurl, { action: 'if2_new_form', nonce: nonce, name: importName }, function (res) {
                if (!res.success) { $btn.prop('disabled', false).text('CREA MODULO'); alert('Errore durante la creazione.'); return; }
                var newId = res.data.id;
                $.post(ajaxurl, {
                    action: 'if2_save_form', nonce: nonce, form_id: newId,
                    fields: JSON.stringify(parsed.fields || []),
                    config: JSON.stringify(parsed.config || {})
                }, function (res2) {
                    $btn.prop('disabled', false).text('CREA MODULO');
                    $modal.removeClass('open');
                    window.location.href = ajaxurl.replace('admin-ajax.php', 'admin.php') + '?page=if2-builder&form_id=' + newId;
                });
            });
            return;
        }

        if (activeType === 'duplica') {
            var srcId = $('#if2-dup-form').val();
            if (!srcId) { $('#if2-dup-form').focus(); return; }
            var dupName = $.trim($nameInput.val());
            var $dbtn = $(this).prop('disabled', true).text('Duplicazione…');
            $.post(ajaxurl, { action: 'if2_get_form', nonce: nonce, form_id: srcId }, function (res) {
                if (!res.success) { $dbtn.prop('disabled', false).text('CREA MODULO'); alert('Errore nel leggere il form da duplicare.'); return; }
                var src = res.data;
                var newName = dupName || ('Copia di ' + (src.name || 'Form'));
                $.post(ajaxurl, { action: 'if2_new_form', nonce: nonce, name: newName }, function (r2) {
                    if (!r2.success) { $dbtn.prop('disabled', false).text('CREA MODULO'); alert('Errore durante la creazione.'); return; }
                    var newId = r2.data.id;
                    $.post(ajaxurl, {
                        action: 'if2_save_form', nonce: nonce, form_id: newId,
                        fields: JSON.stringify(src.fields || []),
                        config: JSON.stringify(src.config || {})
                    }, function () {
                        $dbtn.prop('disabled', false).text('CREA MODULO');
                        $modal.removeClass('open');
                        window.location.href = ajaxurl.replace('admin-ajax.php', 'admin.php') + '?page=if2-builder&form_id=' + newId;
                    });
                });
            });
            return;
        }

        var name = $.trim($nameInput.val());
        if (!name) { $nameInput.focus(); return; }
        var $btn = $(this).prop('disabled', true).text('Creazione…');

        $.post(ajaxurl, { action: 'if2_new_form', nonce: nonce, name: name }, function (res) {
            $btn.prop('disabled', false).text('CREA MODULO');
            if (res.success) {
                $modal.removeClass('open');
                window.location.href = ajaxurl.replace('admin-ajax.php', 'admin.php') +
                    '?page=if2-builder&form_id=' + res.data.id;
            } else {
                alert('Errore durante la creazione del form.');
            }
        });
    });

    // Invio con Enter nell'input nome
    $nameInput.on('keydown', function (e) {
        if (e.key === 'Enter') $('#if2-modal-create').trigger('click');
    });

    // Lettura file JSON dal PC
    $(document).on('change', '#if2-import-file', function () {
        var file = this.files && this.files[0];
        if (!file) return;
        $('#if2-import-filename').text(file.name);
        var reader = new FileReader();
        reader.onload = function (e) {
            var content = e.target.result;
            $('#if2-import-json').val(content);
            try {
                var parsed = JSON.parse(content);
                if (parsed.plugin === 'FormCraft') {
                    $('#if2-import-json').val('');
                    $('#if2-import-filename').text('');
                    alert('File FormCraft rilevato.\n\nPer importarlo:\n1. Crea un form vuoto\n2. Aprilo nel Builder\n3. Vai nel pannello Impostazioni → clicca "Import (.json / FormCraft .txt)"\n4. Seleziona il file .txt da lì');
                    return;
                }
                if (parsed.name && !$.trim($nameInput.val())) {
                    $nameInput.val(parsed.name);
                }
            } catch (ex) {}
        };
        reader.readAsText(file);
    });

    // Click sull'intera riga form → va al builder (non su checkbox o delete)
    $(document).on('click', '.if2-form-row', function (e) {
        if ($(e.target).closest('.if2-btn-delete-form').length) return;
        if ($(e.target).is('input[type="checkbox"]') || $(e.target).closest('input[type="checkbox"]').length) return;
        var url = $(this).data('builder-url');
        if (url) window.location.href = url;
    });

    // Checkbox singola → aggiorna bottone bulk
    $(document).on('change', '.if2-sub-check', function (e) {
        e.stopPropagation();
        updateBulkDelete();
    });

    // Check-all
    $(document).on('change', '#if2-check-all', function (e) {
        e.stopPropagation();
        var checked = $(this).is(':checked');
        $('.if2-sub-check').prop('checked', checked);
        updateBulkDelete();
    });

    function updateBulkDelete() {
        var count = $('.if2-sub-check:checked').length;
        var $btn  = $('#if2-bulk-delete');
        if (count > 0) {
            var label = (IF2Admin.strings && IF2Admin.strings.bulk_delete) ? IF2Admin.strings.bulk_delete : 'ELIMINA SELEZIONATI';
            $btn.text(label + ' (' + count + ')').css('display', 'inline-flex');
        } else {
            $btn.css('display', 'none');
        }
    }

    // Elimina selezionati
    $(document).on('click', '#if2-bulk-delete', function () {
        var $checked = $('.if2-sub-check:checked');
        var ids = $checked.closest('tr').map(function () { return $(this).data('sub-id'); }).get();
        if (!ids.length) return;
        if (!confirm('Eliminare ' + ids.length + ' risposta/e? Operazione irreversibile.')) return;

        var done = 0;
        ids.forEach(function (id) {
            $.post(ajaxurl, { action: 'if2_delete_submission', nonce: nonce, submission_id: id }, function (res) {
                if (res.success) {
                    $('tr[data-sub-id="' + id + '"]').fadeOut(200, function () { $(this).remove(); });
                }
                done++;
                if (done === ids.length) updateBulkDelete();
            });
        });
    });

    // -------------------------------------------------------------------------
    // Elimina form
    // -------------------------------------------------------------------------
    var if2DeleteFormId = null;

    $(document).on('click', '.if2-btn-delete-form', function () {
        if2DeleteFormId = $(this).data('id');
        $('#if2-modal-delete-form').fadeIn(150);
    });

    $(document).on('click', '#if2-delete-modal-close, #if2-delete-form-cancel', function () {
        $('#if2-modal-delete-form').fadeOut(150);
        if2DeleteFormId = null;
    });

    $(document).on('click', '#if2-delete-form-confirm', function () {
        var id = if2DeleteFormId;
        if (!id) return;
        $('#if2-modal-delete-form').fadeOut(150);
        if2DeleteFormId = null;
        $.post(ajaxurl, { action: 'if2_delete_form', nonce: nonce, form_id: id }, function (res) {
            if (res.success) {
                $('tr[data-form-id="' + id + '"]').fadeOut(300, function () { $(this).remove(); });
            } else {
                alert('Errore eliminazione.');
            }
        });
    });

    // -------------------------------------------------------------------------
    // Ricerca form
    // -------------------------------------------------------------------------
    $('#if2-search-forms').on('input', function () {
        var q = $(this).val().toLowerCase();
        $('#if2-forms-table tbody tr').each(function () {
            var name = $(this).find('td:nth-child(2)').text().toLowerCase();
            $(this).toggle(!q || name.indexOf(q) !== -1);
        });
    });

    // (delete submission gestito in fondo al file)

    // -------------------------------------------------------------------------
    // STATISTICHE — caricamento
    // -------------------------------------------------------------------------
    function loadStats(dateFrom, dateTo) {
        var postData = {
            action:  'if2_get_stats',
            nonce:   nonce,
            range:   currentRange,
            form_id: currentFormId,
        };
        if (dateFrom && dateTo) {
            postData.date_from = dateFrom;
            postData.date_to   = dateTo;
        }
        $.post(ajaxurl, postData, function (res) {
            if (!res.success) return;
            var d = res.data;

            $('#stat-views').text(d.views);
            $('#stat-responses').text(d.responses);
            $('#stat-conversion').text(d.conversion + '%');

            renderChart(d.chart);
            equalizeFormPanels();
        });
    }

    function renderChart(chart) {
        var ctx = document.getElementById('if2-stats-chart');
        if (!ctx) return;

        if (statsChart) {
            statsChart.destroy();
            statsChart = null;
        }

        statsChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: chart.labels,
                datasets: [
                    {
                        label: 'Visualizzazioni',
                        data:  chart.views,
                        borderColor:     '#d82d6b',
                        backgroundColor: 'rgba(216,45,107,0.08)',
                        borderWidth: 1,
                        pointRadius: 0,
                        pointHoverRadius: 3,
                        fill: false,
                        tension: 0.3,
                    },
                    {
                        label: 'Risposte',
                        data:  chart.responses || [],
                        borderColor:     '#009bb9',
                        backgroundColor: 'rgba(0,155,185,0.08)',
                        borderWidth: 1,
                        pointRadius: 0,
                        pointHoverRadius: 3,
                        fill: false,
                        tension: 0.3,
                    },
                ],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top',
                        labels: { boxWidth: 28, font: { size: 11 }, color: '#888', padding: 16 },
                    },
                },
                scales: {
                    x: { grid: { color: '#f2f2f2' }, ticks: { font: { size: 11 }, color: '#aaa' } },
                    y: { grid: { color: '#f2f2f2' }, ticks: { font: { size: 11 }, color: '#aaa', precision: 0 } },
                },
            },
        });
    }

    // Filtri range
    $(document).on('click', '.if2-filter-btn', function () {
        var range = $(this).data('range');
        $('.if2-filter-btn').removeClass('active');
        $(this).addClass('active');

        if (range === 'custom') {
            var $cr = $('#if2-custom-range');
            if ($cr.is(':visible')) { $cr.hide(); } else { $cr.css('display', 'flex'); }
            return;
        }

        $('#if2-custom-range').hide();
        currentRange = range;
        loadStats();
    });

    // Applica range personalizzato
    $(document).on('click', '#if2-apply-custom-range', function () {
        var from = $('#if2-date-from').val();
        var to   = $('#if2-date-to').val();
        if (!from || !to) { alert('Seleziona entrambe le date.'); return; }
        currentRange = 'custom';
        loadStats(from, to);
    });

    // Impedisce di selezionare una data fine precedente alla data inizio
    $(document).on('change', '#if2-date-from', function () {
        var from = $(this).val();
        var $to  = $('#if2-date-to');
        $to.attr('min', from);
        if ($to.val() && $to.val() < from) $to.val(from);
    });

    // Filtro per form
    $(document).on('change', '#if2-stats-form-filter', function () {
        currentFormId = parseInt($(this).val(), 10) || 0;
        loadStats();
    });

    // Reset statistiche
    $('#if2-reset-stats').on('click', function () {
        if (!confirm('Azzerare tutte le statistiche? Operazione irreversibile.')) return;
        var $btn = $(this).prop('disabled', true);

        $.post(ajaxurl, { action: 'if2_reset_stats', nonce: nonce }, function (res) {
            $btn.prop('disabled', false);
            if (res.success) {
                loadStats();
            }
        });
    });

    // Disabilita statistiche (solo UI)
    $('#if2-disable-stats').on('change', function () {
        var disabled = $(this).is(':checked');
        $('.if2-chart-wrap, .if2-stats-cards').toggleClass('if2-stats-hidden', disabled);
    });

    // -------------------------------------------------------------------------
    // Export CSV (topbar globale + pulsante form specifico)
    // -------------------------------------------------------------------------
    function downloadCSV(formId, filename) {
        $.post(ajaxurl, { action: 'if2_export_data', nonce: nonce, form_id: formId || 0 }, function (res) {
            if (!res.success) { alert('Errore export.'); return; }
            var blob = new Blob([res.data.csv], { type: 'text/csv;charset=utf-8;' });
            var url  = URL.createObjectURL(blob);
            var a    = document.createElement('a');
            a.href     = url;
            a.download = filename || 'if2-submissions.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        });
    }

    $('#if2-export-all').on('click', function (e) {
        e.preventDefault();
        downloadCSV(0, 'if2-all-submissions.csv');
    });

    $(document).on('click', '#if2-export-form', function (e) {
        e.preventDefault();
        var fid = $(this).data('form-id');
        downloadCSV(fid, 'if2-form-' + fid + '-submissions.csv');
    });

    // -------------------------------------------------------------------------
    // Statistiche pagina dedicata — periodo custom + analisi hotel
    // -------------------------------------------------------------------------

    // Mostra/nascondi riga date custom
    $(document).on('change', '#if2-stats-period-select', function () {
        $('#if2-stats-custom-row').toggle($(this).val() === 'custom');
    });

    // Popola dropdown Config Hotel quando si cambia form
    $(document).on('change', '#if2-stats-form-filter', function () {
        var fid = parseInt($(this).val(), 10) || 0;
        var $selects = $('#if2-checkin-field, #if2-checkout-field, #if2-target-field');
        if (!fid) { $selects.html('<option value="">— Auto —</option>'); return; }
        $.post(ajaxurl, { action: 'if2_get_form', nonce: nonce, form_id: fid }, function (res) {
            if (!res.success || !res.data || !res.data.fields) return;
            var skip = ['submit', 'heading', 'html', 'page_break'];
            var opts = '<option value="">— Auto —</option>';
            res.data.fields.forEach(function (f) {
                if (skip.indexOf(f.type || '') !== -1) return;
                opts += '<option value="' + f.id + '">' + (f.label || f.id) + ' (' + (f.type || '') + ')</option>';
            });
            $selects.html(opts);
        });
    });

    // Chart instances hotel
    var _hotelCharts = {};
    function destroyHotelCharts() {
        Object.keys(_hotelCharts).forEach(function (k) {
            if (_hotelCharts[k]) { _hotelCharts[k].destroy(); _hotelCharts[k] = null; }
        });
    }

    var PINK_PALETTE = ['#BD1350','#D82D6B','#E04A82','#EA729A','#F299B5','#F6BECD','#F9D5E0','#FCEAF0'];

    function hBar(id, labels, data, label, color) {
        var ctx = document.getElementById(id); if (!ctx) return;
        if (_hotelCharts[id]) { _hotelCharts[id].destroy(); }
        _hotelCharts[id] = new Chart(ctx, {
            type: 'bar',
            data: { labels: labels, datasets: [{ label: label || '', data: data, backgroundColor: color || '#D82D6B', borderRadius: 4, borderSkipped: false }] },
            options: { responsive: true, maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    x: { grid: { display: false }, ticks: { font: { size: 10 }, color: '#888', maxRotation: 40 } },
                    y: { beginAtZero: true, grid: { color: '#f5f5f5' }, ticks: { precision: 0, font: { size: 11 }, color: '#aaa' } }
                }
            }
        });
    }

    function hDonut(id, labels, data, colors, totalOverride) {
        var ctx = document.getElementById(id); if (!ctx) return;
        if (_hotelCharts[id]) { _hotelCharts[id].destroy(); }
        var clrs = (colors || PINK_PALETTE).slice(0, data.length);
        var dataSum = data.reduce(function(a, b) { return a + b; }, 0);
        var total   = totalOverride || dataSum;
        var labelsWithPct = labels.map(function(l, i) {
            var pct = total > 0 ? Math.round(data[i] / total * 100) : 0;
            return l + ' ' + pct + '%';
        });
        _hotelCharts[id] = new Chart(ctx, {
            type: 'doughnut',
            data: { labels: labelsWithPct, datasets: [{ data: data, backgroundColor: clrs, borderWidth: 2, borderColor: '#fff', hoverOffset: 6 }] },
            options: { responsive: true, maintainAspectRatio: false, cutout: '52%',
                plugins: {
                    legend: { position: 'bottom', align: 'center', labels: { boxWidth: 12, font: { size: 11, family: 'inherit' }, color: '#555', padding: 12 } },
                    tooltip: { callbacks: { label: function(c) { return ' ' + c.parsed + ' (' + (total > 0 ? Math.round(c.parsed / total * 100) : 0) + '%)'; } } }
                }
            }
        });
    }

    // ─── PROVENIENZA (geolocalizzazione) ─────────────────────────────────────
    function geoEsc(s){ return (s==null?'':String(s)).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
    var _regAlias = {
        'piemonte':'Piemonte','piedmont':'Piemonte',
        'valledaosta':"Valle d'Aosta/Vallée d'Aoste",'valledaostavalleedaoste':"Valle d'Aosta/Vallée d'Aoste",'aostavalley':"Valle d'Aosta/Vallée d'Aoste",'valleedaoste':"Valle d'Aosta/Vallée d'Aoste",
        'lombardia':'Lombardia','lombardy':'Lombardia',
        'trentinoaltoadige':'Trentino-Alto Adige/Südtirol','trentinoaltoadigesudtirol':'Trentino-Alto Adige/Südtirol','trentinosouthtyrol':'Trentino-Alto Adige/Südtirol','trentino':'Trentino-Alto Adige/Südtirol','sudtirol':'Trentino-Alto Adige/Südtirol',
        'veneto':'Veneto','friuliveneziagiulia':'Friuli-Venezia Giulia','liguria':'Liguria','emiliaromagna':'Emilia-Romagna',
        'toscana':'Toscana','tuscany':'Toscana','umbria':'Umbria','marche':'Marche','marches':'Marche',
        'lazio':'Lazio','latium':'Lazio','abruzzo':'Abruzzo','abruzzi':'Abruzzo','molise':'Molise','campania':'Campania',
        'puglia':'Puglia','apulia':'Puglia','basilicata':'Basilicata','calabria':'Calabria',
        'sicilia':'Sicilia','sicily':'Sicilia','sardegna':'Sardegna','sardinia':'Sardegna'
    };
    function geoNorm(s){ return (s||'').toString().toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^a-z]/g,''); }
    function geoCanonRegion(name){ return _regAlias[geoNorm(name)] || null; }
    function geoColor(cnt, maxC){
        if (!cnt || maxC<=0) return 'rgba(255,255,255,0.16)';
        var t=cnt/maxC, c1=[206,238,244], c2=[0,123,145];
        return 'rgb('+Math.round(c1[0]+(c2[0]-c1[0])*t)+','+Math.round(c1[1]+(c2[1]-c1[1])*t)+','+Math.round(c1[2]+(c2[2]-c1[2])*t)+')';
    }
    function renderGeoMap(countByReg, maxC){
        var topo=window.IF2_IT_TOPO, mapEl=document.getElementById('if2-geo-map'), emptyEl=document.getElementById('if2-geo-map-empty');
        if (!mapEl) return;
        if (!topo){ mapEl.innerHTML=''; return; }
        if (emptyEl) emptyEl.style.display = maxC>0 ? 'none' : '';
        var sc=topo.transform.scale, tr=topo.transform.translate;
        var arcs=topo.arcs.map(function(arc){ var x=0,y=0; return arc.map(function(d){ x+=d[0]; y+=d[1]; return [x*sc[0]+tr[0], y*sc[1]+tr[1]]; }); });
        function ac(i){ return i>=0 ? arcs[i] : arcs[~i].slice().reverse(); }
        function ring(r){ var c=[]; r.forEach(function(i,idx){ var a=ac(i); c=c.concat(idx===0?a:a.slice(1)); }); return c; }
        var b=topo.bbox, W=300, H=360, pad=8, k=Math.cos((b[1]+b[3])/2*Math.PI/180);
        var gw=(b[2]-b[0])*k, gh=(b[3]-b[1]), s=Math.min((W-2*pad)/gw,(H-2*pad)/gh), ox=(W-gw*s)/2, oy=(H-gh*s)/2;
        function proj(lon,lat){ return [Math.round((ox+(lon-b[0])*k*s)*10)/10, Math.round((oy+(b[3]-lat)*s)*10)/10]; }
        var paths=topo.objects.regions.geometries.map(function(geom){
            var name=geom.properties.reg_name, polys=geom.type==='MultiPolygon'?geom.arcs:[geom.arcs], d='';
            polys.forEach(function(rings){ rings.forEach(function(rg){ var co=ring(rg); for(var i=0;i<co.length;i++){ var p=proj(co[i][0],co[i][1]); d+=(i===0?'M':'L')+p[0]+' '+p[1]; } d+='Z'; }); });
            var cnt=countByReg[name]||0;
            return '<path d="'+d+'" fill="'+geoColor(cnt,maxC)+'" stroke="#fff" stroke-width="0.6"><title>'+geoEsc(name)+': '+cnt+'</title></path>';
        }).join('');
        mapEl.innerHTML='<svg viewBox="0 0 '+W+' '+H+'" style="width:100%;max-width:300px;height:auto;display:block;margin:0 auto">'+paths+'</svg>';
    }
    function renderGeoRegions(regions){
        var countByReg={};
        Object.keys(regions||{}).forEach(function(name){ var c=geoCanonRegion(name); if(c) countByReg[c]=(countByReg[c]||0)+(regions[name]||0); });
        var entries=Object.keys(countByReg).map(function(r){return {r:r,c:countByReg[r]};}).sort(function(a,b){return b.c-a.c;});
        var maxC=entries.length?entries[0].c:0;
        var rank=document.getElementById('if2-geo-regions-rank');
        if (rank){
            rank.innerHTML = entries.length ? entries.map(function(e){
                var pct=maxC>0?Math.round(e.c/maxC*100):0;
                return '<div style="margin-bottom:6px"><div style="display:flex;justify-content:space-between;font-size:11px;color:#555;margin-bottom:2px"><span>'+geoEsc(e.r)+'</span><span style="font-weight:700">'+e.c+'</span></div><div style="height:6px;background:#eee;border-radius:3px;overflow:hidden"><div style="height:100%;width:'+pct+'%;background:#009bb9"></div></div></div>';
            }).join('') : '<div style="color:#aaa;font-size:12px">Nessun dato regione.</div>';
        }
        renderGeoMap(countByReg, maxC);
    }
    function loadGeoStats(formId){
        $.post(ajaxurl, { action:'if2_get_geo_stats', nonce:nonce, form_id: formId||0 }, function(res){
            if (!res || !res.success || !res.data || !res.data.configured){ $('#if2-section-geo').hide(); return; }
            var g=res.data;
            $('#if2-section-geo').show();
            $('#if2-geo-total').text(g.total||0);
            $('#if2-geo-top-country').text(g.top_country||'—');
            $('#if2-geo-top-country-sub').text(g.top_country_count?g.top_country_count+' richieste':'');
            $('#if2-geo-top-city').text(g.top_city||'—');
            $('#if2-geo-top-city-sub').text(g.top_city_count?g.top_city_count+' richieste':'');
            var cities=g.cities||[];
            if (cities.length) hDonut('if2-geo-cities-chart', cities.map(function(c){return c.name;}), cities.map(function(c){return c.count;}), PINK_PALETTE);
            renderGeoRegions(g.regions||{});
        });
    }

    function renderHotelStats(d) {
        destroyHotelCharts();
        $('#if2-hotel-stats').show();
        $('#if2-section-summary').show();
        $('#if2-total-requests').text(d.total || 0);

        // Soggiorno
        if (d.soggiorno) {
            var s = d.soggiorno;
            $('#if2-section-soggiorno').show();
            $('#if2-avg-stay').text(s.media_giorni + ' giorni');
            $('#if2-stay-count').text('su ' + s.count + ' soggiorni calcolati');
            $('#if2-top-bucket').text(s.top_bucket);
            $('#if2-top-bucket-pct').text(s.top_bucket_pct + ' delle richieste');
            hDonut('if2-chart-stay-pie', s.pie.labels, s.pie.data, PINK_PALETTE);
        } else {
            $('#if2-section-soggiorno').hide();
        }

        // Target
        if (d.target) {
            var tg = d.target;
            $('#if2-section-target').show();
            $('#if2-top-target').text(tg.top);
            $('#if2-top-target-pct').text(tg.top_pct + ' delle richieste');
            $('#if2-top-target-2').text(tg.top);
            $('#if2-top-target-pct-2').text(tg.top_pct + ' delle richieste');
            hDonut('if2-chart-target-pie', tg.pie.labels, tg.pie.data, PINK_PALETTE);
        } else {
            $('#if2-section-target').hide();
            $('#if2-top-target').text('—'); $('#if2-top-target-pct').text('');
        }

        // Periodo — sempre visibile
        var p = d.periodo || { labels: [], data: [], top_month: null, top_week: null, stacked: [], months_pie: { labels: [], data: [] }, weeks_pie: { labels: [], data: [] } };
        $('#if2-section-periodo, #if2-section-periodo-months-bar, #if2-section-periodo-weeks, #if2-section-periodo-weeks-bar').show();
        $('#if2-top-month').text(p.top_month || '—');
        $('#if2-top-month-pct').text(p.top_month_pct ? p.top_month_pct + ' delle richieste' : '');
        if (p.top_week) {
            $('#if2-top-week').text(p.top_week.label);
            $('#if2-top-week-pct').text(p.top_week.pct + ' delle richieste');
        } else {
            $('#if2-top-week').text('—'); $('#if2-top-week-pct').text('');
        }
        // Months donut
        hDonut('if2-chart-periodo-months', p.months_pie.labels, p.months_pie.data, PINK_PALETTE);
        var mPairs = p.months_pie.labels.map(function(l, i) { return { l: l, d: p.months_pie.data[i] }; });
        mPairs.sort(function(a, b) { return b.d - a.d; });
        hBar('if2-chart-months-bar',
            mPairs.map(function(m) { return m.l; }),
            mPairs.map(function(m) { return m.d; }),
            'Richieste', '#BD1350');
        // Weeks donut
        hDonut('if2-chart-periodo-weeks', p.weeks_pie.labels, p.weeks_pie.data, PINK_PALETTE);
        var wL = p.weeks_pie.labels.slice(0, 5);
        var wD = p.weeks_pie.data.slice(0, 5);
        hBar('if2-chart-weeks-bar', wL, wD, 'Richieste', '#D82D6B');

        // Booking window
        if (d.booking_window) {
            var bw = d.booking_window;
            $('#if2-bw-summary-box').show();
            $('#if2-top-bw-avg').text(bw.media_giorni + ' gg');
            $('#if2-section-booking-window').show();
            $('#if2-bw-avg').text(bw.media_giorni + ' giorni');
            $('#if2-bw-count').text('su ' + bw.count + ' richieste');
            $('#if2-bw-top').text(bw.top_bucket);
            $('#if2-bw-top-pct').text(bw.top_pct + ' delle richieste');
            hDonut('if2-chart-bw-pie', bw.pie.labels, bw.pie.data, PINK_PALETTE);
        } else {
            $('#if2-bw-summary-box').hide();
            $('#if2-section-booking-window').hide();
        }

        // Canali
        if (d.canali) {
            var cn = d.canali;
            $('#if2-section-canali').show();
            $('#if2-top-canale').text(cn.top);
            $('#if2-top-canale-pct').text(cn.top_pct + ' delle richieste');
            if (cn.tracked !== undefined && d.total && cn.tracked < d.total) {
                $('#if2-canali-tracked').text(cn.tracked + ' su ' + d.total + ' con canale tracciato').show();
            } else {
                $('#if2-canali-tracked').hide();
            }
            hDonut('if2-chart-canali-pie', cn.pie.labels, cn.pie.data, PINK_PALETTE, d.total);
        } else {
            $('#if2-section-canali').hide();
        }
    }

    // -------------------------------------------------------------------------
    // Statistiche — pulsante CARICA (pagina stats dedicata — per-campo + hotel)
    // -------------------------------------------------------------------------
    // Helper: compute comparison date range
    function getCompareDates(period, compareWith, dateFrom, dateTo) {
        var now = new Date();
        var msDay = 86400000;
        var mainFrom, mainTo, dur;
        if (period === '1s')  { mainTo = now; mainFrom = new Date(+now - 7 * msDay); }
        else if (period === '2s')  { mainTo = now; mainFrom = new Date(+now - 14 * msDay); }
        else if (period === '1m')  { mainTo = now; mainFrom = new Date(+now - 30 * msDay); }
        else if (period === '3m')  { mainTo = now; mainFrom = new Date(+now - 90 * msDay); }
        else if (period === '6m')  { mainTo = now; mainFrom = new Date(+now - 180 * msDay); }
        else if (period === '1a')  { mainTo = now; mainFrom = new Date(+now - 365 * msDay); }
        else if (period === 'custom' && dateFrom && dateTo) { mainFrom = new Date(dateFrom); mainTo = new Date(dateTo); }
        else return null;
        dur = +mainTo - +mainFrom;
        if (compareWith === 'prev') {
            return { from: fmtDate(new Date(+mainFrom - dur)), to: fmtDate(new Date(+mainTo - dur)) };
        } else if (compareWith === 'year') {
            var f2 = new Date(mainFrom); f2.setFullYear(f2.getFullYear() - 1);
            var t2 = new Date(mainTo);   t2.setFullYear(t2.getFullYear() - 1);
            return { from: fmtDate(f2), to: fmtDate(t2) };
        }
        return null;
    }
    function fmtDate(d) {
        return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    }

    // Data-to non può essere prima di data-from
    $(document).on('change', '#if2-stats-date-from', function () {
        var val = $(this).val();
        var $to = $('#if2-stats-date-to');
        $to.attr('min', val || '');
        if (val && $to.val() && $to.val() < val) $to.val(val);
    });

    $(document).on('click', '#if2-load-stats-btn', function () {
        currentFormId = parseInt($('#if2-stats-form-filter').val(), 10) || 0;
        var periodSel = $('#if2-stats-period-select');
        if (periodSel.length) currentRange = periodSel.val() || 'all';
        var dateFrom    = $('#if2-stats-date-from').val() || '';
        var dateTo      = $('#if2-stats-date-to').val()   || '';
        var compareMode = $('#if2-compare-mode').val()    || '';

        // form_id=0 significa "tutti i form" — consentito

        var channelFilter = $('#if2-stats-channel-filter').val() || '';
        var $btn = $(this).prop('disabled', true).text('Caricamento…');
        $('#if2-stats-empty').hide();
        $('#if2-stats-content').empty().show();
        $('#if2-hotel-stats').hide();
        $('#if2-compare-badge').text('').removeClass('if2-analytics-box-delta if2-delta-up if2-delta-down');

        // Chiamata per-campo
        var postData = {
            action:  'if2_get_field_stats',
            nonce:   nonce,
            form_id: currentFormId,
            period:  currentRange,
            channel: channelFilter,
        };
        if (currentRange === 'custom') { postData.date_from = dateFrom; postData.date_to = dateTo; }

        $.post(ajaxurl, postData, function (res) {
            $btn.prop('disabled', false).text('CARICA');
            if (!res.success || !res.data.fields || !res.data.fields.length) {
                $('#if2-stats-content').hide();
                if (!$('#if2-hotel-stats').is(':visible')) $('#if2-stats-empty').show();
            } else {
                renderFieldStats(res.data.fields, currentFormId === 0);
            }
        });

        // Chiamata analisi hotel — sempre eseguita
        var hp = { action: 'if2_get_hotel_stats', nonce: nonce, form_id: currentFormId,
                   period: currentRange, channel: channelFilter,
                   checkin_field:  $('#if2-checkin-field').val()  || '',
                   checkout_field: $('#if2-checkout-field').val() || '',
                   target_field:   $('#if2-target-field').val()   || '' };
        if (currentRange === 'custom') { hp.date_from = dateFrom; hp.date_to = dateTo; }
        $.post(ajaxurl, hp, function (res) {
            if (res.success && res.data) {
                renderHotelStats(res.data);
                loadGeoStats(currentFormId);
                $('#if2-stats-empty').hide();

                // Compare
                if (compareMode) {
                    var cDates = getCompareDates(currentRange, compareMode, dateFrom, dateTo);
                    if (cDates) {
                        var hpC = { action: 'if2_get_hotel_stats', nonce: nonce, form_id: currentFormId,
                                    period: 'custom', checkin_field: '', checkout_field: '',
                                    target_field: '', date_from: cDates.from, date_to: cDates.to };
                        $.post(ajaxurl, hpC, function (resC) {
                            if (resC.success && resC.data) {
                                var currTotal = res.data.total || 0;
                                var prevTotal = resC.data.total || 0;
                                var lbl = compareMode === 'year' ? 'anno prec.' : 'periodo prec.';
                                if (prevTotal > 0) {
                                    var diff  = Math.round((currTotal - prevTotal) / prevTotal * 100);
                                    var cls   = diff >= 0 ? 'if2-delta-up' : 'if2-delta-down';
                                    var arrow = diff >= 0 ? '▲' : '▼';
                                    var color = diff >= 0 ? '#27ae60' : '#e74c3c';
                                    var html  = prevTotal + ' (' + lbl + ')' +
                                                '<br><span style="color:' + color + ';font-weight:700">' +
                                                arrow + ' ' + Math.abs(diff) + '%</span>';
                                    $('#if2-compare-badge')
                                        .html(html)
                                        .addClass('if2-analytics-box-delta ' + cls);
                                } else {
                                    $('#if2-compare-badge')
                                        .text('0 (' + lbl + ')')
                                        .addClass('if2-analytics-box-delta');
                                }
                            }
                        });
                    } else {
                        $('#if2-compare-badge').text('Seleziona un periodo specifico per confrontare').css('color', '#aaa');
                    }
                }
            }
        });
    });

    function escHtml(str) {
        return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }

    function renderFieldStats(fields, allForms) {
        var $container = $('#if2-stats-content').empty();
        if (!fields || !fields.length) { return; }
        $container.append('<div style="font-size:10px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:.07em;padding:6px 0 12px">ANALISI FORM</div>');
        fields.forEach(function (field) {
            var cid  = 'if2-fchart-' + field.id;
            var html = '<div class="if2-field-chart-card">' +
                '<div class="if2-field-chart-header">' +
                '<span class="if2-field-chart-title">' + escHtml(field.label) + '</span>' +
                '<span class="if2-field-chart-count">Risposte analizzate: ' + field.total + '</span>' +
                '</div>' +
                '<div class="if2-field-chart-body"><canvas id="' + cid + '"></canvas></div>' +
                '</div>';
            $container.append(html);

            var ctx = document.getElementById(cid);
            if (!ctx) return;
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: field.labels,
                    datasets: [{
                        label: 'Count',
                        data:  field.data,
                        backgroundColor: 'rgba(216,45,107,0.75)',
                        borderColor:     '#d82d6b',
                        borderWidth: 1,
                        borderRadius: 2,
                    }],
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: { callbacks: { label: function (c) { return ' ' + c.parsed.y; } } }
                    },
                    scales: {
                        x: { grid: { display: false }, ticks: { font: { size: 11 }, color: '#aaa', maxRotation: 45 } },
                        y: { beginAtZero: true, grid: { color: '#f5f5f5' }, ticks: { font: { size: 11 }, color: '#aaa', precision: 0 } },
                    },
                },
            });
        });
    }

    // -------------------------------------------------------------------------
    // Test connessione Supabase (pagina settings)
    // -------------------------------------------------------------------------
    $(document).on('click', '#if2-test-supabase', function () {
        var url = $('input[name="supabase_url"]').val().trim();
        var key = $('input[name="supabase_anon_key"]').val().trim();
        var s    = IF2Admin.strings || {};
        var $res = $('#if2-supabase-test-result').text(s.testing || 'Test in corso…').css('color', '#888');

        if (!url || !key) {
            $res.text(s.insert_url_key || 'Inserisci URL e API Key.').css('color', '#e53e3e');
            return;
        }

        fetch(url + '/rest/v1/form_submissions?limit=1', {
            method:  'GET',
            headers: { 'apikey': key, 'Authorization': 'Bearer ' + key, 'Accept': 'application/json' },
        })
        .then(function (r) {
            // 200 (service_role), 401/403 con anon+RLS = chiave valida ma SELECT non permessa (ok)
            if (r.ok || r.status === 401 || r.status === 403) {
                $res.text(s.connection_ok || '✓ Connessione OK').css('color', '#38a169');
            } else {
                $res.text((s.connection_error || '✗ Errore ') + r.status).css('color', '#e53e3e');
            }
        })
        .catch(function () {
            $res.text(s.connection_failed || '✗ Connessione fallita').css('color', '#e53e3e');
        });
    });

    // -------------------------------------------------------------------------
    // Test connessione Amelia / SMSHosting (pagina settings)
    // -------------------------------------------------------------------------
    $(document).on('click', '#if2-test-amelia', function () {
        var key    = $('#if2_amelia_key').val().trim();
        var secret = $('#if2_amelia_secret').val().trim();
        var apiurl = $('#if2_amelia_apiurl').val().trim() || 'https://api.smsgatewayapi.com/v1';
        var $res   = $('#if2-amelia-test-result').text('Test in corso…').css('color', '#888');

        if (!key || !secret) {
            $res.text('Inserisci Auth Key e Auth Secret.').css('color', '#e53e3e');
            return;
        }

        $.post(ajaxurl, {
            action: 'if2_test_amelia',
            nonce:  nonce,
            key:    key,
            secret: secret,
            apiurl: apiurl,
        }, function (res) {
            if (res.success) {
                $res.text(res.data.message || '✓ Connessione OK').css('color', '#38a169');
            } else {
                $res.text(res.data.message || '✗ Connessione fallita').css('color', '#e53e3e');
            }
        }).fail(function () {
            $res.text('✗ Errore di rete').css('color', '#e53e3e');
        });
    });

    // Test aggiungi contatto Amelia
    $(document).on('click', '#if2-test-amelia-contact', function () {
        var key    = $('#if2_amelia_key').val().trim();
        var secret = $('#if2_amelia_secret').val().trim();
        var apiurl = $('#if2_amelia_apiurl').val().trim() || 'https://api.smshosting.it/rest/api';
        var listid = $('#if2_amelia_listid').val().trim();
        var phone  = $('#if2-amelia-test-phone').val().trim();
        var $res   = $('#if2-amelia-contact-result').text('Test in corso…').css('color', '#888');

        $.post(ajaxurl, { action: 'if2_test_amelia_contact', nonce: nonce, key: key, secret: secret, apiurl: apiurl, listid: listid, phone: phone }, function (res) {
            if (res.success) {
                $res.text(res.data.message || '✓ OK').css('color', '#38a169');
            } else {
                $res.text(res.data.message || '✗ Errore').css('color', '#e53e3e');
            }
        }).fail(function () {
            $res.text('✗ Errore di rete').css('color', '#e53e3e');
        });
    });

    // -------------------------------------------------------------------------
    // Amelia — liste multi-paese (pagina Impostazioni)
    // -------------------------------------------------------------------------
    var IF2_AMELIA_COUNTRIES = [
        { value: 'IT',    label: 'IT — Italia (.it)' },
        { value: 'DE',    label: 'DE — Germania (.de, .at, .ch)' },
        { value: 'FR',    label: 'FR — Francia (.fr)' },
        { value: 'EN',    label: 'EN — UK / Internazionale (.uk, .co.uk, .com, .ie)' },
        { value: 'CZ',    label: 'CZ — Repubblica Ceca (.cz)' },
        { value: 'PL',    label: 'PL — Polonia (.pl)' },
        { value: 'RO',    label: 'RO — Romania (.ro)' },
        { value: 'CA',    label: 'CA — Canada (.ca)' },
        { value: 'ES',    label: 'ES — Spagna (.es)' },
        { value: 'ALTRO', label: 'ALTRO — Altri' },
    ];

    function buildAmeliaCountrySelect(selectedVal) {
        var html = '<select name="if2_amelia_list_country[]" style="padding:4px 6px;border:1px solid #ccc;border-radius:3px;font-size:13px">';
        IF2_AMELIA_COUNTRIES.forEach(function (c) {
            html += '<option value="' + c.value + '"' + (c.value === selectedVal ? ' selected' : '') + '>' + c.label + '</option>';
        });
        html += '</select>';
        return html;
    }

    function buildAmeliaListRow(listid, country) {
        return '<tr>' +
            '<td style="padding:4px 0"><input type="text" name="if2_amelia_list_id[]" value="' + (listid || '') + '" placeholder="es. 42" style="width:120px;padding:4px 6px;border:1px solid #ccc;border-radius:3px;font-size:13px"></td>' +
            '<td style="padding:4px 0 4px 10px">' + buildAmeliaCountrySelect(country || 'IT') + '</td>' +
            '<td style="padding:4px 0 4px 8px"><button type="button" class="if2-amelia-remove-list" style="background:none;border:none;color:#d82d6b;cursor:pointer;font-size:16px;padding:0 4px;line-height:1" title="Rimuovi">✕</button></td>' +
            '</tr>';
    }

    $(document).on('click', '#if2-amelia-add-list', function () {
        $('#if2-amelia-lists-tbody').append(buildAmeliaListRow('', 'IT'));
    });

    $(document).on('click', '.if2-amelia-remove-list', function () {
        $(this).closest('tr').remove();
    });

    // -------------------------------------------------------------------------
    // Toggle label dinamico anti-spam
    // -------------------------------------------------------------------------
    $(document).on('change', '.if2-toggle input[type="checkbox"]', function () {
        var label = $(this).closest('.if2-toggle').find('.if2-toggle-label');
        var s = IF2Admin.strings || {};
        label.text($(this).is(':checked') ? (s.active || 'Attivo') : (s.inactive || 'Disattivo'));
    });

    // -------------------------------------------------------------------------
    // Risposte — NASCONDI CAMPI VUOTI (default: nascosti)
    // -------------------------------------------------------------------------
    var emptyHidden = true;
    function applyEmptyState() {
        var s = IF2Admin.strings || {};
        $('.if2-sub-grid-field.if2-field-empty').toggleClass('if2-hidden', emptyHidden);
        $('#if2-toggle-empty').text(emptyHidden ? (s.show_empty_fields || 'MOSTRA CAMPI VUOTI') : (s.hide_empty_fields || 'NASCONDI CAMPI VUOTI'));
    }
    $(document).ready(function () { applyEmptyState(); });
    $(document).on('click', '#if2-toggle-empty', function () {
        emptyHidden = !emptyHidden;
        applyEmptyState();
    });

    // -------------------------------------------------------------------------
    // Risposte — STAMPA
    // -------------------------------------------------------------------------
    $(document).on('click', '#if2-print-sub', function () {
        window.print();
    });

    // -------------------------------------------------------------------------
    // Risposte — ricerca nella lista sinistra
    // -------------------------------------------------------------------------
    $(document).on('input', '#if2-search-submissions', function () {
        var q = $(this).val().toLowerCase();
        $('#if2-submissions-table tbody tr').each(function () {
            var text = $(this).text().toLowerCase();
            $(this).toggle(!q || text.indexOf(q) !== -1);
        });
    });

    // -------------------------------------------------------------------------
    // Submissions — ordina per data di creazione
    // -------------------------------------------------------------------------
    $(document).on('click', '#if2-sub-sort-created', function () {
        var $ico    = $('#if2-sub-sort-ico');
        var $tbody  = $('#if2-submissions-table tbody');
        var $rows   = $tbody.find('tr.if2-form-row');
        var curDir  = $(this).data('sort-dir') || 'desc';
        var asc     = (curDir === 'desc');
        $rows.sort(function (a, b) {
            var ta = parseInt($(a).data('ts'), 10) || 0;
            var tb = parseInt($(b).data('ts'), 10) || 0;
            return asc ? ta - tb : tb - ta;
        });
        $tbody.append($rows);
        $(this).data('sort-dir', asc ? 'asc' : 'desc');
        $ico.text(asc ? '↑' : '↓').css('color', '#d82d6b');
    });

    // -------------------------------------------------------------------------
    // Risposte — export CSV dal pannello sinistro
    // -------------------------------------------------------------------------
    $(document).on('click', '#if2-export-sub', function (e) {
        e.preventDefault();
        var fid = parseInt($(this).data('form-id'), 10) || 0;
        downloadCSV(fid, fid ? 'if2-form-' + fid + '-submissions.csv' : 'if2-all-submissions.csv');
    });

    // -------------------------------------------------------------------------
    // Risposte — elimina e torna alla lista
    // -------------------------------------------------------------------------
    $(document).on('click', '.if2-delete-submission', function () {
        var id = $(this).data('id');
        if (!confirm('Eliminare questa submission?')) return;
        var $row = $('#if2-submissions-table tr[data-sub-id="' + id + '"]');

        $.post(ajaxurl, { action: 'if2_delete_submission', nonce: nonce, submission_id: id }, function (res) {
            if (res.success) {
                if ($row.length) {
                    $row.fadeOut(300, function () { $(this).remove(); });
                } else {
                    // Siamo nel pannello destro — torna alla lista
                    var url = window.location.href.replace(/&sub_id=\d+/, '');
                    window.location.href = url;
                }
            } else {
                alert('Errore eliminazione submission.');
            }
        });
    });

    // -------------------------------------------------------------------------
    // Sorting colonne DATA CREAZIONE e ULTIMA MODIFICA nella tabella Form
    // -------------------------------------------------------------------------
    var $formsTable = $('#if2-forms-table');
    var originalRowOrder = null; // saved on first sort

    function saveOriginalOrder() {
        if (originalRowOrder !== null) return;
        originalRowOrder = $formsTable.find('tbody tr:not(.if2-empty-row)').toArray().map(function (r) { return r; });
    }

    function restoreOriginalOrder() {
        if (!originalRowOrder) return;
        var $tbody = $formsTable.find('tbody');
        $.each(originalRowOrder, function (i, row) { $tbody.append(row); });
    }

    function applySort(tdClass, icoId, activeCol) {
        saveOriginalOrder();
        var $tbody = $formsTable.find('tbody');
        var $rows  = $tbody.find('tr:not(.if2-empty-row)').toArray();

        // Reset both icons
        $('#if2-sort-ico').text('↕').css('color', '#bbb');
        $('#if2-sort-ico-created').text('↕').css('color', '#bbb');

        // If already sorted asc by this col → restore original
        if ($formsTable.data('sort-col') === activeCol) {
            $formsTable.removeData('sort-col');
            restoreOriginalOrder();
            return;
        }

        // Sort ascending (oldest → newest)
        $rows.sort(function (a, b) {
            var ta = parseInt($(a).find('td.' + tdClass).data('ts'), 10) || 0;
            var tb = parseInt($(b).find('td.' + tdClass).data('ts'), 10) || 0;
            return ta - tb;
        });
        $.each($rows, function (i, row) { $tbody.append(row); });
        $formsTable.data('sort-col', activeCol);
        $(icoId).text('↑').css('color', '#d82d6b');
    }

    $('#if2-sort-date').on('click', function () {
        applySort('if2-form-date', '#if2-sort-ico', 'date');
    });
    $('#if2-sort-created').on('click', function () {
        applySort('if2-form-created', '#if2-sort-ico-created', 'created');
    });

    // -------------------------------------------------------------------------
    // Equalizza altezza pannelli nella pagina Forms
    // -------------------------------------------------------------------------
    function equalizeFormPanels() {
        var $left  = $('.if2-panel-forms');
        var $right = $('.if2-panel-stats');
        if (!$left.length || !$right.length) return;
        $left[0].style.minHeight = '';
        var h = $right.outerHeight(true);
        if (h > $left.outerHeight(true)) $left[0].style.minHeight = h + 'px';
    }

    // -------------------------------------------------------------------------
    // Avvio
    // -------------------------------------------------------------------------
    // Equalizza pannelli nella pagina Risposte (server-rendered, no chart)
    if ($('.if2-panel-forms').length && $('.if2-panel-stats').length && !$('#if2-stats-chart').length) {
        equalizeFormPanels();
        setTimeout(equalizeFormPanels, 150);
        setTimeout(equalizeFormPanels, 500);
        $(window).on('load', equalizeFormPanels);
        if (window.ResizeObserver && $('.if2-panel-stats')[0]) {
            new ResizeObserver(equalizeFormPanels).observe($('.if2-panel-stats')[0]);
        }
    }

    // Carica stats solo nella dashboard Forms (non nella pagina Statistiche dedicata)
    if ($('#if2-stats-chart').length && !$('#if2-load-stats-btn').length) {
        loadStats();
        setTimeout(equalizeFormPanels, 200);
        setTimeout(equalizeFormPanels, 800);
        $(window).on('load', equalizeFormPanels);
        // Ogni volta che il pannello stats cambia altezza, ricalcola
        if (window.ResizeObserver && $('.if2-panel-stats')[0]) {
            new ResizeObserver(equalizeFormPanels).observe($('.if2-panel-stats')[0]);
        }
    }

});
