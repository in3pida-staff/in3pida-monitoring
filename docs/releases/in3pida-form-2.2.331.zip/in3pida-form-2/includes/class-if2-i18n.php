<?php
defined('ABSPATH') || exit;

class IF2_I18n {

    // ── Traduzioni label/placeholder campi ────────────────────────────────────
    private static array $labels = [
        'arrivo'                               => ['en'=>'Check-in',            'de'=>'Ankunft',              'fr'=>'Arrivée',               'pl'=>'Przyjazd',             'cs'=>'Příjezd',              'hu'=>'Érkezés',              'es'=>'Llegada',              'pt'=>'Chegada',              'sl'=>'Prihod',               'hr'=>'Dolazak'],
        'partenza'                             => ['en'=>'Check-out',           'de'=>'Abreise',              'fr'=>'Départ',                'pl'=>'Wyjazd',               'cs'=>'Odjezd',               'hu'=>'Távozás',              'es'=>'Salida',               'pt'=>'Saída',                'sl'=>'Odhod',                'hr'=>'Odlazak'],
        'nome e cognome'                       => ['en'=>'Full Name',           'de'=>'Vor- und Nachname',    'fr'=>'Nom et prénom',         'pl'=>'Imię i nazwisko',      'cs'=>'Jméno a příjmení',     'hu'=>'Teljes név',           'es'=>'Nombre y apellido',    'pt'=>'Nome e apelido',       'sl'=>'Ime in priimek',       'hr'=>'Ime i prezime'],
        'nome'                                 => ['en'=>'First Name',          'de'=>'Vorname',              'fr'=>'Prénom',                'pl'=>'Imię',                 'cs'=>'Jméno',                'hu'=>'Keresztnév',           'es'=>'Nombre',               'pt'=>'Nome',                 'sl'=>'Ime',                  'hr'=>'Ime'],
        'cognome'                              => ['en'=>'Last Name',           'de'=>'Nachname',             'fr'=>'Nom',                   'pl'=>'Nazwisko',             'cs'=>'Příjmení',             'hu'=>'Vezetéknév',           'es'=>'Apellido',             'pt'=>'Apelido',              'sl'=>'Priimek',              'hr'=>'Prezime'],
        'e-mail'                               => ['en'=>'E-mail',              'de'=>'E-Mail',               'fr'=>'E-mail',                'pl'=>'E-mail',               'cs'=>'E-mail',               'hu'=>'E-mail',               'es'=>'Correo electrónico',   'pt'=>'E-mail',               'sl'=>'E-pošta',              'hr'=>'E-mail'],
        'email'                                => ['en'=>'E-mail',              'de'=>'E-Mail',               'fr'=>'E-mail',                'pl'=>'E-mail',               'cs'=>'E-mail',               'hu'=>'E-mail',               'es'=>'Correo electrónico',   'pt'=>'E-mail',               'sl'=>'E-pošta',              'hr'=>'E-mail'],
        'adulti'                               => ['en'=>'Adults',              'de'=>'Erwachsene',           'fr'=>'Adultes',               'pl'=>'Dorośli',              'cs'=>'Dospělí',              'hu'=>'Felnőttek',            'es'=>'Adultos',              'pt'=>'Adultos',              'sl'=>'Odrasli',              'hr'=>'Odrasli'],
        'bambini'                              => ['en'=>'Children',            'de'=>'Kinder',               'fr'=>'Enfants',               'pl'=>'Dzieci',               'cs'=>'Děti',                 'hu'=>'Gyerekek',             'es'=>'Niños',                'pt'=>'Crianças',             'sl'=>'Otroci',               'hr'=>'Djeca'],
        'età 1° bimbo'                         => ['en'=>'Child 1 Age',         'de'=>'Alter Kind 1',         'fr'=>'Âge enfant 1',          'pl'=>'Wiek dziecka 1',       'cs'=>'Věk dítěte 1',         'hu'=>'1. gyermek kora',      'es'=>'Edad niño 1',          'pt'=>'Idade criança 1',      'sl'=>'Starost otroka 1',     'hr'=>'Dob djeteta 1'],
        'eta 1° bimbo'                         => ['en'=>'Child 1 Age',         'de'=>'Alter Kind 1',         'fr'=>'Âge enfant 1',          'pl'=>'Wiek dziecka 1',       'cs'=>'Věk dítěte 1',         'hu'=>'1. gyermek kora',      'es'=>'Edad niño 1',          'pt'=>'Idade criança 1',      'sl'=>'Starost otroka 1',     'hr'=>'Dob djeteta 1'],
        'età 2° bimbo'                         => ['en'=>'Child 2 Age',         'de'=>'Alter Kind 2',         'fr'=>'Âge enfant 2',          'pl'=>'Wiek dziecka 2',       'cs'=>'Věk dítěte 2',         'hu'=>'2. gyermek kora',      'es'=>'Edad niño 2',          'pt'=>'Idade criança 2',      'sl'=>'Starost otroka 2',     'hr'=>'Dob djeteta 2'],
        'età 2° bimbo'                         => ['en'=>'Child 2 Age',         'de'=>'Alter Kind 2',         'fr'=>'Âge enfant 2',          'pl'=>'Wiek dziecka 2',       'cs'=>'Věk dítěte 2',         'hu'=>'2. gyermek kora',      'es'=>'Edad niño 2',          'pt'=>'Idade criança 2',      'sl'=>'Starost otroka 2',     'hr'=>'Dob djeteta 2'],
        'eta 2° bimbo'                         => ['en'=>'Child 2 Age',         'de'=>'Alter Kind 2',         'fr'=>'Âge enfant 2',          'pl'=>'Wiek dziecka 2',       'cs'=>'Věk dítěte 2',         'hu'=>'2. gyermek kora',      'es'=>'Edad niño 2',          'pt'=>'Idade criança 2',      'sl'=>'Starost otroka 2',     'hr'=>'Dob djeteta 2'],
        'età 3° bimbo'                         => ['en'=>'Child 3 Age',         'de'=>'Alter Kind 3',         'fr'=>'Âge enfant 3',          'pl'=>'Wiek dziecka 3',       'cs'=>'Věk dítěte 3',         'hu'=>'3. gyermek kora',      'es'=>'Edad niño 3',          'pt'=>'Idade criança 3',      'sl'=>'Starost otroka 3',     'hr'=>'Dob djeteta 3'],
        'eta 3° bimbo'                         => ['en'=>'Child 3 Age',         'de'=>'Alter Kind 3',         'fr'=>'Âge enfant 3',          'pl'=>'Wiek dziecka 3',       'cs'=>'Věk dítěte 3',         'hu'=>'3. gyermek kora',      'es'=>'Edad niño 3',          'pt'=>'Idade criança 3',      'sl'=>'Starost otroka 3',     'hr'=>'Dob djeteta 3'],
        'età 4° bimbo'                         => ['en'=>'Child 4 Age',         'de'=>'Alter Kind 4',         'fr'=>'Âge enfant 4',          'pl'=>'Wiek dziecka 4',       'cs'=>'Věk dítěte 4',         'hu'=>'4. gyermek kora',      'es'=>'Edad niño 4',          'pt'=>'Idade criança 4',      'sl'=>'Starost otroka 4',     'hr'=>'Dob djeteta 4'],
        'eta 4° bimbo'                         => ['en'=>'Child 4 Age',         'de'=>'Alter Kind 4',         'fr'=>'Âge enfant 4',          'pl'=>'Wiek dziecka 4',       'cs'=>'Věk dítěte 4',         'hu'=>'4. gyermek kora',      'es'=>'Edad niño 4',          'pt'=>'Idade criança 4',      'sl'=>'Starost otroka 4',     'hr'=>'Dob djeteta 4'],
        'trattamento'                          => ['en'=>'Board Type',          'de'=>'Verpflegung',          'fr'=>'Type de pension',       'pl'=>'Wyżywienie',           'cs'=>'Stravování',           'hu'=>'Ellátás',              'es'=>'Régimen',              'pt'=>'Regime',               'sl'=>'Vrsta nastanitve',     'hr'=>'Vrsta pansiona'],
        'telefono'                             => ['en'=>'Phone',               'de'=>'Telefon',              'fr'=>'Téléphone',             'pl'=>'Telefon',              'cs'=>'Telefon',              'hu'=>'Telefon',              'es'=>'Teléfono',             'pt'=>'Telefone',             'sl'=>'Telefon',              'hr'=>'Telefon'],
        'note'                                 => ['en'=>'Notes',               'de'=>'Anmerkungen',          'fr'=>'Remarques',             'pl'=>'Uwagi',                'cs'=>'Poznámky',             'hu'=>'Megjegyzések',         'es'=>'Notas',                'pt'=>'Notas',                'sl'=>'Opombe',               'hr'=>'Napomene'],
        'scegli file'                          => ['en'=>'Choose file',         'de'=>'Datei auswählen',      'fr'=>'Choisir un fichier',    'pl'=>'Wybierz plik',         'cs'=>'Vybrat soubor',        'hu'=>'Fájl kiválasztása',    'es'=>'Elegir archivo',       'pt'=>'Escolher ficheiro',    'sl'=>'Izberi datoteko',      'hr'=>'Odaberi datoteku'],
        'carica file'                          => ['en'=>'Upload file',         'de'=>'Datei hochladen',      'fr'=>'Téléverser un fichier', 'pl'=>'Prześlij plik',        'cs'=>'Nahrát soubor',        'hu'=>'Fájl feltöltése',      'es'=>'Subir archivo',        'pt'=>'Carregar ficheiro',    'sl'=>'Naloži datoteko',      'hr'=>'Učitaj datoteku'],
        'nessun file selezionato'              => ['en'=>'No file selected',    'de'=>'Keine Datei ausgewählt','fr'=>'Aucun fichier sélectionné','pl'=>'Nie wybrano pliku',  'cs'=>'Není vybrán žádný soubor','hu'=>'Nincs fájl kiválasztva','es'=>'Ningún archivo seleccionado','pt'=>'Nenhum ficheiro selecionado','sl'=>'Nobena datoteka ni izbrana','hr'=>'Nijedna datoteka nije odabrana'],
        'accetto l\'informativa sulla privacy' => ['en'=>'I accept the privacy policy','de'=>'Ich akzeptiere die Datenschutzerklärung','fr'=>'J\'accepte la politique de confidentialité','pl'=>'Akceptuję politykę prywatności','cs'=>'Souhlasím se zásadami ochrany osobních údajů','hu'=>'Elfogadom az adatvédelmi nyilatkozatot','es'=>'Acepto la política de privacidad','pt'=>'Aceito a política de privacidade','sl'=>'Sprejemam politiko zasebnosti','hr'=>'Prihvaćam politiku privatnosti'],
        'voglio ricevere promozioni esclusive' => ['en'=>'I want to receive exclusive promotions','de'=>'Ich möchte exklusive Angebote erhalten','fr'=>'Je souhaite recevoir des offres exclusives','pl'=>'Chcę otrzymywać ekskluzywne oferty','cs'=>'Chci dostávat exkluzivní nabídky','hu'=>'Exkluzív ajánlatokat szeretnék kapni','es'=>'Quiero recibir ofertas exclusivas','pt'=>'Quero receber promoções exclusivas','sl'=>'Želim prejemati ekskluzivne ponudbe','hr'=>'Želim primati ekskluzivne ponude'],
        'leggi qui la privacy policy'          => ['en'=>'Read the privacy policy here','de'=>'Hier die Datenschutzerklärung lesen','fr'=>'Consultez ici la politique de confidentialité','pl'=>'Przeczytaj tutaj politykę prywatności','cs'=>'Přečtěte si zásady ochrany osobních údajů','hu'=>'Olvassa el itt az adatvédelmi szabályzatot','es'=>'Lea aquí la política de privacidad','pt'=>'Leia aqui a política de privacidade','sl'=>'Preberite pravilnik o zasebnosti','hr'=>'Pročitajte pravila privatnosti'],
        'leggi la privacy policy'              => ['en'=>'Read the privacy policy','de'=>'Datenschutzerklärung lesen','fr'=>'Lire la politique de confidentialité','pl'=>'Przeczytaj politykę prywatności','cs'=>'Přečíst zásady ochrany osobních údajů','hu'=>'Olvassa el az adatvédelmi szabályzatot','es'=>'Leer la política de privacidad','pt'=>'Ler a política de privacidade','sl'=>'Preberite pravilnik o zasebnosti','hr'=>'Pročitajte pravila privatnosti'],
        'privacy policy'                       => ['en'=>'Privacy Policy','de'=>'Datenschutzerklärung','fr'=>'Politique de confidentialité','pl'=>'Polityka prywatności','cs'=>'Zásady ochrany osobních údajů','hu'=>'Adatvédelmi szabályzat','es'=>'Política de privacidad','pt'=>'Política de privacidade','sl'=>'Pravilnik o zasebnosti','hr'=>'Pravila privatnosti'],
        'invia richiesta'                      => ['en'=>'Send request',        'de'=>'Anfrage senden',       'fr'=>'Envoyer la demande',    'pl'=>'Wyślij zapytanie',     'cs'=>'Odeslat žádost',       'hu'=>'Kérés elküldése',      'es'=>'Enviar solicitud',     'pt'=>'Enviar pedido',        'sl'=>'Pošlji povpraševanje', 'hr'=>'Pošalji upit'],
        'invia'                                => ['en'=>'Send',                'de'=>'Senden',               'fr'=>'Envoyer',               'pl'=>'Wyślij',               'cs'=>'Odeslat',              'hu'=>'Küldés',               'es'=>'Enviar',               'pt'=>'Enviar',               'sl'=>'Pošlji',               'hr'=>'Pošalji'],
        // Opzioni Trattamento
        'pernottamento e colazione'            => ['en'=>'Bed & Breakfast',     'de'=>'Übernachtung mit Frühstück','fr'=>'Chambre et petit-déjeuner','pl'=>'Nocleg ze śniadaniem','cs'=>'Nocleh se snídaní',  'hu'=>'Reggeli',              'es'=>'Alojamiento y desayuno','pt'=>'Alojamento e pequeno-almoço','sl'=>'Nočitev z zajtrkom', 'hr'=>'Noćenje s doručkom'],
        'mezza pensione'                       => ['en'=>'Half Board',          'de'=>'Halbpension',          'fr'=>'Demi-pension',          'pl'=>'Półpensja',            'cs'=>'Polopenze',            'hu'=>'Félpanzió',            'es'=>'Media pensión',        'pt'=>'Meia-pensão',          'sl'=>'Polpenzion',           'hr'=>'Polupansion'],
        'pensione completa'                    => ['en'=>'Full Board',          'de'=>'Vollpension',          'fr'=>'Pension complète',      'pl'=>'Pełne wyżywienie',     'cs'=>'Plná penze',           'hu'=>'Teljes panzió',        'es'=>'Pensión completa',     'pt'=>'Pensão completa',      'sl'=>'Polni penzion',        'hr'=>'Puni pansion'],
        'solo camera'                          => ['en'=>'Room Only',           'de'=>'Nur Zimmer',           'fr'=>'Chambre seule',         'pl'=>'Tylko pokój',          'cs'=>'Pouze pokoj',          'hu'=>'Csak szoba',           'es'=>'Solo habitación',      'pt'=>'Só quarto',            'sl'=>'Samo soba',            'hr'=>'Samo soba'],
        'camera e colazione'                   => ['en'=>'Bed & Breakfast',     'de'=>'Übernachtung mit Frühstück','fr'=>'Chambre et petit-déjeuner','pl'=>'Nocleg ze śniadaniem','cs'=>'Nocleh se snídaní',  'hu'=>'Reggeli',              'es'=>'Alojamiento y desayuno','pt'=>'Alojamento e pequeno-almoço','sl'=>'Nočitev z zajtrkom', 'hr'=>'Noćenje s doručkom'],
        'pernottamento con prima colazione'    => ['en'=>'Bed & Breakfast',     'de'=>'Übernachtung mit Frühstück','fr'=>'Chambre et petit-déjeuner','pl'=>'Nocleg ze śniadaniem','cs'=>'Nocleh se snídaní',  'hu'=>'Reggeli',              'es'=>'Alojamiento y desayuno','pt'=>'Alojamento e pequeno-almoço','sl'=>'Nočitev z zajtrkom', 'hr'=>'Noćenje s doručkom'],
        'all inclusive'                        => ['en'=>'All Inclusive',       'de'=>'All Inclusive',        'fr'=>'All Inclusive',         'pl'=>'All Inclusive',        'cs'=>'All Inclusive',        'hu'=>'All Inclusive',        'es'=>'Todo Incluido',        'pt'=>'Tudo Incluído',        'sl'=>'All Inclusive',        'hr'=>'All Inclusive'],
    ];

    // ── Traduzioni stringhe UI (JS) ────────────────────────────────────────────
    private static array $strings = [
        'required'   => ['it'=>'Questo campo è obbligatorio.',      'en'=>'This field is required.',           'de'=>'Dieses Feld ist erforderlich.',          'fr'=>'Ce champ est obligatoire.',              'pl'=>'To pole jest wymagane.',              'cs'=>'Toto pole je povinné.',             'hu'=>'Ez a mező kötelező.',             'es'=>'Este campo es obligatorio.',          'pt'=>'Este campo é obrigatório.',           'sl'=>'To polje je obvezno.',            'hr'=>'Ovo polje je obavezno.'],
        'email_err'  => ['it'=>'Inserisci un indirizzo email valido.','en'=>'Invalid email address.',           'de'=>'Ungültige E-Mail-Adresse.',              'fr'=>'Adresse e-mail invalide.',               'pl'=>'Nieprawidłowy adres e-mail.',         'cs'=>'Neplatná e-mailová adresa.',        'hu'=>'Érvénytelen e-mail cím.',         'es'=>'Dirección de correo no válida.',      'pt'=>'Endereço de e-mail inválido.',        'sl'=>'Neveljaven e-poštni naslov.',     'hr'=>'Nevažeća e-mail adresa.'],
        'fix_errors' => ['it'=>'Correggi gli errori evidenziati.',   'en'=>'Please fix the highlighted errors.','de'=>'Bitte korrigieren Sie die markierten Fehler.','fr'=>'Veuillez corriger les erreurs.',       'pl'=>'Popraw zaznaczone błędy.',            'cs'=>'Opravte označené chyby.',           'hu'=>'Javítsa a kiemelt hibákat.',      'es'=>'Corrija los errores indicados.',      'pt'=>'Corrija os erros assinalados.',       'sl'=>'Popravite označene napake.',      'hr'=>'Ispravite označene pogreške.'],
        'conn_error' => ['it'=>'Errore di connessione. Riprova.',    'en'=>'Connection error. Please try again.','de'=>'Verbindungsfehler. Bitte erneut versuchen.','fr'=>'Erreur de connexion. Réessayez.',     'pl'=>'Błąd połączenia. Spróbuj ponownie.','cs'=>'Chyba připojení. Zkuste znovu.',    'hu'=>'Csatlakozási hiba. Próbálja újra.','es'=>'Error de conexión. Inténtelo de nuevo.','pt'=>'Erro de ligação. Tente novamente.','sl'=>'Napaka povezave. Poskusite znova.','hr'=>'Greška veze. Pokušajte ponovo.'],
        'multi_err'  => ['it'=>'Hai già inviato questo modulo.',     'en'=>'You have already submitted this form.','de'=>'Sie haben dieses Formular bereits gesendet.','fr'=>'Vous avez déjà envoyé ce formulaire.','pl'=>'Już wysłałeś ten formularz.',       'cs'=>'Tento formulář jste již odeslali.', 'hu'=>'Már elküldte ezt az űrlapot.',    'es'=>'Ya ha enviado este formulario.',      'pt'=>'Já enviou este formulário.',          'sl'=>'Ta obrazec ste že poslali.',      'hr'=>'Već ste poslali ovaj obrazac.'],
        'success'    => ['it'=>'Grazie! Il tuo messaggio è stato inviato.','en'=>'Thank you! Your message has been sent.','de'=>'Danke! Ihre Nachricht wurde gesendet.','fr'=>'Merci ! Votre message a été envoyé.','pl'=>'Dziękujemy! Twoja wiadomość została wysłana.','cs'=>'Děkujeme! Vaše zpráva byla odeslána.','hu'=>'Köszönjük! Üzenetét elküldtük.','es'=>'¡Gracias! Su mensaje ha sido enviado.','pt'=>'Obrigado! A sua mensagem foi enviada.','sl'=>'Hvala! Vaše sporočilo je bilo poslano.','hr'=>'Hvala! Vaša poruka je poslana.'],
        'error'      => ['it'=>'Si è verificato un errore. Riprova.','en'=>'An error occurred. Please try again.','de'=>'Ein Fehler ist aufgetreten. Bitte erneut versuchen.','fr'=>'Une erreur s\'est produite. Veuillez réessayer.','pl'=>'Wystąpił błąd. Spróbuj ponownie.','cs'=>'Došlo k chybě. Zkuste to znovu.','hu'=>'Hiba történt. Kérjük, próbálja újra.','es'=>'Se ha producido un error. Inténtelo de nuevo.','pt'=>'Ocorreu um erro. Tente novamente.','sl'=>'Prišlo je do napake. Poskusite znova.','hr'=>'Došlo je do pogreške. Pokušajte ponovo.'],
    ];

    public static function t(string $text, string $lang): string {
        if ($text === '') return $text;
        // Rimuove suffissi "==traduzione" eventualmente salvati manualmente
        $clean = trim(strpos($text, '==') !== false ? substr($text, 0, strpos($text, '==')) : $text);
        if ($lang === 'it' || $lang === '') return $clean;
        $key = mb_strtolower($clean, 'UTF-8');
        if (isset(self::$labels[$key][$lang])) return self::$labels[$key][$lang];
        // Fallback campi "età bambino" con dicitura libera (es. "Età 1", "Eta 2",
        // "Età 3° bimbo", "Età bambino 4"): riconosce età + numero 1-4 e riusa la
        // traduzione standard "Child N Age". Additivo: se non combacia, resta invariato.
        if (preg_match('/^et[àa][\s0-9]/u', $key) && preg_match('/[1-4]/', $key, $m)) {
            return self::$labels['età ' . $m[0] . '° bimbo'][$lang] ?? $clean;
        }
        return $clean;
    }

    /**
     * Traduce i blocchi "Custom Text" (HTML libero, es. il link "Leggi qui la privacy policy").
     * Traduce SOLO i nodi di testo tra i tag: lascia intatti tag, attributi e href.
     * Ogni nodo viene tradotto solo se il suo testo intero combacia con una voce del
     * dizionario (match esatto), quindi non tocca frasi generiche. Additivo e sicuro.
     */
    public static function t_content(string $html, string $lang): string {
        if ($html === '' || $lang === 'it' || $lang === '') return $html;
        return preg_replace_callback('/>([^<>]+)</u', function ($m) use ($lang) {
            $txt = trim(html_entity_decode($m[1], ENT_QUOTES, 'UTF-8'));
            if ($txt === '') return $m[0];
            // Stacca un eventuale suffisso decorativo (freccia/spazi) per non impedire il match
            preg_match('/^(.*?)([\s>»›→]*)$/u', $txt, $mm);
            $core = $mm[1] ?? $txt;
            $suf  = $mm[2] ?? '';
            $tr = self::t($core, $lang);
            if ($tr === $core) return $m[0]; // nessuna traduzione trovata → invariato
            return '>' . htmlspecialchars($tr . $suf, ENT_QUOTES, 'UTF-8') . '<';
        }, $html);
    }

    public static function strings(string $lang): array {
        $out = [];
        foreach (self::$strings as $k => $v) {
            $out[$k] = $v[$lang] ?? $v['it'] ?? '';
        }
        return $out;
    }
}
