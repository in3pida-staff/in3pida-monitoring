<?php
defined('ABSPATH') || exit;

class IF2_CRM_Combo {

    public static function send(array $creds, array $fields, array $meta): array {
        // METODO API (Combo CRM lato server, doc edita.it): se ci sono ApiID + Token, invia via API.
        $apid  = trim($creds['apid'] ?? '');
        $token = trim($creds['mvcrm_token'] ?? '');
        if ($apid !== '' && $token !== '') {
            return self::send_api($fields, $meta, $apid, $token);
        }

        // METODO EMAIL (fallback, invariato): manda la richiesta via SMTP a Combo.
        $smtp_host      = trim($creds['smtp_host']  ?? 'mail.offerta-hotel.com');
        $smtp_user      = trim($creds['smtp_user']  ?? '');
        $smtp_pass      = trim($creds['smtp_pass']  ?? '');
        $smtp_port      = (int)($creds['smtp_port'] ?? 587);
        $from_email     = trim($creds['from_email'] ?? $smtp_user);
        $from_name      = trim($creds['from_name']  ?? 'In3pida');
        $recipient      = trim($creds['recipient_email'] ?? '');
        $hotel_name     = trim($creds['hotel_name']     ?? '');

        if (!$smtp_user || !$smtp_pass || !$recipient) {
            return ['status' => 'error', 'code' => 0, 'message' => 'smtp_user, smtp_pass o recipient_email mancanti'];
        }

        $full    = trim($fields['fullname'] ?? '');
        $space   = strpos($full, ' ');
        $nome    = $space !== false ? substr($full, 0, $space) : $full;
        $cognome = $space !== false ? trim(substr($full, $space + 1)) : '.';
        if ($cognome === '') $cognome = '.';

        $children_ages = [];
        $children = (int)($fields['children'] ?? 0);
        if ($children > 0) {
            foreach (['child_age_1', 'child_age_2', 'child_age_3', 'child_age_4'] as $slot) {
                $eta = trim((string)($fields[$slot] ?? ''));
                if ($eta !== '') $children_ages[] = $eta;
            }
        }

        $lang = substr(get_locale(), 0, 2);

        $payload = [
            'nome'           => $nome,
            'cognome'        => $cognome,
            'email'          => trim($fields['email']     ?? ''),
            'telefono'       => trim($fields['phone']     ?? ''),
            'note'           => trim($fields['notes']     ?? ''),
            'tipo_richiesta' => '',
            'portale'        => '',
            'lingua'         => $lang,
            'checkin'        => trim($fields['checkin']   ?? ''),
            'checkout'       => trim($fields['checkout']  ?? ''),
            'trattamento'    => trim($fields['treatment'] ?? ''),
            'camere'         => [[
                'adulti'   => max(1, (int)($fields['adults'] ?? 1)),
                'bambini'  => $children_ages,
            ]],
        ];

        $json    = json_encode($payload, JSON_UNESCAPED_UNICODE);
        $subject = 'Richiesta preventivo da ' . $hotel_name;
        $message = '<div id="codice_mail">' . base64_encode($json) . '</div>';

        $smtp_cfg = compact('smtp_host', 'smtp_user', 'smtp_pass', 'smtp_port', 'from_email', 'from_name');

        $mailer_hook = function (&$phpmailer) use ($smtp_cfg) {
            $phpmailer->isSMTP();
            $phpmailer->Host       = $smtp_cfg['smtp_host'];
            $phpmailer->SMTPAuth   = true;
            $phpmailer->Username   = $smtp_cfg['smtp_user'];
            $phpmailer->Password   = $smtp_cfg['smtp_pass'];
            $phpmailer->SMTPSecure = 'tls';
            $phpmailer->Port       = $smtp_cfg['smtp_port'];
            $phpmailer->setFrom($smtp_cfg['from_email'], $smtp_cfg['from_name']);
        };

        add_action('phpmailer_init', $mailer_hook);

        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>',
            'Reply-To: ' . $from_email,
        ];

        $sent = wp_mail($recipient, $subject, $message, $headers);

        remove_action('phpmailer_init', $mailer_hook);

        if (!$sent) {
            global $phpmailer;
            $err = isset($phpmailer) && is_object($phpmailer) ? $phpmailer->ErrorInfo : 'invio fallito';
            return ['status' => 'error', 'code' => 0, 'message' => $err ?: 'wp_mail ha restituito false'];
        }

        return ['status' => 'ok', 'code' => 200, 'message' => ''];
    }

    /** Invio via API di Combo CRM (POST lato server a apis.combohotel.it). */
    private static function send_api(array $fields, array $meta, string $apid, string $token): array {
        $full  = trim($fields['fullname'] ?? '');
        $space = strpos($full, ' ');
        $fname = $space !== false ? substr($full, 0, $space) : $full;
        $lname = $space !== false ? trim(substr($full, $space + 1)) : '';

        $adults   = max(1, (int) ($fields['adults']   ?? 1));
        $children = max(0, (int) ($fields['children'] ?? 0));
        $ages = [];
        $i = 1;
        foreach (['child_age_1', 'child_age_2', 'child_age_3', 'child_age_4'] as $slot) {
            $eta = trim((string) ($fields[$slot] ?? ''));
            if ($eta !== '') { $ages[$i] = (int) $eta; $i++; }
        }

        $data = [
            'fname'       => $fname,
            'lname'       => $lname !== '' ? $lname : '.',
            'email'       => trim($fields['email'] ?? ''),
            'checkin'     => self::to_iso($fields['checkin']  ?? ''),
            'checkout'    => self::to_iso($fields['checkout'] ?? ''),
            'rooms'       => 1,
            'adults'      => [1 => $adults],
            'children'    => [1 => $children],
            'phone'       => trim($fields['phone'] ?? ''),
            'l'           => substr(get_locale(), 0, 2),
            'message'     => trim($fields['notes'] ?? ''),
            'action'      => 'hcc_form',
            'apid'        => $apid,
            'mvcrm_token' => $token,
            'ret_url'     => 'server',
            'r'           => $meta['source_url'] ?? '',
            'traitment'   => self::board_code($fields['treatment'] ?? ''),
        ];
        if ($ages) $data['children_age'] = [1 => $ages];

        $resp = wp_remote_post('https://apis.combohotel.it/api/client/post_form', [
            'body'      => $data,
            'timeout'   => 15,
            'sslverify' => false,
        ]);
        if (is_wp_error($resp)) {
            return ['status' => 'error', 'code' => 0, 'message' => $resp->get_error_message()];
        }
        $code = (int) wp_remote_retrieve_response_code($resp);
        $body = trim(wp_remote_retrieve_body($resp));
        // Combo risponde 200 con corpo VUOTO in caso di successo; se il corpo contiene un testo
        // (es. "Autenticazione fallita") è un ERRORE anche se l'HTTP è 200. Così vediamo l'esito reale.
        $ok = ($code >= 200 && $code < 300) && $body === '';
        return [
            'status'  => $ok ? 'ok' : 'error',
            'code'    => $code,
            'message' => $ok ? '' : ($body !== '' ? substr($body, 0, 300) : ('HTTP ' . $code)),
        ];
    }

    /** Converte una data dd/mm/yyyy (o altro) nel formato ISO yyyy-mm-dd richiesto da Combo. */
    private static function to_iso(string $d): string {
        $d = trim($d);
        if ($d === '') return '';
        if (preg_match('#^(\d{1,2})/(\d{1,2})/(\d{4})$#', $d, $m)) {
            return $m[3] . '-' . str_pad($m[2], 2, '0', STR_PAD_LEFT) . '-' . str_pad($m[1], 2, '0', STR_PAD_LEFT);
        }
        $ts = strtotime($d);
        return $ts ? date('Y-m-d', $ts) : $d;
    }

    /** Mappa il trattamento nel codice Combo (OB/BB/HB/FB/AI). */
    private static function board_code(string $t): string {
        $t = strtolower(remove_accents(trim($t)));
        if ($t === '') return '';
        if (strpos($t, 'all inclusive') !== false || strpos($t, 'tutto incluso') !== false) return 'AI';
        if (strpos($t, 'pensione completa') !== false || strpos($t, 'full board') !== false)  return 'FB';
        if (strpos($t, 'mezza pensione') !== false || strpos($t, 'half board') !== false)      return 'HB';
        if (strpos($t, 'colazione') !== false || strpos($t, 'b&b') !== false
            || strpos($t, 'bed') !== false || strpos($t, 'breakfast') !== false)              return 'BB';
        if (strpos($t, 'solo camera') !== false || strpos($t, 'room only') !== false
            || strpos($t, 'only') !== false)                                                  return 'OB';
        return '';
    }
}
