<?php
defined('ABSPATH') || exit;

class IF2_CRM {

    /**
     * Registry dei driver CRM disponibili.
     * Ogni driver aggiunge le proprie credenziali e i suoi slot campo.
     */
    public static function get_drivers(): array {
        $common_slots = [
            'checkin'     => 'Check-in (Arrivo)',
            'checkout'    => 'Check-out (Partenza)',
            'fullname'    => 'Nome e Cognome',
            'email'       => 'Email',
            'phone'       => 'Telefono',
            'adults'      => 'Adulti',
            'children'    => 'Bambini (numero)',
            'child_age_1' => 'Età bambino 1',
            'child_age_2' => 'Età bambino 2',
            'child_age_3' => 'Età bambino 3',
            'child_age_4' => 'Età bambino 4',
            'notes'       => 'Note',
            'newsletter'  => 'Newsletter (consenso)',
        ];
        $common_slots_with_treatment = $common_slots + ['treatment' => 'Trattamento'];

        return apply_filters('if2_crm_drivers', [

            'hoteldoor' => [
                'label'  => 'HotelDoor',
                'class'  => 'IF2_CRM_HotelDoor',
                'file'   => IF2_PATH . 'includes/crm/class-if2-crm-hoteldoor.php',
                'color'  => '#0ea5e9',
                'slots'  => $common_slots_with_treatment,
                'credentials' => [
                    'token'    => ['label' => 'Token API (Bearer)', 'type' => 'password', 'per_form' => false, 'placeholder' => ''],
                    'hotel_id' => ['label' => 'Hotel ID (default)',  'type' => 'text',     'per_form' => true,  'placeholder' => 'ID numerico struttura'],
                ],
            ],

            'mrpreno' => [
                'label'  => 'Mr Preno',
                'class'  => 'IF2_CRM_MrPreno',
                'file'   => IF2_PATH . 'includes/crm/class-if2-crm-mrpreno.php',
                'color'  => '#8b5cf6',
                'slots'  => $common_slots,
                'credentials' => [
                    'email_api'          => ['label' => 'Email API (es. hotel@mrpreno.net)', 'type' => 'text',     'per_form' => false, 'placeholder' => 'hotel@mrpreno.net'],
                    'apikey'             => ['label' => 'API Key',                            'type' => 'password', 'per_form' => false, 'placeholder' => ''],
                    'requestrefer'       => ['label' => 'URL consenso newsletter',            'type' => 'text',     'per_form' => false, 'placeholder' => 'https://tuosito.it'],
                    'source_description' => ['label' => 'Descrizione sorgente',               'type' => 'text',     'per_form' => false, 'placeholder' => 'In3pida'],
                ],
            ],

            'bedirect' => [
                'label'  => 'Be Direct',
                'class'  => 'IF2_CRM_BeDirect',
                'file'   => IF2_PATH . 'includes/crm/class-if2-crm-bedirect.php',
                'color'  => '#f59e0b',
                'slots'  => $common_slots,
                'credentials' => [
                    'hotel'        => ['label' => 'Hotel ID',      'type' => 'text',     'per_form' => true, 'placeholder' => 'es. 17278'],
                    'layout'       => ['label' => 'Layout ID',     'type' => 'text',     'per_form' => true, 'placeholder' => 'es. 12743'],
                    'widgetapikey' => ['label' => 'Widget API Key','type' => 'password', 'per_form' => true, 'placeholder' => ''],
                    'channel'      => ['label' => 'Channel ID',    'type' => 'text',     'per_form' => true, 'placeholder' => 'es. 16485'],
                ],
            ],

            'bookingdesigner' => [
                'label'  => 'Booking Designer',
                'class'  => 'IF2_CRM_BookingDesigner',
                'file'   => IF2_PATH . 'includes/crm/class-if2-crm-bookingdesigner.php',
                'color'  => '#10b981',
                'slots'  => [
                    'checkin'     => 'Check-in (Arrivo)',
                    'checkout'    => 'Check-out (Partenza)',
                    'firstname'   => 'Nome (campo separato)',
                    'lastname'    => 'Cognome (campo separato)',
                    'email'       => 'Email',
                    'phone'       => 'Telefono',
                    'adults'      => 'Adulti',
                    'children'    => 'Bambini (numero)',
                    'child_age_1' => 'Età bambino 1',
                    'child_age_2' => 'Età bambino 2',
                    'child_age_3' => 'Età bambino 3',
                    'child_age_4' => 'Età bambino 4',
                    'treatment'   => 'Trattamento (Formula)',
                    'notes'       => 'Note',
                    'newsletter'  => 'Newsletter (consenso)',
                ],
                'credentials' => [
                    'apikey'        => ['label' => 'API Key',       'type' => 'password', 'per_form' => false, 'placeholder' => ''],
                    'property_code' => ['label' => 'Property Code', 'type' => 'text',     'per_form' => true,  'placeholder' => 'es. vascelleroresort'],
                ],
            ],

            'combo' => [
                'label'  => 'Combo (Hotel.cc)',
                'class'  => 'IF2_CRM_Combo',
                'file'   => IF2_PATH . 'includes/crm/class-if2-crm-combo.php',
                'color'  => '#ec4899',
                'slots'  => $common_slots_with_treatment,
                'credentials' => [
                    'smtp_host'      => ['label' => 'SMTP Host',       'type' => 'text',     'per_form' => false, 'placeholder' => 'mail.offerta-hotel.com'],
                    'smtp_user'      => ['label' => 'SMTP Username',   'type' => 'text',     'per_form' => false, 'placeholder' => 'richiesta@offerta-hotel.com'],
                    'smtp_pass'      => ['label' => 'SMTP Password',   'type' => 'password', 'per_form' => false, 'placeholder' => ''],
                    'smtp_port'      => ['label' => 'SMTP Port',       'type' => 'text',     'per_form' => false, 'placeholder' => '587'],
                    'from_email'     => ['label' => 'Email mittente',  'type' => 'text',     'per_form' => false, 'placeholder' => 'richiesta@offerta-hotel.com'],
                    'from_name'      => ['label' => 'Nome mittente',   'type' => 'text',     'per_form' => false, 'placeholder' => 'In3pida'],
                    'recipient_email'=> ['label' => 'Email Combo (destinatario)', 'type' => 'text', 'per_form' => true, 'placeholder' => 'hotel@hotel.cc'],
                    'hotel_name'     => ['label' => 'Nome hotel',      'type' => 'text',     'per_form' => true,  'placeholder' => 'es. Hotel Pinco'],
                ],
            ],

        ]);
    }

    /**
     * Esegue il dispatch verso tutti i CRM attivi per un form.
     * Ritorna log entries prefissati con 'crm_'.
     */
    public static function dispatch(array $form, array $data, array $meta, int $submission_id): array {
        $logs    = [];
        $drivers = self::get_drivers();
        $global  = get_option('if2_crm_config', []);

        // Nome del form disponibile ai driver (HotelDoor lo usa, ripulito, come utm_campaign)
        $meta['form_name'] = $form['name'] ?? ($meta['form_name'] ?? '');

        foreach ($drivers as $key => $driver) {
            $gcfg = $global[$key] ?? [];
            $fcfg = $form['config']['crm'][$key] ?? [];

            // Globale disabilitato → disabled
            if (empty($gcfg['enabled'])) {
                $logs['crm_' . $key] = ['status' => 'disabled'];
                continue;
            }
            // Per-form: il toggle comanda. Invia SOLO se attivato nel tab CRM del builder.
            // (Non attivo / mai toccato = non invia.)
            if (empty($fcfg['enabled'])) {
                $logs['crm_' . $key] = ['status' => 'disabled'];
                continue;
            }

            if (isset($driver['file']) && file_exists($driver['file'])) {
                require_once $driver['file'];
            }

            if (!class_exists($driver['class'])) {
                $logs['crm_' . $key] = ['status' => 'error', 'code' => 0, 'message' => 'driver non trovato'];
                continue;
            }

            // Mapping: globale + override per-form
            $mapping = array_merge(
                (array)($gcfg['mapping'] ?? []),
                (array)($fcfg['mapping']  ?? [])
            );

            // Credenziali: globale + override per-form
            $creds = array_merge((array)$gcfg, (array)$fcfg);

            $resolved            = self::resolve($form['fields'] ?? [], $data, $mapping);
            $logs['crm_' . $key] = call_user_func([$driver['class'], 'send'], $creds, $resolved, $meta);
        }

        return $logs;
    }

    /**
     * Risolve il mapping slot→label nei dati reali del form.
     * mapping: ['checkin' => 'Arrivo', 'email' => 'E-mail', ...]
     */
    public static function resolve(array $fields, array $data, array $mapping): array {
        // Normalizza un'etichetta: minuscolo, senza accenti, spazi compressi → match tollerante
        $norm = function ($s) {
            $s = remove_accents(strtolower(trim((string) $s)));
            return preg_replace('/\s+/', ' ', $s);
        };
        // Pulisce un valore: array→stringa, toglie il suffisso "==valore", trim
        $clean = function ($v) {
            if (is_array($v)) $v = implode(', ', $v);
            $v = (string) $v;
            if (strpos($v, '==') !== false) $v = substr($v, 0, strpos($v, '=='));
            return trim($v);
        };

        $by_label = [];     // label normalizzata → field id
        $fmeta    = [];     // field id → label normalizzata
        foreach ($fields as $field) {
            $id = $field['id'] ?? '';
            if (!$id) continue;
            $lbl = $norm($field['label'] ?? '');
            if ($lbl !== '') $by_label[$lbl] = $id;
            $fmeta[$id] = $lbl;
        }

        $out = [];
        foreach ($mapping as $slot => $label) {
            $fid = ($label !== '' && isset($by_label[$norm((string) $label)])) ? $by_label[$norm((string) $label)] : null;
            $out[$slot] = ($fid !== null && array_key_exists($fid, $data)) ? $clean($data[$fid]) : '';
        }

        // Auto-rilevamento per parole chiave: se uno slot noto è rimasto VUOTO (mapping mancante o
        // etichetta non combaciante), prova a trovarlo dall'etichetta del campo. Non sovrascrive mai
        // uno slot già valorizzato dal mapping → non rompe i siti già configurati.
        $slot_keywords = [
            'treatment' => ['trattament', 'treatment', 'pensione', 'board'],
            'checkin'   => ['arriv', 'check-in', 'checkin', 'check in'],
            'checkout'  => ['partenz', 'check-out', 'checkout', 'check out'],
            'fullname'  => ['nome e cognome', 'nominativo', 'nome', 'cognome'],
            'email'     => ['email', 'e-mail', 'mail'],
            'phone'     => ['telefon', 'cellul', 'phone'],
            'adults'    => ['adult'],
            'children'  => ['bambin', 'child', 'ragazz'],
            'notes'     => ['note', 'messagg'],
        ];
        foreach ($slot_keywords as $slot => $kws) {
            if (!empty($out[$slot])) continue;
            foreach ($fmeta as $id => $lbl) {
                foreach ($kws as $kw) {
                    if ($lbl !== '' && strpos($lbl, $kw) !== false && array_key_exists($id, $data)) {
                        $v = $clean($data[$id]);
                        if ($v !== '') { $out[$slot] = $v; break 2; }
                    }
                }
            }
        }
        return $out;
    }

    /**
     * Raccoglie tutti i label unici da tutti i form esistenti.
     * Usato per popolare i dropdown di mapping.
     * Nota: get_all() non carica la colonna fields, quindi query dedicata.
     */
    public static function all_labels(): array {
        global $wpdb;
        $rows  = $wpdb->get_results(
            "SELECT fields FROM " . IF2_DB::forms_table() . " ORDER BY id DESC",
            ARRAY_A
        ) ?: [];
        $labels = [];
        $skip   = ['submit', 'heading', 'html', 'page_break'];
        foreach ($rows as $row) {
            $fields = json_decode($row['fields'] ?? '[]', true) ?: [];
            foreach ($fields as $field) {
                if (in_array($field['type'] ?? '', $skip, true)) continue;
                $l = trim($field['label'] ?? '');
                if ($l !== '') $labels[$l] = $l;
            }
        }
        ksort($labels);
        return $labels;
    }

    /**
     * Calcola lo status aggregato di tutti i CRM attivi (worst-case).
     * Ritorna ['status', 'message', 'detail'].
     */
    public static function aggregate(array $ilog): array {
        $crm_logs = [];
        foreach ($ilog as $k => $v) {
            if (strpos($k, 'crm_') === 0) {
                $crm_logs[$k] = $v;
            }
        }

        $active = array_filter($crm_logs, fn($l) => ($l['status'] ?? 'disabled') !== 'disabled');

        if (empty($active)) {
            return ['status' => 'disabled'];
        }

        $priority = ['error' => 5, 'pending' => 4, 'info' => 3, 'skipped' => 2, 'ok' => 1];
        $worst    = 'ok';
        $msgs     = [];

        foreach ($active as $k => $log) {
            $s    = $log['status'] ?? 'disabled';
            $code = (int) ($log['code'] ?? 0);
            // HotelDoor (e simili) rispondono 5xx pur SALVANDO la richiesta: se il dato è entrato,
            // mostriamo "ok" (verde) anche per i log vecchi salvati come errore. Errore reale solo su 4xx/connessione.
            if ($s === 'error' && $code >= 500) $s = 'ok';
            if (($priority[$s] ?? 0) > ($priority[$worst] ?? 0)) {
                $worst = $s;
            }
            $driver = strtoupper(str_replace('crm_', '', $k));
            $codestr = $code ? ' HTTP ' . $code : '';
            $msg    = isset($log['message']) && $log['message'] ? ' — ' . $log['message'] : '';
            $msgs[] = $driver . ': ' . $s . $codestr . $msg;
        }

        return [
            'status'  => $worst,
            'message' => implode(' | ', $msgs),
            'detail'  => $active,
        ];
    }
}
