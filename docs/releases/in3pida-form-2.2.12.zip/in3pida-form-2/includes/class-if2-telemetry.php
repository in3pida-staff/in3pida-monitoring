<?php
defined('ABSPATH') || exit;

class IF2_Telemetry {

    const OPT_SITE_ID = 'if2_tel_site_id';
    const OPT_API_KEY = 'if2_tel_api_key';
    const OPT_ENABLED = 'if2_tel_enabled';
    const CRON_HOOK   = 'if2_telemetry_heartbeat';

    public static function init(): void {
        if (!get_option(self::OPT_ENABLED, 1)) return;
        add_action(self::CRON_HOOK,       [self::class, 'send_heartbeat']);
        add_action('if2_submission_done', [self::class, 'track_submission'], 10, 3);
        add_action('rest_api_init',       [self::class, 'register_rest']);
    }

    public static function activate(): void {
        if (!get_option(self::OPT_SITE_ID)) {
            update_option(self::OPT_SITE_ID, wp_generate_uuid4(), false);
        }
        if (!get_option(self::OPT_API_KEY)) {
            update_option(self::OPT_API_KEY, wp_generate_password(32, false), false);
        }
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), 'hourly', self::CRON_HOOK);
        }
        self::send_heartbeat();
    }

    public static function deactivate(): void {
        $ts = wp_next_scheduled(self::CRON_HOOK);
        if ($ts) wp_unschedule_event($ts, self::CRON_HOOK);
    }

    // ─── HEARTBEAT ────────────────────────────────────────────────────────────

    public static function send_heartbeat(): void {
        $sb = self::sb_creds();
        if (!$sb) return;

        self::sb_upsert($sb, 'mon_sites', [
            'site_id'        => self::site_id(),
            'api_key'        => self::api_key(),
            'plugin_name'    => 'in3pida-form-2',
            'plugin_version' => IF2_VERSION,
            'wp_version'     => get_bloginfo('version'),
            'php_version'    => PHP_VERSION,
            'theme_active'   => wp_get_theme()->get('Name'),
            'site_url'       => get_site_url(),
            'site_name'      => get_bloginfo('name'),
            'last_heartbeat' => gmdate('c'),
        ]);
    }

    // ─── TRACKING SUBMISSIONS ─────────────────────────────────────────────────

    public static function track_submission(int $submission_id, int $form_id, array $log): void {
        $sb = self::sb_creds();
        if (!$sb) return;

        self::sb_insert($sb, 'mon_events', [
            'site_id'    => self::site_id(),
            'event_type' => 'form_submitted',
            'payload'    => (object) ['form_id' => $form_id, 'submission_id' => $submission_id],
        ]);

        foreach (['supabase', 'crm', 'amelia'] as $key) {
            if (!isset($log[$key])) continue;
            $raw = $log[$key]['status'] ?? '';
            if (!$raw || $raw === 'disabled') continue;
            $status = in_array($raw, ['ok', 'info', 'skipped'], true) ? $raw : 'error';
            self::sb_insert($sb, 'mon_integration_stats', [
                'site_id'       => self::site_id(),
                'integration'   => $key,
                'status'        => $status,
                'error_message' => ($log[$key]['message'] ?? '') ?: null,
            ]);
        }

        foreach ($log as $key => $val) {
            if (strpos($key, 'crm_') !== 0) continue;
            $raw    = $val['status'] ?? '';
            $status = in_array($raw, ['ok', 'info', 'skipped'], true) ? $raw : 'error';
            self::sb_insert($sb, 'mon_integration_stats', [
                'site_id'       => self::site_id(),
                'integration'   => 'crm',
                'status'        => $status,
                'error_message' => ($val['message'] ?? '') ?: null,
            ]);
        }
    }

    // ─── LOG ERRORI ───────────────────────────────────────────────────────────

    public static function log_error(string $message, string $level = 'error', array $context = []): void {
        $sb = self::sb_creds();
        if (!$sb) return;
        self::sb_insert($sb, 'mon_logs', [
            'site_id' => self::site_id(),
            'level'   => $level,
            'message' => $message,
            'context' => empty($context) ? null : (object) $context,
        ]);
    }

    // ─── REST: aggiornamento plugin da monitoring ──────────────────────────────

    public static function register_rest(): void {
        register_rest_route('if2/v1', '/update', [
            'methods'             => ['POST', 'OPTIONS'],
            'callback'            => [self::class, 'rest_update'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('if2/v1', '/status', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'rest_status'],
            'permission_callback' => '__return_true',
        ]);
    }

    public static function rest_status(WP_REST_Request $request): WP_REST_Response {
        header('Access-Control-Allow-Origin: *');
        $api_key = sanitize_text_field($request->get_param('api_key') ?? '');
        if (!$api_key || $api_key !== self::api_key()) {
            return new WP_REST_Response(['error' => 'Unauthorized'], 403);
        }
        return new WP_REST_Response([
            'plugin_version' => IF2_VERSION,
            'wp_version'     => get_bloginfo('version'),
            'php_version'    => PHP_VERSION,
            'site_url'       => get_site_url(),
        ]);
    }

    public static function rest_update(WP_REST_Request $request): WP_REST_Response {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');

        if ($request->get_method() === 'OPTIONS') {
            return new WP_REST_Response(null, 200);
        }

        $api_key      = sanitize_text_field($request->get_param('api_key') ?? '');
        $download_url = esc_url_raw($request->get_param('download_url') ?? '');

        if (!$api_key || $api_key !== self::api_key()) {
            return new WP_REST_Response(['error' => 'Unauthorized'], 403);
        }
        if (!$download_url) {
            return new WP_REST_Response(['error' => 'Missing download_url'], 400);
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        WP_Filesystem();

        $skin     = new Automatic_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader($skin);
        $result   = $upgrader->install($download_url, ['overwrite_package' => true]);

        if (is_wp_error($result)) {
            return new WP_REST_Response(['error' => $result->get_error_message()], 500);
        }
        if ($result === false || $result === null) {
            return new WP_REST_Response(['error' => 'Installazione fallita'], 500);
        }

        if (!is_plugin_active(IF2_BASENAME)) {
            activate_plugin(IF2_BASENAME);
        }

        self::send_heartbeat();

        return new WP_REST_Response(['success' => true, 'message' => 'Plugin aggiornato con successo']);
    }

    // ─── HELPERS PRIVATI ──────────────────────────────────────────────────────

    private static function sb_creds(): ?array {
        $url = get_option('if2_supabase_url', '') ?: get_option('in3pida_supabase_url', '');
        $key = get_option('if2_supabase_anon_key', '') ?: get_option('in3pida_supabase_key', '');
        return ($url && $key) ? compact('url', 'key') : null;
    }

    private static function sb_insert(array $sb, string $table, array $body): void {
        if (!self::site_id()) return;
        wp_remote_post(
            trailingslashit($sb['url']) . 'rest/v1/' . $table,
            [
                'headers'   => [
                    'apikey'        => $sb['key'],
                    'Authorization' => 'Bearer ' . $sb['key'],
                    'Content-Type'  => 'application/json',
                    'Prefer'        => 'return=minimal',
                ],
                'body'      => wp_json_encode($body),
                'timeout'   => 3,
                'blocking'  => false,
                'sslverify' => false,
            ]
        );
    }

    private static function sb_upsert(array $sb, string $table, array $body): void {
        if (!self::site_id()) return;
        wp_remote_post(
            trailingslashit($sb['url']) . 'rest/v1/' . $table,
            [
                'headers'   => [
                    'apikey'        => $sb['key'],
                    'Authorization' => 'Bearer ' . $sb['key'],
                    'Content-Type'  => 'application/json',
                    'Prefer'        => 'resolution=merge-duplicates,return=minimal',
                ],
                'body'      => wp_json_encode($body),
                'timeout'   => 3,
                'blocking'  => false,
                'sslverify' => false,
            ]
        );
    }

    public static function site_id(): string {
        return (string) get_option(self::OPT_SITE_ID, '');
    }

    public static function api_key(): string {
        return (string) get_option(self::OPT_API_KEY, '');
    }
}
