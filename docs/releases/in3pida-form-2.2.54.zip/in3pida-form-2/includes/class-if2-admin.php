<?php
defined('ABSPATH') || exit;

class IF2_Admin {

    public static function admin_notice(): void {
        // Avviso se la chiave Supabase è salvata cifrata ma non si riesce a decifrarla
        $stored = get_option('if2_supabase_anon_key', '');
        if ($stored !== '' && strpos($stored, 'if2enc:') === 0) {
            $dec = if2_decrypt($stored);
            if ($dec === '') {
                $url = admin_url('admin.php?page=if2-settings');
                echo '<div class="notice notice-error"><p>'
                   . '<strong>in3pida Form:</strong> La chiave Supabase non riesce a essere decifrata. '
                   . 'Le richieste <strong>non vengono salvate su Supabase</strong>. '
                   . '<a href="' . esc_url($url) . '">Vai a Impostazioni → re-inserisci la chiave anon e salva.</a>'
                   . '</p></div>';
            }
        }
    }

    public static function register_pages(): void {
        $icon = IF2_URL . 'assets/images/logo-menu.png';
        add_menu_page(
            IF2_Lang::t('menu_main'),
            'in3pidaForm',
            'manage_options',
            'if2-forms',
            [self::class, 'page_forms'],
            $icon,
            56
        );
        add_submenu_page(
            'if2-forms',
            IF2_Lang::t('menu_main'),
            IF2_Lang::t('menu_forms'),
            'manage_options',
            'if2-forms',
            [self::class, 'page_forms']
        );
        add_submenu_page(
            'if2-forms',
            IF2_Lang::t('menu_submissions'),
            IF2_Lang::t('menu_submissions'),
            'manage_options',
            'if2-submissions',
            [self::class, 'page_submissions']
        );
        add_submenu_page(
            'if2-forms',
            IF2_Lang::t('menu_stats'),
            IF2_Lang::t('menu_stats'),
            'manage_options',
            'if2-stats',
            [self::class, 'page_stats']
        );
        add_submenu_page(
            'if2-forms',
            IF2_Lang::t('menu_builder'),
            IF2_Lang::t('menu_builder'),
            'manage_options',
            'if2-builder',
            [self::class, 'page_builder']
        );
        add_submenu_page(
            'if2-forms',
            IF2_Lang::t('menu_settings'),
            IF2_Lang::t('menu_settings'),
            'manage_options',
            'if2-settings',
            [self::class, 'page_settings']
        );
        add_submenu_page(
            'if2-forms',
            IF2_Lang::t('menu_crm'),
            IF2_Lang::t('menu_crm'),
            'manage_options',
            'if2-crm',
            [self::class, 'page_crm']
        );
    }

    // Icona "iF" globale + padding WP sulle pagine IF2
    public static function hide_footer(): void {
        $page = sanitize_key( $_GET['page'] ?? '' );
        if ( strpos( $page, 'if2' ) !== false ) {
            add_filter( 'admin_footer_text', '__return_empty_string' );
            add_filter( 'update_footer',     '__return_empty_string', 11 );
        }
    }

    public static function admin_head(): void {
        // Icona "iF" + nascondi Builder — globale su tutte le pagine admin
        ?>
        <style>
            #toplevel_page_if2-forms .wp-menu-image img {
                padding: 4px 0 0 !important;
                width: 20px !important;
                height: auto !important;
                content: url('<?php echo esc_url( IF2_URL . 'assets/images/logo-menu.png?v=' . IF2_VERSION ); ?>') !important;
            }
            #toplevel_page_if2-forms.wp-has-current-submenu .wp-menu-image img,
            #toplevel_page_if2-forms:hover .wp-menu-image img {
                content: url('<?php echo esc_url( IF2_URL . 'assets/images/logo-menu-hover.png?v=' . IF2_VERSION ); ?>') !important;
            }
            /* Nasconde sempre la voce Builder dal menu laterale */
            #toplevel_page_if2-forms .wp-submenu li a[href*="if2-builder"] { display: none !important; }
        </style>
        <?php
        // Svuota opcache PHP automaticamente se if2-clear.php è presente (post-aggiornamento plugin)
        if ( file_exists( IF2_PATH . 'if2-clear.php' ) ) { ?>
<script>fetch('<?php echo esc_url( IF2_URL . 'if2-clear.php' ); ?>').catch(function(){});</script>
        <?php }
        $page = sanitize_key( $_GET['page'] ?? '' );
        if ( strpos( $page, 'if2' ) === false ) return;
        ?>
        <style>
            #wpcontent { padding-left: 0 !important; }
            #wpbody-content { padding-bottom: 0 !important; }
            #wpbody-content > .notice,
            #wpbody-content > .updated,
            #wpbody-content > .error { margin: 5px 20px; }
            .if2-admin-wrap *, .if2-admin-wrap *::before, .if2-admin-wrap *::after { box-sizing: border-box; }
        </style>
        <?php
    }

    public static function enqueue(string $hook): void {
        if ( strpos( $hook, 'if2' ) === false && strpos( $hook, 'in3pida' ) === false ) return;

        wp_enqueue_style(
            'if2-admin',
            IF2_URL . 'assets/css/admin.css',
            [],
            filemtime( IF2_PATH . 'assets/css/admin.css' )
        );

        if ( strpos( $hook, 'if2-builder' ) !== false ) {
            wp_enqueue_script('wp-element');
            wp_enqueue_style('wp-components');

            wp_enqueue_script(
                'sortablejs',
                IF2_URL . 'assets/js/vendor/sortable.min.js',
                [],
                '1.15.0',
                true
            );
            wp_enqueue_script(
                'if2-deflate',
                IF2_URL . 'assets/js/vendor/deflate.all.js',
                ['jquery'],
                '1.0',
                true
            );
            wp_enqueue_script(
                'if2-builder',
                IF2_URL . 'assets/js/builder.js',
                ['wp-element', 'sortablejs', 'if2-deflate'],
                filemtime( IF2_PATH . 'assets/js/builder.js' ),
                true
            );
            wp_localize_script('if2-builder', 'IF2Builder', [
                'ajaxurl'         => admin_url('admin-ajax.php'),
                'nonce'           => wp_create_nonce('if2_admin'),
                'form_id'         => (int) ( $_GET['form_id'] ?? 0 ),
                'home_url'        => home_url(),
                'lang'            => get_option('if2_lang', 'it'),
                'custom_channels' => array_values(array_filter(array_map('trim', explode("\n", get_option('if2_custom_channels', ''))))),
                'amelia_lists'    => json_decode(get_option('if2_amelia_lists', '[]'), true) ?: [],
                'crm_drivers'     => IF2_CRM::get_drivers(),
                'strings'  => [
                    'add_field'       => IF2_Lang::t('builder_add_field'),
                    'more_fields'     => IF2_Lang::t('builder_more_fields'),
                    'survey'          => IF2_Lang::t('builder_survey'),
                    'tab_general'     => IF2_Lang::t('builder_tab_general'),
                    'tab_email'       => IF2_Lang::t('builder_tab_email'),
                    'tab_embed'       => IF2_Lang::t('builder_tab_embed'),
                    'tab_custom'      => IF2_Lang::t('builder_tab_custom'),
                    'tab_advanced'    => IF2_Lang::t('builder_tab_advanced'),
                    'tab_in3pida'     => IF2_Lang::t('builder_tab_in3pida'),
                    'webhook_label'   => IF2_Lang::t('builder_webhook_label'),
                    'panel_settings'  => IF2_Lang::t('panel_settings'),
                    'panel_styling'   => IF2_Lang::t('panel_styling'),
                    'panel_addons'    => IF2_Lang::t('panel_addons'),
                    'panel_logic'     => IF2_Lang::t('panel_logic'),
                    'panel_help'      => IF2_Lang::t('panel_help'),
                ],
            ]);
        }

        wp_enqueue_script(
            'chartjs',
            IF2_URL . 'assets/js/vendor/chart.min.js',
            [],
            '4.4.0',
            true
        );
        wp_enqueue_script(
            'if2-admin',
            IF2_URL . 'assets/js/admin.js',
            ['jquery', 'chartjs'],
            filemtime( IF2_PATH . 'assets/js/admin.js' ),
            true
        );
        wp_localize_script('if2-admin', 'IF2Admin', [
            'ajaxurl'  => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('if2_admin'),
            'strings'  => [
                'active'             => IF2_Lang::t('antispam_active'),
                'inactive'           => IF2_Lang::t('antispam_inactive'),
                'hide_empty_fields'  => IF2_Lang::t('hide_empty_fields'),
                'show_empty_fields'  => IF2_Lang::t('show_empty_fields'),
                'bulk_delete'        => IF2_Lang::t('bulk_delete'),
                'testing'            => IF2_Lang::t('js_testing'),
                'insert_url_key'     => IF2_Lang::t('js_insert_url_key'),
                'connection_ok'      => IF2_Lang::t('js_connection_ok'),
                'connection_error'   => IF2_Lang::t('js_connection_error'),
                'connection_failed'  => IF2_Lang::t('js_connection_failed'),
            ],
        ]);
    }

    public static function page_forms(): void {
        require IF2_PATH . 'views/page-forms.php';
    }

    public static function page_builder(): void {
        require IF2_PATH . 'views/page-builder.php';
    }

    public static function page_submissions(): void {
        require IF2_PATH . 'views/page-submissions.php';
    }

    public static function page_stats(): void {
        require IF2_PATH . 'views/page-stats.php';
    }

    public static function page_settings(): void {
        require IF2_PATH . 'views/page-settings.php';
    }

    public static function page_crm(): void {
        require IF2_PATH . 'views/page-crm.php';
    }
}
