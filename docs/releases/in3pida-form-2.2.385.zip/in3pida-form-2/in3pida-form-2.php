<?php
/**
 * Plugin Name: in3pida form 2.0
 * Description: Form builder WordPress originale — Supabase, Hotel ID, Reply-To, Thank You Page, Canale, Datepicker avanzato.
 * Author: in3pida
 * Version: 2.2.385
 * Text Domain: in3pida-form-2
 * Domain Path: /languages
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 *
 * Codice originale — nessuna dipendenza da plugin di terze parti.
 * Librerie JS open source usate: Sortable.js (MIT), React via wp.element (GPL-2.0+).
 */

defined('ABSPATH') || exit;

define('IF2_VERSION',  '2.2.385');

// ─── CIFRATURA CHIAVI SENSIBILI ───────────────────────────────────────────────
// Le chiavi (es. Supabase service_role) vengono cifrate nel DB usando costanti
// presenti solo in wp-config.php — un dump del DB da solo non basta a decifrarle.

function if2_encrypt( string $value ): string {
    if ( $value === '' || ! function_exists( 'openssl_encrypt' ) ) return $value;
    $secret = defined( 'SECURE_AUTH_KEY' ) ? SECURE_AUTH_KEY : wp_salt( 'secure_auth' );
    $pepper = defined( 'NONCE_SALT' )      ? NONCE_SALT      : wp_salt( 'nonce' );
    $key    = substr( hash( 'sha256', $secret . $pepper ), 0, 32 );
    $iv     = random_bytes( 16 );
    $enc    = openssl_encrypt( $value, 'AES-256-CBC', $key, 0, $iv );
    return 'if2enc:' . base64_encode( $iv . $enc );
}

function if2_decrypt( string $value ): string {
    if ( $value === '' || strpos( $value, 'if2enc:' ) !== 0 ) return $value;
    if ( ! function_exists( 'openssl_decrypt' ) ) return '';
    $secret = defined( 'SECURE_AUTH_KEY' ) ? SECURE_AUTH_KEY : wp_salt( 'secure_auth' );
    $pepper = defined( 'NONCE_SALT' )      ? NONCE_SALT      : wp_salt( 'nonce' );
    $key    = substr( hash( 'sha256', $secret . $pepper ), 0, 32 );
    $raw    = base64_decode( substr( $value, 7 ) );
    $iv     = substr( $raw, 0, 16 );
    $enc    = substr( $raw, 16 );
    $dec    = openssl_decrypt( $enc, 'AES-256-CBC', $key, 0, $iv );
    return $dec !== false ? $dec : '';
}
define('IF2_PATH',     plugin_dir_path(__FILE__));
define('IF2_URL',      plugin_dir_url(__FILE__));
define('IF2_BASENAME', plugin_basename(__FILE__));

// Migrazione automatica: cifra la chiave Supabase se ancora in chiaro nel DB
add_action( 'init', function () {
    $raw = get_option( 'if2_supabase_anon_key', '' );
    if ( $raw !== '' && strpos( $raw, 'if2enc:' ) !== 0 ) {
        update_option( 'if2_supabase_anon_key', if2_encrypt( $raw ) );
    }
}, 1 );

// Svuota opcache PHP al cambio versione (utile su SiteGround e hosting con opcache persistente)
add_action('init', function () {
    if (get_option('if2_opcache_ver', '') !== IF2_VERSION) {
        if (function_exists('opcache_reset')) {
            @opcache_reset();
        } elseif (function_exists('opcache_invalidate')) {
            foreach ((array) glob(IF2_PATH . 'includes/*.php') as $f) {
                @opcache_invalidate((string) $f, true);
            }
            @opcache_invalidate(__FILE__, true);
        }
        // Assicura che le tabelle del plugin esistano/siano aggiornate dopo OGNI update — anche quelli
        // "in place" (copy_dir) che NON eseguono l'hook di attivazione. dbDelta crea le tabelle mancanti
        // (es. if2_submissions) e aggiorna le colonne: risolve i form che "girano a vuoto" perché la
        // tabella delle richieste manca (la richiesta non si salva e l'invio resta in attesa).
        if (class_exists('IF2_DB')) { IF2_DB::install(); }
        // Backfill una-tantum: marca come staff le richieste test @in3pida.it già salvate (così spariscono
        // da TUTTE le statistiche, anche quelle fatte prima che esistesse la marcatura).
        if (class_exists('IF2_DB') && get_option('if2_staff_backfill_v1', '') !== 'done') {
            IF2_DB::backfill_staff();
            update_option('if2_staff_backfill_v1', 'done', false);
        }
        // Svuota la cache delle pagine dopo ogni aggiornamento: SiteGround, W3TC, WP Rocket, WP Super Cache.
        // Senza questo la nuova versione del plugin non viene vista finché la cache non scade da sola.
        if (function_exists('sg_cachepress_purge_cache'))  { @sg_cachepress_purge_cache(); }
        if (function_exists('w3tc_flush_all'))              { @w3tc_flush_all(); }
        if (function_exists('rocket_clean_domain'))         { @rocket_clean_domain(); }
        if (function_exists('wp_cache_clear_cache'))        { @wp_cache_clear_cache(); }
        update_option('if2_opcache_ver', IF2_VERSION, false);
    }
}, 1);

require_once IF2_PATH . 'includes/class-if2-lang.php';
require_once IF2_PATH . 'includes/class-if2-i18n.php';
require_once IF2_PATH . 'includes/class-if2-db.php';
require_once IF2_PATH . 'includes/class-if2-form.php';
require_once IF2_PATH . 'includes/class-if2-submission.php';
require_once IF2_PATH . 'includes/class-if2-renderer.php';
require_once IF2_PATH . 'includes/class-if2-admin.php';
require_once IF2_PATH . 'includes/class-if2-ajax.php';
require_once IF2_PATH . 'includes/class-if2-extensions.php';
require_once IF2_PATH . 'includes/class-if2-crm.php';
require_once IF2_PATH . 'includes/class-if2-telemetry.php';

register_activation_hook(__FILE__,   ['IF2_DB',        'install']);
register_activation_hook(__FILE__,   ['IF2_Telemetry', 'activate']);
register_deactivation_hook(__FILE__, ['IF2_DB',        'deactivate']);
register_deactivation_hook(__FILE__, ['IF2_Telemetry', 'deactivate']);

add_action('init',                    ['IF2_Renderer', 'register_shortcode']);
add_action('admin_menu',             ['IF2_Admin',    'register_pages']);
add_action('admin_init',             ['IF2_Admin',    'hide_footer']);
add_action('admin_notices',          ['IF2_Admin',    'admin_notice']);
add_action('admin_enqueue_scripts',  ['IF2_Admin',    'enqueue']);
add_action('admin_head',             ['IF2_Admin',    'admin_head']);
// frontend assets enqueued on-demand da IF2_Renderer::enqueue_assets()
IF2_Ajax::init();
IF2_Extensions::init();
IF2_Telemetry::init();

// Esclude i file del plugin dai combine/minify di SiteGround Optimizer e simili
add_filter('sgo_js_combine_exclude',  function($e){ $e[] = 'if2-builder'; $e[] = 'if2-admin'; return $e; });
add_filter('sgo_css_combine_exclude', function($e){ $e[] = 'if2-admin';   return $e; });
add_filter('sgo_js_minify_exclude',   function($e){ $e[] = 'if2-builder'; $e[] = 'if2-admin'; return $e; });
add_filter('sgo_css_minify_exclude',  function($e){ $e[] = 'if2-admin';   return $e; });
// WP Rocket / W3TC / Autoptimize
add_filter('rocket_exclude_js',       function($e){ $e[] = '/in3pida-form-2/assets/js/builder.js'; $e[] = '/in3pida-form-2/assets/js/admin.js'; return $e; });
add_filter('rocket_exclude_css',      function($e){ $e[] = '/in3pida-form-2/assets/css/admin.css'; return $e; });
add_filter('autoptimize_filter_js_exclude',  function($e){ return $e . ',in3pida-form-2/assets/js/builder.js,in3pida-form-2/assets/js/admin.js'; });
add_filter('autoptimize_filter_css_exclude', function($e){ return $e . ',in3pida-form-2/assets/css/admin.css'; });
