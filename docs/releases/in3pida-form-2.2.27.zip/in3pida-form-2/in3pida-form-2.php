<?php
/**
 * Plugin Name: in3pida form 2.0
 * Description: Form builder WordPress originale — Supabase, Hotel ID, Reply-To, Thank You Page, Canale, Datepicker avanzato.
 * Author: in3pida
 * Version: 2.2.27
 * Text Domain: in3pida-form-2
 * Domain Path: /languages
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 *
 * Codice originale — nessuna dipendenza da plugin di terze parti.
 * Librerie JS open source usate: Sortable.js (MIT), React via wp.element (GPL-2.0+).
 */

defined('ABSPATH') || exit;

define('IF2_VERSION',  '2.2.27');
define('IF2_PATH',     plugin_dir_path(__FILE__));
define('IF2_URL',      plugin_dir_url(__FILE__));
define('IF2_BASENAME', plugin_basename(__FILE__));

// Svuota opcache PHP al cambio versione (utile su SiteGround e hosting con opcache persistente)
add_action('init', function () {
    if (get_option('if2_opcache_ver', '') !== IF2_VERSION) {
        if (function_exists('opcache_reset')) {
            @opcache_reset();
        } elseif (function_exists('opcache_invalidate')) {
            foreach ((array) glob(IF2_PATH . 'includes/*.php') as $f) {
                @opcache_invalidate((string) $f, true);
            }
            @opcache_invalidate(__FILE__, true);
        }
        update_option('if2_opcache_ver', IF2_VERSION, false);
    }
}, 1);

require_once IF2_PATH . 'includes/class-if2-lang.php';
require_once IF2_PATH . 'includes/class-if2-db.php';
require_once IF2_PATH . 'includes/class-if2-form.php';
require_once IF2_PATH . 'includes/class-if2-submission.php';
require_once IF2_PATH . 'includes/class-if2-renderer.php';
require_once IF2_PATH . 'includes/class-if2-admin.php';
require_once IF2_PATH . 'includes/class-if2-ajax.php';
require_once IF2_PATH . 'includes/class-if2-extensions.php';
require_once IF2_PATH . 'includes/class-if2-crm.php';
require_once IF2_PATH . 'includes/class-if2-telemetry.php';

register_activation_hook(__FILE__,   ['IF2_DB',        'install']);
register_activation_hook(__FILE__,   ['IF2_Telemetry', 'activate']);
register_deactivation_hook(__FILE__, ['IF2_DB',        'deactivate']);
register_deactivation_hook(__FILE__, ['IF2_Telemetry', 'deactivate']);

add_action('init',                    ['IF2_Renderer', 'register_shortcode']);
add_action('admin_menu',             ['IF2_Admin',    'register_pages']);
add_action('admin_init',             ['IF2_Admin',    'hide_footer']);
add_action('admin_notices',          ['IF2_Admin',    'admin_notice']);
add_action('admin_enqueue_scripts',  ['IF2_Admin',    'enqueue']);
add_action('admin_head',             ['IF2_Admin',    'admin_head']);
// frontend assets enqueued on-demand da IF2_Renderer::enqueue_assets()
IF2_Ajax::init();
IF2_Extensions::init();
IF2_Telemetry::init();

// Esclude i file del plugin dai combine/minify di SiteGround Optimizer e simili
add_filter('sgo_js_combine_exclude',  function($e){ $e[] = 'if2-builder'; $e[] = 'if2-admin'; return $e; });
add_filter('sgo_css_combine_exclude', function($e){ $e[] = 'if2-admin';   return $e; });
add_filter('sgo_js_minify_exclude',   function($e){ $e[] = 'if2-builder'; $e[] = 'if2-admin'; return $e; });
add_filter('sgo_css_minify_exclude',  function($e){ $e[] = 'if2-admin';   return $e; });
// WP Rocket / W3TC / Autoptimize
add_filter('rocket_exclude_js',       function($e){ $e[] = '/in3pida-form-2/assets/js/builder.js'; $e[] = '/in3pida-form-2/assets/js/admin.js'; return $e; });
add_filter('rocket_exclude_css',      function($e){ $e[] = '/in3pida-form-2/assets/css/admin.css'; return $e; });
add_filter('autoptimize_filter_js_exclude',  function($e){ return $e . ',in3pida-form-2/assets/js/builder.js,in3pida-form-2/assets/js/admin.js'; });
add_filter('autoptimize_filter_css_exclude', function($e){ return $e . ',in3pida-form-2/assets/css/admin.css'; });
