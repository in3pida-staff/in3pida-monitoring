<?php
defined('ABSPATH') || exit;
?>
<style>
.if2-panel-forms{flex:0 0 56%!important;max-width:56%!important;border-right:none!important;}
.if2-panel-stats{flex:1 1 0%!important;min-width:0!important;}
.if2-dashboard{padding:32px!important;gap:20px!important;}
.if2-panel{min-height:600px!important;}
.if2-panel-header{padding:18px 20px!important;}
.if2-sub-meta-bar{display:flex!important;flex-wrap:nowrap!important;align-items:center;overflow:hidden;}
.if2-sub-meta-source{flex:1!important;min-width:0!important;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.if2-table thead th{padding:12px 10px!important;font-size:.72rem!important;white-space:nowrap!important;}
.if2-table tbody td{padding:12px 10px!important;}
.if2-table thead th.if2-th-dot{width:22px!important;padding:12px 5px!important;text-align:center!important;}
.if2-table tbody td.if2-td-dot{padding:12px 5px!important;text-align:center!important;}
.if2-dashboard-sub .if2-panel-forms .if2-panel-footer{padding:6px 20px 6px 14px!important;}
/* Dot integrazioni */
.if2-ilog-dot{width:11px;height:11px;border-radius:50%;display:inline-block;cursor:default;flex-shrink:0;}
.if2-ilog-ok{background:#22c55e;}
.if2-ilog-error{background:#d82d6b;}
.if2-ilog-pending{background:#f59e0b;}
.if2-ilog-skipped{background:#c8d0d8;}
.if2-ilog-info{background:#60a5fa;}
.if2-fake-phone-badge{display:inline-block;font-size:.62rem;font-weight:700;color:#f59e0b;background:#fff7ed;border:1px solid #fed7aa;border-radius:4px;padding:1px 6px;letter-spacing:.02em;text-transform:uppercase;}
/* Help legenda pallini */
.if2-help-wrap{position:relative;display:inline-flex;align-items:center;}
.if2-help-icon{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:50%;border:1.5px solid #00bcd4;color:#00bcd4;font-size:12px;font-weight:700;cursor:help;line-height:1;flex-shrink:0;}
.if2-help-popup{position:absolute;top:calc(100% + 8px);left:0;z-index:9999;width:280px;background:#fff;border:1px solid #e8e8e8;border-radius:8px;box-shadow:0 4px 18px rgba(0,0,0,.12);padding:14px 16px;display:none;}
.if2-help-wrap:hover .if2-help-popup{display:block;}
.if2-help-popup-title{font-size:.7rem;font-weight:700;color:#555;text-transform:uppercase;letter-spacing:.04em;margin-bottom:10px;}
.if2-help-row{display:flex;align-items:center;gap:9px;margin-bottom:8px;font-size:.78rem;color:#444;line-height:1.3;}
.if2-help-row:last-child{margin-bottom:0;}
.if2-help-row .if2-ilog-dot{width:11px;height:11px;}
.if2-help-group{font-size:.68rem;font-weight:800;color:#d82d6b;text-transform:uppercase;letter-spacing:.05em;margin:12px 0 7px;}
.if2-help-group:first-of-type{margin-top:0;}
/* Tooltip personalizzato */
#if2-dot-tip{position:fixed;background:#1a1a1a;color:#fff;font-size:.8rem;font-weight:400;padding:6px 12px;border-radius:5px;z-index:99999;pointer-events:none;display:none;max-width:300px;line-height:1.5;box-shadow:0 2px 10px rgba(0,0,0,.3);white-space:nowrap;}
/* Select form filter */
.if2-sub-form-select{max-width:160px;}
.if2-sort-ico{margin-left:4px;font-size:10px;color:#bbb;}
/* Paginazione stile FormCraft */
.if2-pagination-info{overflow-x:auto;overflow-y:hidden;white-space:nowrap;}
.if2-pagination-info a{display:inline-block;padding:0 .85em;height:2.5em;line-height:2.5em;text-decoration:none;font-size:.78rem;font-weight:600;vertical-align:top;text-align:center;border-top:2px solid transparent;color:#bbb;}
.if2-pagination-info a:hover{color:#d82d6b;border-top-color:#d82d6b;}
.if2-pagination-info a.if2-page-active{color:#d82d6b;border-top-color:#d82d6b;}
/* Barra integrazioni nel dettaglio */
.if2-sub-ilog-bar{display:flex;gap:20px;padding:10px 20px;background:#fafafa;border-bottom:1px solid var(--if2-border);flex-wrap:wrap;align-items:center;}
.if2-sub-ilog-item{display:inline-flex;align-items:center;gap:6px;}
.if2-sub-ilog-label{font-size:.72rem;font-weight:700;color:#555;text-transform:uppercase;letter-spacing:.04em;}
.if2-sub-ilog-msg{font-size:.7rem;color:#aaa;}
</style>
<div id="if2-dot-tip"></div>
<script>
(function($){
    var $tip = $('#if2-dot-tip');
    $(document).on('click', '.if2-retry-integration', function() {
        var $btn    = $(this);
        var id      = $btn.data('id');
        var action  = $btn.data('action');
        var ikey    = $btn.data('ikey');
        $btn.text('…').prop('disabled', true);
        $.post(IF2Admin.ajaxurl, {
            action: action,
            nonce:  IF2Admin.nonce,
            submission_id: id
        }, function(r) {
            if (r.success) {
                $btn.closest('.if2-sub-ilog-item').find('span:first').text('✓').css('color','#22c55e');
                $btn.closest('.if2-sub-ilog-item').find('.if2-sub-ilog-msg').text('OK');
                $btn.remove();
                // Aggiorna pallino nella tabella sinistra
                var $row    = $('[data-sub-id="' + id + '"]');
                var colMap  = { supabase: 0, webhook: 1, amelia: 2 };
                var colIdx  = (ikey in colMap) ? colMap[ikey] : (ikey.indexOf('crm_') === 0 ? 1 : -1);
                if (colIdx >= 0) {
                    $row.find('.if2-ilog-error').eq(colIdx).removeClass('if2-ilog-error').addClass('if2-ilog-ok');
                }
            } else {
                $btn.text('✗ ' + (r.data || 'Errore')).css('color','#d82d6b').prop('disabled', false);
            }
        });
    });

    $(document)
        .on('mouseenter', '.if2-ilog-dot[data-tip]', function(e){
            var txt = $(this).data('tip');
            if (!txt) return;
            $tip.text(txt).show();
            var r  = this.getBoundingClientRect();
            var tw = $tip.outerWidth();
            var th = $tip.outerHeight();
            var left = r.left + r.width / 2 - tw / 2;
            var top  = r.top - th - 10;
            if (left < 6) left = 6;
            if (top < 6)  top  = r.bottom + 10;
            $tip.css({left: left, top: top});
        })
        .on('mouseleave', '.if2-ilog-dot[data-tip]', function(){
            $tip.hide();
        });
})(jQuery);
</script>
<?php
/**
 * Dot per i CRM nativi (colonna CRM, aggrega tutti i crm_* del log).
 * Se nessun CRM nativo attivo, fallback a webhook.
 */
function if2_crm_dot_cell(array $ilog): string {
    $crm_keys = array_filter(array_keys($ilog), fn($k) => strpos($k, 'crm_') === 0);
    $active   = array_filter(
        array_intersect_key($ilog, array_flip($crm_keys)),
        fn($l) => ($l['status'] ?? 'disabled') !== 'disabled'
    );

    if (empty($active)) {
        // Fallback al webhook generico
        return if2_ilog_dot_cell($ilog, 'webhook', 'CRM', 'ENTRATO');
    }

    $agg = IF2_CRM::aggregate($ilog);
    $status = $agg['status'] ?? 'disabled';
    if ($status === 'disabled') return '';

    if ($status === 'ok') {
        $tip = 'CRM ENTRATO';
        $parts = [];
        foreach ($active as $k => $log) {
            $driver = strtoupper(str_replace('crm_', '', $k));
            $parts[] = $driver . ' ENTRATO';
        }
        if (count($parts) > 1) $tip = implode(' | ', $parts);
    } else {
        $tip = esc_attr($agg['message'] ?? $status);
    }

    $cls = in_array($status, ['ok','error','pending','skipped','info'], true) ? $status : 'pending';
    return '<span class="if2-ilog-dot if2-ilog-' . $cls . '" data-tip="' . esc_attr($tip) . '"></span>';
}

function if2_ilog_dot_cell(array $ilog, string $key, string $label, string $ok_label = 'OK'): string {
    $entry  = $ilog[$key] ?? null;
    if (!$entry) return '';
    $status = $entry['status'] ?? 'pending';
    if ($status === 'disabled') return '';
    $msg    = $entry['message'] ?? '';
    $code   = isset($entry['code']) && $entry['code'] ? ' HTTP ' . $entry['code'] : '';
    if ($status === 'ok') {
        $tip = esc_attr(strtoupper($label) . ' ' . strtoupper($ok_label));
    } elseif ($status === 'info') {
        $tip = esc_attr(strtoupper($label) . ' ' . strtoupper($msg ?: 'già presente'));
    } else {
        $tip = esc_attr(strtoupper($label) . ': ' . $status . $code . ($msg ? ' — ' . $msg : ''));
    }
    $cls = in_array($status, ['ok','error','pending','skipped','info'], true) ? $status : 'pending';
    return '<span class="if2-ilog-dot if2-ilog-' . $cls . '" data-tip="' . $tip . '"></span>';
}
?>
<?php

$form_id     = (int) ($_GET['form_id'] ?? 0);
$sub_id      = (int) ($_GET['sub_id']  ?? 0);
$page        = max(1, (int) ($_GET['paged'] ?? 1));
$limit       = 10;
$offset      = ($page - 1) * $limit;

$forms       = IF2_Form::get_all();
$rows        = IF2_Submission::get_filtered($form_id, $limit, $offset);
$total       = IF2_Submission::count_filtered($form_id);
$pages       = max(1, (int) ceil($total / $limit));

$detail_sub  = null;
$detail_form = null;
$detail_data = [];
$detail_meta = [];
$cols        = [];

if ($sub_id) {
    $detail_sub = IF2_Submission::get_one($sub_id);
    if ($detail_sub) {
        $detail_form = IF2_Form::get((int) $detail_sub['form_id']);
        $detail_data = json_decode($detail_sub['data'], true) ?: [];
        $detail_meta = json_decode($detail_sub['meta'],  true) ?: [];
        if ($detail_form) {
            $cols = array_values(array_filter(
                $detail_form['fields'],
                fn($f) => !in_array($f['type'], ['page_break', 'html', 'heading', 'submit'], true)
            ));
        }
    }
}

$base_url = admin_url('admin.php?page=if2-submissions');

$show_dot_db     = (bool) get_option('if2_feature_dot_db',     1);
$show_dot_crm    = (bool) get_option('if2_feature_dot_crm',    1);
$show_dot_amelia = (bool) get_option('if2_feature_dot_amelia', 1);
?>
<div class="if2-admin-wrap">

    <div class="if2-topbar">
        <span style="font-size:.82rem;color:#888"><?php echo IF2_Lang::t('submissions_title'); ?></span>
        <span class="if2-topbar-brand">in3pida-form è un plugin di <strong>in3pida</strong></span>
    </div>

    <div class="if2-dashboard if2-dashboard-sub">

        <!-- Panel sinistro: lista submissions -->
        <div class="if2-panel if2-panel-forms">
            <div class="if2-panel-header">
                <span class="if2-panel-title"><?php echo IF2_Lang::t('submissions_title'); ?></span>
                <div class="if2-panel-actions">
                    <div class="if2-help-wrap">
                        <span class="if2-help-icon">?</span>
                        <div class="if2-help-popup">
                            <div class="if2-help-popup-title">Legenda semaforo</div>
                            <div class="if2-help-group">DB</div>
                            <div class="if2-help-row"><span class="if2-ilog-dot if2-ilog-ok"></span>Verde — inserito correttamente</div>
                            <div class="if2-help-row"><span class="if2-ilog-dot if2-ilog-error"></span>Rosso — errore</div>
                            <div class="if2-help-row"><span class="if2-ilog-dot" style="background:#7b8794"></span>Grigio — non configurato</div>
                            <div class="if2-help-group">CRM</div>
                            <div class="if2-help-row"><span class="if2-ilog-dot if2-ilog-ok"></span>Verde — entrato correttamente</div>
                            <div class="if2-help-row"><span class="if2-ilog-dot if2-ilog-error"></span>Rosso — errore</div>
                            <div class="if2-help-row"><span class="if2-ilog-dot" style="background:#7b8794"></span>Grigio — CRM non configurato</div>
                            <div class="if2-help-group">Amelia</div>
                            <div class="if2-help-row"><span class="if2-ilog-dot if2-ilog-ok"></span>Verde — contatto salvato su Amelia</div>
                            <div class="if2-help-row"><span class="if2-ilog-dot if2-ilog-error"></span>Rosso — errore</div>
                            <div class="if2-help-row"><span class="if2-ilog-dot if2-ilog-info"></span>Azzurro — contatto già presente</div>
                            <div class="if2-help-row"><span class="if2-ilog-dot if2-ilog-skipped"></span>Grigio chiaro — telefono o consenso mancante</div>
                            <div class="if2-help-row"><span class="if2-ilog-dot" style="background:#7b8794"></span>Grigio scuro — Amelia non configurato</div>
                        </div>
                    </div>
                    <div class="if2-search-wrap">
                        <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0"><circle cx="5.5" cy="5.5" r="4.5" stroke="#aaa" stroke-width="1.4"/><path d="M9 9l2.5 2.5" stroke="#aaa" stroke-width="1.4" stroke-linecap="round"/></svg>
                        <input type="text" id="if2-search-submissions" placeholder="<?php echo esc_attr(IF2_Lang::t('search_placeholder')); ?>" class="if2-search-input">
                    </div>
                    <button id="if2-bulk-delete" class="if2-btn-primary" style="display:none"><?php echo IF2_Lang::t('bulk_delete'); ?></button>
                    <a href="#" id="if2-export-sub" class="if2-btn-primary" data-form-id="<?php echo esc_attr($form_id); ?>"><?php echo IF2_Lang::t('export_btn'); ?></a>
                </div>
            </div>

            <table class="if2-table" id="if2-submissions-table">
                <thead>
                    <tr>
                        <th style="width:30px"><input type="checkbox" id="if2-check-all" style="margin:0;accent-color:#d82d6b"></th>
                        <th style="width:44px"><?php echo IF2_Lang::t('col_id'); ?></th>
                        <?php if ($show_dot_db):     ?><th class="if2-th-dot">DB</th><?php endif; ?>
                        <?php if ($show_dot_crm):    ?><th class="if2-th-dot">CRM</th><?php endif; ?>
                        <?php if ($show_dot_amelia): ?><th class="if2-th-dot">AM</th><?php endif; ?>
                        <th>
                            <select class="if2-sub-form-select" onchange="window.location.href=this.value">
                                <option value="<?php echo esc_url($base_url); ?>"<?php selected($form_id, 0); ?>><?php echo IF2_Lang::t('all_forms_filter'); ?></option>
                                <?php foreach ($forms as $f): ?>
                                <option value="<?php echo esc_url($base_url . '&form_id=' . $f['id']); ?>"<?php selected($form_id, (int) $f['id']); ?>><?php echo esc_html($f['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <span class="if2-sort-ico">↕</span>
                        </th>
                        <th id="if2-sub-sort-created" style="cursor:pointer;user-select:none;white-space:nowrap"><?php echo IF2_Lang::t('col_created'); ?> <span id="if2-sub-sort-ico" style="font-size:10px;color:#bbb">↕</span></th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($rows)): ?>
                    <tr class="if2-empty-row"><td colspan="7"><?php echo IF2_Lang::t('no_submissions'); ?></td></tr>
                <?php else: foreach ($rows as $row):
                    $ts  = strtotime($row['created_at']);
                    $ago = IF2_Lang::ago($ts);

                    $sub_url   = $base_url . ($form_id ? '&form_id=' . $form_id : '') . '&sub_id=' . $row['id'] . ($page > 1 ? '&paged=' . $page : '');
                    $is_active = (int) $row['id'] === $sub_id;
                ?>
                    <?php
                        $row_meta = json_decode($row['meta'] ?? '{}', true) ?: [];
                        $ilog     = $row_meta['integration_log'] ?? [];
                    ?>
                    <tr class="if2-form-row<?php echo $is_active ? ' if2-sub-active' : ''; ?>"
                        data-sub-id="<?php echo esc_attr($row['id']); ?>"
                        data-ts="<?php echo esc_attr($ts); ?>"
                        data-builder-url="<?php echo esc_url($sub_url); ?>">
                        <td><input type="checkbox" class="if2-sub-check" style="margin:0;accent-color:#d82d6b"></td>
                        <td><?php echo esc_html($row['id']); ?></td>
                        <?php if ($show_dot_db):     ?><td class="if2-td-dot"><?php echo if2_ilog_dot_cell($ilog, 'supabase', 'Supabase', 'INSERITO'); ?></td><?php endif; ?>
                        <?php if ($show_dot_crm):    ?><td class="if2-td-dot"><?php echo if2_crm_dot_cell($ilog); ?></td><?php endif; ?>
                        <?php if ($show_dot_amelia): ?><td class="if2-td-dot"><?php echo if2_ilog_dot_cell($ilog, 'amelia', 'Amelia', 'SALVATO'); ?></td><?php endif; ?>
                        <td class="if2-form-name-link"><?php echo esc_html($row['form_name'] ?? '—'); ?></td>
                        <td class="if2-form-date"><?php echo esc_html($ago); ?></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>

            <div class="if2-panel-footer" style="padding:0">
                <div class="if2-pagination-info">
                    <?php for ($i = 1; $i <= $pages; $i++): ?>
                        <a href="<?php echo esc_url($base_url . ($form_id ? '&form_id=' . $form_id : '') . '&paged=' . $i . ($sub_id ? '&sub_id=' . $sub_id : '')); ?>"
                           <?php echo $i === $page ? 'class="if2-page-active"' : ''; ?>><?php echo $i; ?></a>
                    <?php endfor; ?>
                </div>
                <div class="if2-accent-bar"></div>
            </div>
        </div>

        <!-- Panel destro: dettaglio submission -->
        <div class="if2-panel if2-panel-stats">

            <?php if (!$detail_sub): ?>
            <div class="if2-panel-header">
                <span class="if2-panel-title"><?php echo IF2_Lang::t('view_submission'); ?></span>
            </div>

            <?php else: ?>

            <div class="if2-panel-header">
                <span class="if2-panel-title"><?php echo esc_html($detail_form['name'] ?? ''); ?></span>
                <div class="if2-panel-actions" style="gap:6px">
                    <button class="if2-btn-primary" id="if2-toggle-empty"><?php echo IF2_Lang::t('hide_empty_fields'); ?></button>
                    <button class="if2-btn-primary if2-edit-submission" data-id="<?php echo esc_attr($detail_sub['id']); ?>"><?php echo IF2_Lang::t('edit_submission'); ?></button>
                    <button class="if2-btn-primary" id="if2-print-sub"><?php echo IF2_Lang::t('print_btn'); ?></button>
                </div>
            </div>

            <?php
            $detail_ilog = $detail_meta['integration_log'] ?? [];
            if (!empty($detail_ilog)):
                $ilog_defs = [];
                if ($show_dot_db)     $ilog_defs['supabase'] = ['label' => 'DATABASE', 'ok_label' => 'INSERITO'];
                if ($show_dot_crm)    $ilog_defs['webhook']  = ['label' => 'CRM',      'ok_label' => 'ENTRATO'];
                if ($show_dot_amelia) $ilog_defs['amelia']   = ['label' => 'AMELIA',   'ok_label' => 'SALVATO'];

                // Aggiungi i CRM nativi dinamicamente
                $drivers = IF2_CRM::get_drivers();
                foreach ($drivers as $drv_key => $drv_def) {
                    $log_key = 'crm_' . $drv_key;
                    if (!empty($detail_ilog[$log_key]) && ($detail_ilog[$log_key]['status'] ?? 'disabled') !== 'disabled') {
                        $ilog_defs[$log_key] = ['label' => strtoupper($drv_def['label']), 'ok_label' => 'ENTRATO'];
                        // Rimuovi il webhook generico se c'è un CRM nativo
                        unset($ilog_defs['webhook']);
                    }
                }
            ?>
            <div class="if2-sub-ilog-bar">
                <?php foreach ($ilog_defs as $ikey => $idef):
                    $entry    = $detail_ilog[$ikey] ?? null;
                    if (!$entry) continue;
                    $status   = $entry['status'] ?? 'pending';
                    if ($status === 'disabled') continue;
                    $msg      = $entry['message'] ?? '';
                    $code     = isset($entry['code']) && $entry['code'] ? ' HTTP ' . $entry['code'] : '';
                    $cls      = in_array($status, ['ok','error','pending','skipped','info'], true) ? $status : 'pending';
                    $icon     = ['ok' => '✓', 'error' => '✗', 'pending' => '⟳', 'skipped' => '⊘', 'info' => '↺'][$cls] ?? '?';
                    $color    = ['ok' => '#22c55e', 'error' => '#d82d6b', 'pending' => '#f59e0b', 'skipped' => '#94a3b8', 'info' => '#60a5fa'][$cls] ?? '#aaa';
                    if ($status === 'ok') {
                        $display_msg = $idef['ok_label'];
                    } elseif ($status === 'info') {
                        $display_msg = strtoupper($msg ?: 'già presente');
                    } else {
                        $display_msg = trim(($msg ?: '') . $code);
                    }
                ?>
                <span class="if2-sub-ilog-item">
                    <span style="font-size:13px;color:<?php echo $color; ?>;font-weight:700;line-height:1"><?php echo $icon; ?></span>
                    <span class="if2-sub-ilog-label"><?php echo esc_html($idef['label']); ?></span>
                    <?php if ($display_msg): ?>
                    <span class="if2-sub-ilog-msg"><?php echo esc_html($display_msg); ?></span>
                    <?php endif; ?>
                    <?php if ($ikey === 'amelia' && !empty($entry['fake_phone'])): ?>
                    <span class="if2-fake-phone-badge">tel fake</span>
                    <?php endif; ?>
                    <?php
                    $retry_action = null;
                    if ($ikey === 'supabase' && $status === 'error') $retry_action = 'if2_retry_supabase';
                    elseif ($ikey === 'amelia' && in_array($status, ['error','skipped'], true)) $retry_action = 'if2_retry_amelia';
                    elseif (($ikey === 'webhook' || strpos($ikey, 'crm_') === 0) && $status === 'error') $retry_action = 'if2_retry_crm';
                    ?>
                    <?php if ($retry_action): ?>
                    <button class="if2-retry-integration"
                        data-id="<?php echo esc_attr($detail_sub['id']); ?>"
                        data-action="<?php echo esc_attr($retry_action); ?>"
                        data-ikey="<?php echo esc_attr($ikey); ?>"
                        style="font-size:.68rem;padding:1px 8px;border-radius:3px;border:1px solid #d82d6b;background:#fff;color:#d82d6b;cursor:pointer;line-height:1.6">↻ Riprova</button>
                    <?php endif; ?>
                </span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <div class="if2-sub-meta-bar">
                <span class="if2-sub-meta-id">#<?php echo esc_html($detail_sub['id']); ?></span>
                <span class="if2-sub-meta-date"><?php echo esc_html(date_i18n('d/m/Y \a\l\l\e H:i', strtotime($detail_sub['created_at']))); ?></span>
                <?php if (!empty($detail_meta['channel'])): ?>
                <span class="if2-sub-meta-date" style="font-size:.75rem;background:#fdf0f5;border:1px solid #f5c5d8;border-radius:3px;padding:1px 7px;color:#d82d6b;font-weight:700">
                    <?php echo esc_html(strtoupper($detail_meta['channel'])); ?>
                </span>
                <?php endif; ?>
                <?php if (!empty($detail_meta['ip'])): ?>
                <span class="if2-sub-meta-date" style="font-size:.75rem">IP: <?php echo esc_html($detail_meta['ip']); ?></span>
                <?php endif; ?>
                <span class="if2-sub-meta-source">
                    <?php if (!empty($detail_meta['source_url'])): ?>
                    <?php echo IF2_Lang::t('source_label'); ?>: <a href="<?php echo esc_url($detail_meta['source_url']); ?>" target="_blank"><?php echo esc_html($detail_meta['source_url']); ?></a>
                    <?php else: ?>
                    <span style="color:#ccc;font-size:.75rem;font-style:italic">URL provenienza non disponibile</span>
                    <?php endif; ?>
                </span>
            </div>

            <div class="if2-sub-detail-grid" id="if2-sub-grid">
                <?php foreach ($cols as $col):
                    $val   = $detail_data[$col['id']] ?? '';
                    $strip = fn($v) => is_string($v) && strpos($v,'==') !== false ? substr($v, 0, strpos($v,'==')) : $v;
                    $disp  = is_array($val) ? implode(', ', array_map($strip, $val)) : $strip($val);
                    $empty = ($disp === '');
                ?>
                <div class="if2-sub-grid-field<?php echo $empty ? ' if2-field-empty' : ''; ?>">
                    <div class="if2-sub-grid-label"><?php echo esc_html(strtoupper($col['label'] ?? $col['id'])); ?></div>
                    <div class="if2-sub-grid-value"><?php echo esc_html($disp !== '' ? $disp : IF2_Lang::t('empty_value')); ?></div>
                </div>
                <?php endforeach; ?>
            </div>

            <?php endif; ?>

            <div class="if2-panel-footer">
                <span class="if2-pagination-info">&nbsp;</span>
                <div class="if2-accent-bar"></div>
            </div>
        </div>

    </div>
</div>
