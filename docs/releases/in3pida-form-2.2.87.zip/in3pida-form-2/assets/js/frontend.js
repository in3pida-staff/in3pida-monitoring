/* in3pida Form 2 – Frontend JS */
(function () {
    'use strict';

    var S = (typeof IF2 !== 'undefined' && IF2.strings) ? IF2.strings : {
        required:   'Questo campo è obbligatorio.',
        email_err:  'Inserisci un indirizzo email valido.',
        fix_errors: 'Correggi gli errori evidenziati.',
        conn_error: 'Errore di connessione. Riprova.',
        multi_err:  'Hai già inviato questo modulo.',
    };

    function init() {
        document.querySelectorAll('.if2-form-wrap').forEach(initForm);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    function initForm(wrap) {
        var form     = wrap.querySelector('.if2-form');
        var pages    = Array.from(wrap.querySelectorAll('.if2-page'));
        var response = wrap.querySelector('.if2-response');
        var formId   = wrap.dataset.formId;
        var current  = 0;

        if (!form) return;

        // disable_multiple: blocca se già inviato
        var disableMultiple = wrap.dataset.disableMultiple === '1';
        if (disableMultiple) {
            var sk = 'if2_submitted_' + formId;
            try {
                if (localStorage.getItem(sk)) {
                    form.style.display = 'none';
                    showResponse(response, S.multi_err, 'success');
                    return;
                }
            } catch (e) {}
        }

        // Autosave: ripristina valori salvati
        var autosave = wrap.dataset.autosave === '1';
        if (autosave) restoreAutosave(form, formId);

        // Fallback mobile: se viewport non standard non attiva il media query CSS
        function applyMobileClass() {
            var isMobile = window.innerWidth <= 640;
            wrap.classList.toggle('if2-mobile', isMobile);
        }
        applyMobileClass();
        window.addEventListener('resize', applyMobileClass);

        initDatepickers(wrap);
        initConditions(form);

        // Autosave: salva al cambio di ogni input
        if (autosave) {
            form.addEventListener('change', function () { saveAutosave(form, formId); });
            form.addEventListener('input',  function () { saveAutosave(form, formId); });
        }

        wrap.addEventListener('click', function (e) {
            if (e.target.classList.contains('if2-btn-next')) {
                if (validatePage(pages[current])) {
                    goToPage(pages, current, current + 1, wrap);
                    current++;
                }
            } else if (e.target.classList.contains('if2-btn-prev')) {
                goToPage(pages, current, current - 1, wrap);
                current--;
            }
        });

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            if (!validatePage(pages[current])) return;

            var btn = form.querySelector('.if2-btn-submit');
            btn.disabled = true;
            btn.setAttribute('aria-busy', 'true');
            btn.classList.add('loading');

            submitForm(wrap, form, formId, response, function (success, redirectUrl, redirectDelay) {
                btn.disabled = false;
                btn.removeAttribute('aria-busy');
                btn.classList.remove('loading');

                if (success) {
                    if (disableMultiple) {
                        try { localStorage.setItem('if2_submitted_' + formId, '1'); } catch (e) {}
                    }
                    if (autosave) {
                        try { localStorage.removeItem('if2_autosave_' + formId); } catch (e) {}
                    }
                    if (redirectUrl) {
                        var delay = redirectDelay > 0 ? redirectDelay : 300;
                        setTimeout(function () { window.location.href = redirectUrl; }, delay);
                    }
                }
            });
        });

        form.addEventListener('input', function (e) {
            var el = e.target;
            if (el.classList.contains('if2-input') || el.type === 'radio' || el.type === 'checkbox') {
                clearError(el);
            }
        });
    }

    // -------------------------------------------------------------------------
    // Navigazione multi-step
    // -------------------------------------------------------------------------
    function goToPage(pages, from, to, wrap) {
        pages[from].style.display = 'none';
        pages[to].style.display   = '';
        updateProgress(wrap, to, pages.length);
        wrap.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function updateProgress(wrap, idx, total) {
        var bar = wrap.querySelector('.if2-progress-bar');
        if (!bar) return;
        bar.style.width = Math.round(((idx + 1) / total) * 100) + '%';
    }

    // -------------------------------------------------------------------------
    // Validazione
    // -------------------------------------------------------------------------
    function validatePage(page) {
        var valid = true;

        page.querySelectorAll('[required]').forEach(function (el) {
            if (!isVisible(el.closest('.if2-field'))) return;
            var ok = false;
            if (el.type === 'radio') {
                ok = !!page.querySelector('input[type="radio"][name="' + el.name + '"]:checked');
            } else if (el.type === 'checkbox') {
                ok = !!page.querySelector('input[type="checkbox"][name="' + el.name + '"]:checked');
            } else {
                ok = el.value.trim() !== '';
            }
            if (!ok) { showError(el, S.required); valid = false; }
            else      { clearError(el); }
        });

        page.querySelectorAll('input[type="email"]').forEach(function (el) {
            if (!isVisible(el.closest('.if2-field'))) return;
            if (el.value && !isValidEmail(el.value)) {
                showError(el, S.email_err);
                valid = false;
            }
        });

        // Validazione automatica campi telefono — sempre solo numeri (+ spazi, +, -)
        page.querySelectorAll('input[type="tel"], input[type="phone"]').forEach(function (el) {
            if (!isVisible(el.closest('.if2-field'))) return;
            if (!el.value) return;
            if (!/^[\d\s\+\-\.\(\)]+$/.test(el.value)) {
                showError(el, 'Questo campo accetta solo numeri.');
                valid = false;
            } else {
                clearError(el);
            }
        });

        // Validazione tipo campo (validation_type dal builder)
        page.querySelectorAll('[data-validation-type]').forEach(function (el) {
            if (!isVisible(el.closest('.if2-field'))) return;
            var val  = el.value;
            if (!val) return; // campo vuoto: la validazione required è già sopra
            var type = el.getAttribute('data-validation-type');
            var ok   = true;
            var msg  = '';
            if (type === 'numeric') {
                ok  = /^[\d\s\+\-\.]+$/.test(val);
                msg = 'Questo campo accetta solo numeri.';
            } else if (type === 'alpha') {
                ok  = /^[a-zA-ZÀ-ÿ\s]+$/.test(val);
                msg = 'Questo campo accetta solo lettere.';
            } else if (type === 'alphanumeric') {
                ok  = /^[a-zA-ZÀ-ÿ0-9\s]+$/.test(val);
                msg = 'Questo campo accetta solo lettere e numeri.';
            } else if (type === 'url') {
                ok  = /^https?:\/\/.+\..+/.test(val);
                msg = 'Inserisci un URL valido (es: https://esempio.it).';
            } else if (type === 'regex') {
                var pattern = el.getAttribute('data-validation-regex');
                if (pattern) { try { ok = new RegExp(pattern).test(val); msg = 'Formato non valido.'; } catch(e) {} }
            }
            if (!ok) { showError(el, msg); valid = false; }
            else      { clearError(el); }
        });

        // Validazione min/max caratteri
        page.querySelectorAll('[data-min-chars],[data-max-chars]').forEach(function (el) {
            if (!isVisible(el.closest('.if2-field'))) return;
            var val = el.value;
            if (!val) return;
            var min = parseInt(el.getAttribute('data-min-chars') || '0', 10);
            var max = parseInt(el.getAttribute('data-max-chars') || '0', 10);
            if (min > 0 && val.length < min) {
                showError(el, 'Minimo ' + min + ' caratteri.');
                valid = false;
            } else if (max > 0 && val.length > max) {
                showError(el, 'Massimo ' + max + ' caratteri.');
                valid = false;
            } else {
                clearError(el);
            }
        });

        return valid;
    }

    function showError(el, msg) {
        el.classList.add('if2-invalid');
        var err = getErrorDiv(el);
        if (err) err.textContent = msg;
    }

    function clearError(el) {
        el.classList.remove('if2-invalid');
        var err = getErrorDiv(el);
        if (err) err.textContent = '';
    }

    function getErrorDiv(el) {
        var field = el.closest('.if2-field');
        return field ? field.querySelector('.if2-error') : null;
    }

    function isValidEmail(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
    function isVisible(el) { return el ? el.style.display !== 'none' && el.offsetParent !== null : true; }

    // -------------------------------------------------------------------------
    // AJAX submit
    // -------------------------------------------------------------------------
    function submitForm(wrap, form, formId, response, done) {
        var formData = new FormData(form);
        formData.set('action', 'if2_submit');

        var channel = wrap.querySelector('.if2-hidden-channel');
        var hotelId = wrap.querySelector('.if2-hidden-hotel-id');
        if (channel) formData.set('_channel',  channel.value);
        if (hotelId) formData.set('_hotel_id', hotelId.value);
        formData.set('_source_url', window.location.href);

        fetch(IF2.ajaxurl, { method: 'POST', body: formData, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (json) {
            if (json.success) {
                showResponse(response, json.data.message, 'success');
                form.reset();
                done(true, json.data.redirect || '', json.data.redirect_delay || 0);
            } else {
                if (json.data && json.data.errors) {
                    showFieldErrors(form, json.data.errors);
                    showResponse(response, S.fix_errors, 'error');
                } else {
                    showResponse(response, (json.data && json.data.message) || S.fix_errors, 'error');
                }
                done(false, '', 0);
            }
        })
        .catch(function () {
            showResponse(response, S.conn_error, 'error');
            done(false, '', 0);
        });
    }

    function showFieldErrors(form, errors) {
        Object.keys(errors).forEach(function (fid) {
            var el = form.querySelector('[name="' + fid + '"]') ||
                     form.querySelector('[name="' + fid + '[]"]');
            if (el) showError(el, errors[fid]);
        });
    }

    function showResponse(el, msg, type) {
        el.innerHTML     = msg;
        el.style.display = 'block';
        el.className     = 'if2-response ' + (type === 'success' ? 'if2-success' : 'if2-error-msg');
    }

    // -------------------------------------------------------------------------
    // Autosave (localStorage)
    // -------------------------------------------------------------------------
    function saveAutosave(form, formId) {
        try {
            var data = {};
            var fd   = new FormData(form);
            fd.forEach(function (val, key) {
                if (key === 'if2_nonce' || key === '_wpnonce' || key === 'if2_form_id' || key === 'if2_hp_field') return;
                if (data[key]) {
                    if (!Array.isArray(data[key])) data[key] = [data[key]];
                    data[key].push(val);
                } else {
                    data[key] = val;
                }
            });
            localStorage.setItem('if2_autosave_' + formId, JSON.stringify(data));
        } catch (e) {}
    }

    function restoreAutosave(form, formId) {
        try {
            var raw = localStorage.getItem('if2_autosave_' + formId);
            if (!raw) return;
            var data = JSON.parse(raw);
            Object.keys(data).forEach(function (key) {
                var val = data[key];
                var els = form.querySelectorAll('[name="' + key + '"],[name="' + key + '[]"]');
                els.forEach(function (el) {
                    if (el.type === 'checkbox') {
                        var vals = Array.isArray(val) ? val : [val];
                        el.checked = vals.indexOf(el.value) !== -1;
                    } else if (el.type === 'radio') {
                        el.checked = el.value === val;
                    } else if (el.tagName === 'SELECT') {
                        el.value = val;
                    } else if (el.tagName === 'TEXTAREA' || el.type === 'text' || el.type === 'email' || el.type === 'tel' || el.type === 'number') {
                        el.value = val;
                    }
                });
            });
        } catch (e) {}
    }

    // -------------------------------------------------------------------------
    // Datepicker jQuery UI
    // -------------------------------------------------------------------------
    function expandBlockedRanges(ranges) {
        var dates = [];
        (ranges || []).forEach(function (range) {
            if (!range.from) return;
            var fp = range.from.split('-');
            var from = new Date(+fp[0], +fp[1] - 1, +fp[2]);
            var tp = (range.to || range.from).split('-');
            var to = new Date(+tp[0], +tp[1] - 1, +tp[2]);
            var d = new Date(from);
            while (d <= to) {
                var dd = ('0' + d.getDate()).slice(-2);
                var mm = ('0' + (d.getMonth() + 1)).slice(-2);
                dates.push(dd + '/' + mm + '/' + d.getFullYear());
                d.setDate(d.getDate() + 1);
            }
        });
        return dates;
    }

    function initDatepickers(wrap) {
        if (typeof jQuery === 'undefined' || !jQuery.fn.datepicker) return;

        wrap.querySelectorAll('.if2-datepicker').forEach(function (input) {
            var ranges = [];
            try { ranges = JSON.parse(input.dataset.blocked || '[]'); } catch (e) {}
            var blockedDates = expandBlockedRanges(ranges);

            var daysAllowed = [true,true,true,true,true,true,true];
            try { daysAllowed = JSON.parse(input.dataset.daysAllowed || 'null') || daysAllowed; } catch (e) {}
            // jQuery datepicker: days 0=Sun,1=Mon,...,6=Sat; our array: 0=Mon,...,6=Sun
            var jqDayMap = [6,0,1,2,3,4,5]; // our index → jQuery day

            var formWrap = input.closest('.if2-form-wrap');

            var opts = {
                dateFormat:        input.dataset.dateFormat || 'dd/mm/yy',
                firstDay:          1,
                showOtherMonths:   true,
                selectOtherMonths: true,
                beforeShow: function(inp, inst) {
                    setTimeout(function() {
                        if (!inst.dpDiv || !inst.dpDiv[0]) return;
                        var dp = inst.dpDiv[0];
                        // Inietta variabili CSS dal form
                        if (formWrap) {
                            var cs     = getComputedStyle(formWrap);
                            var color  = cs.getPropertyValue('--if2-focus-color').trim();
                            // Radius: legge dal data-attribute (affidabile al 100%) con fallback al CSS var
                            var radius = formWrap.dataset.dpRadius || cs.getPropertyValue('--if2-datepicker-radius').trim();
                            if (color)  dp.style.setProperty('--if2-focus-color', color);
                            if (radius) {
                                dp.style.setProperty('--if2-datepicker-radius', radius);
                                dp.style.borderRadius = radius;
                                dp.style.overflow     = 'hidden';
                            }
                        }
                        // Corregge posizione se il datepicker esce dallo schermo
                        var rect = dp.getBoundingClientRect();
                        var vw   = window.innerWidth;
                        if (rect.right > vw) {
                            dp.style.left = Math.max(0, (parseInt(dp.style.left, 10) || 0) - (rect.right - vw) - 10) + 'px';
                        }
                        if (rect.left < 0) {
                            dp.style.left = '10px';
                        }
                    }, 0);
                },
                beforeShowDay: function (date) {
                    // Check days allowed (0=Sun in JS)
                    var jsDay = date.getDay(); // 0=Sun
                    var ourIdx = jsDay === 0 ? 6 : jsDay - 1; // convert to our Mon=0 index
                    if (!daysAllowed[ourIdx]) {
                        return [false, 'if2-blocked-date', 'Non disponibile'];
                    }
                    var fmt = input.dataset.dateFormat || 'dd/mm/yy';
                    var str = jQuery.datepicker.formatDate(fmt, date);
                    // Also check against blocked dates (which use the same format)
                    var str2 = jQuery.datepicker.formatDate('dd/mm/yy', date);
                    var ok = blockedDates.indexOf(str2) === -1;
                    return [ok, ok ? '' : 'if2-blocked-date', ok ? '' : 'Non disponibile'];
                },
                onSelect: function () {
                    input.dispatchEvent(new Event('change', { bubbles: true }));
                },
            };

            if (input.dataset.noPast === '1') {
                opts.minDate = 0;
            }
            if (input.dataset.dateMin) {
                var minP = input.dataset.dateMin.split('-');
                if (minP.length === 3) opts.minDate = new Date(+minP[0], +minP[1] - 1, +minP[2]);
            }
            if (input.dataset.dateMax) {
                var maxP = input.dataset.dateMax.split('-');
                if (maxP.length === 3) opts.maxDate = new Date(+maxP[0], +maxP[1] - 1, +maxP[2]);
            }

            var dpLang = wrap.dataset.lang || ((typeof IF2 !== 'undefined' && IF2.lang) ? IF2.lang : 'it');
            if (dpLang === 'it') {
                opts.dayNamesMin     = ['Do', 'Lu', 'Ma', 'Me', 'Gi', 'Ve', 'Sa'];
                opts.monthNames      = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
                opts.monthNamesShort = ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'];
            } else if (dpLang === 'de') {
                opts.dayNamesMin     = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
                opts.monthNames      = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
                opts.monthNamesShort = ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'];
            } else if (dpLang === 'fr') {
                opts.dayNamesMin     = ['Di', 'Lu', 'Ma', 'Me', 'Je', 'Ve', 'Sa'];
                opts.monthNames      = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
                opts.monthNamesShort = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'];
            } else if (dpLang === 'pl') {
                opts.dayNamesMin     = ['Nd', 'Pn', 'Wt', 'Śr', 'Cz', 'Pt', 'So'];
                opts.monthNames      = ['Styczeń', 'Luty', 'Marzec', 'Kwiecień', 'Maj', 'Czerwiec', 'Lipiec', 'Sierpień', 'Wrzesień', 'Październik', 'Listopad', 'Grudzień'];
                opts.monthNamesShort = ['Sty', 'Lut', 'Mar', 'Kwi', 'Maj', 'Cze', 'Lip', 'Sie', 'Wrz', 'Paź', 'Lis', 'Gru'];
            } else if (dpLang === 'cs') {
                opts.dayNamesMin     = ['Ne', 'Po', 'Út', 'St', 'Čt', 'Pá', 'So'];
                opts.monthNames      = ['Leden', 'Únor', 'Březen', 'Duben', 'Květen', 'Červen', 'Červenec', 'Srpen', 'Září', 'Říjen', 'Listopad', 'Prosinec'];
                opts.monthNamesShort = ['Led', 'Úno', 'Bře', 'Dub', 'Kvě', 'Čvn', 'Čvc', 'Srp', 'Zář', 'Říj', 'Lis', 'Pro'];
            } else if (dpLang === 'hu') {
                opts.dayNamesMin     = ['V', 'H', 'K', 'Sz', 'Cs', 'P', 'Szo'];
                opts.monthNames      = ['Január', 'Február', 'Március', 'Április', 'Május', 'Június', 'Július', 'Augusztus', 'Szeptember', 'Október', 'November', 'December'];
                opts.monthNamesShort = ['Jan', 'Feb', 'Már', 'Ápr', 'Máj', 'Jún', 'Júl', 'Aug', 'Sze', 'Okt', 'Nov', 'Dec'];
            } else if (dpLang === 'es') {
                opts.dayNamesMin     = ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sá'];
                opts.monthNames      = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
                opts.monthNamesShort = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
            } else if (dpLang === 'pt') {
                opts.dayNamesMin     = ['Do', 'Se', 'Te', 'Qu', 'Qui', '6ª', 'Sá'];
                opts.monthNames      = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
                opts.monthNamesShort = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
            } else if (dpLang === 'sl') {
                opts.dayNamesMin     = ['Ne', 'Po', 'To', 'Sr', 'Če', 'Pe', 'So'];
                opts.monthNames      = ['Januar', 'Februar', 'Marec', 'April', 'Maj', 'Junij', 'Julij', 'Avgust', 'September', 'Oktober', 'November', 'December'];
                opts.monthNamesShort = ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Avg', 'Sep', 'Okt', 'Nov', 'Dec'];
            } else if (dpLang === 'hr') {
                opts.dayNamesMin     = ['Ne', 'Po', 'Ut', 'Sr', 'Če', 'Pe', 'Su'];
                opts.monthNames      = ['Siječanj', 'Veljača', 'Ožujak', 'Travanj', 'Svibanj', 'Lipanj', 'Srpanj', 'Kolovoz', 'Rujan', 'Listopad', 'Studeni', 'Prosinac'];
                opts.monthNamesShort = ['Sij', 'Vel', 'Ožu', 'Tra', 'Svi', 'Lip', 'Srp', 'Kol', 'Ruj', 'Lis', 'Stu', 'Pro'];
            }

            jQuery(input).datepicker(opts);

            // Min date da altro campo (es. "field9" o "field9+2")
            if (input.dataset.minField) {
                var minFieldRaw = input.dataset.minField.trim();
                var plusIdx     = minFieldRaw.indexOf('+');
                var sourceId    = plusIdx !== -1 ? minFieldRaw.slice(0, plusIdx).trim() : minFieldRaw;
                var offset      = plusIdx !== -1 ? (parseInt(minFieldRaw.slice(plusIdx + 1), 10) || 0) : 0;
                var sourceInput = wrap.querySelector('input[data-field-id="' + sourceId + '"]');
                if (sourceInput) {
                    (function (inp, src, off) {
                        function updateMin() {
                            if (!src.value) return;
                            try {
                                var parsed = jQuery.datepicker.parseDate(src.dataset.dateFormat || 'dd/mm/yy', src.value);
                                if (!parsed) return;
                                var minD = new Date(parsed);
                                minD.setDate(minD.getDate() + off);
                                jQuery(inp).datepicker('option', 'minDate', minD);
                                if (inp.value) {
                                    var cur = jQuery.datepicker.parseDate(inp.dataset.dateFormat || 'dd/mm/yy', inp.value);
                                    if (cur && cur < minD) {
                                        inp.value = '';
                                        jQuery(inp).datepicker('setDate', null);
                                        inp.dispatchEvent(new Event('change', { bubbles: true }));
                                    }
                                }
                            } catch (e) {}
                        }
                        src.addEventListener('change', updateMin);
                        if (src.value) updateMin();
                    }(input, sourceInput, offset));
                }
            }
        });
    }

    // -------------------------------------------------------------------------
    // Conditional logic
    // -------------------------------------------------------------------------
    function initConditions(form) {
        var conditionalFields = form.querySelectorAll('[data-conditions]');
        if (!conditionalFields.length) return;

        function evaluate() {
            conditionalFields.forEach(function (fieldWrap) {
                var cond;
                try { cond = JSON.parse(fieldWrap.dataset.conditions); } catch (e) { return; }
                var show = evaluateConditions(form, cond);
                fieldWrap.style.display = show ? '' : 'none';
                fieldWrap.querySelectorAll('[required]').forEach(function (el) {
                    el.dataset.if2WasRequired = el.dataset.if2WasRequired || 'true';
                    if (!show)                                     el.removeAttribute('required');
                    else if (el.dataset.if2WasRequired === 'true') el.setAttribute('required', '');
                });
            });
        }

        form.addEventListener('change', evaluate);
        form.addEventListener('input',  evaluate);
        evaluate();
    }

    function evaluateConditions(form, conditions) {
        var rules  = conditions.rules || [];
        var logic  = (conditions.logic || 'AND').toUpperCase();
        if (!rules.length) return true;

        var results = rules.map(function (rule) {
            var el  = form.querySelector('[name="' + rule.field + '"]');
            var val = '';
            if (!el) {
                el = form.querySelector('[name="' + rule.field + '[]"]') ||
                     form.querySelector('[name="' + rule.field + '"]:checked');
            }
            if (!el) { val = ''; }
            else if (el.type === 'checkbox') {
                val = Array.from(form.querySelectorAll('[name="' + rule.field + '[]"]:checked')).map(function (c) { return c.value; }).join(',');
            } else if (el.type === 'radio') {
                var r = form.querySelector('[name="' + rule.field + '"]:checked');
                val = r ? r.value : '';
            } else {
                val = el.value;
            }
            switch (rule.operator) {
                case '=':         return val === rule.value;
                case '!=':        return val !== rule.value;
                case 'contains':  return val.indexOf(rule.value) !== -1;
                case 'not_empty': return val.trim() !== '';
                default:          return true;
            }
        });

        return logic === 'AND' ? results.every(Boolean) : results.some(Boolean);
    }

})();
