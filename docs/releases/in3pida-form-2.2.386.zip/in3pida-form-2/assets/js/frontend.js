/* in3pida Form 2 – Frontend JS */
(function () {
    'use strict';

    var S = (typeof IF2 !== 'undefined' && IF2.strings) ? IF2.strings : {
        required:   'Questo campo è obbligatorio.',
        email_err:  'Inserisci un indirizzo email valido.',
        fix_errors: 'Correggi gli errori evidenziati.',
        conn_error: 'Errore di connessione. Riprova.',
        multi_err:  'Hai già inviato questo modulo.',
    };

    function getStrings(wrap) {
        try {
            var ds = wrap && wrap.dataset.strings;
            if (ds) { var parsed = JSON.parse(ds); if (parsed && parsed.required) return parsed; }
        } catch(e) {}
        return S;
    }

    // Messaggi tooltip date bloccate / minimum stay (per lingua)
    var DP_TIPS = {
        it: { noAvail: 'In queste date non c’è disponibilità', minStay: function(n){ return 'In questo periodo minimum stay di ' + n + ' notti'; } },
        en: { noAvail: 'No availability on these dates',          minStay: function(n){ return 'Minimum stay of ' + n + ' nights in this period'; } },
        de: { noAvail: 'Keine Verfügbarkeit an diesen Daten', minStay: function(n){ return 'Mindestaufenthalt von ' + n + ' Nächten in diesem Zeitraum'; } },
        fr: { noAvail: 'Aucune disponibilité à ces dates', minStay: function(n){ return 'Séjour minimum de ' + n + ' nuits sur cette période'; } },
        pl: { noAvail: 'Brak dostępności w tych terminach', minStay: function(n){ return 'Minimalny pobyt ' + n + ' nocy w tym okresie'; } },
        cs: { noAvail: 'V těchto termínech není dostupnost',  minStay: function(n){ return 'Minimální pobyt ' + n + ' nocí v tomto období'; } },
        hu: { noAvail: 'Ezeken a dátumokon nincs elérhetőség', minStay: function(n){ return 'Minimum ' + n + ' éjszakás tartózkodás ebben az időszakban'; } },
        es: { noAvail: 'No hay disponibilidad en estas fechas',    minStay: function(n){ return 'Estancia mínima de ' + n + ' noches en este período'; } },
        pt: { noAvail: 'Sem disponibilidade nestas datas',         minStay: function(n){ return 'Estadia mínima de ' + n + ' noites neste período'; } },
        sl: { noAvail: 'Na te datume ni razpoložljivosti',     minStay: function(n){ return 'Najmanjše bivanje ' + n + ' noči v tem obdobju'; } },
        hr: { noAvail: 'Nema dostupnosti na ove datume',           minStay: function(n){ return 'Minimalni boravak ' + n + ' noći u ovom razdoblju'; } }
    };

    // Tooltip personalizzato per le celle bloccate del datepicker (init una sola volta)
    function initDatepickerTooltip() {
        if (window._if2DpTipInit) return;
        window._if2DpTipInit = true;
        var tip = document.createElement('div');
        tip.id = 'if2-dp-tip';
        tip.style.cssText = 'position:fixed;z-index:100000;background:#1a1a1a;color:#fff;font-size:.78rem;padding:6px 11px;border-radius:6px;pointer-events:none;display:none;max-width:220px;line-height:1.4;box-shadow:0 2px 10px rgba(0,0,0,.25);text-align:center;';
        document.body.appendChild(tip);

        document.addEventListener('mouseover', function (e) {
            var td = e.target.closest ? e.target.closest('#ui-datepicker-div td.if2-blocked-date') : null;
            if (!td) return;
            if (td.getAttribute('title')) { td.dataset.if2tip = td.getAttribute('title'); td.removeAttribute('title'); }
            var msg = td.dataset.if2tip;
            if (!msg) return;
            tip.textContent = msg;
            tip.style.display = 'block';
            var r  = td.getBoundingClientRect();
            var tr = tip.getBoundingClientRect();
            var top = r.top - tr.height - 8;
            if (top < 6) top = r.bottom + 8;
            tip.style.left = Math.max(6, r.left + r.width / 2 - tr.width / 2) + 'px';
            tip.style.top  = top + 'px';
        });
        document.addEventListener('mouseout', function (e) {
            var td = e.target.closest ? e.target.closest('#ui-datepicker-div td.if2-blocked-date') : null;
            if (!td) return;
            var to = e.relatedTarget;
            if (to && td.contains(to)) return; // ancora dentro la stessa cella
            tip.style.display = 'none';
        });
    }

    // Cattura gli UTM all'atterraggio e li conserva per la sessione (come il vecchio script),
    // così la campagna arriva al CRM anche se poi l'utente compila il form su un'altra pagina.
    (function captureUtm() {
        try {
            var qp = new URLSearchParams(window.location.search);
            if (qp.get('utm_campaign') || qp.get('utm_source')) {
                var utm = {};
                ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'].forEach(function (k) {
                    if (qp.get(k)) utm[k] = qp.get(k);
                });
                sessionStorage.setItem('if2_utm', JSON.stringify(utm));
            }
        } catch (e) {}
    })();

    function init() {
        document.querySelectorAll('.if2-form-wrap').forEach(initForm);
    }

    // window.load: garantisce che jquery-ui-datepicker sia caricato prima di init,
    // anche se SGO combina i file in ordine sbagliato o ScrollSmoother riorganizza il DOM.
    if (document.readyState === 'complete') {
        init();
    } else {
        window.addEventListener('load', init);
    }

    // File upload: mostra il nome del file scelto accanto al pulsante custom tradotto
    document.addEventListener('change', function (e) {
        var inp = e.target;
        if (!inp || !inp.classList || !inp.classList.contains('if2-file-input')) return;
        var wrap = inp.closest('.if2-file-wrap');
        if (!wrap) return;
        var nameEl = wrap.querySelector('.if2-file-name');
        if (!nameEl) return;
        if (inp.files && inp.files.length) {
            nameEl.textContent = inp.files.length === 1 ? inp.files[0].name : inp.files.length + ' file';
        } else {
            nameEl.textContent = inp.getAttribute('data-none') || '';
        }
    });

    function initForm(wrap) {
        if (wrap.dataset.if2Init) return;
        wrap.dataset.if2Init = '1';
        var form     = wrap.querySelector('.if2-form');
        var pages    = Array.from(wrap.querySelectorAll('.if2-page'));
        var response = wrap.querySelector('.if2-response');
        var formId   = wrap.dataset.formId;
        var current  = 0;
        var LS       = getStrings(wrap);

        if (!form) return;

        // disable_multiple: blocca se già inviato
        var disableMultiple = wrap.dataset.disableMultiple === '1';
        if (disableMultiple) {
            var sk = 'if2_submitted_' + formId;
            try {
                if (localStorage.getItem(sk)) {
                    form.style.display = 'none';
                    showResponse(response, LS.multi_err, 'success');
                    return;
                }
            } catch (e) {}
        }

        // Autosave: ripristina valori salvati
        var autosave = wrap.dataset.autosave === '1';
        if (autosave) restoreAutosave(form, formId);

        // Fallback mobile: se viewport non standard non attiva il media query CSS
        function applyMobileClass() {
            var isMobile = window.innerWidth <= 640;
            wrap.classList.toggle('if2-mobile', isMobile);
        }
        applyMobileClass();
        window.addEventListener('resize', applyMobileClass);

        // Queste init NON devono mai impedire l'aggancio del submit: se una va in errore (es. un caso
        // non gestito nei blackout/datepicker), la CTA "Invia" resterebbe morta. Le isoliamo in try/catch.
        try { initDatepickers(wrap); } catch (e) { try { console.error('IF2 initDatepickers', e); } catch (_) {} }
        try { initConditions(form); }  catch (e) { try { console.error('IF2 initConditions', e); }  catch (_) {} }
        try { initSetValue(form); }    catch (e) { try { console.error('IF2 initSetValue', e); }    catch (_) {} }

        // Autosave: salva al cambio di ogni input
        if (autosave) {
            form.addEventListener('change', function () { saveAutosave(form, formId); });
            form.addEventListener('input',  function () { saveAutosave(form, formId); });
        }

        wrap.addEventListener('click', function (e) {
            if (e.target.classList.contains('if2-btn-next')) {
                if (validatePage(pages[current])) {
                    goToPage(pages, current, current + 1, wrap);
                    current++;
                }
            } else if (e.target.classList.contains('if2-btn-prev')) {
                goToPage(pages, current, current - 1, wrap);
                current--;
            }
        });

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            if (!validatePage(pages[current])) { current = goToFirstError(form, pages, current, wrap); return; }

            var btn = form.querySelector('.if2-btn-submit');
            if (btn) { btn.disabled = true; btn.setAttribute('aria-busy', 'true'); btn.classList.add('loading'); }

            submitForm(wrap, form, formId, response, function (success, redirectUrl, redirectDelay, waUrl, waDelay) {
                if (btn) { btn.disabled = false; btn.removeAttribute('aria-busy'); btn.classList.remove('loading'); }

                if (success) {
                    if (disableMultiple) {
                        try { localStorage.setItem('if2_submitted_' + formId, '1'); } catch (e) {}
                    }
                    if (autosave) {
                        try { localStorage.removeItem('if2_autosave_' + formId); } catch (e) {}
                    }
                    var waWait = (waDelay >= 0 ? waDelay : 1500);
                    // WhatsApp: si apre in nuova scheda / app; la thank you page resta aperta dietro e continua a tracciare
                    if (waUrl) {
                        setTimeout(function () { window.open(waUrl, '_blank'); }, waWait);
                    }
                    if (redirectUrl) {
                        var base = redirectDelay > 0 ? redirectDelay : 300;
                        // se c'è anche WhatsApp, aspetta che sia partito prima di cambiare pagina
                        var delay = waUrl ? Math.max(base, waWait + 400) : base;
                        setTimeout(function () { window.location.href = redirectUrl; }, delay);
                    }
                } else {
                    // Invio rifiutato (errori di validazione dal server): porta l'utente al primo campo sbagliato.
                    current = goToFirstError(form, pages, current, wrap);
                }
            });
        });

        form.addEventListener('input', function (e) {
            var el = e.target;
            if (el.classList.contains('if2-input') || el.type === 'radio' || el.type === 'checkbox') {
                clearError(el);
            }
        });
    }

    // -------------------------------------------------------------------------
    // Navigazione multi-step
    // -------------------------------------------------------------------------
    function goToPage(pages, from, to, wrap) {
        pages[from].style.display = 'none';
        pages[to].style.display   = '';
        updateProgress(wrap, to, pages.length);
        wrap.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function updateProgress(wrap, idx, total) {
        var bar = wrap.querySelector('.if2-progress-bar');
        if (!bar) return;
        bar.style.width = Math.round(((idx + 1) / total) * 100) + '%';
    }

    // Porta l'utente al primo campo con errore: se è in un'altra pagina (form multi-pagina) la apre,
    // poi ci scrolla sopra. Ritorna il (nuovo) indice di pagina corrente. Non altera il flusso di invio.
    function goToFirstError(form, pages, current, wrap) {
        var firstErr = form.querySelector('.if2-invalid');
        if (!firstErr) return current;
        if (pages.length > 1) {
            var pg  = firstErr.closest('.if2-page');
            var idx = pg ? pages.indexOf(pg) : -1;
            if (idx !== -1 && idx !== current) { goToPage(pages, current, idx, wrap); current = idx; }
        }
        try { firstErr.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (e) {}
        try { firstErr.focus({ preventScroll: true }); } catch (e) {}
        return current;
    }

    // -------------------------------------------------------------------------
    // Validazione
    // -------------------------------------------------------------------------
    function validatePage(page) {
        var valid = true;

        page.querySelectorAll('[required]').forEach(function (el) {
            if (!isVisible(el.closest('.if2-field'))) return;
            var ok = false;
            if (el.type === 'radio') {
                ok = !!page.querySelector('input[type="radio"][name="' + el.name + '"]:checked');
            } else if (el.type === 'checkbox') {
                ok = !!page.querySelector('input[type="checkbox"][name="' + el.name + '"]:checked');
            } else {
                ok = el.value.trim() !== '';
            }
            if (!ok) { showError(el, LS.required); valid = false; }
            else      { clearError(el); }
        });

        page.querySelectorAll('input[type="email"]').forEach(function (el) {
            if (!isVisible(el.closest('.if2-field'))) return;
            if (el.value && !isValidEmail(el.value)) {
                showError(el, LS.email_err);
                valid = false;
            }
        });

        // Validazione automatica campi telefono — sempre solo numeri (+ spazi, +, -)
        page.querySelectorAll('input[type="tel"], input[type="phone"]').forEach(function (el) {
            if (!isVisible(el.closest('.if2-field'))) return;
            if (!el.value) return;
            if (!/^[\d\s\+\-\.\(\)]+$/.test(el.value)) {
                showError(el, 'Questo campo accetta solo numeri.');
                valid = false;
            } else {
                clearError(el);
            }
        });

        // Validazione tipo campo (validation_type dal builder)
        page.querySelectorAll('[data-validation-type]').forEach(function (el) {
            if (!isVisible(el.closest('.if2-field'))) return;
            var val  = el.value;
            if (!val) return; // campo vuoto: la validazione required è già sopra
            var type = el.getAttribute('data-validation-type');
            var ok   = true;
            var msg  = '';
            if (type === 'numeric') {
                ok  = /^[\d\s\+\-\.]+$/.test(val);
                msg = 'Questo campo accetta solo numeri.';
            } else if (type === 'alpha') {
                ok  = /^[a-zA-ZÀ-ÿ\s]+$/.test(val);
                msg = 'Questo campo accetta solo lettere.';
            } else if (type === 'alphanumeric') {
                ok  = /^[a-zA-ZÀ-ÿ0-9\s]+$/.test(val);
                msg = 'Questo campo accetta solo lettere e numeri.';
            } else if (type === 'url') {
                ok  = /^https?:\/\/.+\..+/.test(val);
                msg = 'Inserisci un URL valido (es: https://esempio.it).';
            } else if (type === 'regex') {
                var pattern = el.getAttribute('data-validation-regex');
                if (pattern) { try { ok = new RegExp(pattern).test(val); msg = 'Formato non valido.'; } catch(e) {} }
            }
            if (!ok) { showError(el, msg); valid = false; }
            else      { clearError(el); }
        });

        // Validazione min/max caratteri
        page.querySelectorAll('[data-min-chars],[data-max-chars]').forEach(function (el) {
            if (!isVisible(el.closest('.if2-field'))) return;
            var val = el.value;
            if (!val) return;
            var min = parseInt(el.getAttribute('data-min-chars') || '0', 10);
            var max = parseInt(el.getAttribute('data-max-chars') || '0', 10);
            if (min > 0 && val.length < min) {
                showError(el, 'Minimo ' + min + ' caratteri.');
                valid = false;
            } else if (max > 0 && val.length > max) {
                showError(el, 'Massimo ' + max + ' caratteri.');
                valid = false;
            } else {
                clearError(el);
            }
        });

        return valid;
    }

    function showError(el, msg) {
        el.classList.add('if2-invalid');
        var err = getErrorDiv(el);
        if (err) err.textContent = msg;
    }

    function clearError(el) {
        el.classList.remove('if2-invalid');
        var err = getErrorDiv(el);
        if (err) err.textContent = '';
    }

    function getErrorDiv(el) {
        var field = el.closest('.if2-field');
        return field ? field.querySelector('.if2-error') : null;
    }

    function isValidEmail(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
    function isVisible(el) { return el ? el.style.display !== 'none' && el.offsetParent !== null : true; }

    // -------------------------------------------------------------------------
    // AJAX submit
    // -------------------------------------------------------------------------
    function submitForm(wrap, form, formId, response, done) {
        var formData = new FormData(form);
        formData.set('action', 'if2_submit');

        var channel = wrap.querySelector('.if2-hidden-channel');
        var hotelId = wrap.querySelector('.if2-hidden-hotel-id');
        if (channel) formData.set('_channel',  channel.value);
        if (hotelId) formData.set('_hotel_id', hotelId.value);
        // _source_url: URL corrente, arricchito con gli UTM catturati all'atterraggio (se ora mancano),
        // così la campagna arriva al CRM anche se l'utente ha cambiato pagina (come il vecchio script).
        var srcUrl = window.location.href;
        try {
            var savedUtm = JSON.parse(sessionStorage.getItem('if2_utm') || '{}');
            if (savedUtm.utm_campaign && srcUrl.indexOf('utm_campaign=') === -1) {
                var utmParts = [];
                ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'].forEach(function (k) {
                    if (savedUtm[k]) utmParts.push(k + '=' + encodeURIComponent(savedUtm[k]));
                });
                if (utmParts.length) srcUrl += (srcUrl.indexOf('?') === -1 ? '?' : '&') + utmParts.join('&');
            }
        } catch (e) {}
        formData.set('_source_url', srcUrl);

        // RETE DI SICUREZZA: se il server ci mette troppo (integrazione lenta/server bloccato), dopo 15s
        // smettiamo di aspettare e mostriamo "inviato" — la richiesta è già salvata. Così lo spinner non
        // resta MAI appeso all'infinito, qualunque cosa faccia il server.
        var controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
        var timedOut   = false;
        var safety = setTimeout(function () {
            timedOut = true;
            if (controller) controller.abort();
        }, 10000);

        var opts = { method: 'POST', body: formData, credentials: 'same-origin' };
        if (controller) opts.signal = controller.signal;

        fetch(IF2.ajaxurl, opts)
        .then(function (r) { clearTimeout(safety); return r.text(); })
        .then(function (txt) {
            // Nonce scaduta (pagina servita dalla cache): la rinnoviamo e riproviamo una volta sola.
            if (txt.trim() === '-1' || txt.trim() === '0') {
                var rd = new FormData();
                rd.set('action', 'if2_refresh_nonce');
                rd.set('form_id', formId);
                return fetch(IF2.ajaxurl, { method: 'POST', body: rd, credentials: 'same-origin' })
                    .then(function (r2) { return r2.json(); })
                    .then(function (r2j) {
                        if (r2j && r2j.success && r2j.data && r2j.data.nonce) {
                            var nf = form.querySelector('[name="if2_nonce"]');
                            if (nf) nf.value = r2j.data.nonce;
                            formData.set('if2_nonce', r2j.data.nonce);
                        }
                        return fetch(IF2.ajaxurl, { method: 'POST', body: formData, credentials: 'same-origin' })
                            .then(function (r3) { return r3.text(); });
                    });
            }
            return txt;
        })
        .then(function (txt) {
            var json;
            try { json = JSON.parse(txt); } catch (e) { throw e; }
            var ok = !!(json && json.success);
            // Il rendering di messaggi/errori NON deve MAI impedire lo sblocco del bottone: lo isoliamo.
            try {
                if (ok) {
                    showResponse(response, json.data.message, 'success');
                    form.reset();
                } else {
                    if (json && json.data && json.data.errors) showFieldErrors(form, json.data.errors);
                    showResponse(response, (json && json.data && json.data.message) || LS.fix_errors, 'error');
                }
            } catch (e) {}
            // done() viene chiamato SEMPRE: la rotella si ferma comunque, qualunque cosa faccia il rendering.
            if (ok) done(true, json.data.redirect || '', json.data.redirect_delay || 0, json.data.whatsapp || '', (json.data.whatsapp_delay != null ? json.data.whatsapp_delay : 1500));
            else    done(false, '', 0, '', 0);
        })
        .catch(function () {
            clearTimeout(safety);
            var ok = timedOut; // timeout di sicurezza: la richiesta è probabilmente già salvata
            try {
                if (ok) {
                    showResponse(response, form.getAttribute('data-success') || 'Richiesta inviata!', 'success');
                    form.reset();
                } else {
                    showResponse(response, LS.conn_error, 'error');
                }
            } catch (e) {}
            // done() SEMPRE: la rotella si ferma comunque vada il rendering.
            if (ok) done(true, '', 0, '', 0);
            else    done(false, '', 0, '', 0);
        });
    }

    function showFieldErrors(form, errors) {
        Object.keys(errors).forEach(function (fid) {
            var el = form.querySelector('[name="' + fid + '"]') ||
                     form.querySelector('[name="' + fid + '[]"]');
            if (el) showError(el, errors[fid]);
        });
    }

    function showResponse(el, msg, type) {
        if (!el) return; // se il contenitore risposta manca, non crashare (lascerebbe lo spinner appeso)
        el.innerHTML     = msg;
        el.style.display = 'block';
        el.className     = 'if2-response ' + (type === 'success' ? 'if2-success' : 'if2-error-msg');
    }

    // -------------------------------------------------------------------------
    // Autosave (localStorage)
    // -------------------------------------------------------------------------
    function saveAutosave(form, formId) {
        try {
            var data = {};
            var fd   = new FormData(form);
            fd.forEach(function (val, key) {
                if (key === 'if2_nonce' || key === '_wpnonce' || key === 'if2_form_id' || key === 'if2_hp_field') return;
                if (data[key]) {
                    if (!Array.isArray(data[key])) data[key] = [data[key]];
                    data[key].push(val);
                } else {
                    data[key] = val;
                }
            });
            localStorage.setItem('if2_autosave_' + formId, JSON.stringify(data));
        } catch (e) {}
    }

    function restoreAutosave(form, formId) {
        try {
            var raw = localStorage.getItem('if2_autosave_' + formId);
            if (!raw) return;
            var data = JSON.parse(raw);
            Object.keys(data).forEach(function (key) {
                var val = data[key];
                var els = form.querySelectorAll('[name="' + key + '"],[name="' + key + '[]"]');
                els.forEach(function (el) {
                    if (el.type === 'checkbox') {
                        var vals = Array.isArray(val) ? val : [val];
                        el.checked = vals.indexOf(el.value) !== -1;
                    } else if (el.type === 'radio') {
                        el.checked = el.value === val;
                    } else if (el.tagName === 'SELECT') {
                        el.value = val;
                    } else if (el.tagName === 'TEXTAREA' || el.type === 'text' || el.type === 'email' || el.type === 'tel' || el.type === 'number') {
                        el.value = val;
                    }
                });
            });
        } catch (e) {}
    }

    // -------------------------------------------------------------------------
    // Datepicker jQuery UI
    // -------------------------------------------------------------------------
    function expandBlockedRanges(ranges) {
        var dates = [];
        (ranges || []).forEach(function (range) {
            if (!range.from) return;
            var fp = range.from.split('-');
            var from = new Date(+fp[0], +fp[1] - 1, +fp[2]);
            var tp = (range.to || range.from).split('-');
            var to = new Date(+tp[0], +tp[1] - 1, +tp[2]);
            var d = new Date(from);
            while (d <= to) {
                var dd = ('0' + d.getDate()).slice(-2);
                var mm = ('0' + (d.getMonth() + 1)).slice(-2);
                dates.push(dd + '/' + mm + '/' + d.getFullYear());
                d.setDate(d.getDate() + 1);
            }
        });
        return dates;
    }

    function initDatepickers(wrap) {
        if (typeof jQuery === 'undefined' || !jQuery.fn.datepicker) return;
        initDatepickerTooltip();

        var dpTipLang = wrap.dataset.lang || ((typeof IF2 !== 'undefined' && IF2.lang) ? IF2.lang : 'it');
        var tips = DP_TIPS[dpTipLang] || DP_TIPS.it;

        var firstDateFieldId = null; // la 1ª data del form = arrivo (per il vincolo automatico sulla partenza)
        wrap.querySelectorAll('.if2-datepicker').forEach(function (input) {
            var ranges = [];
            try { ranges = JSON.parse(input.dataset.blocked || '[]'); } catch (e) {}
            var blockedDates = expandBlockedRanges(ranges);

            var daysAllowed = [true,true,true,true,true,true,true];
            try { daysAllowed = JSON.parse(input.dataset.daysAllowed || 'null') || daysAllowed; } catch (e) {}
            // jQuery datepicker: days 0=Sun,1=Mon,...,6=Sat; our array: 0=Mon,...,6=Sun
            var jqDayMap = [6,0,1,2,3,4,5]; // our index → jQuery day

            var formWrap = input.closest('.if2-form-wrap');

            var opts = {
                dateFormat:        input.dataset.dateFormat || 'dd/mm/yy',
                firstDay:          1,
                showOtherMonths:   true,
                selectOtherMonths: true,
                beforeShow: function(inp, inst) {
                    setTimeout(function() {
                        if (!inst.dpDiv || !inst.dpDiv[0]) return;
                        var dp = inst.dpDiv[0];
                        // Inietta variabili CSS dal form
                        if (formWrap) {
                            var cs     = getComputedStyle(formWrap);
                            var color  = cs.getPropertyValue('--if2-focus-color').trim();
                            // Colori datepicker (configurabili da Stile > Datepicker): il datepicker vive
                            // fuori dal form (in <body>), quindi le variabili vanno ricopiate a mano.
                            var dpHeaderBg = cs.getPropertyValue('--if2-dp-header-bg').trim();
                            var dpToday    = cs.getPropertyValue('--if2-dp-today').trim();
                            var dpSelected = cs.getPropertyValue('--if2-dp-selected').trim();
                            // Radius: legge dal data-attribute (affidabile al 100%) con fallback al CSS var
                            var radius = formWrap.dataset.dpRadius || cs.getPropertyValue('--if2-datepicker-radius').trim();
                            if (color)      dp.style.setProperty('--if2-focus-color', color);
                            if (dpHeaderBg) dp.style.setProperty('--if2-dp-header-bg', dpHeaderBg);
                            if (dpToday)    dp.style.setProperty('--if2-dp-today', dpToday);
                            if (dpSelected) dp.style.setProperty('--if2-dp-selected', dpSelected);
                            if (radius) {
                                dp.style.setProperty('--if2-datepicker-radius', radius);
                                dp.style.borderRadius = radius;
                                dp.style.overflow     = 'hidden';
                            }
                        }
                        // Se il campo ha già una data selezionata, mostra SOLO il cerchietto della
                        // data scelta (nel colore impostato) e nascondi quello di "oggi".
                        if (inp.value && inp.value.trim()) { dp.classList.add('if2-dp-has-value'); }
                        else { dp.classList.remove('if2-dp-has-value'); }
                        // Corregge posizione se il datepicker esce dallo schermo
                        var rect = dp.getBoundingClientRect();
                        var vw   = window.innerWidth;
                        if (rect.right > vw) {
                            dp.style.left = Math.max(0, (parseInt(dp.style.left, 10) || 0) - (rect.right - vw) - 10) + 'px';
                        }
                        if (rect.left < 0) {
                            dp.style.left = '10px';
                        }
                    }, 0);
                },
                beforeShowDay: function (date) {
                    // Minimum stay (Field+N): date nel gap tra arrivo e arrivo+N
                    if (input._minStay && date >= input._minStay.from && date < input._minStay.until) {
                        return [false, 'if2-blocked-date if2-minstay-date', input._minStay.msg];
                    }
                    // Check days allowed (0=Sun in JS)
                    var jsDay = date.getDay(); // 0=Sun
                    var ourIdx = jsDay === 0 ? 6 : jsDay - 1; // convert to our Mon=0 index
                    if (!daysAllowed[ourIdx]) {
                        return [false, 'if2-blocked-date', tips.noAvail];
                    }
                    // Also check against blocked dates (which use the same format)
                    var str2 = jQuery.datepicker.formatDate('dd/mm/yy', date);
                    var ok = blockedDates.indexOf(str2) === -1;
                    return [ok, ok ? '' : 'if2-blocked-date', ok ? '' : tips.noAvail];
                },
                onSelect: function () {
                    input.dispatchEvent(new Event('change', { bubbles: true }));
                },
            };

            if (input.dataset.noPast === '1') {
                opts.minDate = 0;
            }
            if (input.dataset.dateMin) {
                var minP = input.dataset.dateMin.split('-');
                if (minP.length === 3) opts.minDate = new Date(+minP[0], +minP[1] - 1, +minP[2]);
            }
            if (input.dataset.dateMax) {
                var maxP = input.dataset.dateMax.split('-');
                if (maxP.length === 3) opts.maxDate = new Date(+maxP[0], +maxP[1] - 1, +maxP[2]);
            }

            var dpLang = wrap.dataset.lang || ((typeof IF2 !== 'undefined' && IF2.lang) ? IF2.lang : 'it');
            if (dpLang === 'it') {
                opts.dayNamesMin     = ['Do', 'Lu', 'Ma', 'Me', 'Gi', 'Ve', 'Sa'];
                opts.monthNames      = ['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'];
                opts.monthNamesShort = ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'];
            } else if (dpLang === 'de') {
                opts.dayNamesMin     = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];
                opts.monthNames      = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
                opts.monthNamesShort = ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'];
            } else if (dpLang === 'fr') {
                opts.dayNamesMin     = ['Di', 'Lu', 'Ma', 'Me', 'Je', 'Ve', 'Sa'];
                opts.monthNames      = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];
                opts.monthNamesShort = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun', 'Jul', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'];
            } else if (dpLang === 'pl') {
                opts.dayNamesMin     = ['Nd', 'Pn', 'Wt', 'Śr', 'Cz', 'Pt', 'So'];
                opts.monthNames      = ['Styczeń', 'Luty', 'Marzec', 'Kwiecień', 'Maj', 'Czerwiec', 'Lipiec', 'Sierpień', 'Wrzesień', 'Październik', 'Listopad', 'Grudzień'];
                opts.monthNamesShort = ['Sty', 'Lut', 'Mar', 'Kwi', 'Maj', 'Cze', 'Lip', 'Sie', 'Wrz', 'Paź', 'Lis', 'Gru'];
            } else if (dpLang === 'cs') {
                opts.dayNamesMin     = ['Ne', 'Po', 'Út', 'St', 'Čt', 'Pá', 'So'];
                opts.monthNames      = ['Leden', 'Únor', 'Březen', 'Duben', 'Květen', 'Červen', 'Červenec', 'Srpen', 'Září', 'Říjen', 'Listopad', 'Prosinec'];
                opts.monthNamesShort = ['Led', 'Úno', 'Bře', 'Dub', 'Kvě', 'Čvn', 'Čvc', 'Srp', 'Zář', 'Říj', 'Lis', 'Pro'];
            } else if (dpLang === 'hu') {
                opts.dayNamesMin     = ['V', 'H', 'K', 'Sz', 'Cs', 'P', 'Szo'];
                opts.monthNames      = ['Január', 'Február', 'Március', 'Április', 'Május', 'Június', 'Július', 'Augusztus', 'Szeptember', 'Október', 'November', 'December'];
                opts.monthNamesShort = ['Jan', 'Feb', 'Már', 'Ápr', 'Máj', 'Jún', 'Júl', 'Aug', 'Sze', 'Okt', 'Nov', 'Dec'];
            } else if (dpLang === 'es') {
                opts.dayNamesMin     = ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sá'];
                opts.monthNames      = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
                opts.monthNamesShort = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
            } else if (dpLang === 'pt') {
                opts.dayNamesMin     = ['Do', 'Se', 'Te', 'Qu', 'Qui', '6ª', 'Sá'];
                opts.monthNames      = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
                opts.monthNamesShort = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
            } else if (dpLang === 'sl') {
                opts.dayNamesMin     = ['Ne', 'Po', 'To', 'Sr', 'Če', 'Pe', 'So'];
                opts.monthNames      = ['Januar', 'Februar', 'Marec', 'April', 'Maj', 'Junij', 'Julij', 'Avgust', 'September', 'Oktober', 'November', 'December'];
                opts.monthNamesShort = ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Avg', 'Sep', 'Okt', 'Nov', 'Dec'];
            } else if (dpLang === 'hr') {
                opts.dayNamesMin     = ['Ne', 'Po', 'Ut', 'Sr', 'Če', 'Pe', 'Su'];
                opts.monthNames      = ['Siječanj', 'Veljača', 'Ožujak', 'Travanj', 'Svibanj', 'Lipanj', 'Srpanj', 'Kolovoz', 'Rujan', 'Listopad', 'Studeni', 'Prosinac'];
                opts.monthNamesShort = ['Sij', 'Vel', 'Ožu', 'Tra', 'Svi', 'Lip', 'Srp', 'Kol', 'Ruj', 'Lis', 'Stu', 'Pro'];
            } else if (dpLang === 'en') {
                opts.dayNamesMin     = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
                opts.monthNames      = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
                opts.monthNamesShort = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            }

            jQuery(input).datepicker(opts);
            // Solo calendario: niente digitazione libera (evita date a mano non valide tipo "17").
            // Lo facciamo SOLO dopo aver inizializzato il datepicker: se il datepicker non parte, il campo
            // resta scrivibile (nessun blocco totale dell'inserimento data).
            input.readOnly = true;
            input.style.cursor = 'pointer';
            // Click su .if2-field: apre il datepicker sull'input corretto.
            // Necessario perché: (a) input readOnly non sempre scatena focus in tutti i browser/temi;
            // (b) su form duplicati, il click viene sempre risolto sull'input del form giusto (inp è chiuso).
            // Separato dal focus per evitare doppia apertura: se il focus ha già aperto il calendario
            // (_datepickerShowing && _lastInput===inp) non facciamo nulla.
            (function (inp) {
                var fieldEl = inp.closest('.if2-field') || inp;
                fieldEl.addEventListener('click', function () {
                    try {
                        if (jQuery.data(inp, 'datepicker') &&
                            (!jQuery.datepicker._datepickerShowing || jQuery.datepicker._lastInput !== inp)) {
                            jQuery(inp).datepicker('show');
                        }
                    } catch (e) {}
                });
            }(input));

            // VINCOLO AUTOMATICO (default per TUTTI i form): la partenza (2ª data) non può essere prima
            // dell'arrivo (1ª data). Se il campo non ha già un minimo configurato, lo impostiamo: arrivo +1 notte.
            if (!input.dataset.minField && firstDateFieldId && input.dataset.fieldId !== firstDateFieldId) {
                input.dataset.minField = firstDateFieldId + '+1';
            }
            if (!firstDateFieldId && input.dataset.fieldId) firstDateFieldId = input.dataset.fieldId;

            // Min date da altro campo (es. "field9" o "field9+2")
            if (input.dataset.minField) {
                var minFieldRaw = input.dataset.minField.trim();
                var plusIdx     = minFieldRaw.indexOf('+');
                var sourceId    = plusIdx !== -1 ? minFieldRaw.slice(0, plusIdx).trim() : minFieldRaw;
                var offset      = plusIdx !== -1 ? (parseInt(minFieldRaw.slice(plusIdx + 1), 10) || 0) : 0;
                var sourceInput = wrap.querySelector('input[data-field-id="' + sourceId + '"]');
                if (sourceInput) {
                    (function (inp, src, off) {
                        function updateMin() {
                            if (!src.value) return;
                            try {
                                var parsed = jQuery.datepicker.parseDate(src.dataset.dateFormat || 'dd/mm/yy', src.value);
                                if (!parsed) return;
                                // Offset effettivo: default da Field+N, sovrascritto da una regola minimum stay
                                // impostata sulla data di arrivo (campo sorgente)
                                var effOff = off;
                                var msRules = [];
                                try { msRules = JSON.parse(src.dataset.minStay || '[]'); } catch (e) {}
                                try { msRules = msRules.concat(JSON.parse(inp.dataset.minStay || '[]')); } catch (e) {}
                                if (msRules.length) {
                                    var ymd = parsed.getFullYear() + '-' +
                                              ('0' + (parsed.getMonth() + 1)).slice(-2) + '-' +
                                              ('0' + parsed.getDate()).slice(-2);
                                    for (var ri = 0; ri < msRules.length; ri++) {
                                        var n = parseInt(msRules[ri].nights, 10);
                                        if (msRules[ri].date === ymd && n > 0) { effOff = n; break; }
                                    }
                                }
                                var minD = new Date(parsed);
                                minD.setDate(minD.getDate() + effOff);
                                jQuery(inp).datepicker('option', 'minDate', minD);
                                // Memorizza il gap minimum-stay per il tooltip (solo se offset > 0)
                                if (effOff > 0) {
                                    inp._minStay = { from: parsed, until: minD, msg: tips.minStay(effOff) };
                                } else {
                                    inp._minStay = null;
                                }
                                if (inp.value) {
                                    var cur = jQuery.datepicker.parseDate(inp.dataset.dateFormat || 'dd/mm/yy', inp.value);
                                    if (cur && cur < minD) {
                                        inp.value = '';
                                        jQuery(inp).datepicker('setDate', null);
                                        inp.dispatchEvent(new Event('change', { bubbles: true }));
                                    }
                                }
                            } catch (e) {}
                        }
                        src.addEventListener('change', updateMin);
                        if (src.value) updateMin();
                    }(input, sourceInput, offset));
                }
            }
        });

        initOptionBlackouts(wrap);
    }

    // -------------------------------------------------------------------------
    // Trattamenti/opzioni non disponibili in certi periodi (additivo)
    // Disabilita le opzioni select/radio che hanno data-blackouts quando il
    // soggiorno scelto (arrivo→partenza) si sovrappone al periodo. Senza
    // data-blackouts non fa NULLA (comportamento invariato).
    // -------------------------------------------------------------------------
    function initOptionBlackouts(wrap) {
        if (typeof jQuery === 'undefined' || !jQuery.fn.datepicker) return;
        if (!wrap.querySelector('[data-blackouts]')) return; // nessuna opzione con periodi → niente da fare
        var dates = Array.prototype.slice.call(wrap.querySelectorAll('.if2-datepicker'));
        if (!dates.length) return;
        var arr = dates[0];            // arrivo
        var dep = dates[1] || null;    // partenza

        function parse(inp) {
            if (!inp || !inp.value) return null;
            try { return jQuery.datepicker.parseDate(inp.dataset.dateFormat || 'dd/mm/yy', inp.value); } catch (e) { return null; }
        }
        function nightHits(d, b) {
            if (!b || !b.from || !b.to) return false;
            var fp = String(b.from).split('-'), tp = String(b.to).split('-');
            if (fp.length < 3 || tp.length < 3) return false;
            if (b.yearly === false) {
                var ds = d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
                var fs = (+fp[0]) * 10000 + (+fp[1]) * 100 + (+fp[2]);
                var ts = (+tp[0]) * 10000 + (+tp[1]) * 100 + (+tp[2]);
                return ds >= fs && ds <= ts;
            }
            var md = (d.getMonth() + 1) * 100 + d.getDate();
            var fmd = (+fp[1]) * 100 + (+fp[2]);
            var tmd = (+tp[1]) * 100 + (+tp[2]);
            return (fmd <= tmd) ? (md >= fmd && md <= tmd) : (md >= fmd || md <= tmd);
        }
        function stayHits(ci, co, bos) {
            if (!ci) return false;
            var end = co ? new Date(co) : new Date(ci.getTime() + 86400000); // se manca la partenza: solo la notte di arrivo
            var guard = 0;
            for (var d = new Date(ci); d < end && guard < 400; d.setDate(d.getDate() + 1), guard++) {
                for (var i = 0; i < bos.length; i++) { if (nightHits(d, bos[i])) return true; }
            }
            return false;
        }
        function apply() {
            var ci = parse(arr), co = parse(dep);
            // SELECT
            wrap.querySelectorAll('select').forEach(function (sel) {
                var changed = false;
                Array.prototype.forEach.call(sel.options, function (o) {
                    var raw = o.getAttribute('data-blackouts'); if (!raw) return;
                    var bos; try { bos = JSON.parse(raw); } catch (e) { return; }
                    if (!bos || !bos.length) return;
                    if (o._boText == null) o._boText = o.textContent;
                    var hit = ci && stayHits(ci, co, bos);
                    o.disabled = !!hit;
                    o.textContent = hit ? (o._boText + ' — non disponibile nel periodo scelto') : o._boText;
                    if (hit && sel.value === o.value) { sel.value = ''; changed = true; }
                });
                if (changed) sel.dispatchEvent(new Event('change', { bubbles: true }));
            });
            // RADIO
            wrap.querySelectorAll('input[type="radio"][data-blackouts]').forEach(function (rb) {
                var bos; try { bos = JSON.parse(rb.getAttribute('data-blackouts')); } catch (e) { return; }
                if (!bos || !bos.length) return;
                var hit = ci && stayHits(ci, co, bos);
                rb.disabled = !!hit;
                var lbl = rb.closest('label');
                if (lbl) {
                    lbl.style.opacity = hit ? '0.5' : '';
                    var note = lbl.querySelector('.if2-bo-note');
                    if (hit && !note) { note = document.createElement('span'); note.className = 'if2-bo-note'; note.style.cssText = 'font-size:11px;color:#b00;margin-left:4px'; note.textContent = '— non disponibile nel periodo scelto'; lbl.appendChild(note); }
                    else if (!hit && note) { note.remove(); }
                }
                if (hit && rb.checked) { rb.checked = false; rb.dispatchEvent(new Event('change', { bubbles: true })); }
            });
        }
        arr.addEventListener('change', apply);
        if (dep) dep.addEventListener('change', apply);
        apply();
    }

    // -------------------------------------------------------------------------
    // Conditional logic
    // -------------------------------------------------------------------------
    function initConditions(form) {
        var conditionalFields = form.querySelectorAll('[data-conditions]');
        if (!conditionalFields.length) return;

        function evaluate() {
            var hiddenIds = [];
            conditionalFields.forEach(function (fieldWrap) {
                var cond;
                try { cond = JSON.parse(fieldWrap.dataset.conditions); } catch (e) { return; }
                var show = evaluateConditions(form, cond);
                fieldWrap.style.display = show ? '' : 'none';
                fieldWrap.querySelectorAll('[required]').forEach(function (el) {
                    el.dataset.if2WasRequired = el.dataset.if2WasRequired || 'true';
                    if (!show)                                     el.removeAttribute('required');
                    else if (el.dataset.if2WasRequired === 'true') el.setAttribute('required', '');
                });
                // Campo nascosto → raccogli gli ID dei suoi input, così il server NON li considera obbligatori.
                if (!show) {
                    fieldWrap.querySelectorAll('[name]').forEach(function (el) {
                        var n = (el.getAttribute('name') || '').replace(/\[\]$/, '');
                        if (n && hiddenIds.indexOf(n) === -1) hiddenIds.push(n);
                    });
                }
            });
            // Passa al server l'elenco esatto dei campi nascosti (vale per QUALSIASI campo condizionale).
            var hf = form.querySelector('input[name="if2_hidden_fields"]');
            if (!hf) {
                hf = document.createElement('input');
                hf.type = 'hidden';
                hf.name = 'if2_hidden_fields';
                form.appendChild(hf);
            }
            hf.value = hiddenIds.join(',');
        }

        form.addEventListener('change', evaluate);
        form.addEventListener('input',  evaluate);
        evaluate();
    }

    // Azione logica "Imposta valore": quando le condizioni sono vere, scrive un valore nei campi target.
    function initSetValue(form) {
        var raw = form.dataset.logic;
        if (!raw) return;
        var rules;
        try { rules = JSON.parse(raw); } catch (e) { return; }
        if (!rules || !rules.length) return;

        function apply() {
            rules.forEach(function (r) {
                if (!evaluateConditions(form, r.conditions)) return;
                (r.targets || []).forEach(function (tid) {
                    var el = form.querySelector('[name="' + tid + '"]') || form.querySelector('[data-field-id="' + tid + '"]');
                    if (!el || el.type === 'checkbox' || el.type === 'radio') return;
                    if (el.value !== r.value) {
                        el.value = r.value;
                        el.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                });
            });
        }
        form.addEventListener('change', apply);
        form.addEventListener('input',  apply);
        apply();
    }

    function evaluateConditions(form, conditions) {
        var rules  = conditions.rules || [];
        var logic  = (conditions.logic || 'AND').toUpperCase();
        if (!rules.length) return true;

        var results = rules.map(function (rule) {
            var el  = form.querySelector('[name="' + rule.field + '"]');
            var val = '';
            if (!el) {
                el = form.querySelector('[name="' + rule.field + '[]"]') ||
                     form.querySelector('[name="' + rule.field + '"]:checked');
            }
            if (!el) { val = ''; }
            else if (el.type === 'checkbox') {
                val = Array.from(form.querySelectorAll('[name="' + rule.field + '[]"]:checked')).map(function (c) { return c.value; }).join(',');
            } else if (el.type === 'radio') {
                var r = form.querySelector('[name="' + rule.field + '"]:checked');
                val = r ? r.value : '';
            } else {
                val = el.value;
            }
            switch (rule.operator) {
                case '=':         return val === rule.value;
                case '!=':        return val !== rule.value;
                case 'contains':  return val.indexOf(rule.value) !== -1;
                case 'not_empty': return val.trim() !== '';
                default:          return true;
            }
        });

        return logic === 'AND' ? results.every(Boolean) : results.some(Boolean);
    }

})();
