<?php
defined('ABSPATH') || exit;

class IF2_Renderer {

    private static bool $enqueued          = false;
    private static bool $datepicker_needed = false;

    // -------------------------------------------------------------------------
    // Traduzioni frontend
    // -------------------------------------------------------------------------
    private static function t(string $key): string {
        static $strings = null;
        if ($strings === null) {
            $lang = get_option('if2_lang', 'it');
            $all  = [
                'it' => [
                    'prev'       => '← Indietro',
                    'next'       => 'Avanti →',
                    'submit'     => 'Invia',
                    'select'     => '— Seleziona —',
                    'date_ph'    => 'GG/MM/AAAA',
                    'required'   => 'Questo campo è obbligatorio.',
                    'email_err'  => 'Inserisci un indirizzo email valido.',
                    'fix_errors' => 'Correggi gli errori evidenziati.',
                    'conn_error' => 'Errore di connessione. Riprova.',
                    'multi_err'  => 'Hai già inviato questo modulo.',
                    'loading'    => 'Invio in corso…',
                    'unavail'    => 'Il modulo non è al momento disponibile.',
                    'max_reach'  => 'Il modulo ha raggiunto il numero massimo di risposte.',
                ],
                'en' => [
                    'prev'       => '← Back',
                    'next'       => 'Next →',
                    'submit'     => 'Send',
                    'select'     => '— Select —',
                    'date_ph'    => 'DD/MM/YYYY',
                    'required'   => 'This field is required.',
                    'email_err'  => 'Please enter a valid email address.',
                    'fix_errors' => 'Please fix the highlighted errors.',
                    'conn_error' => 'Connection error. Please try again.',
                    'multi_err'  => 'You have already submitted this form.',
                    'loading'    => 'Sending…',
                    'unavail'    => 'This form is currently unavailable.',
                    'max_reach'  => 'This form has reached the maximum number of submissions.',
                ],
            ];
            $strings = $all[$lang] ?? $all['it'];
        }
        return $strings[$key] ?? $key;
    }

    public static function register_shortcode(): void {
        add_shortcode('if2', [self::class, 'render']);
        add_action('template_redirect', [self::class, 'maybe_preview']);
    }

    /**
     * Gestisce URL anteprima: /?if2_preview=ID
     */
    public static function maybe_preview(): void {
        if (empty($_GET['if2_preview'])) return;
        $form_id = (int) $_GET['if2_preview'];
        if (!$form_id || !current_user_can('manage_options')) return;

        $form = IF2_Form::get($form_id);
        if (!$form) wp_die('Form non trovato.', 'Preview', ['response' => 404]);

        $has_date = !empty(array_filter($form['fields'], fn($f) => in_array($f['type'] ?? '', ['date','datepicker'], true)));

        // Imposta flag per evitare doppio enqueue nel do_shortcode
        self::$enqueued          = true;
        self::$datepicker_needed = $has_date;

        $if2_obj = wp_json_encode([
            'ajaxurl' => admin_url('admin-ajax.php'),
            'lang'    => get_option('if2_lang', 'it'),
            'strings' => [
                'required'   => self::t('required'),
                'email_err'  => self::t('email_err'),
                'fix_errors' => self::t('fix_errors'),
                'conn_error' => self::t('conn_error'),
                'multi_err'  => self::t('multi_err'),
            ],
        ]);
        ?>
        <!DOCTYPE html><html lang="it">
        <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Preview: <?php echo esc_html($form['name']); ?></title>
        <link rel="stylesheet" href="<?php echo esc_url(IF2_URL . 'assets/css/frontend.css?ver=' . IF2_VERSION); ?>">
        <?php if ($has_date): ?>
        <link rel="stylesheet" href="<?php echo esc_url(IF2_URL . 'assets/css/datepicker.css?ver=' . IF2_VERSION); ?>">
        <script src="<?php echo esc_url(includes_url('js/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo esc_url(includes_url('js/jquery/ui/core.min.js')); ?>"></script>
        <script src="<?php echo esc_url(includes_url('js/jquery/ui/widget.min.js')); ?>"></script>
        <script src="<?php echo esc_url(includes_url('js/jquery/ui/datepicker.min.js')); ?>"></script>
        <?php endif; ?>
        </head>
        <body style="background:#f7f0f3;padding:20px;margin:0">
            <div style="max-width:960px;margin:0 auto 16px;font-family:'Montserrat',sans-serif;font-size:12px;color:#aaa;display:flex;gap:12px;align-items:center">
                <strong style="color:#d82d6b">PREVIEW</strong>
                <span><?php echo esc_html($form['name']); ?></span>
                <a href="<?php echo esc_url(admin_url('admin.php?page=if2-builder&form_id='.$form_id)); ?>" style="color:#009bb9;text-decoration:none;margin-left:auto">← Torna al builder</a>
            </div>
            <div>
                <?php echo do_shortcode('[if2 id="'.$form_id.'"]'); ?>
            </div>
            <script>var IF2 = <?php echo $if2_obj; ?>;</script>
            <script src="<?php echo esc_url(IF2_URL . 'assets/js/frontend.js?ver=' . IF2_VERSION); ?>"></script>
        </body></html>
        <?php
        exit;
    }

    /**
     * Shortcode: [if2 id="1"]
     */
    public static function render(array $atts): string {
        $atts    = shortcode_atts(['id' => 0, 'class' => ''], $atts, 'if2');
        $id      = (int) $atts['id'];
        if (!$id) return '';

        $form = IF2_Form::get($id);
        if (!$form) return '';

        $config = $form['config'];

        if (!empty($config['disable_form'])) {
            return '<p class="if2-form-disabled">' . esc_html(self::t('unavail')) . '</p>';
        }

        $max = (int) ($config['max_submissions'] ?? 0);
        if ($max > 0 && IF2_Submission::count($id) >= $max) {
            return '<p class="if2-form-disabled">' . esc_html(self::t('max_reach')) . '</p>';
        }

        $fields   = $form['fields'];
        $has_date = !empty(array_filter($fields, fn($f) => in_array($f['type'] ?? '', ['date','datepicker'], true)));
        self::enqueue_assets($has_date);
        self::track_view($id);
        $uniq    = 'if2-' . $id . '-' . wp_rand(1000, 9999);
        $extra   = sanitize_html_class($atts['class']);

        // Pre-scan fields: submit col_width → CSS variable
        $_submit_pre = null;
        foreach ($fields as $_f) {
            if (($_f['type'] ?? '') === 'submit') { $_submit_pre = $_f; break; }
        }
        $_css_config = $config;
        $_css_config['submit_col_width'] = $_submit_pre ? ($_submit_pre['col_width'] ?? '100%') : '100%';

        $css_vars = self::build_css_vars($_css_config, $uniq);

        $disable_multiple = !empty($config['disable_multiple']) ? '1' : '0';
        $enable_autosave  = !empty($config['enable_autosave'])  ? '1' : '0';

        ob_start();
        ?>
        <style><?php echo $css_vars; ?></style>
        <div class="if2-form-wrap <?php echo esc_attr($extra); ?>" id="<?php echo esc_attr($uniq); ?>"
             data-form-id="<?php echo esc_attr($id); ?>"
             data-disable-multiple="<?php echo esc_attr($disable_multiple); ?>"
             data-autosave="<?php echo esc_attr($enable_autosave); ?>"
             data-dp-radius="<?php echo esc_attr($config['datepicker_radius'] ?? '14px'); ?>"
             data-lang="<?php echo esc_attr($config['form_lang'] ?: get_option('if2_lang', 'it')); ?>"
             data-strings="<?php echo esc_attr(wp_json_encode(IF2_I18n::strings($config['form_lang'] ?: get_option('if2_lang', 'it')))); ?>">

            <?php if (!empty($config['logo_url'])): ?>
            <div class="if2-form-logo" style="text-align:<?php echo esc_attr($config['logo_position'] ?? 'center'); ?>">
                <img src="<?php echo esc_url($config['logo_url']); ?>"
                     style="max-width:<?php echo esc_attr($config['logo_width'] ?: '120px'); ?>;height:auto" alt="">
            </div>
            <?php endif; ?>

            <?php if (!empty($config['channel'])): ?>
            <input type="hidden" class="if2-hidden-channel" value="<?php echo esc_attr($config['channel']); ?>">
            <?php endif; ?>

            <?php if (!empty($config['hotel_id'])): ?>
            <input type="hidden" class="if2-hidden-hotel-id" value="<?php echo esc_attr($config['hotel_id']); ?>">
            <?php endif; ?>

            <?php
            // Azioni "Imposta valore" della logica → passate al frontend (data-logic)
            $if2_opmap = ['equals'=>'=','not_equals'=>'!=','contains'=>'contains','not_empty'=>'not_empty','is_empty'=>'is_empty','not_contains'=>'not_contains'];
            $logic_frontend = [];
            foreach (($config['logic_rules'] ?? []) as $lr) {
                if (($lr['action_type'] ?? '') !== 'set_value') continue;
                $targets = $lr['action_fields'] ?? (!empty($lr['action_field']) ? [$lr['action_field']] : []);
                $lf_rules = [];
                foreach ((array) ($lr['conditions'] ?? []) as $c) {
                    if (empty($c['field'])) continue;
                    $lf_rules[] = ['field'=>(string)$c['field'], 'operator'=>$if2_opmap[$c['op'] ?? 'equals'] ?? '=', 'value'=>(string)($c['value'] ?? '')];
                }
                if (empty($lf_rules) || empty($targets)) continue;
                $logic_frontend[] = ['targets'=>array_values(array_filter((array)$targets)), 'value'=>(string)($lr['action_value'] ?? ''), 'conditions'=>['rules'=>$lf_rules, 'logic'=>'AND']];
            }
            ?>
            <form class="if2-form" novalidate data-success="<?php echo esc_attr($config['success_message'] ?? 'Grazie!'); ?>"<?php echo !empty($logic_frontend) ? ' data-logic="' . esc_attr(wp_json_encode($logic_frontend)) . '"' : ''; ?>>
                <?php wp_nonce_field('if2_submit_' . $id, 'if2_nonce'); ?>
                <input type="hidden" name="if2_form_id" value="<?php echo esc_attr($id); ?>">

                <?php if (get_option('if2_honeypot_enabled', 1)): ?>
                <div style="display:none!important;visibility:hidden;position:absolute;left:-9999px" aria-hidden="true">
                    <input type="text" name="if2_hp_field" tabindex="-1" autocomplete="off" value="">
                </div>
                <?php endif; ?>

                <?php
                $pages     = self::split_pages($fields);
                $has_pages = count($pages) > 1;
                ?>

                <?php if ($has_pages): ?>
                <div class="if2-progress">
                    <div class="if2-progress-bar" style="width:<?php echo esc_attr(round(100 / count($pages))); ?>%"></div>
                </div>
                <?php endif; ?>

                <?php foreach ($pages as $page_idx => $page_fields):
                    $submit_field = null;
                    foreach ($page_fields as $_pf) {
                        if (($_pf['type'] ?? '') === 'submit') { $submit_field = $_pf; break; }
                    }
                    $submit_align = $submit_field['submit_align'] ?? 'right';
                    $submit_wide  = !empty($submit_field['submit_wide']);
                    $_flang       = $config['form_lang'] ?: get_option('if2_lang', 'it');
                    $submit_label = IF2_I18n::t(!empty($submit_field['label']) ? $submit_field['label'] : ($config['submit_text'] ?? self::t('submit')), $_flang);
                    $nav_justify  = ['left' => 'flex-start', 'center' => 'center', 'right' => 'flex-end'][$submit_align] ?? 'flex-end';
                    $btn_width        = $submit_wide ? 'width:100%;justify-content:center;' : '';
                    $submit_col_width = $submit_field ? ($submit_field['col_width'] ?? '100%') : '100%';
                    $submit_col_w_css = self::col_width_css($submit_col_width);

                    // Pagina singola con pulsante Invia presente: lo rendo nella sua posizione (di fianco
                    // ai campi in colonna). Multi-pagina: resta in fondo come navigazione.
                    $submit_inline = !$has_pages && $submit_field !== null;

                    // newsletter_layout: bottone auto-larghezza affiancato all'email, senza configurare col_width.
                    $nl_layout = !empty($config['newsletter_layout']) && $submit_inline;

                    // Pulsante affiancato a un campo (colonna < 100%): allineo la riga IN BASSO. La casella
                    // sta sempre in fondo al campo (con o senza etichetta sopra), quindi il bottone, allineato
                    // in basso anch'esso, combacia sempre con la casella. Niente più slittamenti.
                    $submit_side = $nl_layout || ($submit_inline && $submit_col_w_css !== '100%');
                    $nav_mt      = $submit_side ? 'margin-top:0;' : '';
                    // Padding-top solo se almeno un campo ha una label visibile (altrimenti
                    // il bottone verrebbe spinto in basso rispetto all'input senza label).
                    $has_labels  = false;
                    if ($submit_side) {
                        foreach ($page_fields as $_pf) {
                            if (in_array($_pf['type'] ?? '', ['submit','heading','html','page_break'], true)) continue;
                            if (!empty($_pf['label'])) { $has_labels = true; break; }
                        }
                    }
                    $submit_pt   = ($submit_side && $has_labels) ? 'padding-top:calc(0.85em * 1.4 + 6px);' : '';
                    // Con newsletter_layout il bottone ha larghezza automatica (si stringe al testo).
                    $submit_w_style = $nl_layout
                        ? 'flex:0 0 auto;width:auto;max-width:none;box-sizing:border-box;align-self:center;'
                        : 'width:' . esc_attr($submit_col_w_css) . ';flex:0 0 ' . esc_attr($submit_col_w_css) . ';max-width:' . esc_attr($submit_col_w_css) . ';box-sizing:border-box;';
                    // Con newsletter_layout: solo il campo email/testo nella stessa riga del submit
                    // prende flex-grow. Gli altri (checkbox, html, ecc.) restano larghezza 100%.
                    $nl_inline_id = '';
                    if ($nl_layout) {
                        foreach (array_reverse($page_fields) as $_pf) {
                            $t = $_pf['type'] ?? '';
                            if (in_array($t, ['submit','heading','html','page_break','checkbox','radio','select'], true)) continue;
                            $nl_inline_id = $_pf['id'] ?? '';
                            break;
                        }
                    }
                ?>
                <div class="if2-page" data-page="<?php echo $page_idx; ?>" style="<?php echo $page_idx > 0 ? 'display:none' : ''; ?>">

                    <?php ob_start(); ?>
                    <div class="if2-field if2-field-type-submit" style="<?php echo $submit_w_style . $submit_pt; ?>">
                    <div class="if2-nav" style="width:100%;justify-content:<?php echo esc_attr($nav_justify); ?>;<?php echo $nav_mt; ?>">
                        <?php if ($page_idx > 0): ?>
                        <button type="button" class="if2-btn if2-btn-prev"><?php echo esc_html(self::t('prev')); ?></button>
                        <?php endif; ?>

                        <?php if ($page_idx < count($pages) - 1): ?>
                        <button type="button" class="if2-btn if2-btn-next"><?php echo esc_html(self::t('next')); ?></button>
                        <?php else: ?>
                        <button type="submit" class="if2-btn if2-btn-submit" style="<?php echo esc_attr($btn_width); ?>">
                            <?php echo esc_html($submit_label); ?>
                        </button>
                        <?php endif; ?>
                    </div>
                    </div>
                    <?php $submit_html = ob_get_clean(); ?>

                    <?php foreach ($page_fields as $field): ?>
                        <?php if ($submit_inline && ($field['type'] ?? '') === 'submit') { echo $submit_html; } else { echo self::render_field($field, $config, $submit_side, $nl_inline_id, $uniq); } ?>
                    <?php endforeach; ?>

                    <?php if (!$submit_inline) echo $submit_html; ?>

                </div>
                <?php endforeach; ?>

                <div class="if2-response" style="display:none"></div>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }

    /** Larghezza di un campo in colonna: lascia il gutter (14px) SOLO tra le colonne, così l'ultima arriva al bordo. */
    private static function col_width_css(string $col_width): string {
        $col_width = trim($col_width);
        if ($col_width === '' || $col_width === '100%') return '100%';
        $pct = (float) rtrim($col_width, '%');
        if ($pct <= 0 || $pct >= 100) return '100%';
        $reduction = round(14 * (1 - $pct / 100), 2);
        return 'calc(' . $col_width . ' - ' . $reduction . 'px)';
    }

    /**
     * Opzione in stile FormCraft "valore == etichetta":
     *  - PRIMA di "==" = valore reale inviato (es. il trattamento che HotelDoor accetta)
     *  - DOPO  di "==" = solo ciò che vede l'utente nel menu
     * Ritorna [valore, etichetta_mostrata]. Senza "==" usa i campi value/label normali.
     */
    private static function opt_parts(array $opt): array {
        $label = (string) ($opt['label'] ?? '');
        $value = (string) ($opt['value'] ?? '');
        $src   = strpos($label, '==') !== false ? $label : (strpos($value, '==') !== false ? $value : '');
        if ($src !== '') {
            $p = explode('==', $src, 2);
            return [trim($p[0]), trim($p[1])];
        }
        return [$value !== '' ? $value : $label, $label];
    }

    private static function render_field(array $field, array $config, bool $submit_side = false, string $nl_inline_id = '', string $uniq = ''): string {
        $raw_type    = $field['type'] ?? 'text';
        $type        = $raw_type === 'phone' ? 'tel' : $raw_type; // phone → tel (standard HTML)
        $id          = $field['id'] ?? '';
        $lang        = $config['form_lang'] ?: get_option('if2_lang', 'it');
        $label       = IF2_I18n::t($field['label'] ?? '', $lang);
        $required    = !empty($field['required']);
        $placeholder = IF2_I18n::t($field['placeholder'] ?? '', $lang);
        $html_id     = ($uniq ?: 'if2') . '-field-' . esc_attr($id);
        $req_attr    = $required ? ' required' : '';
        $req_star    = $required ? ' <span class="if2-required">*</span>' : '';
        $sub_label   = $field['sub_label'] ?? '';
        // Radio/checkbox: se l'etichetta è nascosta e c'è un placeholder, mostralo come
        // intestazione del gruppo (altrimenti quei campi resterebbero senza titolo).
        $labels_hidden = !empty($config['hide_labels']) || !empty($field['hide_labels']);
        $group_title   = ($placeholder !== '' && $labels_hidden)
            ? '<div class="if2-group-label">' . esc_html($placeholder) . '</div>'
            : '';
        $instruction = $field['instruction'] ?? '';
        $col_width   = !empty($field['col_width']) ? $field['col_width'] : '100%';
        $col_w_css   = self::col_width_css($col_width);
        // Con newsletter_layout: solo il campo designato (nl_inline_id) cresce per riempire
        // lo spazio accanto al bottone; gli altri campi (checkbox, html, ecc.) restano su riga intera.
        $is_nl_inline = $nl_inline_id !== '' && ($field['id'] ?? '') === $nl_inline_id;
        if (($submit_side && ($col_width === '100%' || $col_width === '') && $nl_inline_id === '')
            || $is_nl_inline) {
            $field_style = 'flex:1 1 auto;min-width:0;width:auto;box-sizing:border-box;';
        } else {
            $field_style = 'width:' . esc_attr($col_w_css) . ';box-sizing:border-box;';
        }
        if (!empty($field['hidden_default'])) $field_style .= ';display:none';

        if ($type === 'page_break') return '';

        if ($type === 'html') {
            $html_color = !empty($field['html_color']) ? 'color:' . esc_attr($field['html_color']) . ';' : '';
            $html_bg    = !empty($field['html_bg'])    ? 'background:' . esc_attr($field['html_bg']) . ';' : '';
            $hide       = !empty($field['hidden_default']) ? 'display:none;' : '';
            return '<div class="if2-html-block" ' . self::conditional_attrs($field) . ' style="width:' . esc_attr($col_w_css) . ';box-sizing:border-box;' . $html_color . $html_bg . $hide . '">' . wp_kses_post(IF2_I18n::t_content($field['content'] ?? '', $lang)) . '</div>';
        }

        if ($type === 'heading') {
            $tag   = esc_attr(in_array($field['heading_size'] ?? '', ['h1','h2','h3','h4','h5','h6']) ? $field['heading_size'] : 'h3');
            $color = !empty($field['heading_color']) ? 'color:' . esc_attr($field['heading_color']) . ';' : '';
            $bg    = !empty($field['heading_bg'])    ? 'background:' . esc_attr($field['heading_bg']) . ';' : '';
            $pt    = !empty($field['padding_top'])    ? 'padding-top:' . esc_attr($field['padding_top']) . ';' : '';
            $pb    = !empty($field['padding_bottom'])  ? 'padding-bottom:' . esc_attr($field['padding_bottom']) . ';' : '';
            $align = !empty($field['heading_align'])   ? 'text-align:' . esc_attr($field['heading_align']) . ';' : '';
            $hw    = !empty($field['heading_weight'])  ? 'font-weight:' . esc_attr($field['heading_weight']) . ';' : '';
            $hide  = !empty($field['hidden_default'])   ? 'display:none;' : '';
            return '<div class="if2-field if2-field-type-heading" ' . self::conditional_attrs($field) . ' style="width:' . esc_attr($col_w_css) . ';box-sizing:border-box;' . $hide . '"><' . $tag . ' style="margin:0;' . $color . $bg . $pt . $pb . $align . $hw . '">' . esc_html($field['content'] ?? $label) . '</' . $tag . '></div>';
        }

        if ($type === 'submit') return '';

        ob_start();
        ?>
        <div class="if2-field if2-field-type-<?php echo esc_attr($type); ?>"
             data-field-id="<?php echo esc_attr($id); ?>"
             style="<?php echo esc_attr($field_style); ?>"
             <?php echo self::conditional_attrs($field); ?>>

            <?php if ($type !== 'hidden'): ?>
            <label class="if2-label" for="<?php echo $html_id; ?>">
                <?php echo esc_html($label); ?><?php echo $req_star; ?>
            </label>
            <?php if ($sub_label): ?>
            <span class="if2-sub-label"><?php echo esc_html($sub_label); ?></span>
            <?php endif; ?>
            <?php endif; ?>

            <?php switch ($type):
                case 'textarea': ?>
                    <textarea class="if2-input" id="<?php echo $html_id; ?>"
                              name="<?php echo esc_attr($id); ?>"
                              placeholder="<?php echo esc_attr($placeholder); ?>"
                              rows="1"
                              <?php echo $req_attr; ?>></textarea>
                    <?php break;

                case 'select': ?>
                    <div class="if2-select-wrap">
                        <select class="if2-input" id="<?php echo $html_id; ?>"
                                name="<?php echo esc_attr($id); ?>"<?php echo $req_attr; ?>>
                            <option value=""><?php echo esc_html($placeholder ?: self::t('select')); ?></option>
                            <?php foreach ($field['options'] ?? [] as $opt): [$ov, $ol] = self::opt_parts($opt);
                                $bo_attr = (is_array($opt) && !empty($opt['blackouts'])) ? ' data-blackouts="' . esc_attr(wp_json_encode($opt['blackouts'])) . '"' : ''; ?>
                            <option value="<?php echo esc_attr($ov); ?>"<?php echo $bo_attr; ?>>
                                <?php echo esc_html(IF2_I18n::t($ol, $lang)); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php break;

                case 'radio': ?>
                    <?php echo $group_title; ?>
                    <div class="if2-radio-group">
                    <?php foreach ($field['options'] ?? [] as $opt): [$ov, $ol] = self::opt_parts($opt);
                        $bo_attr = (is_array($opt) && !empty($opt['blackouts'])) ? ' data-blackouts="' . esc_attr(wp_json_encode($opt['blackouts'])) . '"' : ''; ?>
                        <label class="if2-radio-label">
                            <input type="radio" name="<?php echo esc_attr($id); ?>"
                                   value="<?php echo esc_attr($ov); ?>"<?php echo $bo_attr; ?>
                                   <?php echo $req_attr; ?>>
                            <?php echo esc_html(IF2_I18n::t($ol, $lang)); ?>
                        </label>
                    <?php endforeach; ?>
                    </div>
                    <?php break;

                case 'checkbox': ?>
                    <?php echo $group_title; ?>
                    <div class="if2-checkbox-group">
                    <?php foreach ($field['options'] ?? [] as $opt): [$ov, $ol] = self::opt_parts($opt); ?>
                        <label class="if2-checkbox-label">
                            <input type="checkbox" name="<?php echo esc_attr($id); ?>[]"
                                   value="<?php echo esc_attr($ov); ?>">
                            <?php echo esc_html(IF2_I18n::t($ol, $lang)); ?>
                        </label>
                    <?php endforeach; ?>
                    </div>
                    <?php break;

                case 'file':
                    $file_btn  = IF2_I18n::t($field['button_label'] ?? 'Scegli file', $lang);
                    $file_none = IF2_I18n::t('Nessun file selezionato', $lang); ?>
                    <div class="if2-file-wrap">
                        <input class="if2-input if2-file-input" type="file" id="<?php echo $html_id; ?>"
                               name="<?php echo esc_attr($id); ?>"
                               accept="<?php echo esc_attr($field['accept'] ?? ''); ?>"
                               <?php echo !empty($field['multiple']) ? 'multiple' : ''; ?>
                               data-none="<?php echo esc_attr($file_none); ?>"
                               <?php echo $req_attr; ?>>
                        <label class="if2-file-btn" for="<?php echo $html_id; ?>"><?php echo esc_html($file_btn); ?></label>
                        <span class="if2-file-name"><?php echo esc_html($file_none); ?></span>
                    </div>
                    <?php break;

                case 'date': ?>
                    <input class="if2-input if2-datepicker" type="text" id="<?php echo $html_id; ?>"
                           name="<?php echo esc_attr($id); ?>"
                           data-field-id="<?php echo esc_attr($id); ?>"
                           placeholder="<?php echo esc_attr($placeholder ?: self::t('date_ph')); ?>"
                           data-blocked="<?php echo esc_attr(wp_json_encode($field['blocked_ranges'] ?? [])); ?>"
                           data-date-format="<?php echo esc_attr($field['date_format'] ?? 'dd/mm/yy'); ?>"
                           data-days-allowed="<?php echo esc_attr(wp_json_encode($field['days_allowed'] ?? [true,true,true,true,true,true,true])); ?>"
                           <?php if (!empty($field['date_min_field'])): ?>data-min-field="<?php echo esc_attr($field['date_min_field']); ?>"<?php endif; ?>
                           <?php if (!empty($field['min_stay_rules'])): ?>data-min-stay="<?php echo esc_attr(wp_json_encode($field['min_stay_rules'])); ?>"<?php endif; ?>
                           <?php if (!empty($field['date_no_past'])): ?>data-no-past="1"<?php endif; ?>
                           <?php if (!empty($field['date_min'])): ?>data-date-min="<?php echo esc_attr($field['date_min']); ?>"<?php endif; ?>
                           <?php if (!empty($field['date_max'])): ?>data-date-max="<?php echo esc_attr($field['date_max']); ?>"<?php endif; ?>
                           autocomplete="off"<?php echo $req_attr; ?>>
                    <?php break;

                case 'hidden': ?>
                    <input type="hidden" name="<?php echo esc_attr($id); ?>"
                           value="<?php echo esc_attr($field['value'] ?? ''); ?>">
                    <?php break;

                case 'thumb': ?>
                    <div class="if2-thumb-group" role="radiogroup">
                        <label class="if2-thumb-label">
                            <input type="radio" name="<?php echo esc_attr($id); ?>" value="up" <?php echo $req_attr; ?>>
                            <span class="if2-thumb-icon">👍</span>
                        </label>
                        <label class="if2-thumb-label">
                            <input type="radio" name="<?php echo esc_attr($id); ?>" value="down">
                            <span class="if2-thumb-icon">👎</span>
                        </label>
                    </div>
                    <?php break;

                case 'star':
                    $max_stars = (int) ($field['max_stars'] ?? 5); ?>
                    <div class="if2-star-group" id="<?php echo $html_id; ?>">
                        <?php for ($s = $max_stars; $s >= 1; $s--): ?>
                        <input type="radio" id="<?php echo $html_id . '_' . $s; ?>"
                               name="<?php echo esc_attr($id); ?>"
                               value="<?php echo $s; ?>"
                               <?php echo $req_attr; ?>>
                        <label for="<?php echo $html_id . '_' . $s; ?>" title="<?php echo $s; ?>">★</label>
                        <?php endfor; ?>
                    </div>
                    <?php break;

                case 'matrix':
                    $m_rows = $field['matrix_rows']    ?? ['Domanda 1'];
                    $m_cols = $field['matrix_columns'] ?? ['Opzione 1', 'Opzione 2']; ?>
                    <div class="if2-matrix-wrap">
                        <table class="if2-matrix-table">
                            <thead>
                                <tr>
                                    <th></th>
                                    <?php foreach ($m_cols as $col): ?>
                                    <th><?php echo esc_html($col); ?></th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($m_rows as $r_idx => $row_label): ?>
                                <tr>
                                    <td class="if2-matrix-row-label"><?php echo esc_html($row_label); ?></td>
                                    <?php foreach ($m_cols as $col): ?>
                                    <td class="if2-matrix-cell">
                                        <input type="radio"
                                               name="<?php echo esc_attr($id . '_row_' . $r_idx); ?>"
                                               value="<?php echo esc_attr($col); ?>"
                                               <?php echo $req_attr; ?>>
                                    </td>
                                    <?php endforeach; ?>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php break;

                default: ?>
                    <input class="if2-input" type="<?php echo esc_attr($type); ?>"
                           id="<?php echo $html_id; ?>"
                           name="<?php echo esc_attr($id); ?>"
                           placeholder="<?php echo esc_attr($placeholder); ?>"
                           <?php echo !empty($field['min']) ? 'min="' . esc_attr($field['min']) . '"' : ''; ?>
                           <?php echo !empty($field['max']) ? 'max="' . esc_attr($field['max']) . '"' : ''; ?>
                           <?php if (!empty($field['validation_type'])): ?>data-validation-type="<?php echo esc_attr($field['validation_type']); ?>"<?php endif; ?>
                           <?php if (!empty($field['validation_regex'])): ?>data-validation-regex="<?php echo esc_attr($field['validation_regex']); ?>"<?php endif; ?>
                           <?php if (!empty($field['min_chars'])  && (int)$field['min_chars']  > 0): ?>data-min-chars="<?php echo (int)$field['min_chars'];  ?>"<?php endif; ?>
                           <?php if (!empty($field['max_chars'])  && (int)$field['max_chars']  > 0): ?>data-max-chars="<?php echo (int)$field['max_chars'];  ?>"<?php endif; ?>
                           <?php if (empty($field['allow_spaces']) && !empty($field['validation_type'])): ?>data-no-spaces="<?php echo ($field['allow_spaces'] ?? true) ? '' : '1'; ?>"<?php endif; ?>
                           <?php echo $req_attr; ?>>
            <?php endswitch; ?>

            <?php if ($instruction): ?>
            <p class="if2-instruction"><?php echo esc_html($instruction); ?></p>
            <?php endif; ?>
            <div class="if2-error" role="alert"></div>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function conditional_attrs(array $field): string {
        if (empty($field['conditions'])) return '';
        return 'data-conditions="' . esc_attr(wp_json_encode($field['conditions'])) . '"';
    }

    private static function split_pages(array $fields): array {
        $pages = []; $current = [];
        foreach ($fields as $field) {
            if ($field['type'] === 'page_break') { $pages[] = $current; $current = []; }
            else                                  { $current[] = $field; }
        }
        $pages[] = $current;
        return array_filter($pages, fn($p) => count($p) > 0);
    }

    private static function build_css_vars(array $config, string $uniq): string {
        static $gf_map = [
            'Roboto, sans-serif'             => 'Roboto:wght@400;500;700',
            'Open Sans, sans-serif'          => 'Open+Sans:wght@400;600;700',
            'Lato, sans-serif'               => 'Lato:wght@400;700',
            'Montserrat, sans-serif'         => 'Montserrat:wght@400;500;600;700',
            'Poppins, sans-serif'            => 'Poppins:wght@400;500;600;700',
            'Inter, sans-serif'              => 'Inter:wght@400;500;600;700',
            'Nunito, sans-serif'             => 'Nunito:wght@400;600;700',
            'Source Sans 3, sans-serif'      => 'Source+Sans+3:wght@400;600;700',
            'Raleway, sans-serif'            => 'Raleway:wght@400;600;700',
            'Ubuntu, sans-serif'             => 'Ubuntu:wght@400;500;700',
            'Playfair Display, serif'        => 'Playfair+Display:wght@400;700',
            'Merriweather, serif'            => 'Merriweather:wght@400;700',
            'Oswald, sans-serif'             => 'Oswald:wght@400;500;700',
            'Noto Sans, sans-serif'          => 'Noto+Sans:wght@400;500;700',
            'Work Sans, sans-serif'          => 'Work+Sans:wght@400;500;700',
            'PT Sans, sans-serif'            => 'PT+Sans:wght@400;700',
            'Fira Sans, sans-serif'          => 'Fira+Sans:wght@400;500;700',
            'Rubik, sans-serif'              => 'Rubik:wght@400;500;700',
            'DM Sans, sans-serif'            => 'DM+Sans:wght@400;500;700',
            'Mulish, sans-serif'             => 'Mulish:wght@400;600;700',
            'Quicksand, sans-serif'          => 'Quicksand:wght@400;600;700',
            'Manrope, sans-serif'            => 'Manrope:wght@400;600;700',
            'Bebas Neue, display'            => 'Bebas+Neue',
            'Karla, sans-serif'              => 'Karla:wght@400;700',
            'Archivo, sans-serif'            => 'Archivo:wght@400;600;700',
            'Space Grotesk, sans-serif'      => 'Space+Grotesk:wght@400;500;700',
            'Outfit, sans-serif'             => 'Outfit:wght@400;500;700',
            'Assistant, sans-serif'          => 'Assistant:wght@400;600;700',
            'Cabin, sans-serif'              => 'Cabin:wght@400;600;700',
            'Hind Madurai, sans-serif'       => 'Hind+Madurai:wght@400;500;700',
            'Josefin Sans, sans-serif'       => 'Josefin+Sans:wght@400;600;700',
            'Cormorant Garamond, serif'      => 'Cormorant+Garamond:wght@400;600;700',
            'Cinzel, serif'                  => 'Cinzel:wght@400;700',
        ];
        $map = [
            'form_width'         => '--if2-form-width',
            'bg_color'           => '--if2-bg-color',
            'font_color'         => '--if2-font-color',
            'font_family'        => '--if2-font-family',
            'font_size'          => '--if2-font-size',
            'label_weight'       => '--if2-label-weight',
            'label_color'        => '--if2-label-color',
            'sub_label_color'    => '--if2-sub-label-color',
            'link_color'         => '--if2-link-color',
            'field_border_color' => '--if2-field-border-color',
            'field_border_width' => '--if2-field-border-width',
            'consent_color'      => '--if2-consent-color',
            'consent_font_color' => '--if2-consent-font-color',
            'field_radius'         => '--if2-field-radius',
            'datepicker_radius'    => '--if2-datepicker-radius',
            'dp_header_bg'         => '--if2-dp-header-bg',
            'dp_today_color'       => '--if2-dp-today',
            'dp_selected_color'    => '--if2-dp-selected',
            'field_padding'      => '--if2-field-padding',
            'input_bg'           => '--if2-input-bg',
            'focus_color'        => '--if2-focus-color',
            'submit_bg'          => '--if2-submit-bg',
            'submit_hover_bg'    => '--if2-submit-hover-bg',
            'submit_color'       => '--if2-submit-color',
            'submit_radius'      => '--if2-submit-radius',
            'submit_col_width'   => '--if2-submit-col-width',
            'logo_width'         => '--if2-logo-width',
            'logo_position'      => '--if2-logo-position',
            'success_bg'         => '--if2-success-bg',
            'success_color'      => '--if2-success-color',
            'success_border'     => '--if2-success-border',
            'error_bg'           => '--if2-error-bg',
            'error_color'        => '--if2-error-color',
            'error_border'       => '--if2-error-border',
            'msg_font_size'      => '--if2-msg-font-size',
        ];
        $vars = '';
        foreach ($map as $key => $var) {
            if (isset($config[$key]) && $config[$key] !== '') {
                $val   = preg_replace('/[^a-zA-Z0-9\s#%.,()_\/-]/', '', (string) $config[$key]);
                $vars .= $var . ':' . $val . ';';
            }
        }
        if (!empty($config['bg_transparent'])) {
            $vars .= '--if2-bg-color:transparent;box-shadow:none;border-color:transparent;';
        }
        $css_extra = '';
        if (!empty($config['hide_labels'])) {
            $css_extra .= '#' . esc_attr($uniq) . ' .if2-label{display:none;}';
        }
        if (!empty($config['bg_image'])) {
            $url   = esc_url_raw($config['bg_image']);
            $size  = in_array($config['bg_size'] ?? '', ['cover','contain','auto','repeat'], true) ? $config['bg_size'] : 'cover';
            $vars .= 'background-image:url(' . $url . ');background-size:' . $size . ';background-repeat:' . ($size === 'repeat' ? 'repeat' : 'no-repeat') . ';background-position:center;';
        }
        $gf_import = '';
        if (!empty($config['font_family']) && isset($gf_map[$config['font_family']])) {
            $gf_import = "@import url('https://fonts.googleapis.com/css2?family=" . $gf_map[$config['font_family']] . "&display=swap');\n";
        }
        $css = $gf_import . '#' . esc_attr($uniq) . '{' . $vars . '}' . $css_extra;
        if (!empty($config['submit_col_width']) && $config['submit_col_width'] !== '100%') {
            $sw  = preg_replace('/[^a-zA-Z0-9%._-]/', '', $config['submit_col_width']);
            $swc = self::col_width_css($sw);
            $css .= '#' . esc_attr($uniq) . ' .if2-field-type-submit{width:' . $swc . '!important;flex-basis:' . $swc . '!important;max-width:' . $swc . '!important;}';
        }
        if (!empty($config['custom_css'])) {
            $css .= $config['custom_css'];
        }
        return $css;
    }

    private static function track_view(int $form_id): void {
        global $wpdb;
        $wpdb->insert(IF2_DB::stats_table(), ['form_id' => $form_id, 'event' => 'view']);
    }

    private static function enqueue_assets(bool $has_date = false): void {
        if (!self::$enqueued) {
            self::$enqueued = true;

            wp_enqueue_style('if2-frontend', IF2_URL . 'assets/css/frontend.css', [], IF2_VERSION);
            wp_enqueue_script('if2-frontend', IF2_URL . 'assets/js/frontend.js', [], IF2_VERSION, true);
            wp_localize_script('if2-frontend', 'IF2', [
                'ajaxurl'      => admin_url('admin-ajax.php'),
                'nonce_action' => 'if2_submit',
                'lang'         => get_option('if2_lang', 'it'),
                'strings'      => [
                    'required'   => self::t('required'),
                    'email_err'  => self::t('email_err'),
                    'fix_errors' => self::t('fix_errors'),
                    'conn_error' => self::t('conn_error'),
                    'multi_err'  => self::t('multi_err'),
                ],
            ]);

            do_action('if2_form_enqueue');
        }

        if ($has_date && !self::$datepicker_needed) {
            self::$datepicker_needed = true;
            wp_enqueue_script('jquery-ui-datepicker');
            wp_enqueue_style('if2-datepicker', IF2_URL . 'assets/css/datepicker.css', [], IF2_VERSION);
        }
    }
}
