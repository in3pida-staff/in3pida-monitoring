<?php
defined('ABSPATH') || exit;

class IF2_Submission {

    public static function get_all(int $form_id, int $limit = 50, int $offset = 0): array {
        global $wpdb;
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . IF2_DB::submissions_table() .
            " WHERE form_id = %d ORDER BY created_at DESC LIMIT %d OFFSET %d",
            $form_id, $limit, $offset
        ), ARRAY_A) ?: [];
    }

    public static function get_filtered(int $form_id, int $limit = 50, int $offset = 0): array {
        global $wpdb;
        $st = IF2_DB::submissions_table();
        $ft = IF2_DB::forms_table();
        if ($form_id) {
            return $wpdb->get_results($wpdb->prepare(
                "SELECT s.*, f.name as form_name FROM {$st} s
                 LEFT JOIN {$ft} f ON s.form_id = f.id
                 WHERE s.form_id = %d ORDER BY s.created_at DESC LIMIT %d OFFSET %d",
                $form_id, $limit, $offset
            ), ARRAY_A) ?: [];
        }
        return $wpdb->get_results($wpdb->prepare(
            "SELECT s.*, f.name as form_name FROM {$st} s
             LEFT JOIN {$ft} f ON s.form_id = f.id
             ORDER BY s.created_at DESC LIMIT %d OFFSET %d",
            $limit, $offset
        ), ARRAY_A) ?: [];
    }

    public static function count_filtered(int $form_id): int {
        global $wpdb;
        $st = IF2_DB::submissions_table();
        if ($form_id) {
            return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$st} WHERE form_id = %d", $form_id));
        }
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$st}");
    }

    /**
     * $force=true → tutte le submission del periodo, anche segnate "ok" falsamente
     * (usare dopo un blocco Supabase in cui i retry hanno marcato ok senza inserire davvero).
     */
    public static function get_supabase_failed(int $days = 7, bool $force = false): array {
        global $wpdb;
        $since = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        $rows  = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . IF2_DB::submissions_table() .
            " WHERE created_at >= %s ORDER BY created_at DESC LIMIT 2000",
            $since
        ), ARRAY_A) ?: [];
        if ($force) return array_values($rows);
        return array_values(array_filter($rows, function($r) {
            $meta = json_decode($r['meta'] ?? '{}', true) ?: [];
            $log  = $meta['integration_log'] ?? [];
            $sb   = $log['supabase'] ?? null;
            return $sb === null || ($sb['status'] ?? '') === 'error';
        }));
    }

    public static function get_one(int $id): ?array {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . IF2_DB::submissions_table() . " WHERE id = %d", $id
        ), ARRAY_A) ?: null;
    }

    public static function count(int $form_id): int {
        global $wpdb;
        return (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . IF2_DB::submissions_table() . " WHERE form_id = %d",
            $form_id
        ));
    }

    public static function save(int $form_id, array $data, array $meta = []): int {
        global $wpdb;
        $tbl = IF2_DB::submissions_table();
        $row = [
            'form_id' => $form_id,
            'data'    => wp_json_encode($data),
            'meta'    => wp_json_encode($meta),
        ];
        $ok = $wpdb->insert($tbl, $row);
        // Auto-riparazione: se l'insert fallisce perché la tabella MANCA (es. attivazione mai avvenuta o
        // update "in place"), la ricrea con dbDelta e riprova una volta. Evita i form che "girano a vuoto".
        if ($ok === false && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $tbl)) !== $tbl) {
            IF2_DB::install();
            $wpdb->insert($tbl, $row);
        }
        return (int) $wpdb->insert_id;
    }

    public static function delete(int $id): bool {
        global $wpdb;
        return $wpdb->delete(IF2_DB::submissions_table(), ['id' => $id]) !== false;
    }

    public static function update_meta_log(int $id, array $log_patch): void {
        global $wpdb;
        $row  = $wpdb->get_var($wpdb->prepare(
            "SELECT meta FROM " . IF2_DB::submissions_table() . " WHERE id = %d", $id
        ));
        $meta            = json_decode($row ?: '{}', true) ?: [];
        $existing        = $meta['integration_log'] ?? [];
        $meta['integration_log'] = array_merge($existing, $log_patch);
        $wpdb->update(IF2_DB::submissions_table(), ['meta' => wp_json_encode($meta)], ['id' => $id]);
    }

    /** Rimuove il suffisso ==valore dai campi select (formato interno label==value). */
    private static function display_val(mixed $v): string {
        if (is_array($v)) return implode(', ', array_map([self::class, 'display_val'], $v));
        $s = (string) $v;
        return strpos($s, '==') !== false ? substr($s, 0, strpos($s, '==')) : $s;
    }

    /** Restituisce il callback phpmailer_init per SMTP personalizzato, null se non configurato. */
    private static function smtp_configure(array $config): ?\Closure {
        if (($config['email_method'] ?? 'wp_mail') !== 'smtp') return null;
        if (empty($config['smtp_host']) || empty($config['smtp_user'])) return null;
        return function (\PHPMailer\PHPMailer\PHPMailer $mailer) use ($config): void {
            $mailer->isSMTP();
            $mailer->Host       = $config['smtp_host'];
            $mailer->SMTPAuth   = true;
            $mailer->Username   = $config['smtp_user'];
            $mailer->Password   = $config['smtp_pass'] ?? '';
            $mailer->Port       = (int) ($config['smtp_port'] ?: 587);
            $enc                = $config['smtp_enc'] ?? 'tls';
            $mailer->SMTPSecure = $enc === 'none' ? '' : $enc;
            // Il mittente DEVE coincidere con l'utente autenticato: molti server SMTP (es. in3pida) rifiutano
            // le email con "From" diverso. Forziamo l'INDIRIZZO = utente SMTP, mantenendo il NOME mittente
            // (es. "Hotel Carmen") e impostando l'envelope-from. Così autoresponder e notifica partono sempre.
            $smtp_user = (string) $config['smtp_user'];
            if ($smtp_user !== '') {
                $mailer->From   = $smtp_user;
                $mailer->Sender = $smtp_user;
            }
        };
    }

    /** Invia via wp_mail applicando SMTP personalizzato se configurato. */
    public static function send_mail(array $config, string|array $to, string $subject, string $body, array $headers): bool {
        $smtp = self::smtp_configure($config);
        if ($smtp) add_action('phpmailer_init', $smtp);
        $result = wp_mail($to, $subject, $body, $headers);
        if ($smtp) remove_action('phpmailer_init', $smtp);
        return $result;
    }

    /**
     * Invia email di notifica all'admin per una submission.
     */
    public static function send_notification(array $form, array $data, int $submission_id, array $meta = []): bool {
        $config = $form['config'];

        if (empty($config['send_email']) || empty($config['email_to'])) {
            return false;
        }

        $to = array_values(array_filter(array_map(
            fn($e) => sanitize_email(trim($e)),
            explode(',', $config['email_to'])
        )));
        $subject_tpl = $config['email_subject'] ?? 'Nuovo messaggio dal form';
        $subject     = sanitize_text_field($subject_tpl);
        $subject     = str_replace('{submission_id}', (string) $submission_id, $subject);
        $subject     = str_replace('{form_name}',     $form['name'],           $subject);
        $subject     = str_replace('{date}',          current_time('d/m/Y'),   $subject);
        $subject     = str_replace('{time}',          current_time('H:i'),     $subject);
        if (strpos($subject_tpl, '{submission_id}') === false) {
            $subject .= ' #' . $submission_id;
        }

        // Genera tabella campi (usata da {all_fields} e dal fallback auto)
        $table  = "<table cellpadding='8' cellspacing='0' border='0' style='border-collapse:collapse;width:100%;max-width:560px;font-family:sans-serif;font-size:13px'>\n";
        foreach ($form['fields'] as $field) {
            if (in_array($field['type'], ['page_break', 'html', 'submit'], true)) continue;
            $raw   = $data[$field['id']] ?? null;
            $value = ($raw !== null && $raw !== '' && $raw !== []) ? trim(self::display_val($raw)) : '';
            if ($value === '') continue;
            $label  = esc_html($field['label'] ?? $field['id']);
            $table .= "<tr style='border-bottom:1px solid #f0f0f0'>"
                    . "<td style='font-weight:700;color:#444;width:38%;vertical-align:top;padding:8px 12px 8px 0'>{$label}</td>"
                    . "<td style='color:#222;vertical-align:top'>" . esc_html($value) . "</td>"
                    . "</tr>\n";
        }
        $table .= "</table>\n";

        // Corpo email: usa email_body personalizzato se configurato, altrimenti genera la tabella
        if (!empty($config['email_body'])) {
            $body = $config['email_body'];

            // Sostituisci placeholder {field_id} con i valori dei singoli campi
            foreach ($data as $key => $val) {
                $body    = str_replace('{' . $key . '}', esc_html(self::display_val($val)), $body);
            }

            // Placeholder speciali
            $body = str_replace('{all_fields}',    $table,                                              $body);
            $body = str_replace('{form_name}',     esc_html($form['name']),                             $body);
            $body = str_replace('{submission_id}', (string) $submission_id,                             $body);
            $body = str_replace('{date}',          current_time('d/m/Y'),                               $body);
            $body = str_replace('{time}',          current_time('H:i'),                                 $body);
            $body = str_replace('{source_url}',    esc_html($meta['source_url'] ?? ''),                 $body);
            $body = str_replace('{channel}',       esc_html($meta['channel']    ?? ''),                 $body);

            $body = wp_kses_post($body);
        } else {
            $body  = "<p style='font-family:sans-serif;font-size:13px;color:#555;margin:0 0 16px'><strong>Data:</strong> " . current_time('d/m/Y H:i') . "</p>\n";
            $body .= $table;
        }

        $headers = ['Content-Type: text/html; charset=UTF-8'];

        // From header
        if (!empty($config['email_from_name']) && !empty($config['email_from'])) {
            $headers[] = 'From: ' . sanitize_text_field($config['email_from_name']) . ' <' . sanitize_email($config['email_from']) . '>';
        } elseif (!empty($config['email_from'])) {
            $headers[] = 'From: ' . sanitize_email($config['email_from']);
        }

        // Reply-To automatico: usa campo specificato o primo campo email
        if (!empty($config['email_reply_to'])) {
            $reply_field = $config['email_reply_to'];
            if (!empty($data[$reply_field])) {
                $headers[] = 'Reply-To: ' . sanitize_email($data[$reply_field]);
            }
        } else {
            foreach ($form['fields'] as $field) {
                if ($field['type'] === 'email' && !empty($data[$field['id']])) {
                    $headers[] = 'Reply-To: ' . sanitize_email($data[$field['id']]);
                    break;
                }
            }
        }

        // Invio separato per ciascun destinatario: se un indirizzo è rifiutato dall'SMTP,
        // gli altri ricevono comunque la notifica (un solo messaggio multi-to fallirebbe per tutti).
        $sent = false;
        foreach ($to as $recipient) {
            if (self::send_mail($config, $recipient, $subject, $body, $headers)) $sent = true;
        }
        return $sent;
    }

    /**
     * Invia email di conferma (autoresponder) all'utente.
     */
    public static function send_autoresponder(array $form, array $data, int $submission_id = 0): bool {
        $config = $form['config'];
        if (empty($config['autoresponder'])) return false;

        $email_field = $config['autoresponder_email_field'] ?? '';
        $to_email    = '';

        if ($email_field && !empty($data[$email_field])) {
            $to_email = sanitize_email($data[$email_field]);
        } else {
            foreach ($form['fields'] as $field) {
                if ($field['type'] === 'email' && !empty($data[$field['id']])) {
                    $to_email = sanitize_email($data[$field['id']]);
                    break;
                }
            }
        }

        if (!$to_email || !is_email($to_email)) return false;

        $ar_subject_tpl = $config['autoresponder_subject'] ?: 'Grazie per averci contattato';
        $subject        = sanitize_text_field($ar_subject_tpl);
        $subject        = str_replace('{submission_id}', (string) $submission_id, $subject);
        $subject        = str_replace('{form_name}',     $form['name'],           $subject);
        $subject        = str_replace('{date}',          current_time('d/m/Y'),   $subject);
        $subject        = str_replace('{time}',          current_time('H:i'),     $subject);
        if ($submission_id && strpos($ar_subject_tpl, '{submission_id}') === false) {
            $subject .= ' #' . $submission_id;
        }
        $body    = $config['autoresponder_body'] ?: '<p>Grazie! Abbiamo ricevuto il tuo messaggio.</p>';

        // Genera tabella campi per {all_fields}
        $ar_table  = "<table cellpadding='8' cellspacing='0' border='0' style='border-collapse:collapse;width:100%;max-width:560px;font-family:sans-serif;font-size:13px'>\n";
        foreach ($form['fields'] as $field) {
            if (in_array($field['type'], ['page_break', 'html', 'submit'], true)) continue;
            $raw_v = $data[$field['id']] ?? null;
            $val   = ($raw_v !== null && $raw_v !== '' && $raw_v !== []) ? trim(self::display_val($raw_v)) : '';
            if ($val === '') continue;
            $lbl = esc_html($field['label'] ?? $field['id']);
            $ar_table .= "<tr style='border-bottom:1px solid #f0f0f0'>"
                       . "<td style='font-weight:700;color:#444;width:38%;vertical-align:top;padding:8px 12px 8px 0'>{$lbl}</td>"
                       . "<td style='color:#222;vertical-align:top'>" . esc_html($val) . "</td>"
                       . "</tr>\n";
        }
        $ar_table .= "</table>\n";

        // Sostituisci placeholder {field_id} con i valori dei singoli campi
        foreach ($data as $key => $val) {
            $body = str_replace('{' . $key . '}', esc_html(self::display_val($val)), $body);
        }

        // Placeholder speciali
        $body = str_replace('{all_fields}',    $ar_table,                    $body);
        $body = str_replace('{form_name}',     esc_html($form['name']),      $body);
        $body = str_replace('{submission_id}', (string) $submission_id,      $body);
        $body = str_replace('{date}',          current_time('d/m/Y'),        $body);
        $body = str_replace('{time}',          current_time('H:i'),          $body);

        $headers = ['Content-Type: text/html; charset=UTF-8'];

        // From: usa i campi specifici dell'autoresponder, con fallback a quelli generici
        $ar_from_name  = !empty($config['autoresponder_from_name'])  ? $config['autoresponder_from_name']  : ($config['email_from_name']  ?? '');
        $ar_from_email = !empty($config['autoresponder_from_email']) ? $config['autoresponder_from_email'] : ($config['email_from']       ?? '');
        if ($ar_from_name && $ar_from_email) {
            $headers[] = 'From: ' . sanitize_text_field($ar_from_name) . ' <' . sanitize_email($ar_from_email) . '>';
        } elseif ($ar_from_email) {
            $headers[] = 'From: ' . sanitize_email($ar_from_email);
        }

        return self::send_mail($config, $to_email, $subject, wp_kses_post($body), $headers);
    }
}
