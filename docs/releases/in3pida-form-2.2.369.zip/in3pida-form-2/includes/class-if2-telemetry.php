<?php
defined('ABSPATH') || exit;

class IF2_Telemetry {

    const OPT_SITE_ID = 'if2_tel_site_id';
    const OPT_API_KEY = 'if2_tel_api_key';
    const OPT_ENABLED = 'if2_tel_enabled';
    const CRON_HOOK   = 'if2_telemetry_heartbeat';

    /**
     * Quando true, la richiesta in corso è dello STAFF in3pida (email @in3pida.it): NON va tracciata in
     * nessuna statistica del monitoring (mon_events / mon_integration_stats). Impostato dal meta['staff']
     * all'inizio di run_integrations (e di retry_crm). Vale solo per la richiesta corrente.
     */
    public static bool $skip = false;

    public static function init(): void {
        if (!get_option(self::OPT_ENABLED, 1)) return;
        add_action(self::CRON_HOOK,       [self::class, 'send_heartbeat']);
        add_action('if2_submission_done', [self::class, 'track_submission'], 10, 4);
        add_action('rest_api_init',       [self::class, 'register_rest']);
        add_action('init',                [self::class, 'maybe_heartbeat_on_update'], 5);
        add_action('init',                [self::class, 'maybe_visit_heartbeat'], 20);
    }

    // Heartbeat leggero a ogni visita (front o back), al massimo una volta ogni 4 ore.
    // Indipendente da WP-Cron: copre i siti a basso traffico o con cron disabilitato,
    // evitando falsi "Senza segnale" nel monitoring. Parte in shutdown → non rallenta la pagina.
    public static function maybe_visit_heartbeat(): void {
        if (wp_doing_cron()) return;                 // il cron ha già il suo heartbeat
        if (get_transient('if2_tel_ping')) return;   // throttle: max 1 ogni 4h
        set_transient('if2_tel_ping', 1, 4 * HOUR_IN_SECONDS);
        register_shutdown_function(function () {
            if (function_exists('fastcgi_finish_request')) { @fastcgi_finish_request(); }
            self::send_heartbeat();
        });
    }

    public static function maybe_heartbeat_on_update(): void {
        if (get_option('if2_tel_version', '') === IF2_VERSION . '-ok') return;
        if (!get_option(self::OPT_SITE_ID)) {
            update_option(self::OPT_SITE_ID, wp_generate_uuid4(), false);
        }
        if (!get_option(self::OPT_API_KEY)) {
            update_option(self::OPT_API_KEY, wp_generate_password(32, false), false);
        }
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), 'hourly', self::CRON_HOOK);
        }
        update_option('if2_tel_version', IF2_VERSION . '-ok', false);
        self::send_heartbeat();
    }

    public static function activate(): void {
        if (!get_option(self::OPT_SITE_ID)) {
            update_option(self::OPT_SITE_ID, wp_generate_uuid4(), false);
        }
        if (!get_option(self::OPT_API_KEY)) {
            update_option(self::OPT_API_KEY, wp_generate_password(32, false), false);
        }
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), 'hourly', self::CRON_HOOK);
        }
        self::send_heartbeat();
    }

    public static function deactivate(): void {
        $ts = wp_next_scheduled(self::CRON_HOOK);
        if ($ts) wp_unschedule_event($ts, self::CRON_HOOK);
    }

    // ─── HEARTBEAT ────────────────────────────────────────────────────────────

    public static function send_heartbeat(): void {
        $sb = self::sb_creds();

        $sb_url     = get_option('if2_supabase_url', '') ?: get_option('in3pida_supabase_url', '');
        $amelia_key = get_option('if2_amelia_key', '');

        // Verifica CRM: config if2, override manuale, vecchio plugin, hotel id, o per-form
        $crm_global = get_option('if2_crm_config', []);
        $has_crm    = !empty($crm_global)
                   || (bool) get_option('if2_has_crm_override', 0)
                   || (bool) get_option('in3pida_hotel_id', '')   // vecchio plugin v1.x
                   || (bool) get_option('if2_hotel_id', '');      // hotel id nel plugin attuale
        $crm_type = '';
        if (!empty($crm_global) && is_array($crm_global)) {
            $active = array_filter(array_keys($crm_global), fn($k) => !empty($crm_global[$k]));
            $crm_type = implode(',', $active);
        }
        if (!$crm_type && get_option('if2_has_crm_override', 0)) $crm_type = 'override';
        if (!$crm_type && (get_option('if2_hotel_id', '') || get_option('in3pida_hotel_id', ''))) $crm_type = 'hotel_id';
        if (!$has_crm) {
            global $wpdb;
            $tbl = $wpdb->prefix . 'if2_forms';
            if ($wpdb->get_var("SHOW TABLES LIKE '$tbl'") === $tbl) {
                $has_crm = (int) $wpdb->get_var(
                    "SELECT COUNT(*) FROM $tbl WHERE config LIKE '%\"crm\":{%' AND config NOT LIKE '%\"crm\":{}%'"
                ) > 0;
            }
        }

        self::sb_upsert($sb, 'mon_sites', [
            'site_id'        => self::site_id(),
            'api_key'        => self::api_key(),
            'plugin_name'    => 'in3pida-form-2',
            'plugin_version' => IF2_VERSION,
            'wp_version'     => get_bloginfo('version'),
            'php_version'    => PHP_VERSION,
            'theme_active'   => wp_get_theme()->get('Name'),
            'site_url'       => get_site_url(),
            'site_name'      => wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES), // niente &amp; nel monitoring
            'last_heartbeat' => gmdate('c'),
            'has_supabase'   => !empty($sb_url),
            'has_crm'        => $has_crm,
            'has_amelia'     => !empty($amelia_key),
            'crm_type'       => $crm_type,
        ]);

        self::sync_forms(); // manda anche l'elenco form (nome + data) al monitoring
    }

    // ─── TRACKING SUBMISSIONS ─────────────────────────────────────────────────

    public static function track_submission(int $submission_id, int $form_id, array $log, array $meta = []): void {
        if (self::$skip) return; // richiesta dello staff in3pida: non conteggiarla nel monitoring
        $sb = self::sb_creds();

        // Nome form + canale nell'evento, così il monitoring può filtrare le richieste per form e per canale.
        $form_name = '';
        if (class_exists('IF2_Form')) { $f = IF2_Form::get($form_id); $form_name = (string) ($f['name'] ?? ''); }
        $channel = (string) ($meta['channel'] ?? '');

        self::sb_insert($sb, 'mon_events', [
            'site_id'    => self::site_id(),
            'event_type' => 'form_submitted',
            'payload'    => (object) ['form_id' => $form_id, 'submission_id' => $submission_id, 'form_name' => $form_name, 'channel' => $channel],
        ]);

        foreach (['supabase', 'crm', 'amelia'] as $key) {
            if (!isset($log[$key])) continue;
            $raw = $log[$key]['status'] ?? '';
            if (!$raw || $raw === 'disabled') continue;
            $status = in_array($raw, ['ok', 'info', 'skipped'], true) ? $raw : 'error';
            self::sb_insert($sb, 'mon_integration_stats', [
                'site_id'       => self::site_id(),
                'integration'   => $key,
                'status'        => $status,
                'error_message' => ($log[$key]['message'] ?? '') ?: null,
            ]);
        }

        $crm_logged = false;
        foreach ($log as $key => $val) {
            if (strpos($key, 'crm_') !== 0) continue;
            $raw = $val['status'] ?? '';
            if (!$raw || $raw === 'disabled') continue;
            $crm_logged = true;
            $status = in_array($raw, ['ok', 'info', 'skipped'], true) ? $raw : 'error';
            self::sb_insert($sb, 'mon_integration_stats', [
                'site_id'       => self::site_id(),
                'integration'   => 'crm',
                'status'        => $status,
                'error_message' => ($val['message'] ?? '') ?: null,
            ]);
        }

        // Nessun driver nativo attivo: se CRM è configurato (qualsiasi metodo) logga "skipped"
        // così il monitoring mostra sempre dati CRM per i siti con CRM abilitato.
        // Se il webhook è pending, il risultato verrà tracciato da track_crm_result() dopo il shutdown.
        if (!$crm_logged && ($log['webhook']['status'] ?? '') !== 'pending') {
            $has_crm = !empty(get_option('if2_crm_config', []))
                    || (bool) get_option('if2_has_crm_override', 0)
                    || (bool) get_option('in3pida_hotel_id', '')
                    || (bool) get_option('if2_hotel_id', '');
            if (!$has_crm) {
                global $wpdb;
                $tbl = $wpdb->prefix . 'if2_forms';
                if ($wpdb->get_var("SHOW TABLES LIKE '$tbl'") === $tbl) {
                    $has_crm = (int) $wpdb->get_var(
                        "SELECT COUNT(*) FROM $tbl WHERE config LIKE '%\"crm\":{%' AND config NOT LIKE '%\"crm\":{}%'"
                    ) > 0;
                }
            }
            if ($has_crm) {
                self::sb_insert($sb, 'mon_integration_stats', [
                    'site_id'       => self::site_id(),
                    'integration'   => 'crm',
                    'status'        => 'skipped',
                    'error_message' => null,
                ]);
            }
        }
    }

    /** Invia al monitoring l'elenco form del sito (nome + data creazione) come evento snapshot su mon_events (nessuna tabella extra). */
    public static function sync_forms(): void {
        if (!class_exists('IF2_Form')) return;
        $forms = IF2_Form::get_all();
        if (!$forms) return;
        $list = [];
        foreach ($forms as $f) {
            $list[] = [
                'id'         => (int) $f['id'],
                'name'       => (string) ($f['name'] ?? ''),
                'created_at' => !empty($f['created_at']) ? gmdate('c', strtotime($f['created_at'])) : null,
            ];
        }
        $sb = self::sb_creds();
        self::sb_insert($sb, 'mon_events', [
            'site_id'    => self::site_id(),
            'event_type' => 'forms_snapshot',
            'payload'    => (object) ['forms' => $list],
        ]);
    }

    // ─── LOG ERRORI ───────────────────────────────────────────────────────────

    public static function log_error(string $message, string $level = 'error', array $context = []): void {
        $sb = self::sb_creds();
        self::sb_insert($sb, 'mon_logs', [
            'site_id' => self::site_id(),
            'level'   => $level,
            'message' => $message,
            'context' => empty($context) ? null : (object) $context,
        ]);
    }

    // ─── REST: aggiornamento plugin da monitoring ──────────────────────────────

    public static function register_rest(): void {
        // Priorità 20 = DOPO rest_send_cors_headers di WordPress (10), che altrimenti
        // rifletterebbe qualsiasi Origin. Così l'ultimo header vince e resta il nostro valore fisso.
        add_filter('rest_pre_serve_request', [self::class, 'cors_headers'], 20);
        register_rest_route('if2/v1', '/update', [
            'methods'             => ['POST', 'OPTIONS'],
            'callback'            => [self::class, 'rest_update'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('if2/v1', '/status', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'rest_status'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('if2/v1', '/set-config', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'rest_set_config'],
            'permission_callback' => '__return_true',
        ]);
        register_rest_route('if2/v1', '/retry-supabase', [
            'methods'             => ['POST', 'OPTIONS'],
            'callback'            => [self::class, 'rest_retry_supabase'],
            'permission_callback' => '__return_true',
        ]);
    }

    public static function cors_headers($value) {
        if (strpos($_SERVER['REQUEST_URI'] ?? '', '/if2/v1/') === false) return $value;
        header('Access-Control-Allow-Origin: https://monitoring.in3pida.it');
        header('Vary: Origin');
        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
        if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
            status_header(200);
            exit;
        }
        return $value;
    }

    public static function rest_status(WP_REST_Request $request): WP_REST_Response {
        header('Access-Control-Allow-Origin: https://monitoring.in3pida.it');
        header('Vary: Origin');
        $api_key = sanitize_text_field($request->get_param('api_key') ?? '');
        if (!$api_key || $api_key !== self::api_key()) {
            return new WP_REST_Response(['error' => 'Unauthorized'], 403);
        }
        return new WP_REST_Response([
            'plugin_version' => IF2_VERSION,
            'wp_version'     => get_bloginfo('version'),
            'php_version'    => PHP_VERSION,
            'site_url'       => get_site_url(),
        ]);
    }

    public static function rest_set_config(WP_REST_Request $request): WP_REST_Response {
        header('Access-Control-Allow-Origin: https://monitoring.in3pida.it');
        header('Vary: Origin');
        $api_key = sanitize_text_field($request->get_param('api_key') ?? '');
        $key     = sanitize_key($request->get_param('key') ?? '');
        $value   = $request->get_param('value');
        if (!$api_key || $api_key !== self::api_key()) {
            return new WP_REST_Response(['error' => 'Unauthorized'], 403);
        }
        $allowed = ['if2_has_crm_override', 'if2_feature_stats', 'if2_feature_crm_tab', 'if2_feature_settings_tab', 'if2_feature_dot_db', 'if2_feature_dot_crm', 'if2_feature_dot_amelia', 'if2_feature_date_chiuse', 'if2_feature_minimum_stay', 'if2_async_integrations'];
        if (!in_array($key, $allowed, true)) {
            return new WP_REST_Response(['error' => 'Chiave non consentita'], 403);
        }
        update_option($key, (int) $value, false);
        self::send_heartbeat();
        return new WP_REST_Response(['success' => true]);
    }

    public static function rest_retry_supabase(WP_REST_Request $request): WP_REST_Response {
        header('Access-Control-Allow-Origin: https://monitoring.in3pida.it');
        header('Vary: Origin');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
        if ($request->get_method() === 'OPTIONS') return new WP_REST_Response(null, 200);

        $api_key = sanitize_text_field($request->get_param('api_key') ?? '');
        if (!$api_key || $api_key !== self::api_key()) {
            return new WP_REST_Response(['error' => 'Unauthorized'], 403);
        }
        $days  = max(1, min(90, (int) ($request->get_param('days') ?? 7)));
        $force = !empty($request->get_param('force'));
        $rows  = IF2_Submission::get_supabase_failed($days, $force);
        $ok = 0; $fail = 0;
        foreach ($rows as $row) {
            $sid  = (int) $row['id'];
            $form = IF2_Form::get((int) $row['form_id']);
            if (!$form) { $fail++; continue; }
            $data = json_decode($row['data'], true) ?: [];
            $meta = json_decode($row['meta'], true) ?: [];
            $meta['_row_created_at'] = $row['created_at'] ?? '';
            $result = IF2_Extensions::retry_supabase($form, $data, $meta, $sid);
            IF2_Submission::update_meta_log($sid, ['supabase' => $result]);
            if ($result['status'] === 'ok') $ok++; else $fail++;
        }
        return new WP_REST_Response(['ok' => $ok, 'fail' => $fail, 'total' => count($rows)]);
    }

    public static function rest_update(WP_REST_Request $request): WP_REST_Response {
        header('Access-Control-Allow-Origin: https://monitoring.in3pida.it');
        header('Vary: Origin');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');

        if ($request->get_method() === 'OPTIONS') {
            return new WP_REST_Response(null, 200);
        }

        $api_key      = sanitize_text_field($request->get_param('api_key') ?? '');
        $download_url = esc_url_raw($request->get_param('download_url') ?? '');

        if (!$api_key || $api_key !== self::api_key()) {
            return new WP_REST_Response(['error' => 'Unauthorized'], 403);
        }
        // Accetta ZIP caricato direttamente (evita N richieste parallele a GitHub → 429).
        // Se presente, usa il file upload; altrimenti cade sul download_url (retrocompat.).
        $has_upload = !empty($_FILES['plugin_zip']['tmp_name']) && is_uploaded_file($_FILES['plugin_zip']['tmp_name']);

        if (!$has_upload) {
            if (!$download_url) {
                return new WP_REST_Response(['error' => 'Missing download_url or plugin_zip'], 400);
            }
            // Accetta SOLO uno zip del repository ufficiale in3pida-staff/in3pida-monitoring
            // (non basta l'host: raw.githubusercontent.com ospita i file di QUALSIASI repo → RCE).
            $pu   = wp_parse_url($download_url);
            $host = $pu['host'] ?? '';
            $path = (string) ($pu['path'] ?? '');
            $ok   = substr($path, -4) === '.zip' && (
                ($host === 'raw.githubusercontent.com' && strpos($path, '/in3pida-staff/in3pida-monitoring/') === 0)
                || ($host === 'monitoring.in3pida.it'  && strpos($path, '/releases/') === 0)
            );
            if (!$ok) {
                return new WP_REST_Response(['error' => 'URL non consentito'], 403);
            }
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        add_filter('filesystem_method', fn() => 'direct');
        WP_Filesystem();
        global $wp_filesystem;

        $was_active = is_plugin_active(IF2_BASENAME);
        if (function_exists('opcache_reset')) @opcache_reset();

        if ($has_upload) {
            // ZIP già in tmp — spostalo in un path controllato e usalo direttamente.
            $tmp_zip = trailingslashit(get_temp_dir()) . 'if2_up_' . wp_generate_password(10, false) . '.zip';
            move_uploaded_file($_FILES['plugin_zip']['tmp_name'], $tmp_zip);
            $tmp_zip_is_ours = true;
        } else {
            $tmp_zip_is_ours = false;
        }

        // AGGIORNAMENTO IN PLACE: scarica lo zip, lo scompatta in una cartella temporanea e SOVRASCRIVE
        // i file del plugin (copy_dir) SENZA rimuovere la cartella esistente. Così si evitano del tutto
        // "could not remove the current plugin" e "directory listing failed" sui server con permessi
        // rigidi (alcuni SiteGround): non serve né elencare né cancellare la vecchia cartella.
        if (!$has_upload) $tmp_zip = download_url($download_url, 60);
        if (!$has_upload && is_wp_error($tmp_zip)) {
            return new WP_REST_Response(['error' => 'Download fallito: ' . $tmp_zip->get_error_message()], 500);
        }
        $tmp_dir = trailingslashit(get_temp_dir()) . 'if2_upd_' . wp_generate_password(10, false);
        $unzip   = unzip_file($tmp_zip, $tmp_dir);
        @unlink($tmp_zip);
        if (is_wp_error($unzip)) {
            if ($wp_filesystem) $wp_filesystem->delete($tmp_dir, true);
            return new WP_REST_Response(['error' => 'Scompattazione fallita: ' . $unzip->get_error_message()], 500);
        }
        // Cartella del plugin dentro lo zip (in3pida-form-2), con fallback alla prima sottocartella.
        $src = trailingslashit($tmp_dir) . 'in3pida-form-2';
        if (!$wp_filesystem->is_dir($src)) {
            $list  = $wp_filesystem->dirlist($tmp_dir);
            $first = is_array($list) ? (string) array_key_first($list) : '';
            if ($first !== '') $src = trailingslashit($tmp_dir) . $first;
        }
        $dest   = trailingslashit(WP_PLUGIN_DIR) . 'in3pida-form-2';
        $copied = copy_dir($src, $dest); // sovrascrive i file in place (non elenca/rimuove il dest)
        if ($wp_filesystem) $wp_filesystem->delete($tmp_dir, true);
        if (function_exists('opcache_reset')) @opcache_reset();

        if (is_wp_error($copied)) {
            if ($was_active && !is_plugin_active(IF2_BASENAME)) activate_plugin(IF2_BASENAME);
            return new WP_REST_Response(['error' => 'Copia file fallita: ' . $copied->get_error_message()], 500);
        }

        if (!is_plugin_active(IF2_BASENAME)) {
            activate_plugin(IF2_BASENAME);
        }

        // NON chiamare send_heartbeat() qui: il processo PHP corrente ha ancora la
        // vecchia versione in memoria. maybe_heartbeat_on_update() si attiverà
        // automaticamente alla prima richiesta successiva con il nuovo codice caricato.
        // Forza il reset della versione cached così il prossimo init manda subito il heartbeat.
        delete_option('if2_tel_version');

        return new WP_REST_Response(['success' => true, 'message' => 'Plugin aggiornato con successo']);
    }

    // ─── HELPERS PRIVATI ──────────────────────────────────────────────────────

    private static function sb_creds(): array {
        $url = 'https://yyauvoqjdzrbmebeafit.supabase.co';
        $key = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl5YXV2b3FqZHpyYm1lYmVhZml0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzk3OTM2MDAsImV4cCI6MjA5NTM2OTYwMH0.M6kD56PEO_UcJ68Vjquo03vuORjv62MflIzGLzYKN9w';
        return compact('url', 'key');
    }

    private static function sb_insert(array $sb, string $table, array $body): void {
        if (!self::site_id()) return;
        wp_remote_post(
            trailingslashit($sb['url']) . 'rest/v1/' . $table,
            [
                'headers'   => [
                    'apikey'        => $sb['key'],
                    'Authorization' => 'Bearer ' . $sb['key'],
                    'Content-Type'  => 'application/json',
                    'Prefer'        => 'return=minimal',
                ],
                'body'      => wp_json_encode($body),
                'timeout'   => 3,
                'blocking'  => false,
                'sslverify' => false,
            ]
        );
    }

    private static function sb_upsert(array $sb, string $table, array $body): void {
        if (!self::site_id()) return;
        // mon_sites viene scritto tramite la funzione sicura mon_heartbeat (RPC): la chiave
        // pubblica NON ha permessi di scrittura diretti sulla tabella, così nessuno può
        // modificare/cancellare i dati dei siti. La funzione opera solo sul proprio site_id.
        wp_remote_post(
            trailingslashit($sb['url']) . 'rest/v1/rpc/mon_heartbeat',
            [
                'headers'   => [
                    'apikey'        => $sb['key'],
                    'Authorization' => 'Bearer ' . $sb['key'],
                    'Content-Type'  => 'application/json',
                    'Prefer'        => 'return=minimal',
                ],
                'body'      => wp_json_encode(['p' => $body]),
                'timeout'   => 8,
                'blocking'  => true,
                'sslverify' => false,
            ]
        );
    }

    /**
     * Traccia il risultato del webhook (usato come CRM) su mon_integration_stats.
     * Chiamato dallo shutdown function dopo che il webhook ha risposto.
     */
    public static function track_crm_result(array $log): void {
        if (self::$skip) return; // richiesta dello staff in3pida: non conteggiarla nel monitoring
        $raw = $log['status'] ?? '';
        if (!$raw || $raw === 'disabled') return;
        $sb     = self::sb_creds();
        $status = in_array($raw, ['ok', 'info', 'skipped'], true) ? $raw : 'error';
        self::sb_insert($sb, 'mon_integration_stats', [
            'site_id'       => self::site_id(),
            'integration'   => 'crm',
            'status'        => $status,
            'error_message' => ($log['message'] ?? '') ?: null,
        ]);
    }

    public static function track_amelia_result(array $log): void {
        if (self::$skip) return; // richiesta dello staff in3pida: non conteggiarla nel monitoring
        $raw = $log['status'] ?? '';
        if (!$raw || $raw === 'disabled') return;
        $sb     = self::sb_creds();
        $status = in_array($raw, ['ok', 'info', 'skipped'], true) ? $raw : 'error';
        self::sb_insert($sb, 'mon_integration_stats', [
            'site_id'       => self::site_id(),
            'integration'   => 'amelia',
            'status'        => $status,
            'error_message' => ($log['message'] ?? '') ?: null,
        ]);
    }

    /** Traccia l'esito del salvataggio DB (Supabase) su mon_integration_stats. Usato dal retry. */
    public static function track_supabase_result(array $log): void {
        if (self::$skip) return; // richiesta dello staff in3pida: non conteggiarla nel monitoring
        $raw = $log['status'] ?? '';
        if (!$raw || $raw === 'disabled') return;
        $sb     = self::sb_creds();
        $status = in_array($raw, ['ok', 'info', 'skipped'], true) ? $raw : 'error';
        self::sb_insert($sb, 'mon_integration_stats', [
            'site_id'       => self::site_id(),
            'integration'   => 'supabase',
            'status'        => $status,
            'error_message' => ($log['message'] ?? '') ?: null,
        ]);
    }

    public static function site_id(): string {
        return (string) get_option(self::OPT_SITE_ID, '');
    }

    public static function api_key(): string {
        return (string) get_option(self::OPT_API_KEY, '');
    }
}
