<?php
defined('ABSPATH') || exit;

class IF2_CRM_BookingDesigner {

    const ENDPOINT          = 'https://api.bookingdesigner.com/bdConnect/bookingRequest';
    const ADULT_PLACEHOLDER = 30;

    public static function send(array $creds, array $fields, array $meta): array {
        $apikey        = trim($creds['apikey']        ?? '');
        $property_code = trim($creds['property_code'] ?? '');

        if (!$apikey || !$property_code) {
            return ['status' => 'error', 'code' => 0, 'message' => 'apikey o property_code mancanti'];
        }

        $checkin  = self::fmt_date($fields['checkin']  ?? '');
        $checkout = self::fmt_date($fields['checkout'] ?? '');

        $adults   = max(0, (int)($fields['adults']   ?? 0));
        $children = (int)($fields['children'] ?? 0);

        $guest_ages    = array_fill(0, $adults, self::ADULT_PLACEHOLDER);
        $children_cnt  = 0;
        $infants_cnt   = 0;

        if ($children > 0) {
            foreach (['child_age_1', 'child_age_2', 'child_age_3', 'child_age_4'] as $slot) {
                $eta = trim((string)($fields[$slot] ?? ''));
                if ($eta === '') continue;
                if ($eta === '-1' || $eta === '<1') {
                    $infants_cnt++;
                    $guest_ages[] = 0;
                } else {
                    $age = (int)$eta;
                    if ($age === 0) {
                        $infants_cnt++;
                        $guest_ages[] = 0;
                    } else {
                        $children_cnt++;
                        $guest_ages[] = $age;
                    }
                }
            }
        }

        $accommodation = [];
        if ($adults > 0)      $accommodation['Adults']   = $adults;
        if ($children_cnt > 0) $accommodation['Children'] = $children_cnt;
        if ($infants_cnt > 0) {
            $accommodation['Infants'] = $infants_cnt;
            $accommodation['Infant']  = $infants_cnt;
        }
        if (!empty($guest_ages)) $accommodation['Ages'] = $guest_ages;

        if (empty($accommodation)) {
            return ['status' => 'error', 'code' => 0, 'message' => 'occupazione non valida'];
        }

        $channel_key  = $meta['channel'] ?? '';
        [$utm_source, $utm_medium] = self::channel_map($channel_key);
        // Source Tag: 1) vero utm_campaign dell'URL di provenienza; 2) se manca, nome del form
        // (come HotelDoor); 3) solo come ultima spiaggia "Diretta".
        $campaign = $meta['campaign'] ?? '';
        if ($campaign === '' && ($qs = parse_url($meta['source_url'] ?? '', PHP_URL_QUERY))) {
            parse_str($qs, $utm_q);
            if (!empty($utm_q['utm_campaign'])) $campaign = sanitize_text_field($utm_q['utm_campaign']);
        }
        if ($campaign === '') $campaign = trim($meta['form_name'] ?? '');
        if ($campaign === '') $campaign = 'Diretta';
        $lang     = substr(get_locale(), 0, 2);

        $source_url  = $meta['source_url'] ?? get_site_url();
        $parent_host = parse_url($source_url, PHP_URL_HOST) ?: parse_url(get_site_url(), PHP_URL_HOST);
        $parent_url  = 'https://' . $parent_host . '/?' . http_build_query([
            'utm_source'   => $utm_source,
            'utm_medium'   => $utm_medium,
            'utm_campaign' => $campaign,
        ]);

        $newsletter = (trim((string)($fields['newsletter'] ?? '')) === '1');

        $notes = trim($fields['notes'] ?? '');

        $additional_info = [
            'NewsletterSubscription' => $newsletter,
        ];
        if (!empty($meta['ip'])) {
            $additional_info['Ip'] = $meta['ip'];
        }
        // Numero animali/cani come dato strutturato (come lo script di Antonio); la specifica
        // (numero + peso) resta anche nelle Note. Booking Designer lo mostra insieme all'occupazione.
        $pets = (int) ($fields['pets'] ?? 0);
        if ($pets > 0) {
            $additional_info['PetsCount'] = $pets;
        }

        $payload = [
            'PropertyCode'   => $property_code,
            'FromDate'       => $checkin,
            'ToDate'         => $checkout,
            'FirstName'      => trim($fields['firstname'] ?? ''),
            'LastName'       => trim($fields['lastname']  ?? ''),
            'Email'          => trim($fields['email']     ?? ''),
            'Phone'          => trim($fields['phone']     ?? ''),
            'Notes'          => $notes,
            'PrivacyCheck'   => true,
            'CampaignSource' => $campaign,
            'ParentUrl'      => $parent_url,
            'Lang'           => $lang,
            'Accomodations'  => [$accommodation],
            'AdditionalInfo' => $additional_info,
        ];

        $arrangement = self::normalize_treatment($fields['treatment'] ?? '');
        if ($arrangement !== null) {
            $payload['ArrangementCode'] = $arrangement;
        }

        $resp = wp_remote_post(self::ENDPOINT, [
            'headers' => [
                'APIKey'       => $apikey,
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
            ],
            'body'    => wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'timeout' => 15,
            'blocking'=> true,
        ]);

        if (is_wp_error($resp)) {
            return ['status' => 'error', 'code' => 0, 'message' => $resp->get_error_message()];
        }

        $code     = wp_remote_retrieve_response_code($resp);
        $body     = wp_remote_retrieve_body($resp);
        $decoded  = json_decode($body, true);

        if ($code >= 400) {
            $msg = isset($decoded['error']) ? substr((string)$decoded['error'], 0, 200) : substr($body, 0, 200);
            return ['status' => 'error', 'code' => $code, 'message' => $msg];
        }

        if (!empty($decoded['error'])) {
            return ['status' => 'error', 'code' => $code, 'message' => substr((string)$decoded['error'], 0, 200)];
        }

        if (isset($decoded['Success']) && $decoded['Success'] !== true) {
            return ['status' => 'error', 'code' => $code, 'message' => 'esito non positivo dal CRM'];
        }

        return ['status' => 'ok', 'code' => $code, 'message' => ''];
    }

    private static function fmt_date(string $d): string {
        if (preg_match('/^(\d{2})\/(\d{2})\/(\d{4})$/', $d, $m)) {
            return $m[3] . '-' . $m[2] . '-' . $m[1];
        }
        return $d;
    }

    private static function normalize_treatment(?string $val): ?string {
        if ($val === null || trim($val) === '') return null;
        $map = [
            'FB' => 'FB', 'PENSIONE COMPLETA' => 'FB', 'FULL BOARD' => 'FB',
            'HB' => 'HB', 'MEZZA PENSIONE'    => 'HB', 'HALF BOARD' => 'HB',
            'BB' => 'BB', 'BED & BREAKFAST'   => 'BB', 'B&B' => 'BB',
                          'BED AND BREAKFAST'  => 'BB',
                          'CAMERA E COLAZIONE' => 'BB', 'PERNOTTAMENTO E COLAZIONE' => 'BB',
            'RS' => 'RS', 'FORMULA RESIDENCE'  => 'RS', 'RESIDENCE' => 'RS',
            'SAI'=> 'SAI','SOFT ALL INCLUSIVE' => 'SAI',
            'AI' => 'AI', 'ALL INCLUSIVE'      => 'AI',
            'SI' => 'SI', 'SOFT INCLUSIVE'     => 'SI',
            'OB' => 'OB', 'ONLY BED'           => 'OB',
            'LC' => 'LC', 'LOCAZIONE'          => 'LC',
            'FC' => 'FC', 'FORMULA CLUB'       => 'FC',
        ];
        $key = strtoupper(trim($val));
        return $map[$key] ?? $key;
    }

    private static function channel_map(string $ch): array {
        $map = [
            'fb'         => ['facebook',           'social'],
            'Meta'       => ['facebook',           'social'],
            'ads'        => ['google-adwords',     'ppc'],
            'Google Ads' => ['google-adwords',     'ppc'],
            'nl'         => ['newsletter',          'email'],
            'Newsletter' => ['newsletter',          'email'],
            'rmk'        => ['google-remarketing', 'ppc'],
            'web'        => ['Sito',               'organic'],
            'Sito'       => ['Sito',               'organic'],
            'landing'    => ['landing',             'landing'],
        ];
        return $map[$ch] ?? [$ch ?: 'Sito', 'organic'];
    }
}
