<?php
defined('ABSPATH') || exit;

class IF2_CRM_Passepartout {

    const ENDPOINT = 'https://smartbookingmanager.passepartout.cloud/sbmapi/api/public/richiesta';

    public static function send(array $creds, array $fields, array $meta): array {
        $oid_albergo = (int) ($creds['oid_albergo'] ?? 0);
        $api_key     = trim($creds['apikey']        ?? '');
        $oid_portale = trim($creds['oid_portale']   ?? '');

        if (!$oid_albergo || $api_key === '' || $oid_portale === '') {
            return ['status' => 'error', 'code' => 0, 'message' => 'oidAlbergo, apiKey o oid portale mancanti'];
        }

        $checkin  = self::fmt_date($fields['checkin']  ?? '');
        $checkout = self::fmt_date($fields['checkout'] ?? '');

        $full    = trim($fields['fullname'] ?? '');
        $space   = strpos($full, ' ');
        $nome    = $space !== false ? substr($full, 0, $space) : $full;
        $cognome = $space !== false ? substr($full, $space + 1) : '';

        $adults   = max(1, (int)($fields['adults'] ?? 1));
        $pax      = [['anni' => -1, 'quantita' => $adults]];
        $children = (int)($fields['children'] ?? 0);
        if ($children > 0) {
            foreach ([1, 2, 3, 4] as $n) {
                $eta = trim((string)($fields['child_age_' . $n] ?? ''));
                if ($eta === '') continue;
                if ($eta === '<1') $eta = '0';
                $pax[] = ['anni' => (int)$eta, 'quantita' => 1];
            }
        }

        $channel  = $meta['channel'] ?? '';
        $sorgente = self::channel_map($channel);
        $campaign = trim($meta['campaign'] ?? '');
        if ($campaign === '' || $campaign === '*') {
            $form_name = trim($meta['form_name'] ?? '');
            if ($form_name !== '') $campaign = $form_name;
        }

        // urlRichiesta/urlReferrer: URL reale + utm_source + utm_campaign
        $page_url = trim($meta['page_url'] ?? '');
        if ($page_url === '') $page_url = home_url('/');
        $utm_args = ['utm_source' => $channel ?: 'web'];
        if ($campaign !== '' && $campaign !== '*') $utm_args['utm_campaign'] = $campaign;
        $url_req = add_query_arg($utm_args, $page_url);

        // Note: note del form + campagna + sorgente (come fa Antonio)
        $note = trim($fields['notes'] ?? '');
        if ($campaign !== '' && $campaign !== '*') {
            $note .= ($note !== '' ? ' | ' : '') . 'Campagna: ' . $campaign;
        }
        $note .= ($note !== '' ? ' - ' : '') . 'Sorgente: ' . $sorgente;

        $payload = [
            'oidAlbergo' => $oid_albergo,
            'apiKey'     => $api_key,
            'richiesta'  => [
                'portaleXAlbergo' => ['oid' => $oid_portale],
                'dal'             => $checkin,
                'al'              => $checkout,
                'note'            => $note,
                'cliente'         => [
                    'cognome'      => $cognome,
                    'nome'         => $nome,
                    'email'        => $fields['email'] ?? '',
                    'cellulare'    => $fields['phone'] ?? '',
                    'codiceLingua' => true,
                    'privacy'      => true,
                ],
                'camere'          => [['pax' => $pax]],
                'urlRichiesta'    => $url_req,
                'urlReferrer'     => $url_req,
            ],
            'inviaEmail' => false,
        ];

        $resp = wp_remote_post(self::ENDPOINT, [
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode($payload),
            'timeout' => 15,
            'blocking'=> true,
        ]);

        if (is_wp_error($resp)) {
            return ['status' => 'error', 'code' => 0, 'message' => $resp->get_error_message()];
        }

        $code    = (int) wp_remote_retrieve_response_code($resp);
        $body    = wp_remote_retrieve_body($resp);
        $decoded = json_decode($body, true);
        $errori  = is_array($decoded) ? ($decoded['errori'] ?? []) : [];

        if (!empty($errori)) {
            $msg = implode('; ', array_map(fn($e) => is_array($e) ? json_encode($e) : (string)$e, $errori));
            return ['status' => 'error', 'code' => $code, 'message' => substr($msg, 0, 200)];
        }

        $ok = $code >= 200 && $code < 300;
        return [
            'status'  => $ok ? 'ok' : 'error',
            'code'    => $code,
            'message' => $ok ? '' : substr($body, 0, 200),
        ];
    }

    private static function fmt_date(string $d): string {
        if (preg_match('/^(\d{2})\/(\d{2})\/(\d{4})$/', $d, $m)) {
            return $m[3] . '-' . $m[2] . '-' . $m[1];
        }
        return $d;
    }

    private static function channel_map(string $ch): string {
        $map = [
            'fb'         => 'facebook',
            'Meta'       => 'facebook',
            'ads'        => 'google-ads',
            'Google Ads' => 'google-ads',
            'nl'         => 'newsletter',
            'Newsletter' => 'newsletter',
            'rmk'        => 'google-remarketing',
            'web'        => 'Sito',
            'Sito'       => 'Sito',
            'landing'    => 'landing',
            'ct'         => 'contatti',
            'cl'         => 'clienti',
        ];
        return $map[$ch] ?? ($ch ?: 'Sito');
    }
}
