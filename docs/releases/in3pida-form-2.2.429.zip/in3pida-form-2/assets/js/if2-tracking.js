(function () {
    var COOKIE = 'if2_prima_campagna';

    function getDomain() {
        var p = window.location.hostname.split('.');
        return p.length > 2 ? '.' + p.slice(-2).join('.') : window.location.hostname;
    }

    function setCookie(val) {
        var exp = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toUTCString();
        document.cookie = COOKIE + '=' + encodeURIComponent(val) + '; expires=' + exp + '; domain=' + getDomain() + '; path=/; SameSite=Lax';
    }

    function capture() {
        if (document.cookie.indexOf(COOKIE + '=') !== -1) return;
        // localStorage già valorizzato: ri-imposta il cookie (es. dopo CookieScript reset)
        var lsVal = null;
        try { lsVal = localStorage.getItem(COOKIE); } catch (e) {}
        if (lsVal) { setCookie(lsVal); return; }

        var qp  = new URLSearchParams(window.location.search);
        var src = (qp.get('utm_source') || '').toLowerCase();
        var med = (qp.get('utm_medium') || '').toLowerCase();
        var camp = qp.get('utm_campaign') || '';
        var canale = '';
        if (qp.get('gclid') || qp.get('gbraid') || qp.get('wbraid') || med === 'cpc' || med === 'paid' || med === 'ppc') {
            canale = 'Google Ads';
        } else if (qp.get('fbclid') || src === 'facebook' || src === 'instagram' || src === 'meta') {
            canale = 'Meta';
        } else if (med === 'email' || src === 'newsletter' || src === 'mailup' || src === 'amelia') {
            canale = 'Newsletter';
        } else if (med === 'dem' || src === 'dem') {
            canale = 'DEM';
        }
        if (!canale) return;

        var val = JSON.stringify({ canale: canale, campagna: camp, data: new Date().toISOString().slice(0, 10) });
        setCookie(val);
        try { localStorage.setItem(COOKIE, val); } catch (e) {}
    }

    capture();

    // ─── PERCORSO: passaggi campagna/pagina in ordine (niente query string, niente dati personali) ───
    var PCOOKIE = 'if2_percorso';

    function setNamedCookie(name, val) {
        var exp = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toUTCString();
        document.cookie = name + '=' + encodeURIComponent(val) + '; expires=' + exp + '; domain=' + getDomain() + '; path=/; SameSite=Lax';
    }

    function readPercorso() {
        var raw = null;
        var m = document.cookie.match(/(?:^|; )if2_percorso=([^;]*)/);
        if (m) { try { raw = decodeURIComponent(m[1]); } catch (e) {} }
        if (!raw) { try { raw = localStorage.getItem(PCOOKIE); } catch (e) {} }
        if (!raw) return [];
        try { var a = JSON.parse(raw); return Array.isArray(a) ? a : []; } catch (e) { return []; }
    }

    function detectCanale(qp) {
        var src = (qp.get('utm_source') || '').toLowerCase();
        var med = (qp.get('utm_medium') || '').toLowerCase();
        if (qp.get('gclid') || qp.get('gbraid') || qp.get('wbraid') || med === 'cpc' || med === 'paid' || med === 'ppc') return 'Google Ads';
        if (qp.get('fbclid') || src === 'facebook' || src === 'instagram' || src === 'meta') return 'Meta';
        if (med === 'email' || src === 'newsletter' || src === 'mailup' || src === 'amelia') return 'Newsletter';
        if (med === 'dem' || src === 'dem') return 'DEM';
        return '';
    }

    function trackPercorso() {
        var steps = readPercorso();
        var ts    = Math.floor(Date.now() / 1000);
        var qp    = new URLSearchParams(window.location.search);
        var last  = steps.length ? steps[steps.length - 1] : null;

        var canale = detectCanale(qp);
        if (canale) {
            var camp = (qp.get('utm_campaign') || '').slice(0, 60);
            if (!(last && last[0] === 'c' && last[1] === canale && last[2] === camp)) {
                steps.push(['c', canale, camp, ts]);
                last = steps[steps.length - 1];
            }
        }

        var host = window.location.hostname.indexOf('offerte') !== -1 ? 'l' : 's';
        var path = (window.location.pathname || '/').slice(0, 40);
        if (!(last && last[0] === 'p' && last[1] === host && last[2] === path)) {
            steps.push(['p', host, path, ts]);
        }

        // Limiti: max 30 passaggi e 1000 caratteri; si tolgono prima le pagine più vecchie, mai le campagne.
        while (steps.length > 30 || JSON.stringify(steps).length > 1000) {
            var idx = -1;
            for (var i = 0; i < steps.length; i++) { if (steps[i][0] === 'p') { idx = i; break; } }
            if (idx === -1) break;
            steps.splice(idx, 1);
        }

        var val = JSON.stringify(steps);
        setNamedCookie(PCOOKIE, val);
        try { localStorage.setItem(PCOOKIE, val); } catch (e) {}
    }

    try { trackPercorso(); } catch (e) {}

    // CookieScript cancella i cookie non-necessari prima del consenso.
    // Strategia: ripristina da localStorage dopo il consenso.
    function restoreFromLS() {
        try {
            if (document.cookie.indexOf(PCOOKIE + '=') === -1) {
                var pv = null;
                try { pv = localStorage.getItem(PCOOKIE); } catch (e) {}
                if (pv) setNamedCookie(PCOOKIE, pv);
            }
            if (document.cookie.indexOf(COOKIE + '=') !== -1) return;
            var lsVal = null;
            try { lsVal = localStorage.getItem(COOKIE); } catch (e) {}
            if (lsVal) setCookie(lsVal);
        } catch (e) {}
    }

    // Se l'utente ha già dato consenso in precedenza (cookie CookieScriptConsent presente),
    // ripristina subito il nostro cookie senza aspettare eventi.
    if (document.cookie.indexOf('CookieScriptConsent=') !== -1) {
        restoreFromLS();
    }

    // Ascolta tutti i nomi di evento usati dalle varie versioni di Cookie-Script
    ['CookieScriptConsent', 'CookieScriptAcceptAll', 'CookieScriptAccept', 'cookiescriptloaded'].forEach(function (evt) {
        window.addEventListener(evt, function () {
            // setTimeout: lascia a Cookie-Script il tempo di finire la sua elaborazione
            setTimeout(restoreFromLS, 300);
        });
    });

    // Cookie-Script supporta anche un callback globale
    var _prevCb = window.CookieScriptCallback;
    window.CookieScriptCallback = function () {
        if (_prevCb) try { _prevCb.apply(this, arguments); } catch (e) {}
        setTimeout(restoreFromLS, 300);
    };
})();
