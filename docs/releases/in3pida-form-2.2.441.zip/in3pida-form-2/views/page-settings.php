<?php
defined('ABSPATH') || exit;

if (isset($_POST['if2_settings_nonce']) && wp_verify_nonce($_POST['if2_settings_nonce'], 'if2_save_settings')) {
    update_option('if2_lang',             sanitize_text_field($_POST['if2_lang']          ?? 'it'));
    update_option('if2_supabase_url',     sanitize_text_field($_POST['supabase_url']      ?? ''));
    $raw_key = sanitize_text_field($_POST['supabase_anon_key'] ?? '');
    if ($raw_key !== '') update_option('if2_supabase_anon_key', if2_encrypt($raw_key));
    update_option('if2_hotel_id',         sanitize_text_field($_POST['hotel_id']          ?? ''));
    update_option('if2_custom_channels',  sanitize_textarea_field($_POST['custom_channels'] ?? ''));
    update_option('if2_antispam_limit',   (int) ($_POST['antispam_limit'] ?? 5));
    update_option('if2_antispam_enabled', !empty($_POST['antispam_enabled']) ? 1 : 0);
    update_option('if2_honeypot_enabled', !empty($_POST['honeypot_enabled']) ? 1 : 0);
    update_option('if2_has_crm_override',  !empty($_POST['if2_has_crm_override']) ? 1 : 0);
    update_option('if2_amelia_key',       sanitize_text_field($_POST['if2_amelia_key']    ?? ''));
    update_option('if2_amelia_secret',    sanitize_text_field($_POST['if2_amelia_secret'] ?? ''));
    update_option('if2_amelia_listid',    sanitize_text_field($_POST['if2_amelia_listid'] ?? ''));
    update_option('if2_amelia_apiurl',    esc_url_raw($_POST['if2_amelia_apiurl']          ?? 'https://api.smshosting.it/rest/api'));
    // Newsletter: o Amelia o MailUp
    update_option('if2_newsletter_provider', ($_POST['if2_newsletter_provider'] ?? '') === 'mailup' ? 'mailup' : 'amelia');
    update_option('if2_mailup_client_id', sanitize_text_field($_POST['if2_mailup_client_id'] ?? ''));
    update_option('if2_mailup_username',  sanitize_text_field($_POST['if2_mailup_username']  ?? ''));
    update_option('if2_mailup_list',      preg_replace('/\D+/', '', (string) ($_POST['if2_mailup_list']  ?? '')));
    update_option('if2_mailup_group',     preg_replace('/\D+/', '', (string) ($_POST['if2_mailup_group'] ?? '')));
    update_option('if2_mailup_confirm',   !empty($_POST['if2_mailup_confirm']) ? 1 : 0);
    // Secret e password: si sovrascrivono solo se scritti (campo vuoto = resta quello salvato)
    $mu_secret = trim((string) ($_POST['if2_mailup_client_secret'] ?? ''));
    if ($mu_secret !== '') update_option('if2_mailup_client_secret', if2_encrypt($mu_secret));
    $mu_pass = (string) ($_POST['if2_mailup_password'] ?? '');
    if ($mu_pass !== '') update_option('if2_mailup_password', if2_encrypt($mu_pass));
    // Multi-liste per paese
    $raw_list_ids      = array_map('sanitize_text_field', (array) ($_POST['if2_amelia_list_id']      ?? []));
    $raw_list_countries= array_map('sanitize_text_field', (array) ($_POST['if2_amelia_list_country'] ?? []));
    $clean_amelia_lists = [];
    foreach ($raw_list_ids as $i => $lid) {
        $lid = trim($lid);
        $cnt = trim($raw_list_countries[$i] ?? '');
        if ($lid && $cnt) {
            $clean_amelia_lists[] = ['listid' => $lid, 'country' => $cnt];
        }
    }
    update_option('if2_amelia_lists', wp_json_encode($clean_amelia_lists));
    // La chiave Amelia va su Supabase in automatico (IF2_Extensions::sync_amelia_key_to_bi), forziamo l'invio ora.
    delete_option('if2_amelia_bi_synced');
    if (class_exists('IF2_Extensions')) IF2_Extensions::sync_amelia_key_to_bi();

    // Reset cache lingua dopo il salvataggio
    IF2_Lang::reset();
}

$lang             = get_option('if2_lang', 'it');
$supabase_url     = get_option('if2_supabase_url', '');
$supabase_key     = if2_decrypt( get_option('if2_supabase_anon_key', '') );
$hotel_id         = get_option('if2_hotel_id', '');
$custom_channels  = get_option('if2_custom_channels', '');
$antispam_limit   = (int) get_option('if2_antispam_limit', 5);
$antispam_enabled = (bool) get_option('if2_antispam_enabled', 1);
$honeypot_enabled = (bool) get_option('if2_honeypot_enabled', 1);
$has_crm_override = (bool) get_option('if2_has_crm_override', 0);
$amelia_key       = get_option('if2_amelia_key', '');
$amelia_secret    = get_option('if2_amelia_secret', '');
$amelia_listid    = get_option('if2_amelia_listid', '');
$amelia_apiurl    = get_option('if2_amelia_apiurl', 'https://api.smshosting.it/rest/api');
$amelia_lists     = json_decode(get_option('if2_amelia_lists', '[]'), true) ?: [];
$nl_provider      = get_option('if2_newsletter_provider', 'amelia') === 'mailup' ? 'mailup' : 'amelia';
$mailup_client_id = get_option('if2_mailup_client_id', '');
$mailup_username  = get_option('if2_mailup_username', '');
$mailup_list      = get_option('if2_mailup_list', '');
$mailup_group     = get_option('if2_mailup_group', '');
$mailup_confirm   = (bool) get_option('if2_mailup_confirm', 0);
$mailup_has_secret = get_option('if2_mailup_client_secret', '') !== '';
$mailup_has_pass   = get_option('if2_mailup_password', '') !== '';
$amelia_country_opts = [
    'IT'    => 'IT — Italia (.it)',
    'DE'    => 'DE — Germania (.de, .at, .ch)',
    'FR'    => 'FR — Francia (.fr)',
    'EN'    => 'EN — UK / Internazionale (.uk, .co.uk, .com, .ie)',
    'CZ'    => 'CZ — Repubblica Ceca (.cz)',
    'PL'    => 'PL — Polonia (.pl)',
    'RO'    => 'RO — Romania (.ro)',
    'CA'    => 'CA — Canada (.ca)',
    'ES'    => 'ES — Spagna (.es)',
    'ALTRO' => 'ALTRO — Altri',
];
?>
<div class="if2-admin-wrap">
<div class="in3pida-settings-wrap">

    <div class="in3pida-page-header">
        <div>
            <h1>IN3PIDAFORM</h1>
            <p class="in3pida-tagline"><?php echo IF2_Lang::t('tagline'); ?></p>
        </div>
        <span class="in3pida-version-badge">v<?php echo esc_html(IF2_VERSION); ?></span>
    </div>

    <?php if (isset($_POST['if2_settings_nonce'])): ?>
    <div class="notice notice-success is-dismissible"><p><?php echo IF2_Lang::t('settings_saved'); ?></p></div>
    <?php endif; ?>

    <form method="post">
        <?php wp_nonce_field('if2_save_settings', 'if2_settings_nonce'); ?>

        <!-- LINGUA -->
        <div class="in3pida-section">
            <h2><?php echo IF2_Lang::t('section_lang'); ?></h2>
            <table class="form-table">
                <tr>
                    <th><?php echo IF2_Lang::t('lang_label'); ?></th>
                    <td>
                        <select name="if2_lang" class="in3pida-select">
                            <option value="it" <?php selected($lang, 'it'); ?>><?php echo IF2_Lang::t('lang_option_it'); ?></option>
                            <option value="en" <?php selected($lang, 'en'); ?>><?php echo IF2_Lang::t('lang_option_en'); ?></option>
                        </select>
                        <p class="description"><?php echo IF2_Lang::t('lang_desc'); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- DATABASE SUPABASE -->
        <div class="in3pida-section">
            <h2><?php echo IF2_Lang::t('section_supabase'); ?></h2>
            <?php
            $stored_enc = get_option('if2_supabase_anon_key', '');
            $key_corrupt = ($stored_enc !== '' && strpos($stored_enc, 'if2enc:') === 0 && $supabase_key === '');
            if ($key_corrupt): ?>
            <div style="background:#fff3cd;border:1px solid #ffc107;border-radius:4px;padding:10px 14px;margin-bottom:12px;font-size:13px;color:#856404">
                <strong>⚠ Chiave non decifrata.</strong> La chiave Supabase è salvata in forma cifrata ma non riesce a essere letta (probabilmente le costanti di wp-config.php sono cambiate).
                Re-inserisci la chiave anon qui sotto e salva.
            </div>
            <?php elseif ($supabase_url && !$supabase_key): ?>
            <div style="background:#fff3cd;border:1px solid #ffc107;border-radius:4px;padding:10px 14px;margin-bottom:12px;font-size:13px;color:#856404">
                <strong>⚠ Chiave Supabase mancante.</strong> L'URL è configurato ma la chiave API non è presente. Le richieste non vengono salvate su Supabase.
            </div>
            <?php endif; ?>
            <table class="form-table">
                <tr>
                    <th><?php echo IF2_Lang::t('supabase_url_label'); ?></th>
                    <td>
                        <input type="text" name="supabase_url" value="<?php echo esc_attr($supabase_url); ?>"
                               placeholder="https://xxxxxxxxxxx.supabase.co" class="regular-text">
                        <p class="description"><?php echo IF2_Lang::t('supabase_url_desc'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><?php echo IF2_Lang::t('supabase_key_label'); ?></th>
                    <td>
                        <input type="password" name="supabase_anon_key" value="<?php echo esc_attr($supabase_key); ?>"
                               placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." class="regular-text"
                               <?php if ($key_corrupt) echo 'style="border-color:#ffc107"'; ?>>
                        <p class="description"><?php echo IF2_Lang::t('supabase_key_desc'); ?></p>
                    </td>
                </tr>
            </table>
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:4px">
                <button type="button" id="if2-test-supabase" class="if2-btn-primary">► <?php echo IF2_Lang::t('test_connection'); ?></button>
                <span id="if2-supabase-test-result" style="font-size:12px"></span>
            </div>
        </div>

        <!-- IDENTIFICAZIONE HOTEL -->
        <div class="in3pida-section">
            <h2><?php echo IF2_Lang::t('section_hotel'); ?></h2>
            <table class="form-table">
                <tr>
                    <th><?php echo IF2_Lang::t('hotel_id_label'); ?></th>
                    <td>
                        <input type="text" name="hotel_id" value="<?php echo esc_attr($hotel_id); ?>"
                               placeholder="hotel-in3pida-riccione" class="regular-text">
                        <p class="description"><?php echo IF2_Lang::t('hotel_id_desc'); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- CANALI PERSONALIZZATI -->
        <div class="in3pida-section">
            <h2><?php echo IF2_Lang::t('section_channels'); ?></h2>
            <table class="form-table">
                <tr>
                    <th><?php echo IF2_Lang::t('channels_label'); ?></th>
                    <td>
                        <textarea name="custom_channels" rows="4" class="regular-text"
                                  placeholder="TikTok"><?php echo esc_textarea($custom_channels); ?></textarea>
                        <p class="description"><?php echo IF2_Lang::t('channels_desc'); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- ANTI-SPAM -->
        <div class="in3pida-section">
            <h2><?php echo IF2_Lang::t('section_antispam'); ?></h2>
            <table class="form-table">
                <tr>
                    <th><?php echo IF2_Lang::t('antispam_ip_label'); ?></th>
                    <td>
                        <label class="in3pida-toggle">
                            <input type="checkbox" name="antispam_enabled" <?php checked($antispam_enabled); ?>>
                            <span class="in3pida-toggle-slider"></span>
                            <span class="in3pida-toggle-label"><?php echo IF2_Lang::t($antispam_enabled ? 'antispam_active' : 'antispam_inactive'); ?></span>
                        </label>
                        <input type="number" name="antispam_limit" value="<?php echo esc_attr($antispam_limit); ?>"
                               min="1" max="100" class="in3pida-number-input">
                        <span style="margin-left:6px;font-size:13px;color:#666"><?php echo IF2_Lang::t('antispam_max_label'); ?></span>
                        <p class="description"><?php echo IF2_Lang::t('antispam_ip_desc'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><?php echo IF2_Lang::t('honeypot_label'); ?></th>
                    <td>
                        <label class="in3pida-toggle">
                            <input type="checkbox" name="honeypot_enabled" <?php checked($honeypot_enabled); ?>>
                            <span class="in3pida-toggle-slider"></span>
                            <span class="in3pida-toggle-label"><?php echo IF2_Lang::t($honeypot_enabled ? 'antispam_active' : 'antispam_inactive'); ?></span>
                        </label>
                        <p class="description"><?php echo IF2_Lang::t('honeypot_desc'); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- CRM ESTERNO -->
        <div class="in3pida-section">
            <h2>CRM (integrazione esterna)</h2>
            <table class="form-table">
                <tr>
                    <th><label for="if2_has_crm_override">CRM collegato</label></th>
                    <td>
                        <label class="in3pida-toggle">
                            <input type="checkbox" id="if2_has_crm_override" name="if2_has_crm_override" value="1" <?php checked($has_crm_override, true); ?>>
                            <span class="in3pida-toggle-slider"></span>
                            <span class="in3pida-toggle-label"><?php echo $has_crm_override ? 'Attivo' : 'Non attivo'; ?></span>
                        </label>
                        <p class="description">Attiva se questo sito usa un CRM esterno non gestito da questo plugin (es. vecchio script). Il pallino CRM nel monitoring diventerà verde.</p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- NEWSLETTER: AMELIA O MAILUP -->
        <div class="in3pida-section">
            <h2>Newsletter</h2>
            <table class="form-table">
                <tr>
                    <th><label for="if2_newsletter_provider">Servizio newsletter</label></th>
                    <td>
                        <select id="if2_newsletter_provider" name="if2_newsletter_provider" class="in3pida-select">
                            <option value="amelia" <?php selected($nl_provider, 'amelia'); ?>>Amelia / SMSHosting</option>
                            <option value="mailup" <?php selected($nl_provider, 'mailup'); ?>>MailUp</option>
                        </select>
                        <p class="description">Dove vanno i contatti che danno il consenso newsletter. O uno o l'altro. Se non lo cambi resta Amelia.</p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- MAILUP -->
        <div class="in3pida-section" id="if2-mailup-section" <?php if ($nl_provider !== 'mailup') echo 'style="display:none"'; ?>>
            <h2>MailUp</h2>
            <table class="form-table">
                <tr>
                    <th><label for="if2_mailup_client_id">Client ID</label></th>
                    <td><input type="text" id="if2_mailup_client_id" name="if2_mailup_client_id" value="<?php echo esc_attr($mailup_client_id); ?>" class="regular-text">
                        <p class="description">Dal pannello MailUp, sezione sviluppatori (codici API).</p></td>
                </tr>
                <tr>
                    <th><label for="if2_mailup_client_secret">Client Secret</label></th>
                    <td><input type="password" id="if2_mailup_client_secret" name="if2_mailup_client_secret" value="" autocomplete="new-password"
                               placeholder="<?php echo $mailup_has_secret ? '•••••••• (salvato — scrivi solo per cambiarlo)' : ''; ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="if2_mailup_username">Username</label></th>
                    <td><input type="text" id="if2_mailup_username" name="if2_mailup_username" value="<?php echo esc_attr($mailup_username); ?>" placeholder="es. m12345" class="regular-text" autocomplete="off"></td>
                </tr>
                <tr>
                    <th><label for="if2_mailup_password">Password</label></th>
                    <td><input type="password" id="if2_mailup_password" name="if2_mailup_password" value="" autocomplete="new-password"
                               placeholder="<?php echo $mailup_has_pass ? '•••••••• (salvata — scrivi solo per cambiarla)' : ''; ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="if2_mailup_list">ID lista</label></th>
                    <td><input type="text" id="if2_mailup_list" name="if2_mailup_list" value="<?php echo esc_attr($mailup_list); ?>" placeholder="es. 1" class="regular-text">
                        <p class="description">Lista in cui iscrivere i contatti. Un form può avere una lista sua (tab IN3PIDA del form).</p></td>
                </tr>
                <tr>
                    <th><label for="if2_mailup_group">ID gruppo (facoltativo)</label></th>
                    <td><input type="text" id="if2_mailup_group" name="if2_mailup_group" value="<?php echo esc_attr($mailup_group); ?>" class="regular-text">
                        <p class="description">Se lo scrivi, il contatto va anche in questo gruppo della lista.</p></td>
                </tr>
                <tr>
                    <th>Doppia conferma</th>
                    <td><label><input type="checkbox" name="if2_mailup_confirm" value="1" <?php checked($mailup_confirm); ?>>
                        MailUp manda al cliente una mail per confermare l'iscrizione</label></td>
                </tr>
            </table>
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:4px">
                <button type="button" id="if2-test-mailup" class="if2-btn-primary" style="height:30px!important">► Test connessione MailUp</button>
                <span id="if2-mailup-test-result" style="font-size:12px"></span>
            </div>
            <p class="description" style="margin-top:10px">Prima salva le impostazioni, poi fai il test. Nel builder il consenso si segna come per Amelia (campo <em>Amelia Consenso</em>, <em>Amelia Telefono</em>, <em>Amelia Nome</em>): valgono anche per MailUp.</p>
        </div>
        <script>
        document.getElementById('if2_newsletter_provider').addEventListener('change', function () {
            document.getElementById('if2-mailup-section').style.display = this.value === 'mailup' ? '' : 'none';
        });
        </script>

        <!-- AMELIA / SMSHOSTING -->
        <div class="in3pida-section">
            <h2>Amelia / SMSHosting</h2>
            <table class="form-table">
                <tr>
                    <th><label for="if2_amelia_key">Auth Key (Client ID)</label></th>
                    <td>
                        <input type="text" id="if2_amelia_key" name="if2_amelia_key"
                               value="<?php echo esc_attr($amelia_key); ?>"
                               placeholder="il-tuo-client-id" class="regular-text">
                        <p class="description">Client ID fornito da SMSHosting/SMSTools.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="if2_amelia_secret">Auth Secret (Client Secret)</label></th>
                    <td>
                        <input type="password" id="if2_amelia_secret" name="if2_amelia_secret"
                               value="<?php echo esc_attr($amelia_secret); ?>"
                               placeholder="il-tuo-client-secret" class="regular-text">
                        <p class="description">Client Secret fornito da SMSHosting/SMSTools.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="if2_amelia_listid">List ID globale (fallback)</label></th>
                    <td>
                        <input type="text" id="if2_amelia_listid" name="if2_amelia_listid"
                               value="<?php echo esc_attr($amelia_listid); ?>"
                               placeholder="123" class="regular-text">
                        <p class="description">Lista di default se non è configurata nessuna lista per paese e il form non ha una lista specifica.</p>
                    </td>
                </tr>
                <tr>
                    <th style="vertical-align:top;padding-top:14px"><label>Liste per paese</label></th>
                    <td>
                        <table id="if2-amelia-lists-table" style="border-collapse:collapse;margin-bottom:10px;min-width:480px">
                            <thead>
                                <tr>
                                    <th style="text-align:left;font-size:11px;color:#888;font-weight:700;padding:0 0 6px;border-bottom:1px solid #e0e0e0;width:130px">List ID</th>
                                    <th style="text-align:left;font-size:11px;color:#888;font-weight:700;padding:0 0 6px 10px;border-bottom:1px solid #e0e0e0">Paese / TLD</th>
                                    <th style="border-bottom:1px solid #e0e0e0;width:30px"></th>
                                </tr>
                            </thead>
                            <tbody id="if2-amelia-lists-tbody">
                                <?php foreach ($amelia_lists as $item): ?>
                                <tr>
                                    <td style="padding:4px 0">
                                        <input type="text" name="if2_amelia_list_id[]"
                                               value="<?php echo esc_attr($item['listid'] ?? ''); ?>"
                                               placeholder="es. 42"
                                               style="width:120px;padding:4px 6px;border:1px solid #ccc;border-radius:3px;font-size:13px">
                                    </td>
                                    <td style="padding:4px 0 4px 10px">
                                        <select name="if2_amelia_list_country[]"
                                                style="padding:4px 6px;border:1px solid #ccc;border-radius:3px;font-size:13px">
                                            <?php foreach ($amelia_country_opts as $val => $label): ?>
                                            <option value="<?php echo esc_attr($val); ?>"
                                                    <?php selected($item['country'] ?? '', $val); ?>>
                                                <?php echo esc_html($label); ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                    <td style="padding:4px 0 4px 8px">
                                        <button type="button" class="if2-amelia-remove-list"
                                                style="background:none;border:none;color:#d82d6b;cursor:pointer;font-size:16px;padding:0 4px;line-height:1"
                                                title="Rimuovi">✕</button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <button type="button" id="if2-amelia-add-list"
                                style="font-size:12px;padding:5px 12px;background:#fff;border:1px solid #d82d6b;color:#d82d6b;border-radius:3px;cursor:pointer">
                            + Aggiungi lista
                        </button>
                        <p class="description" style="margin-top:8px">
                            Configura una lista per ogni paese. Al submit, il sistema legge il TLD della email del contatto
                            e lo manda nella lista corrispondente.<br>
                            <strong>Priorità:</strong> TLD email → Lista default del form → List ID globale (fallback).
                        </p>
                    </td>
                </tr>
                <tr>
                    <th><label for="if2_amelia_apiurl">API URL</label></th>
                    <td>
                        <input type="text" id="if2_amelia_apiurl" name="if2_amelia_apiurl"
                               value="<?php echo esc_attr($amelia_apiurl); ?>"
                               placeholder="https://api.smshosting.it/rest/api" class="regular-text">
                        <p class="description">URL base delle API SMSHosting (senza slash finale).</p>
                    </td>
                </tr>
            </table>
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:4px">
                <button type="button" id="if2-test-amelia" class="if2-btn-primary" style="height:30px!important">► Test connessione Amelia</button>
                <input type="text" id="if2-amelia-test-phone" placeholder="+39XXXXXXXXXX" style="width:160px;padding:0 10px;border:1.5px solid var(--if2-border);border-radius:4px;font-size:12px;font-family:var(--if2-font);height:30px;box-sizing:border-box">
                <button type="button" id="if2-test-amelia-contact" class="if2-btn-primary" style="height:30px!important">► Test aggiungi contatto</button>
                <span id="if2-amelia-test-result" style="font-size:12px"></span>
                <span id="if2-amelia-contact-result" style="font-size:12px;font-family:monospace"></span>
            </div>
            <p class="description" style="margin-top:10px">
                Nel builder, segna un campo <strong>Checkbox</strong> come <em>Amelia Consenso</em> e un campo testo come <em>Amelia Telefono</em>.
                La email viene rilevata automaticamente. Al submit, se il consenso è spuntato, il contatto viene aggiunto alla lista.
            </p>
        </div>

        <!-- SUBMISSIONS IN CODA -->
        <div class="in3pida-section">
            <h2><?php echo IF2_Lang::t('section_queue'); ?></h2>
            <?php
            global $wpdb;
            $tbl     = IF2_DB::submissions_table();
            $pending = $wpdb->get_var("SELECT COUNT(*) FROM $tbl WHERE JSON_EXTRACT(meta, '$.queued') = true");
            $failed  = $wpdb->get_var("SELECT COUNT(*) FROM $tbl WHERE JSON_EXTRACT(meta, '$.queued_retries') >= 5");
            ?>
            <table class="widefat">
                <thead><tr><th><?php echo IF2_Lang::t('queue_status'); ?></th><th><?php echo IF2_Lang::t('queue_count'); ?></th><th><?php echo IF2_Lang::t('queue_action'); ?></th></tr></thead>
                <tbody>
                    <tr>
                        <td><?php echo IF2_Lang::t('queue_pending'); ?></td>
                        <td><?php echo (int) $pending; ?></td>
                        <td><button type="button" class="button"><?php echo IF2_Lang::t('queue_retry'); ?></button></td>
                    </tr>
                    <tr>
                        <td><?php echo IF2_Lang::t('queue_failed'); ?></td>
                        <td><?php echo (int) $failed; ?></td>
                        <td><em><?php echo IF2_Lang::t('queue_manual'); ?></em></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <p class="in3pida-save-row">
            <button type="submit" id="in3pida-save-btn">
                <?php echo IF2_Lang::t('save_settings'); ?>
            </button>
        </p>

    </form>
</div><!-- .in3pida-settings-wrap -->
</div><!-- .if2-admin-wrap -->
