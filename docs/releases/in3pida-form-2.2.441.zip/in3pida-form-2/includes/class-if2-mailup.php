<?php
defined('ABSPATH') || exit;

/**
 * MailUp — alternativa ad Amelia per la newsletter (Impostazioni → Newsletter: o Amelia o MailUp).
 * Accesso OAuth2 "password" (Client ID + Client Secret + username + password dell'account MailUp),
 * poi iscrizione del contatto alla lista (o al gruppo) con la REST API v1.1.
 * Il risultato finisce nello stesso log/pallino "AM" di Amelia.
 */
class IF2_MailUp {

    const TOKEN_URL   = 'https://services.mailup.com/Authorization/OAuth/Token';
    const CONSOLE_URL = 'https://services.mailup.com/API/v1.1/Rest/ConsoleService.svc/Console';

    public static function provider(): string {
        return get_option('if2_newsletter_provider', 'amelia') === 'mailup' ? 'mailup' : 'amelia';
    }

    private static function creds(): array {
        return [
            'client_id'     => trim((string) get_option('if2_mailup_client_id', '')),
            'client_secret' => trim(if2_decrypt((string) get_option('if2_mailup_client_secret', ''))),
            'username'      => trim((string) get_option('if2_mailup_username', '')),
            'password'      => if2_decrypt((string) get_option('if2_mailup_password', '')),
        ];
    }

    public static function configured(): bool {
        $c = self::creds();
        return $c['client_id'] !== '' && $c['client_secret'] !== '' && $c['username'] !== '' && $c['password'] !== ''
            && trim((string) get_option('if2_mailup_list', '')) !== '';
    }

    /** Token di accesso (tenuto in memoria finché vale, per non chiederlo a ogni richiesta). */
    public static function token(bool $force = false): array {
        $c = self::creds();
        if ($c['client_id'] === '' || $c['client_secret'] === '' || $c['username'] === '' || $c['password'] === '') {
            return ['ok' => false, 'message' => 'credenziali MailUp mancanti'];
        }
        $cache_key = 'if2_mailup_token_' . md5($c['client_id'] . '|' . $c['username']);
        if (!$force) {
            $cached = get_transient($cache_key);
            if ($cached) return ['ok' => true, 'token' => $cached];
        }
        $resp = wp_remote_post(self::TOKEN_URL, [
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode($c['client_id'] . ':' . $c['client_secret']),
                'Content-Type'  => 'application/x-www-form-urlencoded',
            ],
            'body'    => [
                'grant_type' => 'password',
                'username'   => $c['username'],
                'password'   => $c['password'],
                'client_id'  => $c['client_id'],
                'client_secret' => $c['client_secret'],
            ],
            'timeout' => 15,
        ]);
        if (is_wp_error($resp)) return ['ok' => false, 'code' => 0, 'message' => $resp->get_error_message()];
        $code = (int) wp_remote_retrieve_response_code($resp);
        $json = json_decode(wp_remote_retrieve_body($resp), true);
        if ($code !== 200 || empty($json['access_token'])) {
            $msg = is_array($json) ? ($json['error_description'] ?? $json['error'] ?? '') : '';
            return ['ok' => false, 'code' => $code, 'message' => 'accesso MailUp rifiutato' . ($msg ? ': ' . $msg : '') . ' (HTTP ' . $code . ')'];
        }
        $ttl = max(60, (int) ($json['expires_in'] ?? 900) - 60);
        set_transient($cache_key, $json['access_token'], $ttl);
        return ['ok' => true, 'token' => $json['access_token']];
    }

    /**
     * Iscrive il contatto. $list = lista del form (vuoto = lista delle Impostazioni).
     * Ritorna un log nel formato di Amelia: status ok / info / error / skipped.
     */
    public static function subscribe(string $email, string $name, string $phone, string $list = ''): array {
        if (!is_email($email)) return ['status' => 'skipped', 'message' => 'email mancante o non valida', 'via' => 'mailup'];
        $list    = trim($list) !== '' ? trim($list) : trim((string) get_option('if2_mailup_list', ''));
        $group   = trim((string) get_option('if2_mailup_group', ''));
        $confirm = (bool) get_option('if2_mailup_confirm', 0);
        if (!ctype_digit($list)) return ['status' => 'skipped', 'message' => 'ID lista MailUp mancante', 'via' => 'mailup'];

        $parts = preg_split('/\s+/', trim($name), 2);
        $body  = ['Email' => $email, 'Name' => trim($name), 'Fields' => []];
        if (($parts[0] ?? '') !== '') $body['Fields'][] = ['Id' => 1, 'Value' => $parts[0]];   // campo MailUp "nome"
        if (($parts[1] ?? '') !== '') $body['Fields'][] = ['Id' => 2, 'Value' => $parts[1]];   // campo MailUp "cognome"
        // Cellulare solo se è un numero italiano valido: un numero strano farebbe scartare tutto il contatto.
        if (preg_match('/^39(3\d{8,9})$/', $phone, $m)) {
            $body['MobilePrefix'] = '+39';
            $body['MobileNumber'] = $m[1];
        }

        $path = ctype_digit($group) ? '/Group/' . $group . '/Recipient' : '/List/' . $list . '/Recipient';
        $url  = self::CONSOLE_URL . $path . ($confirm ? '?ConfirmEmail=true' : '');

        $r = self::call($url, $body);
        if ($r['code'] === 401) $r = self::call($url, $body, true); // token scaduto → nuovo token e riprova
        if (!empty($r['token_error'])) return ['status' => 'error', 'code' => $r['code'], 'message' => $r['message'], 'via' => 'mailup'];
        if ($r['code'] >= 200 && $r['code'] < 300) {
            return ['status' => 'ok', 'code' => $r['code'], 'message' => $confirm ? 'aggiunto (attende conferma via email)' : 'aggiunto', 'via' => 'mailup'];
        }
        if (stripos($r['body'], 'already') !== false || stripos($r['body'], 'exist') !== false) {
            return ['status' => 'info', 'code' => $r['code'], 'message' => 'già presente', 'via' => 'mailup'];
        }
        return ['status' => 'error', 'code' => $r['code'], 'message' => substr($r['body'] !== '' ? $r['body'] : 'HTTP ' . $r['code'], 0, 160), 'via' => 'mailup'];
    }

    private static function call(string $url, array $body, bool $new_token = false): array {
        $t = self::token($new_token);
        if (!$t['ok']) return ['code' => (int) ($t['code'] ?? 0), 'body' => '', 'token_error' => true, 'message' => $t['message']];
        $resp = wp_remote_post($url, [
            'headers' => ['Authorization' => 'Bearer ' . $t['token'], 'Content-Type' => 'application/json', 'Accept' => 'application/json'],
            'body'    => wp_json_encode($body),
            'timeout' => 15,
        ]);
        if (is_wp_error($resp)) return ['code' => 0, 'body' => $resp->get_error_message()];
        return ['code' => (int) wp_remote_retrieve_response_code($resp), 'body' => trim((string) wp_remote_retrieve_body($resp))];
    }

    /** Test connessione dalla pagina Impostazioni: prova l'accesso e legge le liste dell'account. */
    public static function test(): array {
        $t = self::token(true);
        if (!$t['ok']) return ['ok' => false, 'message' => $t['message']];
        $resp = wp_remote_get(self::CONSOLE_URL . '/User/Lists?pageSize=50', [
            'headers' => ['Authorization' => 'Bearer ' . $t['token'], 'Accept' => 'application/json'],
            'timeout' => 15,
        ]);
        if (is_wp_error($resp)) return ['ok' => false, 'message' => $resp->get_error_message()];
        $json  = json_decode(wp_remote_retrieve_body($resp), true);
        $lists = [];
        foreach ((array) ($json['Items'] ?? []) as $l) {
            if (isset($l['IdList'])) $lists[] = $l['IdList'] . ' = ' . ($l['Name'] ?? '');
        }
        return ['ok' => true, 'message' => 'Connessione OK' . ($lists ? ' — liste: ' . implode(' · ', $lists) : '')];
    }
}
