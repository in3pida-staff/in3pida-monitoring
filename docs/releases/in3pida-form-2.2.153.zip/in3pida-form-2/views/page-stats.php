<?php defined('ABSPATH') || exit;
$forms = IF2_Form::get_all();
?>
<style>
.if2-stats-simple-card{flex:0 0 280px!important;max-width:280px!important;}
.if2-stats-simple-header{padding:14px 16px!important;display:flex;align-items:center;justify-content:space-between;gap:10px;border-bottom:1px solid var(--if2-border)}
.if2-stats-simple-title{font-size:.95rem!important;font-weight:700!important;color:#181834!important;}
.if2-stats-simple-label{padding:8px 12px!important;font-size:11px!important;font-weight:600!important;color:#888!important;text-transform:uppercase!important;letter-spacing:.03em!important;background:#fafafa!important;border-right:1px solid var(--if2-border)!important;vertical-align:middle!important;width:44%!important;}
.if2-stats-simple-value{padding:8px 12px!important;background:#fff!important;vertical-align:middle!important;font-size:12px!important;}
.if2-stats-simple-select{border:none!important;background:transparent!important;padding:2px 0!important;outline:none!important;box-shadow:none!important;font-size:12px!important;font-family:inherit!important;width:100%!important;color:#333!important;}
/* Analytics sections */
.if2-analytics-section{background:#fff;border:1px solid var(--if2-border);border-radius:6px;margin-bottom:16px;overflow:hidden}
.if2-analytics-title{margin:0;padding:12px 18px;font-size:11px;font-weight:700;color:#181834;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid var(--if2-border);background:#fafafa;display:flex;align-items:center;gap:8px}
.if2-analytics-boxes{display:flex;gap:10px;padding:14px 18px;border-bottom:1px solid #f5f5f5;flex-wrap:wrap}
.if2-analytics-box{flex:1;min-width:130px;border:1.5px solid var(--if2-border);border-radius:6px;padding:12px 14px;background:#fff}
.if2-analytics-box-hl{border-color:#d82d6b!important;background:linear-gradient(135deg,#fff 55%,#fdf0f5)!important}
.if2-analytics-box-lbl{font-size:10px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px}
.if2-analytics-box-val{font-size:18px;font-weight:700;color:#181834;line-height:1.2;margin-bottom:3px}
.if2-analytics-box-sub{font-size:11px;color:#888;margin-top:2px}
.if2-analytics-box-pct{font-size:13px;font-weight:700;color:#d82d6b;margin-top:3px}
.if2-analytics-box-delta{font-size:10px;font-weight:700;margin-top:4px;padding:2px 6px;border-radius:3px;display:inline-block}
.if2-delta-up{background:#e6f9ef;color:#1a7a45}
.if2-delta-down{background:#fde8ee;color:#c0184a}
.if2-analytics-chart-row{padding:16px 18px;border-top:1px solid #f5f5f5}
.if2-analytics-chart-title{font-size:10px;font-weight:700;color:#999;text-transform:uppercase;letter-spacing:.04em;margin-bottom:10px}
.if2-section-cfg-hdr{padding:9px 14px;font-size:10px;font-weight:700;color:#888;text-transform:uppercase;letter-spacing:.04em;background:#fafafa;border-top:1px solid var(--if2-border);border-bottom:1px solid var(--if2-border)}
.if2-field-chart-card{background:#fff;border:1px solid var(--if2-border);border-radius:6px;overflow:hidden;margin-bottom:14px}
.if2-field-chart-header{padding:10px 16px;background:#fafafa;border-bottom:1px solid var(--if2-border);display:flex;align-items:center;justify-content:space-between}
.if2-field-chart-title{font-size:11px;font-weight:700;color:#181834}
.if2-field-chart-count{font-size:10px;color:#aaa;font-weight:600}
.if2-field-chart-body{padding:14px 16px;height:220px;position:relative}
.if2-geo-view-btn{border:1px solid var(--if2-border);background:#fff;color:#666;font-size:11px;font-weight:600;padding:5px 12px;border-radius:5px;cursor:pointer;margin-left:4px;transition:all .12s}
.if2-geo-view-btn:hover{border-color:#d82d6b;color:#d82d6b}
.if2-geo-view-btn.is-active{background:#d82d6b;border-color:#d82d6b;color:#fff}
.if2-geo-area{transition:fill-opacity .1s,stroke-width .1s}
.if2-geo-area:hover{fill-opacity:.75;stroke:#fff;stroke-width:1.6}
</style>
<div class="if2-admin-wrap">

    <div class="if2-topbar">
        <a href="#" id="if2-export-all" class="if2-topbar-link"><?php echo IF2_Lang::t('export_all'); ?></a>
        <span class="if2-topbar-brand">in3pida-form è un plugin di <strong>in3pida</strong></span>
    </div>

    <div style="display:flex;gap:0;padding:28px 32px;background:var(--if2-light);align-items:flex-start;min-height:calc(100vh - 96px)">

        <!-- LEFT: filtri + config hotel + confronta -->
        <div class="if2-panel if2-stats-simple-card" style="min-height:auto;min-width:0;position:sticky;top:52px;overflow:hidden">

            <div class="if2-stats-simple-header">
                <span class="if2-stats-simple-title">Statistiche</span>
            </div>

            <!-- FILTRI — IN ALTO -->
            <div class="if2-section-cfg-hdr">Filtri</div>
            <table class="if2-stats-simple-table" style="width:100%">
                <tbody>
                    <tr>
                        <td class="if2-stats-simple-label">Modulo</td>
                        <td class="if2-stats-simple-value">
                            <select id="if2-stats-form-filter" class="if2-stats-simple-select">
                                <option value="0">— Tutti —</option>
                                <?php foreach ($forms as $f): ?>
                                <option value="<?php echo esc_attr($f['id']); ?>"><?php echo esc_html($f['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td class="if2-stats-simple-label">Periodo</td>
                        <td class="if2-stats-simple-value">
                            <select id="if2-stats-period-select" class="if2-stats-simple-select">
                                <option value="all">— Tutti —</option>
                                <option value="1s">Ultima settimana</option>
                                <option value="2s">Ultimi 14 giorni</option>
                                <option value="1m">Ultimo mese</option>
                                <option value="3m">Ultimi 3 mesi</option>
                                <option value="6m">Ultimi 6 mesi</option>
                                <option value="1a">Ultimo anno</option>
                                <option value="custom">Personalizzato…</option>
                            </select>
                        </td>
                    </tr>
                    <tr id="if2-stats-custom-row" style="display:none">
                        <td class="if2-stats-simple-label">Intervallo</td>
                        <td class="if2-stats-simple-value">
                            <input type="text" readonly id="if2-stats-date-from" placeholder="aaaa-mm-gg" autocomplete="off" style="border:1px solid var(--if2-border);border-radius:3px;padding:3px 6px;font-size:11px;font-family:inherit;width:100%;margin-bottom:4px;cursor:pointer;background:#fff">
                            <input type="text" readonly id="if2-stats-date-to"   placeholder="aaaa-mm-gg" autocomplete="off" style="border:1px solid var(--if2-border);border-radius:3px;padding:3px 6px;font-size:11px;font-family:inherit;width:100%;cursor:pointer;background:#fff">
                        </td>
                    </tr>
                    <tr>
                        <td class="if2-stats-simple-label">Canale</td>
                        <td class="if2-stats-simple-value">
                            <select id="if2-stats-channel-filter" class="if2-stats-simple-select">
                                <option value="">— Tutti —</option>
                                <option value="sito">Sito</option>
                                <option value="meta">Meta</option>
                                <option value="google_ads">Google Ads</option>
                                <option value="newsletter">Newsletter</option>
                                <option value="altro">Altro</option>
                                <?php
                                $custom_ch = get_option('if2_custom_channels', '');
                                foreach (array_filter(array_map('trim', explode("\n", $custom_ch))) as $ch):
                                ?>
                                <option value="<?php echo esc_attr($ch); ?>"><?php echo esc_html($ch); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                </tbody>
            </table>

            <!-- CONFRONTA -->
            <div class="if2-section-cfg-hdr">Confronta</div>
            <table class="if2-stats-simple-table" style="width:100%">
                <tbody>
                    <tr>
                        <td class="if2-stats-simple-label">Con</td>
                        <td class="if2-stats-simple-value">
                            <select id="if2-compare-mode" class="if2-stats-simple-select">
                                <option value="">— Non confrontare —</option>
                                <option value="prev">Periodo precedente</option>
                                <option value="year">Anno precedente</option>
                            </select>
                        </td>
                    </tr>
                </tbody>
            </table>

            <div style="padding:12px 14px">
                <button class="if2-btn-primary" id="if2-load-stats-btn" style="width:100%;justify-content:center">CARICA</button>
            </div>
        </div><!-- /left -->

        <!-- RIGHT: risultati -->
        <div style="flex:1;padding:0 0 0 20px;min-width:0">

            <div id="if2-stats-empty" style="color:#aaa;font-size:13px;padding-top:4px">
                Seleziona un modulo e clicca <strong style="color:#555">CARICA</strong>.<br>
                <small>Configura i campi Hotel per l'analisi richieste, target e periodo.</small>
            </div>

            <!-- Analisi Hotel — IN CIMA -->
            <div id="if2-hotel-stats" style="display:none">

                <!-- RIEPILOGO GENERALE -->
                <div class="if2-analytics-section" id="if2-section-summary">
                    <h3 class="if2-analytics-title">
                        <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#d82d6b;margin-right:4px"></span>
                        Riepilogo Richieste
                    </h3>
                    <div class="if2-analytics-boxes">
                        <div class="if2-analytics-box if2-analytics-box-hl">
                            <div class="if2-analytics-box-lbl">Totale Richieste</div>
                            <div class="if2-analytics-box-val" id="if2-total-requests">—</div>
                            <div class="if2-analytics-box-sub" id="if2-compare-badge"></div>
                        </div>
                        <div class="if2-analytics-box">
                            <div class="if2-analytics-box-lbl">Mese Più Richiesto</div>
                            <div class="if2-analytics-box-val" id="if2-top-month" style="font-size:16px">—</div>
                            <div class="if2-analytics-box-pct" id="if2-top-month-pct"></div>
                        </div>
                        <div class="if2-analytics-box">
                            <div class="if2-analytics-box-lbl">Settimana Più Richiesta</div>
                            <div class="if2-analytics-box-val" id="if2-top-week" style="font-size:13px">—</div>
                            <div class="if2-analytics-box-pct" id="if2-top-week-pct"></div>
                        </div>
                        <div class="if2-analytics-box">
                            <div class="if2-analytics-box-lbl">Target Principale</div>
                            <div class="if2-analytics-box-val" id="if2-top-target" style="font-size:13px">—</div>
                            <div class="if2-analytics-box-pct" id="if2-top-target-pct"></div>
                        </div>
                        <div class="if2-analytics-box" id="if2-bw-summary-box" style="display:none">
                            <div class="if2-analytics-box-lbl">Booking Window</div>
                            <div class="if2-analytics-box-val" id="if2-top-bw-avg">—</div>
                            <div class="if2-analytics-box-sub">gg anticipo in media</div>
                        </div>
                    </div>
                </div>

                <!-- ANALISI RICHIESTE (durata soggiorno) -->
                <div class="if2-analytics-section" id="if2-section-soggiorno" style="display:none">
                    <h3 class="if2-analytics-title">
                        <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#d82d6b;margin-right:4px"></span>
                        Analisi Richieste
                    </h3>
                    <div class="if2-analytics-boxes">
                        <div class="if2-analytics-box">
                            <div class="if2-analytics-box-lbl">Durata Media Soggiorno</div>
                            <div class="if2-analytics-box-val" id="if2-avg-stay">—</div>
                            <div class="if2-analytics-box-sub" id="if2-stay-count"></div>
                        </div>
                        <div class="if2-analytics-box if2-analytics-box-hl">
                            <div class="if2-analytics-box-lbl">Periodo Più Richiesto</div>
                            <div class="if2-analytics-box-val" id="if2-top-bucket">—</div>
                            <div class="if2-analytics-box-pct" id="if2-top-bucket-pct"></div>
                        </div>
                    </div>
                    <div class="if2-analytics-chart-row">
                        <div class="if2-analytics-chart-title">Distribuzione Durata Soggiorno</div>
                        <div style="height:280px;position:relative"><canvas id="if2-chart-stay-pie"></canvas></div>
                    </div>
                </div>

                <!-- ANALISI TARGET -->
                <div class="if2-analytics-section" id="if2-section-target" style="display:none">
                    <h3 class="if2-analytics-title">
                        <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#d82d6b;margin-right:4px"></span>
                        Analisi Target
                    </h3>
                    <div class="if2-analytics-boxes">
                        <div class="if2-analytics-box if2-analytics-box-hl">
                            <div class="if2-analytics-box-lbl">Target Più Frequente</div>
                            <div class="if2-analytics-box-val" id="if2-top-target-2">—</div>
                            <div class="if2-analytics-box-pct" id="if2-top-target-pct-2"></div>
                        </div>
                    </div>
                    <div class="if2-analytics-chart-row">
                        <div class="if2-analytics-chart-title">Tipologia di Target</div>
                        <div style="height:300px;position:relative"><canvas id="if2-chart-target-pie"></canvas></div>
                    </div>
                </div>

                <!-- ANALISI PERIODO — 4 sezioni separate -->
                <div class="if2-analytics-section" id="if2-section-periodo" style="display:none">
                    <h3 class="if2-analytics-title">
                        <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#d82d6b;margin-right:4px"></span>
                        Mesi Più Richiesti — Torta
                    </h3>
                    <div class="if2-analytics-chart-row">
                        <div style="height:300px;position:relative"><canvas id="if2-chart-periodo-months"></canvas></div>
                    </div>
                </div>
                <div class="if2-analytics-section" id="if2-section-periodo-months-bar" style="display:none">
                    <h3 class="if2-analytics-title">
                        <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#d82d6b;margin-right:4px"></span>
                        Mesi Più Richiesti — Istogramma
                    </h3>
                    <div class="if2-analytics-chart-row">
                        <div style="height:240px;position:relative"><canvas id="if2-chart-months-bar"></canvas></div>
                    </div>
                </div>
                <div class="if2-analytics-section" id="if2-section-periodo-weeks" style="display:none">
                    <h3 class="if2-analytics-title">
                        <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#d82d6b;margin-right:4px"></span>
                        Settimane Più Richieste — Torta
                    </h3>
                    <div class="if2-analytics-chart-row">
                        <div style="height:300px;position:relative"><canvas id="if2-chart-periodo-weeks"></canvas></div>
                    </div>
                </div>
                <div class="if2-analytics-section" id="if2-section-periodo-weeks-bar" style="display:none">
                    <h3 class="if2-analytics-title">
                        <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#d82d6b;margin-right:4px"></span>
                        Top 5 Settimane Più Richieste — Istogramma
                    </h3>
                    <div class="if2-analytics-chart-row">
                        <div style="height:240px;position:relative"><canvas id="if2-chart-weeks-bar"></canvas></div>
                    </div>
                </div>

                <!-- BOOKING WINDOW -->
                <div class="if2-analytics-section" id="if2-section-booking-window" style="display:none">
                    <h3 class="if2-analytics-title">
                        <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#d82d6b;margin-right:4px"></span>
                        Booking Window — Anticipo Richiesta
                    </h3>
                    <div class="if2-analytics-boxes">
                        <div class="if2-analytics-box if2-analytics-box-hl">
                            <div class="if2-analytics-box-lbl">Media Giorni Anticipo</div>
                            <div class="if2-analytics-box-val" id="if2-bw-avg">—</div>
                            <div class="if2-analytics-box-sub" id="if2-bw-count"></div>
                        </div>
                        <div class="if2-analytics-box">
                            <div class="if2-analytics-box-lbl">Tipo Più Frequente</div>
                            <div class="if2-analytics-box-val" id="if2-bw-top" style="font-size:13px">—</div>
                            <div class="if2-analytics-box-pct" id="if2-bw-top-pct"></div>
                        </div>
                    </div>
                    <div class="if2-analytics-chart-row">
                        <div class="if2-analytics-chart-title">Distribuzione Anticipo Prenotazione</div>
                        <div style="height:280px;position:relative"><canvas id="if2-chart-bw-pie"></canvas></div>
                    </div>
                </div>

                <!-- CANALI -->
                <div class="if2-analytics-section" id="if2-section-canali" style="display:none">
                    <h3 class="if2-analytics-title">
                        <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#d82d6b;margin-right:4px"></span>
                        Analisi Canali
                    </h3>
                    <div class="if2-analytics-boxes">
                        <div class="if2-analytics-box if2-analytics-box-hl">
                            <div class="if2-analytics-box-lbl">Canale Principale</div>
                            <div class="if2-analytics-box-val" id="if2-top-canale">—</div>
                            <div class="if2-analytics-box-pct" id="if2-top-canale-pct"></div>
                            <div class="if2-analytics-box-sub" id="if2-canali-tracked" style="display:none"></div>
                        </div>
                    </div>
                    <div class="if2-analytics-chart-row">
                        <div class="if2-analytics-chart-title">Distribuzione Canali</div>
                        <div style="height:280px;position:relative"><canvas id="if2-chart-canali-pie"></canvas></div>
                    </div>
                </div>

                <!-- PROVENIENZA (geolocalizzazione) — in fondo a tutte le altre sezioni -->
                <div class="if2-analytics-section" id="if2-section-geo" style="display:none">
                    <h3 class="if2-analytics-title">
                        <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#009bb9;margin-right:4px"></span>
                        Provenienza
                        <span id="if2-geo-total" style="font-size:11px;color:#aaa;font-weight:400;margin-left:8px"></span>
                    </h3>
                    <div class="if2-analytics-boxes">
                        <div class="if2-analytics-box if2-analytics-box-hl">
                            <div class="if2-analytics-box-lbl">Nazione principale</div>
                            <div class="if2-analytics-box-val" id="if2-geo-top-country" style="font-size:16px">—</div>
                            <div class="if2-analytics-box-pct" id="if2-geo-top-country-sub"></div>
                        </div>
                        <div class="if2-analytics-box">
                            <div class="if2-analytics-box-lbl">Città principale</div>
                            <div class="if2-analytics-box-val" id="if2-geo-top-city" style="font-size:15px">—</div>
                            <div class="if2-analytics-box-pct" id="if2-geo-top-city-sub"></div>
                        </div>
                    </div>
                    <!-- Mappa a tutta larghezza con selettore inquadratura -->
                    <div class="if2-analytics-chart-row">
                        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;margin-bottom:10px">
                            <div class="if2-analytics-chart-title" style="margin:0">Richieste per provenienza</div>
                            <div id="if2-geo-views">
                                <button type="button" class="if2-geo-view-btn is-active" data-view="italia">Italia</button>
                                <button type="button" class="if2-geo-view-btn" data-view="europa">Europa</button>
                                <button type="button" class="if2-geo-view-btn" data-view="mondo">Mondo</button>
                                <button type="button" class="if2-geo-view-btn" data-view="asia">Asia</button>
                                <button type="button" class="if2-geo-view-btn" data-view="america">America</button>
                            </div>
                        </div>
                        <div id="if2-geo-map" style="position:relative;background:#d82d6b;border-radius:6px;overflow:hidden;min-height:200px">
                            <div id="if2-geo-tip" style="position:absolute;display:none;pointer-events:none;background:rgba(24,24,52,.92);color:#fff;font-size:12px;line-height:1.35;padding:7px 10px;border-radius:6px;white-space:nowrap;z-index:5;box-shadow:0 2px 8px rgba(0,0,0,.25)"></div>
                        </div>
                        <div id="if2-geo-map-empty" style="color:#aaa;font-size:12px;text-align:center;padding:24px 0">Nessun dato di provenienza ancora.</div>
                    </div>

                    <!-- Classifica regioni -->
                    <div class="if2-analytics-chart-row">
                        <div class="if2-analytics-chart-title">Classifica regioni (Italia)</div>
                        <div id="if2-geo-regions-rank"></div>
                    </div>

                    <!-- Top 5 nazioni — istogramma -->
                    <div class="if2-analytics-chart-row">
                        <div class="if2-analytics-chart-title">Top 5 nazioni</div>
                        <div style="height:240px;position:relative"><canvas id="if2-geo-countries-chart"></canvas></div>
                    </div>

                    <!-- Top 5 città — istogramma -->
                    <div class="if2-analytics-chart-row">
                        <div class="if2-analytics-chart-title">Top 5 città</div>
                        <div style="height:240px;position:relative"><canvas id="if2-geo-cities-chart"></canvas></div>
                    </div>
                </div>

            </div><!-- /hotel-stats -->

            <!-- Per-campo stats — IN BASSO -->
            <div id="if2-stats-content" style="display:none"></div>

        </div><!-- /right -->
    </div>
</div>
