<?php
defined('ABSPATH') || exit;

class IF2_CRM_HotelDoor {

    const ENDPOINT = 'https://hub.hoteldoor.it/api/v1/request/add';

    public static function send(array $creds, array $fields, array $meta): array {
        $token    = trim($creds['token'] ?? '');
        $hotel_id = (int)($creds['hotel_id'] ?? 0);

        if (!$token || !$hotel_id) {
            return ['status' => 'error', 'code' => 0, 'message' => 'token o hotel_id mancanti'];
        }

        // Date DD/MM/YYYY → YYYY-MM-DD
        $checkin  = self::convert_date($fields['checkin']  ?? '');
        $checkout = self::convert_date($fields['checkout'] ?? '');

        // Nome → first + last
        $full  = trim($fields['fullname'] ?? '');
        $space = strpos($full, ' ');
        $first = $space !== false ? substr($full, 0, $space) : '';
        $last  = $space !== false ? substr($full, $space + 1) : $full;

        // Bambini
        $children = [];
        foreach (['child_age_1', 'child_age_2', 'child_age_3', 'child_age_4'] as $slot) {
            $age = $fields[$slot] ?? '';
            if ($age === '' || $age === null) continue;
            $children[] = $age === '-1' ? 0 : (int)$age;
        }

        $newsletter = filter_var($fields['newsletter'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $lang       = substr(get_locale(), 0, 2);

        // RequestReferer costruito ESATTAMENTE come il vecchio hd-insert.php (che HotelDoor accetta):
        //   https://<dominio>/<campagna>?utm_source=...&utm_medium=...&utm_campaign=<campagna>
        // NIENTE source_url lunga della landing (gclid & co.): quella mandava HotelDoor in HTTP 500.
        $channel = $meta['channel'] ?? '';
        [$src, $medium] = self::channel_utm($channel);
        $host    = wp_parse_url(get_site_url(), PHP_URL_HOST) ?: (string) ($_SERVER['SERVER_NAME'] ?? '');
        $form_name = trim($meta['form_name'] ?? '');
        $campaign  = $form_name !== '' ? sanitize_title($form_name) : sanitize_title($channel);
        $referer   = 'https://' . $host;
        if ($src && $campaign !== '') {
            $referer .= '/' . rawurlencode($campaign)
                      . '?utm_source='   . rawurlencode($src)
                      . '&utm_medium='   . rawurlencode($medium)
                      . '&utm_campaign=' . rawurlencode($campaign);
        }

        $occupancy = ['AdultsCount' => max(1, (int)($fields['adults'] ?? 1))];
        if (!empty($children)) {
            $occupancy['ChildrenAgeArray'] = $children;
        }

        // Trattamento: lo mandiamo come BoardBasis E lo aggiungiamo alle note (GuestNotes), così è VISIBILE
        // di sicuro in HotelDoor anche se il campo BoardBasis non venisse mostrato.
        $tratt = trim((string) ($fields['treatment'] ?? ''));
        $notes = trim((string) ($fields['notes'] ?? ''));
        $guest_notes = $notes;
        if ($tratt !== '') {
            $guest_notes = ($notes !== '' ? $notes . ' — ' : '') . 'Trattamento: ' . $tratt;
        }

        $payload = [
            'StayRequest' => [
                'Key'              => null,
                'ReceivedDateTime' => current_time('Y-m-d\TH:i'), // come hd-insert.php: al minuto, SENZA secondi (HotelDoor lo vuole così)
                'CheckIn'          => $checkin,
                'CheckOut'         => $checkout,
                'HotelsId'         => [$hotel_id],
                'GuestNotes'       => $guest_notes,
                'RequestReferer'   => $referer,
                'RoomsDetails'     => [[
                    'BoardBasis' => $tratt,
                    'Occupancy'  => $occupancy,
                ]],
            ],
            'Contact' => [
                'Key'                    => null,
                'Email'                  => $fields['email'] ?? '',
                'Language'               => $lang,
                'FirstName'              => $first,
                'LastName'               => $last,
                'MobilePhone'            => $fields['phone'] ?? '',
                'NewsletterSubscription' => $newsletter,
            ],
        ];

        $resp = wp_remote_post(self::ENDPOINT, [
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $token,
            ],
            'body'    => wp_json_encode($payload),
            'timeout' => 8,
            'blocking'=> true,
        ]);

        if (is_wp_error($resp)) {
            return ['status' => 'error', 'code' => 0, 'message' => $resp->get_error_message()];
        }

        $code = wp_remote_retrieve_response_code($resp);
        // HotelDoor SALVA la richiesta ma a volte risponde 500: come il vecchio hd-insert.php (che ignorava i 5xx),
        // trattiamo i 5xx come "entrata OK". Errore reale solo su 4xx. Così i pallini riflettono il dato realmente entrato.
        $ok    = ($code >= 200 && $code < 400) || $code >= 500;
        $tratt = trim((string) ($fields['treatment'] ?? ''));
        // Diagnostico: mostriamo nel dettaglio cosa è stato spedito come trattamento (BoardBasis),
        // così si capisce se parte vuoto (problema mapping) o pieno (eventuale rifiuto lato HotelDoor).
        return [
            'status'  => $ok ? 'ok' : 'error',
            'code'    => $code,
            'message' => $ok ? ('Trattamento inviato: ' . ($tratt !== '' ? '«' . $tratt . '»' : 'VUOTO')) : substr(wp_remote_retrieve_body($resp), 0, 200),
        ];
    }

    private static function convert_date(string $date): string {
        if (preg_match('/^(\d{2})\/(\d{2})\/(\d{4})$/', $date, $m)) {
            return $m[3] . '-' . $m[2] . '-' . $m[1];
        }
        return $date; // già ISO o vuoto
    }

    private static function channel_utm(string $ch): array {
        // Mappatura case-insensitive (il canale può arrivare come "GOOGLE ADS", "Fb", "NL", ecc.)
        $map = [
            'fb'           => ['facebook',           'social'],
            'meta'         => ['facebook',           'social'],
            'facebook'     => ['facebook',           'social'],
            'ads'          => ['google-adwords',     'ppc'],
            'google ads'   => ['google-adwords',     'ppc'],
            'google-ads'   => ['google-adwords',     'ppc'],
            'adwords'      => ['google-adwords',     'ppc'],
            'nl'           => ['newsletter',         'email'],
            'newsletter'   => ['newsletter',         'email'],
            'rmk'          => ['google-remarketing', 'ppc'],
            'remarketing'  => ['google-remarketing', 'ppc'],
            'web'          => ['Sito',               'organic'],
            'sito'         => ['Sito',               'organic'],
            'landing'      => ['landing',            'landing'],
        ];
        $key = strtolower(trim($ch));
        // Fallback URL-safe: niente spazi/caratteri strani nell'utm_source (avrebbero rotto l'URL).
        return $map[$key] ?? [($ch !== '' ? sanitize_title($ch) : ''), 'referral'];
    }
}
